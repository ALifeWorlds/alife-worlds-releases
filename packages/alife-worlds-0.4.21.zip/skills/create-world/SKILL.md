---
name: create-world
description: Create or connect an ALife World in a local Codex project. In regular ChatGPT, explain the Codex requirement and guide an authorized transfer instead of reporting a broken connection. Also handle world and rule maintenance without provisioning merely from entry selection.
---

# ALife Worlds: create-world

This is the plugin's single advertised entry. Before submission, the user selects alife-worlds:create-world. The host owns its composer and submitted-message chips; do not claim to rewrite an earlier chip or simulate a conditional host label.

Read the packet AGENTS.md, current project instructions and owning [command guide](../../docs/COMMANDS.md). For source authoring or resume, follow [Git and documentation freshness](../../docs/OPERATIONS.md#git-and-documentation-freshness) through the current Git owner. Preserve actual project/chat identity, existing worlds and agents, approved settings, current effects and full custody.

## Start in the right place

World setup runs in a **local Codex project chat**, with that project's actual folder and supported native tools. A regular ChatGPT conversation can help plan the world or prepare a transfer; it is not itself a failed Codex connection. Before any local setup command or native creation, follow [ChatGPT to Codex](references/chatgpt-to-codex.md). Never infer a local folder from a ChatGPT project name, invent a native thread ID, or run setup in the plugin cache or a cloud scratch folder.

## Keep files with their project

Apply `bootstrap.project-files` to all project-owned files, including helpers, evidence, uploaded artwork copies, plans, logs and exports. Resolve the actual project folder before writing. Use its canonical source folders or private `.alife-worlds` subfolders; do not default to a shared Agent Dump/Agents bucket. Read the [storage and migration contract](../../../docs/INTEGRATION.md#project-local-files). An existing root/binding mismatch stops migration, not a reason to choose another project.

## Imports stay in this project

Follow `bootstrap.import-version` and `bootstrap.import-version-merge` for incoming role versions: preserve the explicitly supplied creation title/version; merge incoming updates with local work at a version newer than both, retaining immutable sources and resolving conflicts. Use the [versioned import workflow](../../../docs/INTEGRATION.md#versioned-agent-imports-and-combined-updates). A merge candidate is not a native update; never clone an existing agent merely to apply an update.

Follow `bootstrap.import-current-project`: every /import applies only to this chat's verified local project and folder. Role instructions and rule overrides are project-owned content, never shared plugin additions. Source files can be read from an explicitly selected external location; the destination remains the invoking project. Use that other project's own chat to import there. Do not use Dump/Agents as a destination for new work.

## Route the submitted request

- To create/build/test/connect a world from a submitted goal or reference images, read and complete [the building-world workflow](references/building-world.md). Use its actual native context and approved private baseline, reuse verified cores first, and continue through the real setup chain.
- For /world, /plugin, /rule, /universal, /import, /delete, list/export, existing-world opening, installation/readiness inspection or plugin source maintenance, use [the world guide](references/world-guide.md). Those requests do not provision cores merely because this entry was selected. Portable import and folder cleanup follow the fixed project-content host phases. Execute only its exact returned supported native tool request, once; record and reconcile the original result through independently reread host evidence. Agent Support owns new-agent intake. Cleanup additionally requires each existing owner’s own held custody and real native idle readback, outside recovery and actual plan-specific human confirmation.
- A policy change describing setup, reset or delete performs no setup or cleanup.

## Custom-world creation and changes

Follow `custom-worlds.create-and-modify` in the Plugin Rules. A submitted custom design can start directly from the user's idea or references. Default ant-world presentation is optional; preserve the user's selected design and keep the bundled default as a separate backup. Build or adapt a compatible scene when needed and explain actual adapter limits. Do not treat default art, ant anatomy or default game gestures as mandatory for custom worlds. Real identities, permissions, privacy, recovery and native capability checks still apply. Ordinary design changes do not require a second policy vote; genuine rule changes use the existing exact-proposal review.

## Report the actual running phase

After begin successfully returns an actual in-progress setup for this exact submitted project, report alife-worlds:building-world (Building world) as the current progress status and continue the supported workflow. Do not show that running status merely for selecting the plugin, before an actual submitted setup begins, or for a maintenance/read-only request.

An already connected world is reused and opened; do not pretend it is being created again. A refusal, blocked dependency or unknown native effect is reported truthfully. Source files, queued tool calls and artwork do not prove native creation or visible readiness. Keep the original host-owned invocation chip separate from the actual progress report.
