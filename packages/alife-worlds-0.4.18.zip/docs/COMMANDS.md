# ALife World and project commands

These are ALife World chat conventions, not new Codex built-ins or native-message endpoints. Rule-source authoring uses the verified writable checkout. Portable project operations use the actual selected project and a qualified packet; built/installed packets remain read-only authoring inputs.

| Command | Scope | Owning source and manual |
| --- | --- | --- |
| /plugin <info> | Plugin operation, policy and workflow | rules/plugin.json; [Plugin Rules](PLUGIN_RULES.md) |
| /world <info> | World appearance and represented behavior | rules/world.json; [World Rules](WORLD_RULES.md) |
| /rule <info> | Only the agent whose chat receives the command | rules/agents.json; [Rules by Agent](AGENT_RULES.md) |
| /universal <info> | Additions inherited by incoming agents and successors | rules/universal.json; [Universal Agent Rules](UNIVERSAL_AGENT_RULES.md) |
| /import <content> | Parse, review and apply selected portable definitions through the destination owner | [Portable project content](#portable-project-content-commands) |
| /delete | Plan exact-folder cleanup; removal requires recovery and actual plan-specific confirmation | [Portable project content](#portable-project-content-commands) |

The four rule-authoring commands support list and export. A bare /rule never means plugin-wide policy: the former meaning is superseded; use /plugin. Historical request records retain their original text without becoming active instructions.

## Agent Support and creation

Creation authority is owned by universal onboarding.support-owned-creation, including the selected one-time Director first-Support bootstrap. After Agent Support's actual acknowledgement, normal staffing belongs to Agent Support. The rule-authoring CLI assembles contracts; the create-world entry and its building-world reference coordinate supported native creation with exact-project and own-receipt checks.

Agent Support reads the complete shared/retirement contract, active universal additions, the role packet and that role's active additions, then includes latest human/task/permission/effect custody. The actual new role must prove exact project/home access, complete reading and custody. No agent or native identity is created by a rule, documentation edit or contract export.

## User-invoked new-project setup

The plugin exposes one skill, alife-worlds:create-world. Its facade sends actual submitted setup to skills/create-world/references/building-world.md and rule/world/open/installation maintenance to skills/create-world/references/world-guide.md. The pre-submission entry is create-world; Building world / alife-worlds:building-world is reported only once actual setup has begun. The original composer/submitted-message chip belongs to the host; this package makes no unsupported dynamic chip-rewrite claim. A rule-only edit, read-only open or install inspection never provisions cores. An onboarding pointer alone does not redirect an explicitly invoked competing skill, so the former general SKILL.md is retained as reference guidance instead of a second advertised entry.

An ordinary world-setup invocation authorizes core chats/homes and private runtime in its actual project. That specific destination takes priority over generic Agent Dump orchestration routing for those records; unrelated helper routing is preserved. Do not repeat folder, routing-exception, baseline or setup-permission questions when the supported context and approved policy already supply them. Mandatory host permissions, unavailable capabilities and identity conflicts remain truthful limits.

1. Read actual cwd/CODEX_THREAD_ID, the invoking native thread and current list_projects metadata. begin independently verifies the session and selects the unique exact local saved-path mapping. A null thread projectId is supported when that mapping is exact; foreign, cloud-only or ambiguous mappings never fall back to the source/cache.
2. Reuse verified core/world state first. A fresh invocation becomes Director; existing chats/settings/receipts and worlds remain intact. Existing legacy bindings are preserved for their verified connection workflow, never silently duplicated.
3. begin loads the approved private creation baseline automatically when explicit approved settings are absent. The private operator policy is outside source/cache and Git. Existing episodes retain their approved settings; any explicit changed override still requires actual human approval. No missing-policy error silently falls back to another/higher model.
4. Read Director's FULL generated AGENT.md, RETIREMENT.md and checkpoint.json, then acknowledge from its own actual session. For a fresh episode, complete the exact invoking chat's reserve-director-title / supported set_thread_title / record-director-title readback sequence described below; this updates the existing setup chat title to Director. Incoming contracts include the current project instruction hierarchy and complete master/shared/retirement/universal/role/own additions.
5. Director reserves missing Agent Support once, uses the exact supported native create_thread arguments and records its actual result. Agent Support must prove its own distinct binding/full reading/access/custody before it creates missing World Requests through the same protocol.
6. A child that acknowledges before creator binding uses finite await-binding. The creator waits for actual progression; if a known child is idle after binding, reserve-continuation records the original send before the ONE supported same-chat follow-up. Record its actual result. Unknown creates/sends are reconciled, never replayed.
7. Once all three real bindings/own receipts exist, World Requests starts/reuses the actual verified private loopback world, registers only that world while preserving other profile entries, and uses the supported opener for its verified operatorUrl (the full local dashboard). The separate viewerUrl remains a sanitized spectator link. Windows background launches remain hidden.
8. Continue through the actual core/world chain or report the exact original unresolved operation/mandatory capability. Files, contracts, queued calls, source tests and a host-open return are separate from native completion and visible rendering. The included default world needs no optional visual description.

Only Director, Agent Support and World Requests are supplied as core contracts. There is no automatic specialist roster or replay of the maintainer team. Additional/linked visual membership and hosted generalization are separate feature scopes; they do not block a minimal local three-core test. Actual native world-button messaging remains separate from startup-only supported host calls.

### Private bootstrap helper

Run scripts/bootstrap-world.mjs from the current qualified packet or its vendored runtime. Except start-world/help, commands read one bounded JSON object on stdin. The actual invoking cwd is the default projectRoot; begin accepts native metadata instead of a manually chosen destination. Native create/send actions remain supported host-tool calls, never a hidden local RPC.

| Command | Input and effect |
| --- | --- |
| begin | nativeThread (including its actual current title), nativeProjects, optional goal, existingAgents and actual approved settings override. Resolves actual cwd/session/saved project, loads approved private policy and creates/reuses the episode. |
| prepare | Advanced exact projectRoot/projectId/projectName/goal/explicitSetup:true and optional approved settings and actual nativeThread metadata for the fresh title intent. Missing settings load the private policy; an existing episode reuses its established approved settings. |
| status | Optional projectRoot. Reads bindings, own receipts, requested/applied metadata and pending effects without freshening work activity. |
| acknowledge | roleId, fullRead:true, contractSha256 and original operationId for a newly created role. Only after that actual role reads its full contracts and verifies own access. |
| reserve-director-title | nativeThread: actual current supported metadata. Only the exact onboarded fresh invoking Director may reserve one rename. Returns canRename, original operationId, expected-target/title preflight and supported set_thread_title arguments; no native call occurs. Older episodes, already matching names, changed titles and missing initial metadata are preserved. |
| record-director-title | operationId, status ("verified", "observed", "failed", "unavailable" or "unknown"), optional nativeResult:{threadId,title:"Director"}, nativeThread. Verified needs both the original actual native returned target/title and the separate exact readback title Director. Observed-only reconciliation needs actual readback and no fabricated tool return; failure/unknown states contain status only. Original reservations never replay. |
| await-binding | roleId, original operationId and optional timeoutMs (at most 15 seconds). Finite own-receipt handshake; timeout retains the pending original launch. |
| reserve | roleId. Reconciles current full instructions only in an uncreated/unreserved draft, retains preimages, and reserves native creation once. |
| record-created | roleId, operationId, nativeResult:{threadId?,clientThreadId?,hostId:"local",projectId,cwd}. Stores the actual return; a queued client ID is not a ready thread. |
| reserve-continuation | roleId. Only the verified creator reserves one follow-up to its known existing child. Already pending/sent or progressed work is never replayed. |
| record-continuation | roleId, operationId, nativeResult:{threadId,hostId?}. Records only the original same-core send result. |
| start-world | Uses actual cwd, or explicit --project-root. World Requests starts/reuses this exact read-only local service only after the core receipts. |
| register-launcher | explicitRegister:true. Part of authorized world setup; verifies actual service identity, preserves other private world entries, and returns separate operatorUrl (full local dashboard) and viewerUrl (sanitized spectator). |
| include-project | source:{projectRoot,projectId,projectName,explicitInclude:true,members:[...]}. Separate explicitly selected protected read-only inventory; no native modification or display acceptance follows. |
| reset-plan | projectId, explicitReset:true. Proposal of verified plugin-created core targets only, with zero archive/delete/file-removal effects. |

existingAgents/linked members use {threadId,title,projectId,projectRoot,sessionPath?}. Verify exact metadata and inventory completeness; names alone are not core bindings. Extra membership is private/namespaced and gives no core authority, task progress, messaging or public disclosure permission.

The approved private policy contract is owned by [Operations](OPERATIONS.md). The default file is <actual CODEX_HOME>/alife-worlds/core-creation-profile.json; ALIFE_CORE_CREATION_PROFILE may select a normal absolute external file. It is at most 8 KiB, a regular non-redirected file, with exactly schemaVersion:1, approvedByHuman:true, model and thinking. Runtime source contains no personal model default. Root/operator alone writes real approved policy; tests use isolated fixtures. Malformed/missing policy reports its configuration dependency without inventing approval or another model.

Reset/delete policy edits execute no reset. Actual retirement follows supported custody/succession procedures, excludes reused/pre-existing/linked chats and stops on pending/unknown effects. Never pass the combined display roster to a delete operation or reuse the first-Agent-Support exception for recovery.

## Private world release records

The owning policy is [Operations](OPERATIONS.md#world-releases-and-site-updates); the portable record is [World releases](WORLD_RELEASES.md). Run node <qualified-packet>/scripts/world-release.mjs from the actual selected project cwd/chat. The CLI uses CODEX_THREAD_ID and its verified native session, then requires exact current bootstrap bindings or the current project's existing data/agent-bindings.json plus the actor's own full access/reading/custody receipt. It never takes a payload project-root override. Director or World Requests owns writes; Agent Support may perform the separately authorized world-title bookkeeping. Other bound roles may read the private report.

The shipped world/world-release.json is only the neutral 1.0.0 definition. Initialize the private records once after core onboarding using init with {requestId,explicitInitialize:true}. Existing records and custom design remain intact. Keep stable request IDs; changed input under the same ID is refused. These commands perform no native call, service restart, hosting action or destructive restoration.

| Command | One bounded JSON object on stdin |
| --- | --- |
| profile | requestId, expectedRevision, artDirection (string or null), assets:[{id,path,license?,provenance?}], preferences:{}, surfaces:[{id,kind:"local" or "private" or "public",url,optedOut:boolean}], automaticUpdates:boolean or null, mode? ("preserve", "customize", "replace"). Default preserve fills missing settings without changing saved choices. Explicit customize changes supplied settings while preserving other fields/assets/surfaces; explicit replace replaces these collections. Retains the complete prior profile privately for recovery. |
| legacy | requestId, surfaceId, label, hostingVersionId (string or null), evidence:[{path,sha256?}], recovery:[{path,sha256?}], note?. Actual historical surfaces remain unversioned. Evidence and recovery references must be existing reduced JSON/Markdown/text/ZIP files; never transcripts, sessions, credentials or raw tool history. |
| prepare | requestId, version, artifactRoot, files:[project-relative selected world paths], summary, sourceReference, checks:{}, profileUpdate?:{mode?,artDirection?,assets?,preferences?}. Stages the desired design and hash-verifies selected world/design assets without changing the active profile. Use customize only for requested design changes. A renderable scene includes every WORLD_SCENE_FILES entry; safe additional media use web/custom-world/. New versions advance; exact retries preserve identity. A prepared artifact is not active or deployed. |
| activate | requestId, expectedRevision, version. Selects an already prepared complete scene for this exact world. Verifies the artifact and its original profile revision before atomically selecting it with its design and immutable asset paths. Keeps the full prior profile, surfaces, access and update preferences. Changed, incomplete, stale or foreign candidates fail without replacing the current selection. Retrying the same request does not advance the revision twice. This command performs no Site deployment or native action. |
| reconcile-snapshot | operationId. Verifies the retained original snapshot; incomplete/changed files stop reconciliation without replaying native or hosting effects. |
| reserve-surface | requestId, surfaceId, version. Requires an actual prepared snapshot and an existing mapped surface without an opt-out. Returns one durable operation reservation; no publication occurs. Current saved preferences, target permissions and latest holds still govern the actual owner's action. |
| record-surface | operationId, status ("deployed", "verified", "failed" or "unknown"), hostingVersionId (string or null), evidence:[{path,sha256?}], verificationKind?. Record the actual supported result. Verified requires an already recorded deployment, matching hosting revision, actual evidence and verificationKind:"surface-acceptance". Other surfaces stay independent. |
| rollback-plan | version, targetRoot. Returns a concrete retained artifact/diff/recovery plan. Restores zero files or sites; the actual owner separately preserves current work and executes any authorized recovery. |
| reserve-title | requestId, version, nativeThread (actual supported metadata). Reserves only the exact bound world-requests target and returns supported set_thread_title arguments; it never calls the tool. |
| record-title | operationId, nativeResult:{threadId}, readback:{id,kind:"codex",hostId:"local",cwd,projectId?,title}. Requires the original owner and exact supported result/readback. A requested or file-only label is not native verification. |

report --format json or report --format markdown reads the actual private history without stdin or work-timestamp writes. The readable report includes actual release date, summary, source, checks/limits, immutable recovery, independent surface versions, unversioned hosting history and pending/unknown operations. Preserve a private report with the actual ledger for handoff. Never package its private paths, surface URLs, identities or evidence.

New setup requests World 1.0 for the world-requests native display using the neutral definition; its logical ID and packet remain World Requests. Existing episodes keep their previous requested names, identities, homes and settings. Bootstrap status keeps requestedDisplayTitle separate from observedDisplayTitle and never infers an observed title from a file/requested name; actual supported readback is recorded separately in the title journal. World 1.0.1 and World 1.1 follow numeric world versions independently of the plugin version.

### First setup chat title

Fresh begin captures the supported invoking thread's current title and exact native identity in private state. After the Director's own acknowledgement, reserve the title action, reread and compare the returned preflight target/title immediately, then execute only its supported set_thread_title request once. If the title changed before the action, preserve that choice and record failed without a native result. Use actual supported readback to record verified; unknown effects are reconciled under their original operation rather than resent. This changes no agent binding, folder, model, speed, reasoning, task or world data.

The title workflow is fresh-episode only. Reopening an established world or an older episode does not introduce a rename intent or overwrite a custom title. Missing initial metadata or a missing/refused native capability remains an explicit title limitation while independent core setup can progress. The original invocation chip is unrelated. Bootstrap status exposes requested display, last observed display/time and titleState independently; file text is not a native rename receipt.

### Startup validation boundary

Version 0.1.5 source/install/discovery acceptance remains historical. The automatic-context, private-policy, single-entry and continuation correction passes 68 affected source cases: 22 bootstrap, nine launcher/profile, five core-package, nine version/publication and 23 rule/inheritance/contract checks. The skill validator and generated-rule check also pass. Actual invoking-project native acceptance remains separate. Its fixtures are synthetic session/receipt data; no fixture result is a real chat creation or visible-world PASS.

Use a disposable qualified source copy for focused checks:

```powershell
node --test tests/world-bootstrap.test.mjs tests/world-launcher.test.mjs tests/core-package.test.mjs tests/plugin-version.test.mjs
```

The release owner separately qualifies/freezes the new version, publishes Git and performs supported private refresh. Then verify the actual advertised entry and target-bound core/world effects. Do not reopen completed older criteria or invent another user target question when actual native history/context already identifies it.

The local operator/spectator destination correction and its current source validation are owned by [Full local dashboard destination](CODEX.md#full-local-dashboard-destination).

## Invoking-role context and inheritance

In Director's chat, /rule adds a Director rule; in another role's chat it adds that role's rule. Verify the current chat's actual logical role from its existing binding before supplying --agent. The CLI flag is operator context, not an authenticated native identity or a discovery mechanism. No role is guessed from the source folder, a name or a missing argument. A payload cannot redirect the change to another role.

Universal additions accompany the current complete shared contract, including retirement, for future agents/successors. /universal does not rewrite or notify the existing team automatically. An authorized /rule recipient carries its own new rule into its own persistent instructions/checkpoint; no other home is changed by this source tool. Current human/project authority and universal obligations take priority; an agent addition cannot duplicate/override an active universal property.

## Property merge and documentation upkeep

Group related properties by subject and preserve stable IDs, required rules and independent compatible facets. The owning rule-authoring.human-and-ai-format requires a short human title, a plain-language description and separate detailed AI instructions in text. The instructions state the trigger, required behavior, authority/scope, constraints, exceptions, failure handling and evidence. Preserve exact human intent; descriptive text is not a second instruction authority. Legacy catalogues remain readable; newly proposed plugin/world properties always supply description. Current format-v2 catalogues enforce it.

For every future /plugin or /world change, rule-authoring.review-before-apply requires a concrete proposal before saving: improve the AI wording, show the exact human and AI fields, explain weaknesses/vulnerabilities, mitigations, compatible overlaps, conflicts and unanswered questions, then obtain accept, reject or revise. Silence, the initial idea and agent-authored approval flags are not acceptance. Reuse a direct explicit decision that already covers the exact change, including the 9 November bulk upgrade. A changed proposal or stale base revision needs renewed review; rejection changes no active rule. The existing exact Keep/Modify/Remove safeguard continues to apply to removals and consolidation. No lexical similarity check grants deletion authority.

After every command that adds/changes rules:

1. Read the applicable current registries, role context and owning manuals.
2. For plugin/world changes, prepare and present the proposal, wait for the actual human decision, record that decision against its digest, then apply that exact revision-bound proposal. Preserve one original request ID, concurrent work and unknown results. For /rule and /universal, preserve the existing verified-role and inheritance workflow.
3. Regenerate all views, prompts and per-role documentation from the same title/description/text fields. Remove, replace or consolidate only under an exact applicable human decision, preserving unaffected facets and necessary non-authoritative history.
4. Implement/check the selected effect where needed. Documented means saved; implemented needs observed behavior/checks. A rule never accepts a task.
5. Check rule documents, affected tests and a qualification packet. Commit/push completed authorized source after safe Git sync. Hosted publication and installed refresh require their current explicit authorization; neither follows from a rule or Git push.

The tool detects exact active duplicates within a registry, universal/agent key or text collisions, stale revisions and invalid targets. It cannot decide every semantic conflict in prose; the agent must review meaning and ask only for a genuinely missing decision. Deprecated references remain read-only unless the human selected the exact import.

## Source tools

- List: node scripts/rules.mjs list plugin (world/universal/all also supported).
- Invoking role: node scripts/rules.mjs list agent --agent director.
- Export: node scripts/rules.mjs export plugin, world, universal, or agent --agent director.
- Complete creation bundle: node scripts/rules.mjs contract director.
- Regenerate/check: npm run rules:generate; npm run rules:check.
- Propose: node scripts/rules.mjs propose, with change and analysis on stdin. Analysis includes intent, weaknesses, safeguards, conflicts and openQuestions. The result shows exact before/after labels, descriptions, instructions and active state, including enable/disable changes. It binds both base revision and complete catalogue digest. This saves a private draft, not an active rule; oversized complete proposals must be split before review.
- Decide: node scripts/rules.mjs decide, with proposalId, proposalSha256, decision (accept/reject) and the actual human sourceReference. The host/agent must verify the genuine conversation decision; this CLI record is an operator assertion, not an authentication provider.
- Apply accepted plugin/world proposal: node scripts/rules.mjs apply, with proposalId and proposalSha256. Unaccepted, changed and stale proposals are refused. New/changed definitions start documented.
- Reconcile an uncertain original save: node scripts/rules.mjs reconcile with that same proposal ID/digest. It checks original receipts and never replays an unknown save.
- Archive selected inactive history: node scripts/rules.mjs archive-history with {scope,expectedRevision,propertyIds:["group.property"],requestId}, only under actual human authorization covering that exact selection and retained recovery. It first preserves the complete original/candidate and hashes under ignored runtime/RuleHistory, then retains the newest twelve entries only for those selected properties. Active instructions and unrelated properties stay intact. It is never invoked automatically by a rule edit or poll. Completed retries retain the original receipt; unknown preimages/conflicts are not replayed. The same operation reconciles only an exact saved candidate. Private storage is bounded at 1,000 explicit archive operations; capacity exhaustion requires an authorized retention action, never silent cleanup. No live history was archived during this upgrade.
- Existing /rule and /universal: node scripts/rules.mjs apply with the structured scoped change; /rule also needs --agent director or the actual verified invoking role.
- Qualify without replacing the registered frozen packet: npm run build:plugin -- --candidate.

The proposal change contains command, requestId, expectedRevision, groupId, groupTitle and properties with id/title/description/text, optional active and operation (set/enable/disable). Only a hash of the original command is retained in the private proposal journal; supplied rewritten rules and analysis must be display-safe. Accepted content, decisions and original application receipts stay under ignored runtime/RuleAuthoring, outside packets and public APIs. This workflow does not call a model: the current agent supplies the improved wording and bounded semantic review. List/export stay read-only. /rule additionally needs verified invoking context via --agent; an optional payload agentRoleId must match it.

Portable packets with descriptions emit schemaVersion 2; readers accept legacy version 1 and preserve its existing AI instructions. Legacy human descriptions fall back to titles when upgrading a portable packet. The new catalogue ruleFormatVersion is 2; canonical text remains the AI instruction field. Older clients must reject unsupported portable versions rather than silently discarding descriptions. Node and browser serializers retain the same closed fields. History/request metadata is checked for private material too. Property recovery no longer silently truncates at twelve entries; the bounded history limit requires an explicit private archival workflow before further edits. Request-cache retention remains distinct from durable proposal/application receipts.

## Portable project content commands

Run node <integrated-packet>/scripts/project-content.mjs <command> with one bounded JSON object on stdin. The fixed default is createProjectContentHost(supportedLocalAdapters()), using concrete package-owned implementations. There are no payload root/config/module/URL/code-loader flags or hidden Node app-server RPC. Parse is data-only; effectful phases verify the actual selected cwd, CODEX_THREAD_ID, current bindings and the actor’s own full access/reading/custody receipt. Source authoring does not establish feature qualification or authority to act on the current project.

| Command | JSON input and phase |
| --- | --- |
| parse | content, optional kind/title/agentId. Returns parsed-not-applied for a closed packet or scoped plain prompt. |
| preview | content, optional kind/title/agentId/review. Returns the actual destination’s revision-bound plan and unresolved semantic choices. |
| prepare-review | plan. Read-only actual invoking human-message references, plan.review, supported read_thread request and record template. |
| record-review | plan, source:{lineIndex,sha256,textSha256?}, semanticNotes. Independently rereads the exact direct human /import, matching packet, actor and review digest. No approval boolean. |
| apply | plan. Independently verifies the actual direct submitted /import and resolved plan, then performs the original one-shot revision-bound rule write/readback. No routine extra question for an unambiguous authorized import. |
| status | {}. Reads original import/intake state without freshening activity or accepting tasks. |
| reconcile-import | operationId. Reads the original writer journal/outcome without resending. |
| prepare-intake | importOperationId, roleId. Acknowledged Agent Support reads the actual full inherited and imported-role instructions, own checkpoint and approved private settings; returns sourceSha256. |
| record-intake | importOperationId, roleId, sourceSha256, custody:{goal,acceptance,tasks,permissions,pauses,helpers,schedules,effects:{active,settled,unknown}}. Independently rechecks original human authority, complete custody/current inputs and approved baseline. Active/unknown effects block. |
| reserve-agent | importOperationId, roleId. Persists the original reservation and hostRequest before action. Returns one exact functions.exec bridge; nativeToolRequest is its inner create intent, not a second action. |
| native-status | operationId. Independently reads the original supported native call/completed output or reports its precise pending/unsupported state. Never permits replay. |
| record-agent | operationId, optional evidence:{kind:"native-tool-result",sourceThreadId,callId,expectedRecordDigest}. Independently rereads actual original supported call/output and new local session. Pasted nativeResult is not accepted. |
| await-agent-binding | operationId, optional timeoutMs up to15000. Incoming role waits finitely for its original creator binding; timeout does not create a replacement. |
| acknowledge-agent | operationId, contractSha256, fullRead. Real incoming role acknowledges its own complete reading/access/custody and invokes the actual canonical binding writer. |
| prepare-cleanup-hold | evidenceRoot. Actual bound Director/Support with direct /delete creates the outside original hold/nonce and returns exact existing-owner message requests requiring actual native messaging authority. Sends no messages or chat pauses itself. |
| prepare-own-cleanup-hold | holdDirectory. Original participant obtains its own complete custody hash and current helper/schedule/effect inventory. |
| acknowledge-cleanup-hold | holdDirectory, custodySha256, fullRead:true. Participant settles its own inventory and records its full checkpoint/outside acknowledgment, then ends idle without project writes or self-resume while held. Missing/unverified inventory or active/unknown effects block. |
| prepare-cleanup-readback | holdDirectory. Original cleanup actor, after all own acknowledgments, persists the outside readback nonce and exact supported read_thread bridge for every bound participant. |
| record-cleanup-readback | holdDirectory, requestId. Independently rereads original bridge/result/nonce; requires exact local native identity/cwd, idle thread and completed turn after own acknowledgment, unchanged checkpoint and native-journal frame. |
| stop-project-service | evidenceRoot. Direct /delete only; one guarded Windows Stop-Process of the exact registered selected-project PID/creation/command identity, journaled outside before the effect. Unknown/global processes are refused. |
| reconcile-service-stop | journal. Reads that original PID/creation identity without another stop. |
| delete-plan | {}. Final inventory of selected-folder contents and actual Windows metadata/capability blockers, bound to the native cleanup hold. Retains the root. |
| delete-recovery | plan, evidenceRoot. Uses the exclusive writer/owner/service fence and real Windows checks; prepares outside recovery and independently verifies contents and supported ACL/audit/streams/attributes/times. |
| record-delete-confirmation | operationDirectory, optional source:{lineIndex,sha256,textSha256?}. Independently verifies the actual new direct human answer to the original exact Confirm/Keep contents question, bound to root/plan/recovery/nonce. Negative answers record no removal. |
| delete-execute | operationDirectory. Rechecks original real confirmation, exact contents/root/recovery and complete fence. Retains the root. Partial/unknown results stop and remain in the outside journal. |
| delete-reconcile | operationDirectory. Reads original outside journal and remaining contents without deletion replay, including after internal bindings are removed. |
| release-cleanup-hold | holdDirectory, operationDirectory. Original cleanup actor releases the same hold only after a known declined or local-cleared original outcome; returns scoped owner release messages requiring actual messaging authority. Never releases an unknown/timeout result. |

Portable packets have format alife-portable, schemaVersion 2 when human descriptions are present (legacy version 1 remains readable), and kind world/plugin/agent/bundle, bounded prompts and grouped stable properties. A plain prompt needs an explicit verified scope unless its supported share header supplies one. Runtime role ID and authored packet ID may differ: existingRoleId names an actual selected runtime role with the exact original definition hash. Copy/Clone preserves the original validated packet’s ID/content/hash. Review meaning as well as structural conflicts; imported data cannot grant permission, override universal/project authority or import native identity. The owner dashboard keeps its separate Rules section at the bottom of Sprints; whole-scope, group and property Copy import/Clone definition retain short human titles/descriptions and separate complete AI instructions, with no live agents, settings, tasks or private history. Copy/Clone and effective profile/roster consumption are owned by [Integration](INTEGRATION.md#portable-private-owner-site-and-rules-library--042).

The effective resolver combines the qualified base with selected-project overrides. Its revision covers both; changed base or overlay requires renewed review. A reconciliation-needed result has no effective rules and must not silently export the base. Built/installed/vendored source catalogues remain immutable. Rule saved, definition saved, effect implementation, Support intake, actual native binding and the role’s own receipt are separate outcomes. Preserve unaffected compatible properties, full inherited instructions and complete custody; truncate none.

For host-assisted intake, invoke only the exact fixed bridge returned by the original reservation once. The hostRequest and top-level toolRequest describe the same action. Independently recorded real native evidence, never a pasted result or queue label, establishes what happened. A missing original completion or unsupported native record format blocks that original operation. No helper agent, arbitrary adapter or fabricated readback is a fallback. Current supported evidence comes from the independently derived invoking native session and closed original call/output formats; no arbitrary evidence path is accepted.

For cleanup, acquire original owner holds and actual native readbacks before the final content/recovery snapshot. The cooperative gate excludes known package writers; a Windows no-handles observation alone proves no native quiescence. Every bound owner must settle and acknowledge its own full custody, helpers, schedules and effects and remain idle with unchanged journal frames. The cleanup actor is the scoped lifecycle exception and must still inventory its own work. Stop only the exact registered selected service when required, and reconcile any unknown stop rather than repeating it. All cleanup exchange, recovery and consent records remain outside the selected root.

After verified recovery, execute the helper’s exact request_user_input_async question with short Confirm and Keep contents choices. The recorder verifies the original call/item, exact question/root/plan/recovery/nonce and new direct human send_user_message_question_reply. Preselection, elapsed time, tool/serverRequest completion, assistant text and automatic approval review are not human consent. The exact challenge is an optional fallback; the human need not retype hashes. A later actual stop/pause/cancel or matching negative answer is checked through fenced cleanup. A known decline allows original hold release; an unknown or partial outcome stays held for original reconciliation.

Missing current native/Support/platform/recovery/confirmation/service capability remains a precise blocker. Finite native/checkpoint readers and preflight capacity checks preserve full contracts without truncation. Non-Windows, unavailable ACL/audit privilege, unsupported links/streams/sparse/encrypted/offline entries, changed owner evidence or current unverified helper/schedule inventory can block the actual operation. Preserve any journal or recovery already authored after a late refusal. The CLI performs the narrowly guarded local service stop; native creation/questions/messages use actual supported caller tools. It changes no global settings or hosting. Native chat/global/cloud closeout is separate. None of this source authoring authorizes a live import or removal.

## Privacy and publication

No new browser mutation or agent-rules endpoint is introduced. Existing read-only world/plugin exports stay separate; raw registries, native IDs, private homes, credentials and live plans remain unavailable through the server. Generic role IDs identify rules, not live chats. All exported contracts are checked for private machine/identity material. A portable prompt transfers no native authority.

## Check the setup context before creating a world

In a local Codex project chat, bootstrap-world.mjs preflight accepts the same nativeThread/nativeProjects metadata as begin and writes no files or agents. It reports the exact destination and missing capability before setup. Decode supported tool JSON envelopes or pass the bounded result directly. Regular ChatGPT follows the [guided Codex transfer](../skills/create-world/references/chatgpt-to-codex.md), not a generic connection-repair loop. Fresh writer records are project-contained; retained legacy fences and explicit destructive-cleanup recovery keep their original custody.
