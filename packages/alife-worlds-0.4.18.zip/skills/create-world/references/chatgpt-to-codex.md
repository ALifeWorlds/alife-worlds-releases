# Start here: ChatGPT or Codex?

## Explain where worlds are created

ALife Worlds creates the world in a **local Codex project chat**. Its artwork, agent homes, runtime and setup records belong under that selected project folder. Regular ChatGPT can discuss the design and prepare the request. A missing local executor or Codex project in regular ChatGPT is a surface limitation, not evidence that a world or the user's files are broken.

Check actual capabilities before running setup: a local executor, its real cwd and CODEX_THREAD_ID, supported metadata identifying that same local Codex chat, and a unique saved local project for that folder. Do not guess from the app window name. A Codex cloud or ChatGPT scratch executor is not the user's local project. Do not write world files, call begin, reserve core agents, or create a Site before the destination is established.

If those capabilities are present, continue building-world.md. Decode the supported tool result's single JSON text content when needed: list_projects has a projects array; read_thread has a thread object. Preserve actual values. Read-only failed metadata calls may be retried once. Report the exact remaining missing capability; never repeatedly reopen projects or replay a create/send operation as a retry.

## Offer a transfer when supported

When setup was requested in regular ChatGPT, say: **“Your world is created in Codex, where it can save files in your project. I can help prepare the request here.”** If supported local Codex project/chat tools are available, offer **“Create a Codex chat for this request”** and show the destination folder. This is a new user-owned chat: require the user's explicit request for that chat/transfer and exact destination before creating or sending it. Selecting the plugin or asking about it alone grants neither action.

After that request, call the current supported list_projects and select the user's exact returned local project. If no exact mapping exists, ask them to add that folder in Codex. Never substitute the plugin folder, another similarly named project, a ChatGPT project ID, a projectless directory, a worktree or Codex Cloud. Use the current create_thread schema, with target type project, its actual projectId, and environment type local. Preserve configured settings; omit model/effort overrides unless explicitly authorized. Use the returned ready threadId or reconcile the original queued clientThreadId; do not submit another chat while its outcome is pending or unknown. Link the actual new Codex chat and report queued versus running truthfully.

Transfer only the user's world brief, requested destination, relevant design choices and approved reference paths or accessible attachments. Never copy hidden instructions, private history, another project's state, pairing credentials or unsupported attachment links. Ask the user to upload references in Codex if the destination cannot actually access them. The destination must invoke its installed $alife-worlds:create-world, derive its own native context and reuse any existing world/team. A transfer receipt is not proof that the world exists or is connected.

Do not use handoff_thread for this: that tool moves an existing Codex chat and Git state; it does not convert a ChatGPT conversation into a local Codex chat. Do not message an existing Codex chat unless the user explicitly selected that target and requested forwarding.

## Always provide a manual path

If automatic transfer is unavailable or the user prefers it, give these simple steps and one copyable request, retaining their actual brief:

1. In the desktop app, switch to **Codex**. Choose **Local / This computer** when shown.
2. Open or add the folder for this world. Start a chat inside that project.
3. Type **/alife**, select **ALife Worlds → create-world**, and send the prepared request. Upload references as a folder or separate files there.

Example request: **“Use $alife-worlds:create-world to create or connect this project's private world. Keep all world files in this project. [The user's actual world description.] Preserve any existing world, agents, artwork and settings.”** Replace the bracket with the real brief, not invented preferences. Keep the intended cast selection and explain any inaccessible references. Do not claim automatic transfer or creation occurred when only text was prepared.
