import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {acquireProjectOperation,releaseProjectOperation} from '../lib/project-operations.mjs';
const scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));
async function fixture(fn){
 await fs.mkdir(scratch,{recursive:true});const base=await fs.mkdtemp(path.join(scratch,'operation-storage-')),root=path.join(base,'project');await fs.mkdir(root);
 try{await fn({base,root});}finally{assert.equal(path.dirname(base),path.resolve(scratch));await fs.rm(base,{recursive:true,force:true});}
}
test('fresh setup keeps its writer records inside the invoking project',()=>fixture(async({base,root})=>{
 const lease=await acquireProjectOperation(root,'world-bootstrap');
 try{assert.ok(lease.file.startsWith(path.join(root,'.alife-worlds','operations')+path.sep));assert.deepEqual(await fs.readdir(base),['project']);}
 finally{await releaseProjectOperation(lease);}
 await fs.writeFile(path.join(root,'.alife-worlds','bootstrap.json'),'{}');
 const next=await acquireProjectOperation(root,'rules');assert.equal(next.gate,lease.gate);await releaseProjectOperation(next);
}));
test('an established world retains its original fence without relocating recovery',()=>fixture(async({base,root})=>{
 await fs.mkdir(path.join(root,'.alife-worlds'));await fs.writeFile(path.join(root,'.alife-worlds','bootstrap.json'),'{}');
 const lease=await acquireProjectOperation(root,'world-bootstrap');try{assert.equal(path.dirname(lease.gate),path.join(base,'.alife-project-operations'));}finally{await releaseProjectOperation(lease);}
}));
test('local writers and explicit outside cleanup fences exclude each other',()=>fixture(async({root})=>{
 const local=await acquireProjectOperation(root,'world-bootstrap');try{await assert.rejects(acquireProjectOperation(root,'project-delete',{exclusive:true}),{code:'ALIFE_PROJECT_BUSY'});}finally{await releaseProjectOperation(local);}
 const cleanup=await acquireProjectOperation(root,'project-delete',{exclusive:true});try{await assert.rejects(acquireProjectOperation(root,'world-bootstrap'),{code:'ALIFE_PROJECT_BUSY'});}finally{await releaseProjectOperation(cleanup);}
}));
test('an unresolved legacy fence blocks a new writer and is preserved',()=>fixture(async({base,root})=>{
 const canonical=process.platform==='win32'?path.resolve(root).toLowerCase():path.resolve(root),key=createHash('sha256').update(canonical).digest('hex'),gate=path.join(base,'.alife-project-operations',key+'.lock');await fs.mkdir(gate,{recursive:true});
 await fs.writeFile(path.join(gate,'lease.json'),'original pending outcome');await assert.rejects(acquireProjectOperation(root,'world-bootstrap'),{code:'ALIFE_PROJECT_BUSY'});assert.equal(await fs.readFile(path.join(gate,'lease.json'),'utf8'),'original pending outcome');
}));
