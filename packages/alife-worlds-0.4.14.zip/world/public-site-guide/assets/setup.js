/* One shared world-creation prompt builder for every website entry point. */
(() => {
  'use strict';
  const casts={both:'Dot + agents',dot:'Dot only',agents:'Agents only'};
  const projects={new:'New project',existing:'Existing project'};
  const worlds={default:'Default world',custom:'Describe a world',upload:'Use my references'};
  const buttonGroup=(key,items)=>Object.entries(items).map(([value,label])=>'<button type="button" data-setup-'+key+'="'+value+'" aria-pressed="false">'+label+'</button>').join('');
  const copy=async(field,status)=>{try{await navigator.clipboard.writeText(field.value);status.textContent='Copied. Paste it into your Codex project chat.';}catch{field.focus();field.select();status.textContent='Select and copy the prompt, then paste it into Codex.';}};
  function refresh(box){
    const project=box.dataset.project||'new',world=box.dataset.world||'default',cast=box.dataset.cast||'both';
    for(const [key,value]of Object.entries({project,world,cast}))box.querySelectorAll('[data-setup-'+key+']').forEach(b=>b.setAttribute('aria-pressed',String(b.getAttribute('data-setup-'+key)===value)));
    box.querySelector('[data-world-notes-wrap]').hidden=world==='default';
    box.querySelector('[data-reference-help]').hidden=world!=='upload';
    box.querySelector('[data-agent-options]').hidden=cast==='dot';
    box.querySelector('[data-dot-help]').hidden=cast==='agents';
    box.querySelector('[data-cast-dot]').hidden=cast==='agents';
    box.querySelector('[data-cast-agents]').hidden=cast==='dot';
    box.querySelector('[data-cast-caption]').textContent=casts[cast]+' in your world';
    const notes=box.querySelector('[data-world-description]').value.trim();
    const agentNotes=box.querySelector('[data-agent-prompts]').value.trim();
    const source=box.querySelector('[data-agent-source]').value;
    const lines=['/Alife worlds','Create or connect an owner-private ALife World in this Codex project.'];
    lines.push(project==='existing'?'Use this existing project. Preserve its work, chats, settings and selected custom world.':'Help me create a new world in my chosen project folder.');
    if(world==='default')lines.push('Start with the default world. Keep it available as a backup when I customize my world.');
    if(world==='custom')lines.push('Create my own world from this description: '+(notes||'[describe the place, art style and interactions]')+'. Use this custom world as the main view and retain the default as a backup.');
    if(world==='upload')lines.push('Use the references I will be uploading as the visual direction. I will add them in one folder or as separate files in Codex. If I provide a folder, use the path I give you. Wait for the references before replacing them with invented artwork.'+(notes?' My notes: '+notes+'.':'')+' Keep the default world as a backup.');
    lines.push('On-screen characters: '+casts[cast]+'.');
    if(cast!=='agents')lines.push('Use my existing Dot and avatar where supported. If the avatar is unavailable, ask me for a reference image. Preserve the existing Dot chat and settings; do not invent a connection or create a replacement Dot.');
    if(cast==='dot')lines.push('Show only Dot in the scene. Keep any required world-building roles behind the scenes; do not add other on-screen agents.');
    if(cast==='agents')lines.push('Show the project agents in the scene and leave Dot out of the scene. Preserve my existing Dot.');
    if(cast!=='dot'){
      lines.push(source==='existing'?'Reuse the verified agents already in this project. Do not reset or replace them.':source==='starter'?'Use or reuse the ordinary starting team under this project’s existing creation rules and approved settings.':source==='external'?'Ask me which agent folder to use before linking anything. Preserve the original agents, chats, homes, work and settings.':'Use the agent roles and prompts I provide; follow the project’s existing approval and creation rules.');
      if(agentNotes)lines.push('Agent preferences: '+agentNotes);
    }
    lines.push('Keep private information and credentials out of public output. Preserve my references, selected models and settings. Finish with a reviewable working preview.');
    box.querySelector('[data-setup-prompt]').value=lines.join('\n\n');
  }
  document.querySelectorAll('[data-setup-choices]').forEach((box,index)=>{
    const outputId=box.querySelector('[data-setup-prompt]')?.id||'world-create-prompt-'+index;
    box.classList.add('world-setup-flow');box.dataset.cast='both';
    box.innerHTML=[
      '<fieldset class="setup-choice-group"><legend><span class="guide-step-number">1</span> Choose your project</legend><div class="setup-choice-options">'+buttonGroup('project',projects)+'</div></fieldset>',
      '<fieldset class="setup-choice-group"><legend><span class="guide-step-number">2</span> Choose your world</legend><div class="setup-choice-options">'+buttonGroup('world',worlds)+'</div>',
      '<div data-world-notes-wrap hidden><label>Describe your world or add notes<textarea data-world-description rows="3" placeholder="A quiet reading room, a storybook village, a moon outpost…"></textarea></label></div>',
      '<p class="guide-help" data-reference-help hidden>Add your references in Codex after copying the prompt. Put everything in one folder and give Codex its path, or attach the files separately. You do not need to make a document.</p></fieldset>',
      '<fieldset class="setup-choice-group"><legend><span class="guide-step-number">3</span> Who appears in the world?</legend><div class="setup-choice-options cast-options">'+buttonGroup('cast',casts)+'</div>',
      '<div class="cast-preview" aria-label="Example character preview"><div data-cast-dot><span class="preview-dot" aria-hidden="true">✦</span><span>Dot</span></div><div class="preview-agents" data-cast-agents><span class="preview-agent">Agent</span><span class="preview-agent">Agent</span><span class="preview-agent">Agent</span></div><p data-cast-caption></p></div>',
      '<p class="guide-help" data-dot-help>Want your own Dot’s look? Include an avatar picture with your references if Codex cannot access it.</p>',
      '<details data-agent-options><summary>Agent preferences <span>optional</span></summary><label>Which agents?<select data-agent-source><option value="existing">Use this project’s agents</option><option value="starter">Use a starting team</option><option value="external">Choose an agent folder</option><option value="custom">Describe the roles I want</option></select></label><label>Roles or preferences<textarea data-agent-prompts rows="2" placeholder="Optional roles, prompts, or details to preserve"></textarea></label></details></fieldset>',
      '<div class="prompt-box guide-generated-prompt"><label for="'+outputId+'">Your ready-to-copy prompt</label><textarea id="'+outputId+'" data-setup-prompt readonly rows="7"></textarea><button type="button" class="button green" data-copy-world>Copy world prompt</button><p class="copy-status" role="status"></p><p class="guide-help">Paste this into your chosen Codex project chat. The plugin invocation is included. Allow about 20–40 minutes when the world needs new artwork.</p></div>'
    ].join('');
    box.addEventListener('click',event=>{
      const b=event.target.closest('[data-setup-project],[data-setup-world],[data-setup-cast]');
      if(b){if(b.hasAttribute('data-setup-project')&&!box.dataset.agentPreferenceEdited)box.querySelector('[data-agent-source]').value=b.getAttribute('data-setup-project')==='existing'?'existing':'starter';for(const key of ['project','world','cast'])if(b.hasAttribute('data-setup-'+key))box.dataset[key]=b.getAttribute('data-setup-'+key);refresh(box);}
      if(event.target.closest('[data-copy-world]'))void copy(box.querySelector('[data-setup-prompt]'),box.querySelector('.copy-status'));
    });
    box.querySelector('[data-agent-source]').value=box.dataset.project==='existing'?'existing':'starter';
    box.addEventListener('input',()=>refresh(box));box.addEventListener('change',event=>{if(event.target.matches('[data-agent-source]'))box.dataset.agentPreferenceEdited='true';refresh(box);});
    refresh(box);
  });
  window.refreshSetup=refresh;
  document.querySelectorAll('[data-art-choice]').forEach(button=>button.addEventListener('click',()=>{
    const box=document.querySelector('#start-dialog [data-setup-choices]');if(box){box.dataset.world=button.dataset.artChoice==='upload'?'upload':'custom';refresh(box);}
  }));
  document.querySelectorAll('#download-concept').forEach(button=>button.remove());
  document.querySelectorAll('textarea[readonly]').forEach(field=>{if(field.id==='world-prompt'&&!field.value.startsWith('/Alife worlds'))field.value='/Alife worlds\n\n'+field.value;});
})();