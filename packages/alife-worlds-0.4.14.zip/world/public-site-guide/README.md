# Reusable public Site guide

Copy this directory to a static frontend root or adapt its three shared assets into an existing Site. Keep the destination’s hosting identity, access, approved services and credentials separate. There is no backend, world feed, pairing or stored project data here. The components copy user-reviewed prompts; they do not run tools or call AI services. Serve the folder with your existing preview workflow. Clipboard access may require a secure origin; manual copy remains available.

The shared creation prompt includes /Alife worlds, references supplied in Codex as a folder/path or separate files, and Dot + agents / Dot only / agents only on-screen choices. A host’s native capabilities still govern actual Dot/avatar access and world-building roles. The goal planner is a browser-local fictional example, not a project progress editor. It does not persist personal input. Lists of more than five sprints scroll, and the planner permits up to ten example sprints.

The public marketing Site separately retains the latest portrait art, creator-Dot example, contrast, modal scrolling and control-alignment repairs. Those public presentation repairs do not change the selected custom world or authorize copying a creator’s example avatar into another user’s Dot. This portable guide intentionally contains no personal avatar or tenant-specific Site data.
