
# Building an ALife World

This is the complete setup workflow behind the single advertised alife-worlds:create-world entry. Building world / alife-worlds:building-world is the actual post-submission running phase, not a second advertised skill or a rewritten user-message chip.

## Route the actual request

- A first ordinary plugin invocation to build/create/test/connect a world, a goal or reference images starts the automatic project-bound setup below. That invocation authorizes the ordinary core homes/chats, private runtime, registration and opening in its actual project; do not ask the human to repeat the folder, routing exception, baseline or setup permission.
- Rule/policy changes, /world, /plugin, /rule, /universal, listing/export and plugin source maintenance use [the world guide](world-guide.md). Do not provision agents for those requests.
- A read-only open/view, installation, update inspection or readiness question does not create cores. Use the same guide and preserve actual existing owners/services.
- A mandatory host permission, missing supported capability or conflicting identity remains a real limit. Report it precisely; do not bypass it or fake completion.

The packet root is three directories above this reference directory. Read its AGENTS.md, docs/COMMANDS.md and portable master plus the actual project's current instructions. For plugin authoring or resume, follow [Git and documentation freshness](../../../docs/OPERATIONS.md#git-and-documentation-freshness) through the current Git owner before editing or publishing. Source-maintainer assignments do not transfer into another project. Preserve existing chats, worlds, art, rules, tasks, settings and history.

## Derive context; do not ask for it

Discover the host's real list_projects, read_thread, list_threads, create_thread, set_thread_title and wait_threads tools and supported schemas. Read the actual process cwd and CODEX_THREAD_ID, then obtain that native thread's metadata and the current saved-project list. Use the exact current local cwd/thread/host and unique saved-project path mapping. Include that exact thread's actual current title; if read_thread omits it, obtain it from supported list_threads metadata before begin. Never invent the initial title. A null projectId in thread metadata is allowed when its exact cwd has one verified local saved mapping. A foreign mapping or ambiguous/unavailable local target is a capability/identity failure; never fall back to this plugin's source/cache or maintainer team.

Inspect the actual project's existing bootstrap/config/bindings and verified core/world first. Reuse its existing team and healthy world; package defaults do not retire existing agents. Do not infer core identity from a title. Inventory actual same-folder agents as protected recorded members; additional visual membership requires its own qualified projection.

For fresh setup run the current qualified packet's scripts/bootstrap-world.mjs begin with one JSON object on stdin:
{nativeThread:<actual native thread metadata including its current title>,nativeProjects:<actual list_projects projects>,goal:<human request or ordinary default-world goal>,existingAgents:<verified same-folder inventory>}

Once begin has successfully returned an actual in-progress setup for the submitted project, report Building world / alife-worlds:building-world as the running status. Do not claim that the original invocation chip changed. A reused already-connected world is opened instead of being rebuilt.

The command uses the invoking cwd, independently verifies its native session, and resolves the saved project itself. It loads the approved private core-creation profile automatically. No model/settings questionnaire is part of ordinary setup. Root/operator owns that profile; the source and installed packet are read-only policy consumers. Missing or invalid approval is a real configuration error, never an unapproved/higher fallback. Explicit later human-approved overrides are preserved. Existing and reserved agents retain their settings.

The private journal/runtime/homes live under the project's ignored .alife-worlds namespace. The invoking chat is Director for a fresh episode. Repeated begin reuses the original episode and verified native bindings; do not rerun a known or unknown launch.

## Complete the real startup

1. Read Director's FULL generated AGENT.md, RETIREMENT.md and checkpoint.json. Acknowledge only from the actual own native session, with the returned contract hash after actual reading/access checks.
After Director's own acknowledgement, obtain its current supported native metadata and run reserve-director-title with {nativeThread:<that exact current thread>}. Fresh begin has retained the actual initial title and exact invoking identity. If canRename is true, reread the same native target immediately and compare its identity/title with the returned preflight data; perform ONLY the returned supported set_thread_title request once when they still match. Then read back that same thread and run record-director-title with {operationId,status:"verified",nativeResult:{threadId:<actual returned target>,title:"Director"},nativeThread:<actual readback showing Director>}. This renames the existing setup chat, never creates a replacement.

A changed title before the native action is preserved; record failed without a tool result if the preflight prevents the action. A missing/refused capability is recorded unavailable or failed, and a genuinely uncertain effect is unknown. An original pending/unknown reservation is never replayed; reconcile an actually matching readback with status:"observed" and no fabricated native result. Already-named Director and older/established episodes are no-ops. Missing initial supported title metadata stays explicit. Title failure does not prevent independent core setup, but never report the name verified without its actual supported readback.

2. Director reserves only missing Agent Support through reserve. If canCreate is true, execute the returned supported create_thread arguments ONCE, then record-created with its actual return and original operation ID. The approved model/reasoning come from the approved policy; never invent an upgrade.
3. Reconcile queued/unknown native effects under the original identity. A clientThreadId is not a ready threadId. Wait for the real child and its own receipt; no other chat may attest for it.
4. Agent Support's complete initial prompt tells it to acknowledge, use the finite await-binding handshake if necessary, and create only missing World Requests through reserve/native create/record-created. Only after Agent Support's own actual binding/access/custody acknowledgement does it own that creation.
5. World Requests reads/acknowledges its own FULL contracts. Once all three actual bindings and own receipts exist, it starts or reuses the verified private service and records its actual identity/result.
6. Keep following the actual assigned core turns through bounded supported wait_threads and status. If a known child has gone idle after binding without progressing, the creator uses reserve-continuation, sends only the returned supported same-chat follow-up once, then record-continuation with the real target result. A reserved/unknown continuation must never be replayed.
7. Do not end at files, a contract export, a reservation or queued call. Complete the real core/world chain, or name the exact unresolved original operation/mandatory capability. Every role retains full instructions, task/permission/effect custody and next action in its own checkpoint.

Before a first missing-role reservation, the helper reconciles the complete current incoming project/master/shared/retirement/role/universal/own-rule contract only in an uncreated/unreserved generated draft, retaining durable recovery. Edited drafts need reconciliation; established/reserved custody is never overwritten or replayed.

## Keep this world release history

For an explicitly authorized owner-private hosted Site, use the packet's [portable owner-Site implementation](../../../docs/INTEGRATION.md#portable-private-owner-site-and-rules-library--042) and `world/owner-site-template`, rather than rebuilding a metadata-only connection page. Follow the current Sites skill to create or open only the destination's actual Site and retain its returned identity/audience. Supply its own opaque world alias, authorized logical roles, actual prepared world release and qualified scene; use `scripts/prepare-owner-site.mjs` from the clean packet to populate that Site's source. The reusable dashboard keeps Plugin/World Rules after the sprint hierarchy, with human descriptions, detailed AI instructions and modular scope/group/property Copy import/Clone definition. Definition exports grant no connection or native authority.

Only after matching source, selected scene, receiver and private hosting are ready, replace that project's existing publisher through `scripts/start-site-relay.mjs` with `mode: "owner-bundle"`, exact Site/dashboard origins and that destination's memory-only pairing/service credentials on hidden stdin. Reconcile its original PID, common lock and pending receipt before replacement. Never start concurrent v1/v2 publishers or copy another project's agents, settings, tasks, bindings or credentials. A new logical role catalogue requires a matching authorized receiver/Site configuration update; an unconfigured role is refused, not silently imported. Renames and model/activity updates for configured roles use the existing shared source loop. Verify original live receipts and truthful freshness separately from browser and human acceptance. This paragraph creates no Site, agent, service, schedule or permission merely by being read.

After the exact three core bindings and own receipts exist, World Requests uses the [private world record commands](../../../docs/COMMANDS.md#private-world-release-records) from its actual project context. Initialize the neutral definition only when missing; preserve existing custom art/profile/preferences/records. Save actual reference provenance and selected design assets in the private world profile, retain hash-verified immutable snapshots when preparing a real world change, and report actual source checks and limits. The neutral 1.0.0 definition is neither an already deployed world nor hosting acceptance.

A fresh native world-owner creation requests World 1.0; its role ID remains world-requests. Existing episodes, identities, homes, work and settings are preserved. File/requested names are not observed native titles. Any separately authorized version-based title update requires original reservation, exact supported result and native readback. Record actual local/private/public surface results independently; honor saved per-world preferences, opt-outs and latest holds. These helpers make no native or hosting call.

## Connect and open the actual world

World Requests starts the helper's start-world from its actual project cwd in a supported hidden background process on Windows. Preserve the actual PID/output. The service verifies exact project/root/world identity on an available loopback port. Do not start a duplicate while the original operation is pending.

The explicit setup includes register-launcher with explicitRegister:true for this exact verified world; preserve every unrelated launcher entry and profile. Open the verified operatorUrl with the supported host opener or local launcher: the full local dashboard at /?project=<actual projectId>. Fresh local worlds start in Public presentation mode with the existing Public/Private/View modes, project dropdowns and cosmetic Interact controls; preserve an existing world's selected mode. The separate viewerUrl at /world/view?project=<public worldId> is the sanitized spectator route, not the default local destination. Public presentation does not publish the world or enable unavailable native actions. Actual host success and visible rendering are separate checks. A host refusal is not permission for an Opera/browser retry, invented deep link or fabricated visible result.

No supplied visual brief is required: use the included default world. If images are supplied, apply the guide's complete image workflow; inspect every reference and preserve user art. Native world-button dispatch, public hosting and linked-project generalization remain separate.

## Preserve other agents and close out

Same-folder pre-existing and explicitly selected linked agents remain protected recorded members. Inclusion is not permission to modify, message, move, retire or delete another project's agents, or to expose private membership publicly. No exact linked folder is inferred from an inventory.

An explicit reset/delete policy edit performs no reset. For a separately authorized actual reset, Agent Support uses reset-plan: only verified plugin-created core targets are proposed, excluding reused/pre-existing/linked agents. The plan archives/deletes nothing; unknown effects block it and actual retirement follows full supported custody procedures.

Report real core identities/receipts, requested versus observed applied settings, verified private URL and actual rendering/capability result. Keep source qualification, installed discovery, native creation, connection and visible acceptance separate. Apply the guide's task-tab and actual computer-handback rules if UI was used.
