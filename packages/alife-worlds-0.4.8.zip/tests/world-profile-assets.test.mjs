import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {createApp} from '../server.mjs';
import {createHash} from 'node:crypto';
import {createDemo} from '../lib/demo.mjs';
import {loadRegistry} from '../lib/projection.mjs';
import {publicWorldId} from '../lib/public-world.mjs';
import {PREVIEW_DESCRIPTOR} from '../lib/world-preview.mjs';
import {ownerPreviewProfileMatches} from '../lib/owner-preview-qualification.mjs';
import {readWorldProfile,readWorldSceneFile,createServedWorldResource,WORLD_SCENE_FILES,WORLD_OPTIONAL_SCENE_FILES} from '../lib/world-profile.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex'),projectId='scene-fixture',worldId='scene-fixture-world';
async function fixture(optional,fn,{version=optional?'1.2.7':'1.2.6',actualSource=false}={}){
 const root=await mkdtemp(path.join(os.tmpdir(),'alife-scene-assets-')),files=[],contents=new Map();
 try{
  for(const rel of [...WORLD_SCENE_FILES,...(optional?WORLD_OPTIONAL_SCENE_FILES:[])]){const b=actualSource?await readFile(new URL('../web/'+rel,import.meta.url)):Buffer.from('fixture:'+rel);contents.set('web/'+rel,b);files.push({path:'web/'+rel,sha256:sha(b),bytes:b.length});}
  files.push({path:'web/private-not-allowed.txt',sha256:sha('excluded'),bytes:8});
  const manifest={schemaVersion:1,kind:'world-artifact',version,design:{assets:[],artDirection:null,preferences:{}},files};
  const artifactSha256=sha(JSON.stringify(manifest)),artifactRoot=path.join(root,'.alife-worlds/world-release/artifacts',artifactSha256);
  for(const f of files){const target=path.join(artifactRoot,f.path);await mkdir(path.dirname(target),{recursive:true});await writeFile(target,contents.get(f.path)??'excluded');}
  await writeFile(path.join(artifactRoot,'manifest.json'),JSON.stringify(manifest));
  await writeFile(path.join(root,'.alife-worlds/world-profile.json'),JSON.stringify({schemaVersion:1,projectId,worldId,revision:1,assets:[],artDirection:null,preferences:{scene:{schemaVersion:1,renderer:'midnight-colony',version:manifest.version,artifactSha256}}}));
  await writeFile(path.join(root,'.alife-worlds/world-release/ledger.json'),JSON.stringify({schemaVersion:1,projectId,worldId,projectRoot:root,releases:[{version:manifest.version,state:'prepared',artifactSha256}]}));
  await fn({root,artifactRoot,profile:await readWorldProfile({packageRoot:root,projectRoot:root,projectId})});
 }finally{assert.ok(path.resolve(root).startsWith(path.resolve(os.tmpdir())+path.sep));await rm(root,{recursive:true,force:true});}
}
function servedResource(f,readProfile){const allowed=new Set([...WORLD_SCENE_FILES,...WORLD_OPTIONAL_SCENE_FILES].map(path=>'web/'+path)),qualification={descriptor:PREVIEW_DESCRIPTOR,files:f.profile.selection.files.filter(row=>allowed.has(row.path))};return createServedWorldResource({projectId,descriptor:PREVIEW_DESCRIPTOR,readProfile,qualifyProfile:profile=>ownerPreviewProfileMatches(profile,qualification)});}
test('older immutable worlds remain compatible without new optional artwork or fonts',()=>fixture(false,async f=>{
 assert.equal(f.profile.status,'ready');assert.equal(f.profile.worldVersion,'1.2.6');
 assert.equal((await readWorldSceneFile(f.profile,WORLD_SCENE_FILES[0])).toString(),'fixture:'+WORLD_SCENE_FILES[0]);
 await assert.rejects(readWorldSceneFile(f.profile,WORLD_OPTIONAL_SCENE_FILES[0]),/not selected/);
}));
test('selected supplementary artwork and font require exact allowlist and immutable hashes',()=>fixture(true,async f=>{
 assert.equal(f.profile.status,'ready');
 for(const rel of WORLD_OPTIONAL_SCENE_FILES)assert.equal((await readWorldSceneFile(f.profile,rel)).toString(),'fixture:'+rel);
 for(const rel of ['private-not-allowed.txt','../manifest.json','agent-outpost/assets/other.png'])await assert.rejects(readWorldSceneFile(f.profile,rel),/unavailable/);
 const rel=WORLD_OPTIONAL_SCENE_FILES[0];await writeFile(path.join(f.artifactRoot,'web',rel),'changed');
 await assert.rejects(readWorldSceneFile(f.profile,rel),/changed/);
 assert.equal((await readWorldProfile({packageRoot:f.root,projectRoot:f.root,projectId})).status,'unavailable');
}));

test('an unready or receiver-mismatched next release retains only verified resources from the same world and art',()=>fixture(true,async f=>{
 const descriptor={worldVersion:f.profile.worldVersion,artifactSha256:f.profile.artifactSha256};
 let selected=f.profile;
 const resource=servedResource(f,async()=>selected);
 assert.equal((await resource.read()).state,'current');
 const profilePath=path.join(f.root,'.alife-worlds/world-profile.json'),next=JSON.parse(await readFile(profilePath,'utf8'));
 next.preferences.scene={...next.preferences.scene,version:'1.2.8',artifactSha256:'a'.repeat(64)};
 await writeFile(profilePath,JSON.stringify(next));selected=await readWorldProfile({packageRoot:f.root,projectRoot:f.root,projectId});
 assert.equal(selected.status,'unavailable');
 const retained=await resource.read();assert.equal(retained.state,'retained');assert.equal(retained.served.worldVersion,'1.2.7');
 assert.equal((await readWorldSceneFile(retained.served,WORLD_SCENE_FILES[0])).toString(),'fixture:'+WORLD_SCENE_FILES[0]);
 selected={...f.profile,worldVersion:'1.2.8',artifactSha256:'b'.repeat(64),selection:{...f.profile.selection,files:f.profile.selection.files.map((row,i)=>i===0?{...row,sha256:'0'.repeat(64)}:row)}};
 assert.equal((await resource.read()).served.worldVersion,'1.2.7','ready selection alone does not qualify a different receiver');
 next.preferences.palette='new-human-art';await writeFile(profilePath,JSON.stringify(next));
 selected=await readWorldProfile({packageRoot:f.root,projectRoot:f.root,projectId});
 assert.equal((await resource.read()).state,'unavailable','changed custom art must not borrow the previous scene');
 assert.equal((await resource.read()).served.selection,null);
 const other={...next,worldId:'different-world'};await writeFile(profilePath,JSON.stringify(other));
 const otherProfile=await readWorldProfile({packageRoot:f.root,projectRoot:f.root,projectId});
 assert.notEqual(otherProfile.resourceIdentity,f.profile.resourceIdentity,'same-project world IDs do not share retained scenery');
}));

test('local scene HTTP routes do not substitute package artwork for a receiver-mismatched world',()=>fixture(false,async f=>{
 const configFile=path.join(f.root,'config.json');await writeFile(configFile,JSON.stringify({mode:'demo',projectId,nativeReadOnly:true,nativeWorkspaceRoot:f.root,commandsEnabled:false}));
 const app=await createApp({configFile,adapter:{},journalPath:path.join(f.root,'journal.json')}),url=await app.listen(0);
 try{
  const response=await fetch(url+'/agent-outpost/agent-outpost.js');assert.equal(response.status,503);assert.match((await response.json()).error,/Compatible world resource unavailable/);
  const dashboard=await(await fetch(url+'/api/dashboard')).json();assert.equal(dashboard.worldProfile.status,'unavailable');assert.equal(dashboard.worldUpdate.state,'unavailable');assert.equal(dashboard.worldUpdate.selected.status,'ready');assert.equal(dashboard.worldUpdate.selected.worldVersion,'1.2.6');assert.equal(dashboard.ownerPreview,null);
 }finally{app.server.closeAllConnections();await new Promise(resolve=>app.server.close(resolve));}
}));

test('retained scene integrity, foreign world and first-start qualification remain fail closed',()=>fixture(false,async f=>{
 const descriptor={worldVersion:f.profile.worldVersion,artifactSha256:f.profile.artifactSha256};let selected={...f.profile,worldVersion:'9.0.0',selection:{...f.profile.selection,files:f.profile.selection.files.map((row,i)=>i===0?{...row,sha256:'0'.repeat(64)}:row)}};
 const resource=servedResource(f,async()=>selected);
 assert.equal((await resource.read()).served.status,'unavailable');
 selected=f.profile;assert.equal((await resource.read()).state,'current');
 selected={...f.profile,status:'unavailable',selection:null};
 await writeFile(path.join(f.artifactRoot,'web',WORLD_SCENE_FILES[0]),'changed immutable bytes');
 assert.equal((await resource.read()).state,'unavailable');
 selected={...f.profile,projectId:'foreign-project'};assert.equal((await resource.read()).served.status,'unavailable');
}));

test('concurrent reads share one qualification and returned records cannot mutate the served resource',()=>fixture(false,async f=>{
 let reads=0;const resource=servedResource(f,async()=>{reads++;return f.profile;});
 const [a,b]=await Promise.all([resource.read(),resource.read()]);assert.equal(reads,1);assert.equal(a,b);
 a.served.selection.files[0].sha256='0'.repeat(64);
 const fresh=await resource.read();assert.equal(fresh.state,'current');assert.notEqual(fresh.served.selection.files[0].sha256,'0'.repeat(64));
}));
test('a known foreign or malformed ledger clears retained scenery even when profile art identity is unchanged',()=>fixture(false,async f=>{
 const ledgerPath=path.join(f.root,'.alife-worlds/world-release/ledger.json'),original=await readFile(ledgerPath,'utf8'),ledger=JSON.parse(original);
 for(const replacement of [JSON.stringify({...ledger,projectId:'foreign-project'}),JSON.stringify({...ledger,worldId:'foreign-world'}),JSON.stringify({...ledger,projectRoot:path.dirname(f.root)}),'null','{"projectId":']){
  await writeFile(ledgerPath,original);let selected=f.profile;const resource=servedResource(f,async()=>selected);assert.equal((await resource.read()).state,'current');await writeFile(ledgerPath,replacement);selected=await readWorldProfile({packageRoot:f.root,projectRoot:f.root,projectId});assert.equal(selected.status,'unavailable');assert.equal(selected.resourceIdentity,null);const result=await resource.read();assert.equal(result.state,'unavailable');assert.equal(result.served.selection,null);
 }
}));

test('actual world1.0.2 and renderer1.3.8 retain exact scenery without refreshing original settings or work evidence',()=>fixture(true,async f=>{
 assert.equal(f.profile.worldVersion,'1.0.2');assert.equal(PREVIEW_DESCRIPTOR.worldVersion,'1.3.8');
 const original=Date.now(),sourceAt=new Date(original-1000).toISOString(),workAt=new Date(original-30000).toISOString(),appliedAt=new Date(original-20000).toISOString(),selectionAt=new Date(original-5000).toISOString(),roles=await loadRegistry(),input=createDemo(roles,'working');input.observedUtc=sourceAt;input.nativeMetadata={persistence:'available',revision:1,contentHash:'a'.repeat(64)};
 for(const agent of input.agents)Object.assign(agent,{observedUtc:workAt,model:'gpt-6.1-sol',modelSource:'turn_context',modelState:'current',modelObservedUtc:appliedAt,selectedModel:'gpt-6.1-sol',selectedModelSource:'native-index-selection',selectedModelState:'current',selectedModelObservedUtc:selectionAt,reasoningEffortObservedUtc:appliedAt,serviceTierObservedUtc:appliedAt,serviceTierSource:'turn_context'});
 const configFile=path.join(f.root,'config.json');await writeFile(configFile,JSON.stringify({mode:'live',projectId,nativeReadOnly:true,nativeWorkspaceRoot:f.root,commandsEnabled:false}));const app=await createApp({configFile,journalPath:path.join(f.root,'commands.json'),adapter:{readSnapshot:async()=>structuredClone(input)}}),url=await app.listen(0),world=publicWorldId(projectId);
 try{
  await fetch(url+'/api/workspace');const before=await(await fetch(url+'/api/agent-metadata')).json();assert.equal(before.state,'current');assert.equal(before.observedUtc,sourceAt);assert.equal(before.metadata.agents[0].applied.observedUtc,appliedAt);
  const profilePath=path.join(f.root,'.alife-worlds/world-profile.json'),next=JSON.parse(await readFile(profilePath,'utf8'));next.preferences.scene={...next.preferences.scene,version:'1.0.3',artifactSha256:'c'.repeat(64)};await writeFile(profilePath,JSON.stringify(next));
  const dashboard=await(await fetch(url+'/api/dashboard')).json();assert.equal(dashboard.worldUpdate.state,'retained');assert.equal(dashboard.worldProfile.worldVersion,'1.0.2');assert.equal(dashboard.ownerPreview.renderer.worldVersion,'1.3.8');assert.equal(dashboard.feed.observedUtc,sourceAt);assert.equal(dashboard.ownerPreview.snapshot.observedUtc,sourceAt);
  await fetch(url+'/api/workspace');const after=await(await fetch(url+'/api/agent-metadata')).json();assert.equal(after.receivedUtc,before.receivedUtc);assert.equal(after.observedUtc,before.observedUtc);assert.equal(after.metadata.agents[0].applied.observedUtc,appliedAt);assert.equal(after.metadata.agents[0].selection.observedUtc,selectionAt);assert.equal(after.metadata.agents[0].activity.observedUtc,workAt);
  next.preferences.palette='different-authorized-art';await writeFile(profilePath,JSON.stringify(next));const changed=await(await fetch(url+'/api/dashboard')).json();assert.equal(changed.worldUpdate.state,'unavailable');assert.equal(changed.worldProfile.status,'unavailable');assert.equal(changed.ownerPreview,null);assert.equal((await fetch(url+'/agent-outpost/agent-outpost.js')).status,503);
  assert.equal((await fetch(url+'/api/agent-metadata?project='+world+'&project='+world)).status,404);
 }finally{app.server.closeAllConnections();await new Promise(resolve=>app.server.close(resolve));}
},{version:'1.0.2',actualSource:true}));
