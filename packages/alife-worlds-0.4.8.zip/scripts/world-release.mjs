import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {worldReleaseProof} from '../lib/world-release-context.mjs';
import {initializeWorldRelease,saveWorldProfile,recordLegacyWorldSurface,prepareWorldRelease,reconcileWorldSnapshot,reserveWorldSurfaceUpdate,recordWorldSurfaceResult,worldRollbackPlan,reserveWorldTitleUpdate,recordWorldTitleUpdate,readWorldReleaseReport} from '../lib/world-release.mjs';
const packageRoot=fileURLToPath(new URL('../',import.meta.url)),command=process.argv[2],args=process.argv.slice(3);
let selectedRoot=process.cwd();const rootIndex=args.indexOf('--project-root');if(rootIndex!==-1){if(!args[rootIndex+1]||!path.isAbsolute(args[rootIndex+1]))throw Error('Exact canonical project root required.');selectedRoot=path.resolve(args[rootIndex+1]);args.splice(rootIndex,2);}
async function input(){let size=0,value='';for await(const b of process.stdin){size+=b.length;if(size>1024*1024)throw Error('World release input limit exceeded.');value+=b.toString('utf8');}return JSON.parse(value.replace(/^\uFEFF/,''));}
const out=v=>console.log(typeof v==='string'?v:JSON.stringify(v,null,2));
try{
 if(!command||command==='help'){
  out({command:'world-release',commands:['init','profile','legacy','prepare','reconcile-snapshot','reserve-surface','record-surface','rollback-plan','reserve-title','record-title','report --format json|markdown'],context:'Run in the actual native Codex chat. An explicit --project-root requires an existing hash-pinned mapped context when it differs from the execution cwd. No native or hosting actions are performed. Other commands accept one bounded JSON object on stdin.'});
 }else{
  const root=selectedRoot,threadId=process.env.CODEX_THREAD_ID;if(!threadId)throw Error('Actual native Codex thread context is missing.');
  const current=await worldReleaseProof(root,threadId);
  if(command==='report'){
   if(args.length!==0&&(args.length!==2||args[0]!=='--format'))throw Error('Use report --format json|markdown.');
   out(await readWorldReleaseReport(packageRoot,root,current,{format:args[1]??'json'}));
  }else{
   if(args.length!==0)throw Error('Use structured JSON on stdin, with only the optional exact --project-root.');const data=await input();
   if(command==='init')out(await initializeWorldRelease(packageRoot,root,data,current));
   else if(command==='profile')out(await saveWorldProfile(root,data,current));
   else if(command==='legacy')out(await recordLegacyWorldSurface(root,data,current));
   else if(command==='prepare')out(await prepareWorldRelease(root,data,current));
   else if(command==='reconcile-snapshot'){if(!data||Object.keys(data).sort().join(',')!=='operationId')throw Error('Original operationId only.');out(await reconcileWorldSnapshot(root,data.operationId,current));}
   else if(command==='reserve-surface')out(await reserveWorldSurfaceUpdate(root,data,current));
   else if(command==='record-surface')out(await recordWorldSurfaceResult(root,data,current));
   else if(command==='rollback-plan')out(await worldRollbackPlan(root,data,current));
   else if(command==='reserve-title')out(await reserveWorldTitleUpdate(root,data,current));
   else if(command==='record-title')out(await recordWorldTitleUpdate(root,data,current));
   else throw Error('Unknown world release command.');
  }
 }
}catch(error){console.error(error.message);process.exitCode=1;}
