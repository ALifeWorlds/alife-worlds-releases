import {context,assets,ruleLibrary,legacyStorageKey,packageVersion,assetSetSha256,frameRelease} from '__SITE_DATA__';
import {createSiteBundleService} from '__PACKAGE_ROOT__/site-sync-receiver.mjs';
import {createSiteConnectionWorker} from '__PACKAGE_ROOT__/site-sync-worker.mjs';
import {createOwnerFrameService} from '__PACKAGE_ROOT__/owner-frame-service.mjs';
import {renderOwnerFrameDocument} from '__PACKAGE_ROOT__/owner-frame-document.mjs';
const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'};
const json=(value,status=200)=>Response.json(value,{status,headers});
const isOwner=request=>!!request.headers.get('oai-authenticated-user-id');
let configured=null,bundleSource=null,scope=null;
// Sites validates and consumes its service token before this owner-private
// Worker. The application pairing key remains an independent narrow write gate;
// it never supplies a visitor identity or authorizes public hosting.
function service(env){if(!configured||scope!==env.PROJECT_SCOPE){scope=env.PROJECT_SCOPE;const bundleService=createSiteBundleService({project:scope,worldId:context.worldId,roles:context.roles,renderer:context.renderer,ownerOrigin:context.ownerOrigin});bundleSource=bundleService;configured=createSiteConnectionWorker({bundleService,isOwner,isServicePublisher:request=>new URL(request.url).origin===context.ownerOrigin,...(legacyStorageKey?{legacyStorageKey}:{})});}return configured;}
async function paired(request,env){const a=request.headers.get('X-ALife-Sync-Key'),b=env.BUNDLE_SYNC_KEY;if(typeof a!=='string'||typeof b!=='string'||a.length<32||b.length<32)return false;const hash=x=>crypto.subtle.digest('SHA-256',new TextEncoder().encode(x)),[x,y]=await Promise.all([hash(a),hash(b)]);let mismatch=0;const one=new Uint8Array(x),two=new Uint8Array(y);for(let i=0;i<one.length;i++)mismatch|=one[i]^two[i];return mismatch===0;}
export default {async fetch(request,env){
 const url=new URL(request.url);
 if(url.origin!==context.ownerOrigin)return json({error:'Exact Site required'},403);
 if(url.pathname==='/api/owner-world-release'||url.pathname==='/owner-frame-client.mjs'||url.pathname.startsWith('/world-frame/')){
  if(!isOwner(request))return json({error:'Sign in required'},401);
  service(env);
  const frames=createOwnerFrameService({worldId:context.worldId,access:context.access,ownerOrigin:context.ownerOrigin,websiteVersion:context.websiteVersion,
   readReleases:()=>({current:frameRelease,previous:null}),
   readSnapshot:async()=>{const response=await bundleSource.response(new Request(context.ownerOrigin+'/api/owner-world-preview'),env.SNAPSHOTS);if(!response.ok)throw Error('Current owner preview unavailable');return response.json();},
   readAsset:async(_renderer,row)=>{const asset=assets['/'+row.path.slice(4)];if(!asset)throw Error('Selected asset unavailable');return Uint8Array.from(atob(asset.base64),c=>c.charCodeAt(0));},
   readClientModule:()=>{const asset=assets['/owner-frame-client.mjs'];return Uint8Array.from(atob(asset.base64),c=>c.charCodeAt(0));},
   renderFrame:renderOwnerFrameDocument,readWorldVersion:()=>context.worldVersion
  });return frames.ownerFrameResponse(request,{ownerAuthorized:true});
 }
 if(url.pathname.startsWith('/api/')){
  if(url.pathname==='/api/site-release'){
   if(request.method!=='GET'||url.search||request.headers.has('Origin'))return json({error:'Read-only release verification'},405);
   if(!isOwner(request)&&!await paired(request,env))return json({error:'Authentication required'},401);
   let synchronization={state:'unavailable',observedUtc:null,receivedUtc:null,agents:0,tasks:0};
   try{service(env);const response=await bundleSource.response(new Request(context.ownerOrigin+'/api/workspace'),env.SNAPSHOTS),value=await response.json();synchronization={state:value.state??'unavailable',observedUtc:value.snapshot?.observedUtc??null,receivedUtc:value.receivedUtc??null,agents:value.snapshot?.agents?.length??0,tasks:value.snapshot?.tasks?.length??0};}catch{}
   return json({schemaVersion:1,kind:'owner-site-release',packageVersion,websiteVersion:context.websiteVersion,worldVersion:context.worldVersion,renderer:context.renderer,assetSetSha256,rules:ruleLibrary.scopes.map(s=>({scope:s.scope,revision:s.revision,properties:s.packet[s.scope].groups.reduce((n,g)=>n+g.properties.length,0)})),synchronization});
  }
  if(url.pathname.startsWith('/api/qa-'))return isOwner(request)?json({error:'Human QA service not configured'},503):json({error:'Sign in required'},401);
  return service(env).fetch(request,env);
 }
 if(!isOwner(request))return json({error:'Sign in required'},401);
 if(!['GET','HEAD'].includes(request.method))return json({error:'Read-only display'},405);
 if(url.pathname==='/'&&(url.searchParams.getAll('project').length>1||url.searchParams.has('project')&&url.searchParams.get('project')!==context.worldId))return json({error:'World unavailable'},404);
 const asset=assets[url.pathname];if(!asset)return json({error:'Not found'},404);
 const h={...headers,'Content-Type':asset.type,ETag:'"'+asset.sha256+'"'};
 if(asset.type.startsWith('text/html'))h['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self'; font-src 'self'; connect-src 'self'; frame-src 'self'; frame-ancestors 'self'; object-src 'none'; base-uri 'self'";
 if(request.method==='HEAD')return new Response(null,{headers:h});
 const bytes=Uint8Array.from(atob(asset.base64),c=>c.charCodeAt(0));return new Response(bytes,{headers:h});
}};
