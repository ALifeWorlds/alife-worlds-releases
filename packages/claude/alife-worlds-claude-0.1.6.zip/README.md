# ALife Worlds for Claude Code

A Claude Code plugin that gives your agents a shared visual world. A small team of agents — **Director**, **World 1.0** and **Agent Support** — plans and does work in your project, and a local browser dashboard (the existing ALife Worlds world, Sprints view and visual controls) shows what actually happened.

This is the Claude Code edition of [ALife Worlds](https://alifeworlds.com/) (upstream baseline **0.4.30**, created by Itzel Juarez, MIT licensed). It runs entirely on your own computer; nothing here deploys anything.

## The one rule: only proven progress is shown

The dashboard never infers progress from "an agent seems busy". It shows only what verified receipts in the project's own evidence ledger prove:

1. a Director **handoff** is issued for a task (one-time token),
2. the assignee **acknowledges** it (needs the token and the instance id minted when it read its contract) → the task becomes *In Progress*,
3. the assignee **submits** work with concrete evidence → *In Review*,
4. a reviewer who is **not the submitter** (Director, or you) **accepts** it → *Done* and sprint progress advances.

Agent activity and task completion are separate. Anything unproven is shown as unavailable or unconfirmed. Demo/fixture activity is labelled as such and is excluded from the dashboard unless a test switch is set.

## What you get

- 10 skills: `alife-worlds:start`, `create-world`, `world`, `import`, `export`, `rule`, `universal`, `plugin`, `commands`, `delete`.
- 3 built-in agents: `alife-worlds:director`, `alife-worlds:world-requests` (World 1.0), `alife-worlds:support` (Agent Support). Roles you add by import are project-local.
- A local stdio MCP server (`alife-worlds`) with the evidence, planning, rules, import/export and viewer tools.
- A loopback-only dashboard (`127.0.0.1`), per project.

## Where it runs

> **Runs only in Claude Code.** Use the **Code** tab in the Claude desktop app (a **Local** session on a folder) or the Claude Code terminal. Regular claude.ai chats and claude.ai **Projects** can't run this plugin: they skip its local tools and agents, so nothing happens there.

## Install

In Claude Code, run:

```
/plugin marketplace add ALifeWorlds/alife-worlds-releases
/plugin install alife-worlds@alife-worlds
```

Or from a terminal:

```bash
claude plugin marketplace add ALifeWorlds/alife-worlds-releases
claude plugin install alife-worlds@alife-worlds
```

To get a newer version later: `/plugin marketplace update alife-worlds`. To try an unzipped copy without installing: `claude --plugin-dir /path/to/alife-worlds` from inside your project folder.

## Start a world (step by step)

1. Make a **new, empty folder** for your world.
2. In the Claude desktop app, open the **Code** tab, start a **Local** session and choose that folder. (Terminal: open the folder and run `claude`.)
3. Install the plugin once, if you haven't (see **Install** above). Start a new session after installing.
4. Type `/alife-worlds:start` followed by your idea, for example:

   ```text
   /alife-worlds:start a moonlit pine village
   ```

   This sets up the folder, creates the world, adds the **Director**, **World 1.0** and **Agent Support** agents to the folder's `.claude/agents/`, and opens the world viewer link.
5. **That chat becomes the Director.** It asks what to build first. With no goal, its goal is "Create the world". Say go, and it plans the work and starts World 1.0 and Agent Support itself.
6. **Later chats in the same folder:** they are set to start as Director. If a new chat doesn't, type `/alife-worlds:start` in it. That changes nothing in your world; it just makes that chat the Director. (Terminal alternative: `claude --agent director`.)

Open the `http://127.0.0.1:…` link Claude gives you in your browser to see the world. It works while that Claude Code session is open. To use your own art, tell the Director which files or folder to use.

## Using your agents and world

Use a **Claude Code** session: the Code tab of the Claude desktop app, the terminal, or an IDE. Regular claude.ai chats and Projects can't run this plugin's local tools or agents. Open Claude Code **inside your project folder** (the plugin works on that folder only), then just ask in plain words:

| You want to | Type |
| --- | --- |
| Set up everything in one step | `/alife-worlds:start a moonlit pine village` (sets up the folder, creates the world, adds Director, World 1.0 and Agent Support to `.claude/agents/`, and turns this chat into the Director) |
| Make a later chat the Director | Run `/alife-worlds:start` again in that chat (it changes nothing in the world), or start Claude Code with `claude --agent director`. Setup also sets `"agent": "director"` in `.claude/settings.json`. |
| Set up a world with more choices | `/alife-worlds:create-world` |
| Open the world | *Open the ALife World viewer* (you get a `http://127.0.0.1:…` link; open it in your browser) |
| Plan work | *Ask the Director to plan the next sprint* (with no goal set, Director's goal is "Create the world") |
| Do world work | *Start World 1.0 with the Director's handoff* |
| Add or import agents | *Ask Agent Support to import this agent file* |
| See every command | *Show the alife-worlds commands* |

Every ALife Worlds command from the Codex edition is here as `/alife-worlds:<name>`: `start`, `create-world`, `world`, `import`, `export`, `rule`, `universal`, `plugin`, `delete`, `commands`. `/agents` lists the agents and `/skills` lists the skills. The viewer runs while Claude Code is open; to keep it running on its own use `node scripts/claude-viewer.mjs --project /path/to/your/project` from the plugin folder. See [SETUP.md](SETUP.md) for troubleshooting and [docs/CAPABILITIES.md](docs/CAPABILITIES.md) for what works and what is limited.

## Privacy and scope

- State lives only in `<project>/.alife-worlds/` (git-ignored by default). Nothing is read from other projects or from any global Claude or Codex history.
- Art you supply is copied *into* the project; original locations are not recorded and originals are not changed.
- The viewer binds to loopback only. Importing, exporting and merging act on the verified current project only and need your confirmation before anything is applied.
- The package contains no credentials, user art, website assets, website Dot, Sprite Machine or production site configuration.

## Licensing and attribution

See [CONTRIBUTING.md](CONTRIBUTING.md), [CONTRIBUTORS.md](CONTRIBUTORS.md), [GOVERNANCE.md](GOVERNANCE.md), [BRANDING.md](BRANDING.md) and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

MIT. Original ALife Worlds branding and the creator credit are preserved; see `LICENSE`, `THIRD_PARTY_NOTICES.md`, `BRANDING.md`, and `UPSTREAM-PROVENANCE.json` / `PORT-MODIFICATIONS.json` for exactly which upstream files were reused unchanged and which were modified.
