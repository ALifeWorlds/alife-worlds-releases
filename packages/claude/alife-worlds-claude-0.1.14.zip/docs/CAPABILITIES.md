# Capabilities of the Claude Code edition

Status for local package **0.1.14** (upstream baseline ALife Worlds 0.4.30). Version 0.1.14 removes the in-chat helper agents entirely (roles only run as chats), has Agent Support approve World 1.0 chats at start-up, and has Director queue each handoff for the role it names (World 1.0 opens in its own chat; unapproved roles go through Agent Support); 0.1.13 opens the Agent Support and World 1.0 chats on start and moves them to the top level; 0.1.12 renames the first chat Director and has Director and Agent Support open role chats with the Claude desktop app's session tools (0.1.11: generic open-chat instructions (0.1.10: each role runs in its own chat instead of a subagent (Agent Support creates role chats; the SessionStart hook names each new chat and starts it in its role)). The behavior below reflects tests from the preceding release. Fixture checks are identified separately from Claude Code checks.

| Area | State | Notes |
| --- | --- | --- |
| Plugin manifest, skills, hooks, MCP discovery | Works | `claude plugin validate --strict` passes; the package ships 1 MCP server, 11 skills, 1 SessionStart hook and no agents (roles run as chats). |
| Loading in a logged-in Claude Code session | **Blocked here** | The build environment has no Claude login, so `/plugin`, `/skills`, `/agents`, `/mcp` and a real subagent run were not exercised against a live host. The first thing to do on a machine that is logged in: follow SETUP.md and run the `create-world` skill. |
| Local MCP server (stdio, 26 tools) | Works (fixture client) | Initialise, tool listing, roots, error handling and every tool are covered by a fixture MCP client. |
| Project verification | Works | The project is the folder Claude Code reports (`CLAUDE_PROJECT_DIR` and/or MCP roots); conflicting, missing, redirected, plugin-folder and copied-store cases are refused. |
| Setup: new folder, existing folder, repeat | Works | New folder needs your confirmation of the exact path. Existing files are untouched; the three core roles are created once; repeating changes nothing. |
| Art | Works | Explicit files or one explicit folder; content-checked (png/jpg/webp/gif); copied inside the project; source paths are not recorded; a custom-art world release carries the copies. |
| Viewer | Works | Loopback only, per project. Operator page and root page render the existing world, Sprints view, world picker, mode, pause, sound and fullscreen controls (checked in headless Chrome). Read-only: it cannot message agents. |
| Verified progress | Works, with limits | Handoff → acknowledge → progress → submit → accept/reject, bound to a one-time token, an instance id and the exact role contract hash. See limits below. |
| Honest unknown/stale states | Works | Missing evidence shows as unconfirmed; old evidence stops showing as working; a broken ledger shows as unavailable. |
| Demo / fixture labelling | Works | The demo viewer is titled "fictional demo". Receipts from any client other than `claude-code` are excluded from the dashboard unless a test-only switch is set. |
| Import / export / merge | Works | Versioned agent, rules and bundle; exact preview first; confirmation before applying; destination mismatch and unsafe paths rejected; same-role updates keep identity and record all baselines with a newer version; clones only on request. |
| Rules (agent, universal, world) | Works | Scopes stay separate. Plugin-scope rules are read-only. Changing a rule changes the role's contract hash. |
| Versions | Works | Plugin, world and each role have separate versions; `status` and the `plugin` skill report them separately. |
| Cleanup | Works | Removes only `.alife-worlds/`, after a verified recovery copy and an exact typed phrase. |
| Package and privacy audit | Works | `scripts/audit-package.mjs` checks the ZIP for credentials, home paths, histories, project state, non-upstream binaries, website/Dot/Sprite-Machine assets, production site config, and that only three roles ship. |

## Limits you should know about

- **Receipts are self-attested.** An MCP call carries no caller identity. A receipt proves that someone holding the one-time token and an instance id minted for that role called the tool inside a Claude Code session; it does not prove which process did. It is not native Claude lifecycle evidence, and the dashboard never claims it is.
- **"Host" labelling depends on the client name** Claude Code reports to MCP servers (`claude-code`). If a different name is reported, receipts are excluded and the dashboard shows agents as unconfirmed rather than wrongly showing activity. This could not be checked against a live host here.
- **Roles are chats, not subagents.** Opening a chat automatically needs the Claude desktop app's session tools (`start_session`, `detach_session`); elsewhere the person clicks + New and the SessionStart hook starts the chat in its queued role.
- **Model, effort and speed are shown as unknown.** The plugin never sets or claims them. Some shipped help text and inherited upstream rule documents still say "Codex"; the Claude host instructions (`roles/CLAUDE-HOST.md`) take precedence.
- **The world renderer is the stock upstream scene.** Your art is attached to the release as assets and shown through the existing approved-art mechanics; this edition does not generate new renderers or art. The world picker names a project by its folder name.
- **Imports of plugin-scope rules** are stored as project overrides; the shipped plugin rules are never edited.
- **The version seal is local.** It records this build's fingerprint so the packaged default world can be served; it is not a public release.
- **Out of scope:** publishing, production deployment, the public website, website Dot, Sprite Machine, and any change to existing host installs.
