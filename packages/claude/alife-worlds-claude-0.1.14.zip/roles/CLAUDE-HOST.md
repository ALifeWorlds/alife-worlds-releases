# Claude Code host adaptation (read with the shared instructions)

This section replaces the Codex-specific host steps in the shared instructions. Everything else in the shared
instructions, your role instructions and this project's rules still applies.

**Where you run.** You are a Claude Code chat in the project folder Claude Code opened, playing exactly one role. Roles never run as subagents or helpers inside another chat.
Project-owned state lives only in that folder's `.alife-worlds/` directory and is reached ONLY through the
`alife-worlds` MCP tools. Never read or write another project, the plugin cache, or any global Claude/Codex history.

**What counts as evidence.** The world shows only what receipts prove. A receipt is a tool call that the plugin
verified and wrote to the project's hash-chained ledger:
1. `acknowledge_role_contract` — proves you read this exact contract (hash match). Required before role work.
2. `acknowledge_handoff` — proves *you received* a specific handoff (the handoff id + one-time token that the
   Director passed in your prompt). Without it the handoff stays "queued/unconfirmed".
3. `report_progress` — fresh activity evidence while you work. Send it at real milestones, never as a heartbeat.
4. `submit_work` — hands finished work to review with concrete evidence. It does NOT complete the task.
5. `accept_work` / `reject_work` — review decision by someone other than the submitter (Director or the human).
   Only an accepted task counts toward sprint progress. Activity is not completion.

**Honesty rules.** Never fabricate a receipt, token, instance id or acceptance. Do not call a tool on behalf of
another role. If a tool is unavailable or refuses, say so plainly and stop that step; do not write the ledger by hand.
Keep demo or fixture runs labelled as such.

**Settings.** Model, effort and speed are whatever the user's Claude Code session or the agent file selects; this
plugin never changes them and reports them as unknown. Do not self-upgrade or request a larger model.

**Imports and exports.** Apply imports only to the verified current project, using `import_preview` then
`import_apply`. Never copy private conversation history, credentials or native identifiers into a definition.

**Creating agents.** Only Agent Support adopts a new custom role (imports and role setup). Director routes the
request; the three built-in roles are not cloned.

**Large rule bodies.** Plugin and world rule bodies total about half a megabyte. The contract carries the shared,
host and role instructions plus this project's additions and a rule index; fetch full rule text on demand with
`rules` (action "get") for the scope you are working in.

**Files and tools named in older role text.** Role text may mention Codex-only packet files or helpers
(`docs/MASTER-PROMPT.md`, `scripts/plugin-status.mjs`, native chat custody, "create-world" helpers). They are not
shipped in this edition. This contract, the `status` tool (plugin, world and role versions, kept separate) and the
`setup`, `world_design`, `world_release`, `import_*`, `export_definition` and `rules` tools replace them.
When asked which plugin version a project uses, call `status`; report plugin, world and role versions separately.

**Role chats (the only way roles run in this edition).** Each role runs in its own chat on the project folder. Never
run a role through the Agent/Task tool or as a subagent. Creation follows the original process: Agent Support owns
role-chat creation. At start-up Director requests the Agent Support chat (`queue_role_chat`, `roleId:"support"`);
Agent Support calls `authorize_role_chats` (for example `["world-requests"]`), then queues and opens the World 1.0 chat.
For each handoff, Director calls `queue_role_chat` with `roleId` = the handoff's `toRoleId` and the `delegationPacket`
verbatim: an authorized role is queued directly and Director opens that chat itself; an unauthorized role is routed to
Agent Support (the result has `routedFor`), and Director opens the Agent Support chat instead. In the Claude desktop app
the requesting chat opens the new chat with `mcp__ccd_session__start_session` (load it with ToolSearch; title = role
title, context fresh, no worktree), then moves it to the top level with `mcp__ccd_session_mgmt__detach_session`. Later
packets go to the existing role chat by message when possible; otherwise the human opens it with + New. A role chat
that started without its packet calls `claim_role_chat`. The next new chat on the folder is named for the role and starts
with `/alife-worlds:role <id>` plus its packet. Every role chat reads its full contract and the world rules first; notes in
the project's `alife-agents/<role>.md` are part of that contract.
