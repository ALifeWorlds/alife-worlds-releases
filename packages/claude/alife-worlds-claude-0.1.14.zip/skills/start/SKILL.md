---
name: start
description: Run /alife-worlds:start by itself for the bundled Anthill. Sets up the current Claude Code project, adds Director, World 1.0 and Agent Support (in a visible alife-agents folder), and starts this chat as Director. Add a world idea to start with a custom world.
---

# ALife Worlds: start

The person wants ALife Worlds set up in **the current project folder** (the folder Claude Code was opened in) in one go. Use the `alife-worlds` MCP tools; never write `.alife-worlds/` files by hand.

World idea from the command: $ARGUMENTS

1. Call `status`.
   - If `setUp` is true: the world already exists. Call `setup` again with the existing project name (it changes nothing except restoring any missing role notes file), then go to step 3.
2. If `setUp` is false: call `setup` for the current folder with `projectName` set to the folder's name and `idea` set to the idea above. If no idea was given, use the packaged default world (`useDefaultWorld: true`) and do not stop to ask. Do not ask about art; artwork can be added later with the `alife-worlds:world` skill.
3. Call `open_viewer` and give the `operatorUrl` link (it opens in a browser on this computer while Claude Code is running).
4. **Name this chat "Director".** Load the app's rename tool with `ToolSearch` (query `select:mcp__ccd_session_mgmt__set_session_title`) and call `mcp__ccd_session_mgmt__set_session_title` with title `Director` (for this current session). If that tool is not available, tell the person they can type `/rename Director`.
5. **This chat becomes the Director.** Follow the `alife-worlds:role` skill's steps for `director` now: `get_role_contract` (`roleId:"director"`), read it all, `acknowledge_role_contract`, keep the `instanceId`, and load the world and universal rules with the `rules` tool. From here on this chat is the Director: it plans and routes and does not do assigned work. Roles run in their own chats, never as subagents or helpers in this chat. Agent Support creates the first role chats (step 6) and approves which roles Director may open directly afterwards. Later handoffs go to the existing role chats by message when the app allows it; otherwise Director queues a new chat for that role (or for Agent Support when the role is not approved yet).
6. **Open the role chats now.** Role chats are created through Agent Support, so: call `queue_role_chat` with `roleId:"support"`, `requestedByRoleId:"director"`, your `instanceId` and packet `Start-up: open the World 1.0 chat for this world. No task yet.`, then open that chat with the app's session tools exactly as the `alife-worlds:role` skill's **Opening the chat** section says (start it, then detach it to the top level), with `initiation:"user_asked"` because the person ran this command. Agent Support then approves World 1.0 chats (`authorize_role_chats`) and opens the World 1.0 chat the same way. The result is three chats in this project folder: Director, Agent Support and World 1.0. If the tools are missing, tell the person to click **+ New** for a Local chat on this folder twice (the first becomes Agent Support, the second World 1.0).
7. Reply briefly with:
   - the world name/version and whether it was created now or already existed;
   - that this chat is now the Director and was renamed "Director" (or, if the rename tool was missing, that they can type `/rename Director`);
   - that the Agent Support and World 1.0 chats were opened (or that they should click + New twice), and how role chats work: Agent Support creates role chats and approves which ones Director can open for later tasks. In the Claude desktop app the requesting chat opens the role chat itself with the app's chat tool (named for the role, same folder); elsewhere they click **+ New** for a Local chat on this folder. Either way the new chat is named for its role and starts in it with its contract and the world rules. Any other new chat in this folder starts as Director;
   - the agents' files are in the visible `alife-agents/` folder (`agentFiles`);
   - the dashboard link;
   - one question: what should we build first? If they have no goal, offer the default goal "Create the world" and, when they agree (or say go), set it and plan the first sprint.

Report only what the tools returned. Never claim a role is active: activity appears only after receipts (Director handoff, then the role chat's acknowledgement).
