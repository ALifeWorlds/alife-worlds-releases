# Setup

> **Runs only in Claude Code.** Use the **Code** tab in the Claude desktop app (a **Local** session on a folder) or the Claude Code terminal. Regular claude.ai chats and claude.ai **Projects** can't run this plugin: they skip its local tools and agents, so nothing happens there.

Requirements: Claude Code (a version with plugin support) and Node.js 20 or newer. The plugin has no npm dependencies and makes no network requests.

## Install it

```bash
claude plugin marketplace add ALifeWorlds/alife-worlds-releases
claude plugin install alife-worlds@alife-worlds
```

Unzip `alife-worlds-claude-0.1.14.zip` into its own folder. From your project folder, run `claude --plugin-dir /absolute/path/to/that/folder`. Check for `alife-worlds` in `/plugin` and `/mcp`, and `alife-worlds:start` in `/skills`. (Roles run as chats, so nothing is listed in `/agents`.)

Validate the folder: `claude plugin validate /absolute/path/to/the/plugin/folder --strict`.

## Update it

**In a Claude Code chat** (desktop Code tab or terminal), send these one at a time:

```text
/plugin marketplace update alife-worlds
/plugin update alife-worlds@alife-worlds
```

**Or in a terminal / PowerShell:**

```sh
claude plugin marketplace update alife-worlds
claude plugin update alife-worlds@alife-worlds
```

On Windows, if PowerShell says `claude` is not recognized, use the full path to `claude.exe` (often `& "$env:USERPROFILE\.local\bin\claude.exe" plugin update alife-worlds@alife-worlds`).

Then **fully quit and reopen Claude** (or exit the terminal session and run `claude` again) and start a new chat. If Claude offers **Update now** for ALife Worlds, you can select that instead. For a ZIP installation, upload the latest Claude ZIP.

## First world

1. Make a **new, empty folder** for your world.
2. In the Claude desktop app, open the **Code** tab, start a **Local** session and choose that folder. (Terminal: open the folder and run `claude`.)
3. Install the plugin once, if you haven't (see **Install it** above). Start a new session after installing.
4. Run this command by itself to start with the bundled Anthill:

   ```text
   /alife-worlds:start
   ```

   This sets up the folder, creates the world, puts notes files for the **Director**, **World 1.0** and **Agent Support** roles in a visible **`alife-agents`** folder inside your project, and opens the world viewer link. Anything you write under "Project notes" in those files is added to that role's rules.
5. **That chat becomes the Director** and renames itself "Director" (in the desktop app; elsewhere type `/rename Director`). It asks what to build first. With no goal, its goal is "Create the world". Say go, and it plans the work.
6. **Each role gets its own chat (never a helper inside another chat).** As in the Codex edition, the Director first brings in **Agent Support**, and Agent Support creates the other role chats such as **World 1.0**. In the Claude desktop app's Code tab this happens right after `/alife-worlds:start`: Director opens the **Agent Support** chat, and Agent Support approves World 1.0 chats and opens the **World 1.0** chat, each named for its role on the same folder and moved to the top level, so the project shows Director, Agent Support and World 1.0 side by side. Later World tasks go to that World 1.0 chat (or Director opens a new World 1.0 chat, since Agent Support approved it). If a chat doesn't appear (for example in the terminal), click **+ New** for a **Local** chat on this same folder (type `go` if it waits). The plugin names each chat for its role ("Agent Support", "World 1.0", ...) and starts it in that role with its full rules and the world rules.
7. **Any other new chat in this folder** is named "Director" and starts as the Director. Type `/alife-worlds:role director`, `/alife-worlds:role support` or `/alife-worlds:role world-requests` to switch a chat's role yourself.

Open the `http://127.0.0.1:…` link Claude gives you in your browser to see the world. It works while that Claude Code session is open. To use your own art, tell the Director which files or folder to use.

## Dashboard without Claude

```bash
node scripts/claude-viewer.mjs --project /absolute/path/to/your/project
node scripts/claude-viewer.mjs --demo        # fictional demo, touches no project
```

The folder must already be set up. Ctrl+C stops it. The viewer reads and displays; it never messages agents.

## Where things live

`<project>/.alife-worlds/` holds the project record, the hash-chained evidence ledger, the plan, rules, role records, copied art, world releases, imports and exports. It is git-ignored. `delete` removes only this folder, after a recovery copy and a confirmation phrase you type.

## Troubleshooting

- *"Claude Code did not report a project folder"*: start Claude Code inside the project folder; the plugin never guesses one.
- *"belongs to a different folder"*: a `.alife-worlds` folder was copied or moved. It is not adopted silently.
- *Tasks never leave Ready*: no verified receipt exists yet. Director must issue a handoff and the assignee must acknowledge it.
- *Package installs / network*: not needed to run the plugin.
