# Setup

Requirements: Claude Code (a version with plugin support) and Node.js 20 or newer. The plugin has no npm dependencies and makes no network requests.

## Load it

From your project folder:

```bash
claude --plugin-dir /absolute/path/to/claude-port
```

or unzip `alife-worlds-claude-0.1.2.zip` into its own folder and point `--plugin-dir` at that folder. Check it loaded: `/plugin` lists `alife-worlds`; `/skills` shows `alife-worlds:create-world` and eight more; `/agents` shows `director`, `world-requests` and `support`; `/mcp` shows the `alife-worlds` server.

Validate the folder: `claude plugin validate /absolute/path/to/claude-port --strict`.

## First world

Ask Claude to run `alife-worlds:create-world`. You choose the current project or a new folder, give an idea in your own words and, optionally, name art files (or one folder) to copy in. Running it again changes nothing. It prints a loopback URL for the dashboard.

## Dashboard without Claude

```bash
node scripts/claude-viewer.mjs --project /absolute/path/to/your/project
node scripts/claude-viewer.mjs --demo        # fictional demo, touches no project
```

The folder must already be set up. Ctrl+C stops it. The viewer reads and displays; it never messages agents.

## Where things live

`<project>/.alife-worlds/` holds the project record, the hash-chained evidence ledger, the plan, rules, role records, copied art, world releases, imports and exports. It is git-ignored. `delete` removes only this folder, after a recovery copy and a confirmation phrase you type.

## Troubleshooting

- *"Claude Code did not report a project folder"*: start Claude Code inside the project folder; the plugin never guesses one.
- *"belongs to a different folder"*: a `.alife-worlds` folder was copied or moved. It is not adopted silently.
- *Tasks never leave Ready*: no verified receipt exists yet. Director must issue a handoff and the assignee must acknowledge it.
- *Package installs / network*: not needed to run the plugin.
