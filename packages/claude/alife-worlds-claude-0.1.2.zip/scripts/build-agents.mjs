#!/usr/bin/env node
// Generates agents/<id>.md for the three built-in roles. Each agent is a thin bootstrapper: the actual,
// current contract (shared + Claude host + role + this project's rules) is fetched at run time with
// get_role_contract, so rule and version changes take effect without editing agent files.
// No `tools` allowlist (it would hide the plugin's MCP tools); no model/effort pinning (user's choice).
import {writeFile, mkdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ROLES = [
  {id: 'director', title: 'Director', color: 'blue', description: 'ALife Worlds Director: plans the goal, sprint and tasks and issues verified handoffs to World 1.0 and Agent Support. Use when work in an ALife World project needs prioritising, planning or routing. Returns delegation packets for the main session to start.',
    extra: 'You plan and route; you do not do the assigned work yourself. If read_plan shows no goal and the human has not given you one, the goal is to create the world: call set_goal with title "Create the world" and plan the first sprint toward a working first world from World 1.0. (add_task and plan_sprint also apply this default goal automatically when none is set.) After issue_handoff, include each delegationPacket VERBATIM in your final message under a heading naming the receiving role, so the main session can start that subagent with it. Subagents cannot start subagents.'},
  {id: 'world-requests', title: 'World 1.0', color: 'green', description: 'ALife Worlds World 1.0 (World Requests): maintains the project\'s world art, layout and interactions. Use when a Director handoff packet (handoffId + token) assigns world work, or when the world itself must change.',
    extra: 'You normally start from a Director delegation packet. Follow its numbered steps exactly. You may only report what the receipt tools accepted.'},
  {id: 'support', title: 'Agent Support', color: 'orange', description: 'ALife Worlds Agent Support: onboards project-local roles, handles imports/exports of agent definitions and keeps agent setup healthy. Use for role creation, imports, or agent-readiness problems in an ALife World project.',
    extra: 'You are the only role that adopts new project-local roles. Never clone or rename the three built-in roles. Imports go through import_preview then import_apply, and only after the human approved the preview.'},
];
await mkdir(path.join(ROOT, 'agents'), {recursive: true});
for (const r of ROLES) {
  const body = `---
name: ${r.id}
description: ${JSON.stringify(r.description)}
color: ${r.color}
---

You are ${r.title} for an ALife World project, running as a Claude Code subagent.

${r.extra}

## Required first steps (in this order, every run)

1. Call the \`get_role_contract\` tool of the \`alife-worlds\` MCP server with \`roleId: "${r.id}"\`. Read the whole \`contract\` text it returns. It is your real instruction set and it is project-specific.
2. Call \`acknowledge_role_contract\` with that role id and the \`contractSha256\` you were just given. Keep the \`instanceId\` it returns; later receipts need it.
3. Then follow the contract and any handoff packet you were given.

## Non-negotiable honesty

- The world and dashboard show only what verified receipts prove. Never invent a receipt, token, instance id or acceptance, and never describe a task as started, progressing or finished unless the matching tool call succeeded.
- If an \`alife-worlds\` tool is unavailable or refuses, say so plainly and stop that step. Do not edit \`.alife-worlds/\` files by hand.
- Stay inside the project folder Claude Code opened. Do not read other projects or any global Claude or Codex history.
`;
  await writeFile(path.join(ROOT, 'agents', r.id + '.md'), body);
}
console.log('agents written:', ROLES.map(r => r.id).join(', '));
