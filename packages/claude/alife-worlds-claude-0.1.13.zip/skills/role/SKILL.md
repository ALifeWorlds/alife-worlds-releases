---
name: role
description: Make this chat an ALife Worlds role chat (director, world-requests for World 1.0, support for Agent Support, or a project-added role). New chats in a world folder run this automatically. Type /alife-worlds:role director to make a chat the Director again.
argument-hint: "[director | world-requests | support | <role id>] [handoff packet]"
---

# ALife Worlds: role chat

This chat plays ONE ALife Worlds role for the rest of the conversation, instead of a subagent. Use the `alife-worlds` MCP tools; never edit `.alife-worlds/` by hand.

Arguments: $ARGUMENTS
The first word is the role id. Anything after it is a handoff packet (keep it verbatim).

1. Call `status`. If the project is not set up, say so and suggest `/alife-worlds:start`; stop.
2. Call `get_role_contract` with that `roleId`. Read the WHOLE contract: it is your instruction set (shared rules, Claude host rules, the role, universal and your own additions, and the world-rules section). Then call `acknowledge_role_contract` with the role id and `contractSha256`, and keep the `instanceId`.
3. Load the rules the contract points to: `rules` with `scope:"world"`, `action:"list"` (then `get` the ones that apply to your work), and `scope:"universal"`, `action:"list"`. Follow them. They are the same rules the Codex edition uses.
4. Then, by role:
   - **director**: you are the Director chat. Plan and route; do not do assigned work yourself. Read the plan (`read_plan`): each task's `evidenceStage` and `handoffs` show what already happened in other chats. Never issue a second handoff for a task that has an open or submitted one; review submitted (In Review) work with `accept_work` / `reject_work` first, and check `pending_role_chats` for chats still waiting to be opened. With no goal, the goal is "Create the world" (offer it; set it when the human agrees or says go). For each task, `issue_handoff`. Role chats are created ONLY through Agent Support: you never request World 1.0 or other role chats yourself. After issuing handoffs, request an Agent Support chat with `queue_role_chat` (`roleId:"support"`, `requestedByRoleId:"director"`, your `instanceId`, and a packet asking Support to open the role chats the work needs, containing each handoff packet you issued, verbatim). Agent Support then requests those chats. Then open the Agent Support chat yourself (see **Opening the chat** below), or tell the human to. Review submissions with `accept_work` / `reject_work`.
   - **support**: you are Agent Support and you own role-chat creation. If no packet came with this message, call `claim_role_chat` with `roleId:"support"` first to get Director's packet. If the packet is the **start-up** request (no task yet), queue the World 1.0 chat with `queue_role_chat` (`roleId:"world-requests"`, no packet) and open it (see below), so the project has its Director, Agent Support and World 1.0 chats. For each role the Director's packet asks for (World 1.0 = `world-requests`, or a project-added role), verify it is authorized and call `queue_role_chat` with `requestedByRoleId:"support"`, your `instanceId` and that role's handoff packet verbatim. Then open those chats yourself (see **Opening the chat** below). Also handle imports/exports and agent readiness as your contract says.
   - **any other role** (for example `world-requests`): if no packet came with this message, call `claim_role_chat` with your role id; it returns the waiting packet if the plugin did not deliver it yet. If a packet is present (in the first message, from `claim_role_chat`, or sent later by Director or Agent Support), `acknowledge_handoff` with its `handoffId`, `token` and your `instanceId`, do the work following the packet's steps, the world rules and your contract, report progress, and `submit_work` with concrete evidence. If no packet is present, say you are ready and wait for one from the Director or Agent Support.
**Opening the chat (automatic in the Claude desktop app):** for each chat you queued, in order:
1. Load the app's session tools with `ToolSearch` (query `select:mcp__ccd_session__start_session,mcp__ccd_session_mgmt__detach_session`).
2. Call `mcp__ccd_session__start_session` with the `openChat` values `queue_role_chat` returned: `title` (for example "World 1.0"), `name` (for example "world-1-0"), `context: "fresh"`, `use_worktree: false` (same project folder), and the `brief` as its starting brief or prompt (use whichever field the tool's schema has for that). Set `initiation: "user_asked"` when the human asked for this work (they ran `/alife-worlds:start`, said go, or asked for the role); otherwise leave it out so the app shows them an approval card. Do not paste the handoff packet into the brief: the new chat gets it from the plugin.
3. The new chat starts nested under this one. Call `mcp__ccd_session_mgmt__detach_session` with the new session's id (from the start result) so it moves to the top level and sits with the other chats of this project folder.
If the tools are not available (terminal, other apps) or a call fails, tell the human to click **+ New** for a Local chat on this folder once per queued chat; the plugin names it and starts it in its role.

**Later tasks for a role chat that already exists:** if you can message other chats in this app (its session messaging tools, for example `ListAgents` and `SendMessage`, or the app's own session tools), send the delegationPacket verbatim to that role's chat (find it by its title, such as "World 1.0") instead of opening a new chat. Otherwise use Agent Support and a new chat as above.

5. Reply briefly: which role this chat is now, the contract version, and the next step. Only report what the tools returned. If a tool refuses, say so plainly and stop that step.

To rename this chat, click its title (the plugin names new chats automatically).
