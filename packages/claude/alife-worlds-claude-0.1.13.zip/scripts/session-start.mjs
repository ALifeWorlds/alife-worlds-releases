#!/usr/bin/env node
// SessionStart hook (only in project folders ALife Worlds already set up; does nothing anywhere else).
//  1. Refresh .claude/agents/ from the visible alife-agents/ folder (creating it once for older projects).
//  2. Remove the "agent": "director" setting earlier versions added (role chats replaced subagents).
//  3. For a brand-new chat: if Agent Support requested a role chat, give this chat that role's title and first
//     message (/alife-worlds:role <id> + handoff packet); otherwise name it "Director" and start it as Director.
// Never blocks a session: any failure prints nothing and exits 0.
import path from 'node:path';
import {lstat} from 'node:fs/promises';
import {exactDirectory} from '../lib/claude/fsx.mjs';
import {FILES} from '../lib/claude/constants.mjs';
import {syncVisibleAgents, ensureVisibleAgents, VISIBLE_AGENTS_DIR} from '../lib/claude/agent-sync.mjs';
import {removeDirectorAgentSetting} from '../lib/claude/setup.mjs';
import {takeNextRoleChat} from '../lib/claude/chat-queue.mjs';

const readStdin = () => new Promise(res => { let b = ''; process.stdin.setEncoding('utf8'); process.stdin.on('data', c => { b += c; if (b.length > 1e6) b = ''; }); process.stdin.on('end', () => res(b)); process.stdin.on('error', () => res('')); setTimeout(() => res(b), 2000); });
let out = null;
try {
  let input = {}; try { input = JSON.parse(await readStdin() || '{}'); } catch {}
  const dir = process.env.CLAUDE_PROJECT_DIR || input.cwd;
  if (dir) {
    const root = await exactDirectory(dir);
    const rec = await lstat(path.join(root, FILES.project)).catch(() => null);
    if (rec?.isFile()) {
      if (!(await lstat(path.join(root, VISIBLE_AGENTS_DIR)).catch(() => null))) await ensureVisibleAgents(root);
      await syncVisibleAgents(root);
      await removeDirectorAgentSetting(root);
      if ((input.source || 'startup') === 'startup') {
        const next = await takeNextRoleChat(root);
        out = next
          ? {sessionTitle: next.title, initialUserMessage: '/alife-worlds:role ' + next.roleId + (next.packet ? '\n\n' + next.packet : '')}
          : {sessionTitle: 'Director', initialUserMessage: '/alife-worlds:role director'};
      }
    }
  }
} catch { out = null; }
if (out) process.stdout.write(JSON.stringify({hookSpecificOutput: {hookEventName: 'SessionStart', ...out}}) + '\n');
process.exit(0);
