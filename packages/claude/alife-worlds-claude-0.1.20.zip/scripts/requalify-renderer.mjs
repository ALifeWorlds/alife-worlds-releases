#!/usr/bin/env node
// Maintainer step after changing an approved world scene file (agent-outpost.js / .css / colony-art.js):
// re-sync the approved copies in web/launcher-world113/, regenerate manifest fingerprints and artifactSha256, and update
// PREVIEW_DESCRIPTOR / MANIFEST_SHA256 in lib/world-preview.mjs. The release check (default-world-check) must then pass.
import path from 'node:path';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sha = b => createHash('sha256').update(b).digest('hex');
const pairs = [['agent-outpost.js', 'renderer', 'web/agent-outpost/agent-outpost.js', 'web/launcher-world113/renderer.js'], ['colony-art.js', 'art', 'web/agent-outpost/colony-art.js', 'web/launcher-world113/art.js'], ['agent-outpost.css', 'css', 'web/agent-outpost/agent-outpost.css', 'web/launcher-world113/renderer.css']];
const mp = path.join(ROOT, 'web/launcher-world113/manifest.json');
const m = JSON.parse(await readFile(mp, 'utf8'));
for (const [input, key, src, copy] of pairs) {
  const data = await readFile(path.join(ROOT, src));
  await writeFile(path.join(ROOT, copy), data);
  m.sourceInputs[input] = sha(data); m.assets[key].sha256 = sha(data); m.assets[key].bytes = data.length;
}
const oldArtifact = m.artifactSha256; delete m.artifactSha256;
m.artifactSha256 = sha(JSON.stringify(m));
const text = JSON.stringify(m, null, 2) + '\n';
await writeFile(mp, text);
const wp = path.join(ROOT, 'lib/world-preview.mjs');
let w = await readFile(wp, 'utf8');
w = w.replaceAll(oldArtifact, m.artifactSha256).replace(/const MANIFEST_SHA256='[0-9a-f]{64}'/, `const MANIFEST_SHA256='${sha(Buffer.from(text))}'`);
await writeFile(wp, w);
console.log(JSON.stringify({artifactSha256: m.artifactSha256, manifestSha256: sha(Buffer.from(text))}));
