#!/usr/bin/env node
// Build the distributable ZIP from exactly the sealed payload file list (never tests, dev tools, project
// state, runtime folders or website assets). Dependency-free; entries are stored at the plugin root so the
// extracted folder is a Claude Code plugin directory.  node scripts/package-zip.mjs [--out <file.zip>]
import path from 'node:path';
import {readFile, writeFile, mkdir, stat} from 'node:fs/promises';
import {deflateRawSync, crc32} from 'node:zlib';
import {parseArgs} from 'node:util';
import {fileURLToPath} from 'node:url';
import {collectPackageInputs, checkPluginVersion, readPluginManifests} from '../lib/plugin-version.mjs';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const {values} = parseArgs({options: {out: {type: 'string'}}});
{ const {checkPackagedDefaultWorld} = await import('../lib/claude/default-world-check.mjs');
  const dw = await checkPackagedDefaultWorld(ROOT); if (!dw.ok) { console.error('Default world check failed:\n- ' + dw.problems.join('\n- ')); process.exit(1); } }
const state = await checkPluginVersion(ROOT);
if (state.releaseState !== 'released') { console.error('Refusing to package an unsealed build. Run: node scripts/seal-local.mjs'); process.exit(1); }
const {version} = await readPluginManifests(ROOT);
const files = (await collectPackageInputs(ROOT)).sort();
const out = path.resolve(values.out || path.join(ROOT, '..', 'dist', 'alife-worlds-claude-' + version + '.zip'));
const DOS_TIME = 0, DOS_DATE = ((2026 - 1980) << 9) | (1 << 5) | 1;      // fixed 2026-01-01: reproducible
const parts = [], central = []; let offset = 0;
for (const rel of files) {
  const data = await readFile(path.join(ROOT, rel)), name = Buffer.from(rel, 'utf8'), packed = deflateRawSync(data, {level: 9}), crc = crc32(data) >>> 0;
  const exec = rel.startsWith('scripts/') || rel === 'mcp/server.mjs', mode = (exec ? 0o100755 : 0o100644) << 16 >>> 0;
  const local = Buffer.alloc(30); local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x0800, 6); local.writeUInt16LE(8, 8); local.writeUInt16LE(DOS_TIME, 10); local.writeUInt16LE(DOS_DATE, 12); local.writeUInt32LE(crc, 14); local.writeUInt32LE(packed.length, 18); local.writeUInt32LE(data.length, 22); local.writeUInt16LE(name.length, 26);
  parts.push(local, name, packed);
  const cd = Buffer.alloc(46); cd.writeUInt32LE(0x02014b50, 0); cd.writeUInt16LE(0x031e, 4); cd.writeUInt16LE(20, 6); cd.writeUInt16LE(0x0800, 8); cd.writeUInt16LE(8, 10); cd.writeUInt16LE(DOS_TIME, 12); cd.writeUInt16LE(DOS_DATE, 14); cd.writeUInt32LE(crc, 16); cd.writeUInt32LE(packed.length, 20); cd.writeUInt32LE(data.length, 24); cd.writeUInt16LE(name.length, 28); cd.writeUInt32LE(mode, 38); cd.writeUInt32LE(offset, 42);
  central.push(cd, name); offset += 30 + name.length + packed.length;
}
const cdSize = central.reduce((n, b) => n + b.length, 0), end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cdSize, 12); end.writeUInt32LE(offset, 16);
await mkdir(path.dirname(out), {recursive: true});
await writeFile(out, Buffer.concat([...parts, ...central, end]));
console.log(JSON.stringify({zip: out, entries: files.length, bytes: (await stat(out)).size, version, contentFingerprint: state.contentFingerprint}, null, 2));
