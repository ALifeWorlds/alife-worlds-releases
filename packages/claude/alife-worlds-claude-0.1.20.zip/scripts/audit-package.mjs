#!/usr/bin/env node
// Privacy / package audit of a plugin folder or ZIP.  node scripts/audit-package.mjs <folder-or-zip>
// Fails (exit 1) on: credentials, home-directory paths, chat histories, project state, non-upstream binaries
// (user art), website/Dot/Sprite-Machine assets, production site config, Codex-only manifests, or any role
// set other than the three built-ins.
import path from 'node:path';
import os from 'node:os';
import {readFile, readdir, lstat, mkdtemp, rm} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const target = process.argv[2];
if (!target) { console.error('usage: audit-package.mjs <folder-or-zip>'); process.exit(2); }
let root = path.resolve(target), cleanup = null;
if (root.endsWith('.zip')) {
  const tmp = await mkdtemp(path.join(os.tmpdir(), 'alife-audit-')); cleanup = tmp;
  const r = spawnSync('unzip', ['-q', root, '-d', tmp]); if (r.status !== 0) { console.error('unzip failed: ' + r.stderr); process.exit(2); }
  root = tmp;
}
const findings = [], notes = [];
{ const {checkPackagedDefaultWorld} = await import('../lib/claude/default-world-check.mjs');
  const dw = await checkPackagedDefaultWorld(root); if (dw.ok) notes.push('default world: passes the viewer qualification (ownerPreviewProfileMatches)'); else findings.push(...dw.problems); }
const walk = async (d, out = []) => { for (const e of await readdir(d, {withFileTypes: true})) { const f = path.join(d, e.name); if (e.isSymbolicLink()) { findings.push('symlink: ' + path.relative(root, f)); continue; } if (e.isDirectory()) await walk(f, out); else out.push(f); } return out; };
const files = await walk(root), rel = f => path.relative(root, f).replaceAll('\\', '/');
const prov = JSON.parse(await readFile(path.join(root, 'UPSTREAM-PROVENANCE.json'), 'utf8')), upstream = new Map(prov.files.map(f => [f.file, f.sha256]));
const TEXT = /\.(mjs|js|cjs|json|md|css|html|txt|svg|cmd|yaml|yml|toml)$/i, BINARY_OK = /\.(png|mp3|ttf|woff2?)$/i;
const SECRET = [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, /\bAKIA[0-9A-Z]{16}\b/, /\bghp_[A-Za-z0-9]{30,}\b/, /\bgithub_pat_[A-Za-z0-9_]{30,}\b/, /\bsk-[A-Za-z0-9]{32,}\b/, /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/, /\bsk-ant-[A-Za-z0-9_-]{20,}\b/, /\bCLOUDFLARE_API_TOKEN\s*=\s*\S+/];
const HOME = [/\/home\/[a-z_][a-z0-9_-]*\//i, /\/Users\/[A-Za-z0-9._-]+\//, /[A-Za-z]:\\Users\\[A-Za-z0-9._-]+\\/];
const BAD_NAME = [/(^|\/)\.env(\..*)?$/, /\.pem$|\.p12$|\.pfx$|id_rsa|id_ed25519/, /credentials?\.json$/i, /(^|\/)\.alife-worlds(\/|-recovery)/, /(^|\/)\.codex(\/|$)|\.codex-plugin/, /(^|\/)\.claude\/(projects|history|settings\.local)/, /rollout-.*\.jsonl$/, /sprite-?machine/i, /public-site-guide/, /(^|\/)docs\/media(\/|$)/, /(^|\/)(wrangler\.toml|\.dev\.vars|site\.config\.json)$/, /(^|\/)node_modules(\/|$)/, /(^|\/)tests?\//, /(^|\/)dev\//, /(^|\/)runtime(\/|$)/, /\.jsonl$/];
for (const f of files) {
  const r = rel(f);
  for (const re of BAD_NAME) if (re.test(r)) findings.push('forbidden path: ' + r);
  const bytes = await readFile(f);
  if (!TEXT.test(r) && !BINARY_OK.test(r) && !['LICENSE', '.gitattributes'].includes(r)) findings.push('unexpected file type: ' + r);
  if (BINARY_OK.test(r) && createHash('sha256').update(bytes).digest('hex') !== upstream.get(r)) findings.push('binary/art not byte-identical to the recorded upstream baseline (possible user art): ' + r);
  if (/\.(svg)$/i.test(r) && createHash('sha256').update(bytes).digest('hex') !== upstream.get(r)) findings.push('svg not byte-identical to upstream: ' + r);
  if (TEXT.test(r)) {
    const text = bytes.toString('utf8');
    for (const re of SECRET) if (re.test(text)) findings.push('credential-like text in ' + r);
    for (const re of HOME) { const m = re.exec(text); if (m) findings.push('home path (' + m[0] + ') in ' + r); }
  }
}
const roles = JSON.parse(await readFile(path.join(root, 'data/roles.json'), 'utf8')).map(x => x.id).sort();
if (JSON.stringify(roles) !== JSON.stringify(['director', 'support', 'world-requests'])) findings.push('data/roles.json must hold exactly director, support, world-requests; found ' + roles.join(','));
// Roles run only in their own chats (0.1.14+): the package ships no subagent definitions.
if (await lstat(path.join(root, 'agents')).then(() => true, () => false)) findings.push('agents/ must not be shipped: roles run in their own chats, not as subagents');
const rolesDir = (await readdir(path.join(root, 'roles'))).sort();
if (JSON.stringify(rolesDir) !== JSON.stringify(['CLAUDE-HOST.md', 'SHARED.md', 'director.md', 'support.md', 'world-requests.md'])) findings.push('roles/ contents unexpected: ' + rolesDir.join(','));
const manifest = JSON.parse(await readFile(path.join(root, '.claude-plugin/plugin.json'), 'utf8'));
if (manifest.name !== 'alife-worlds') findings.push('manifest name');
for (const must of ['LICENSE', 'THIRD_PARTY_NOTICES.md', 'BRANDING.md']) { try { await lstat(path.join(root, must)); } catch { findings.push('missing ' + must); } }
const branding = await readFile(path.join(root, 'server.mjs'), 'utf8');
if (!branding.includes('Created by Itzel Juarez')) findings.push('original creator credit missing from the viewer server');
notes.push(files.length + ' files scanned', 'roles: ' + roles.join(', '), 'agents: none (roles run in their own chats)');
if (cleanup) await rm(cleanup, {recursive: true, force: true});
console.log(JSON.stringify({target, ok: findings.length === 0, notes, findings}, null, 2));
process.exitCode = findings.length ? 1 : 0;
