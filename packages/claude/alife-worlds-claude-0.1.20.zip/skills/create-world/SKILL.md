---
name: create-world
description: Set up an ALife World in this project, or a brand-new project folder, from an idea and optional artwork, then open the local dashboard. Idempotent; never touches your existing files.
---

# ALife Worlds: create-world

Use the `alife-worlds` MCP tools. Do not write `.alife-worlds/` files by hand.

1. Call `status`. If `setUp` is true, tell the person the world already exists, show its versions, and offer to open the viewer (`open_viewer`) or customise it (the `world` skill). Do not re-run setup over it.
2. Ask, in one short question, whether this is the **current project** or a **new project folder** (use AskUserQuestion when available). A new folder needs an exact absolute path the person chooses; call `new_project_folder` with it, show the returned path and ask if they agree, and only then repeat the call with the returned `confirmToken`.
3. Ask for the world idea in their own words if they did not give one. Artwork is optional: use only files, or one folder, that the person explicitly names. Never browse their home folder, downloads or other projects to look for art. Art is copied *into* the project; originals are not changed.
4. Call `setup` with `projectName`, `idea`, `art` (each `{kind:"file"|"folder", path}`) and, for a new folder, `newProjectFolder`. It creates the three built-in roles (Director, World 1.0, Agent Support), adds an editable notes file for each in the project's visible `alife-agents/` folder (`director.md`, `world-requests.md`, `support.md`; files that already exist are kept, never overwritten; anything written under "## Project notes" becomes part of that role's contract), saves the idea and prepares world 1.0.0. Running it again changes nothing except restoring a missing notes file. Roles run in their own chats, never as subagents: it removes old plugin copies from `.claude/agents/` and any `"agent": "director"` setting older versions added (`chatAgent`). Tell the person which notes files were created or kept (`agentFiles`), and that the next new chat in this folder starts as Director (or run `/alife-worlds:start`).
5. Call `open_viewer` and give the person the `operatorUrl` / `dashboardUrl` (loopback only). `open_viewer` with `demo:true` shows a clearly marked fictional demo instead.
6. If a new folder was created, tell them to start Claude Code inside it so the agents work there.

Report only what the tools returned. If the world says it needs a sealed local build, say that plainly. Never claim an agent is active: activity appears only after receipts (Director handoff → World acknowledgement).
