---
name: commands
description: Show the ALife Worlds skill menu with short descriptions and example requests. Read-only help; changes nothing.
---

# ALife Worlds: commands

Show this menu (Claude Code lists plugin skills as `/alife-worlds:<name>`; the person can type that slash command or just describe what they want):

| Skill | Use it to |
| --- | --- |
| `start` | One step: set up this folder, open the Agent Support and World 1.0 chats, and World 1.0 builds the world (`/alife-worlds:start your idea`) |
| `role` | Make this chat a role chat: `/alife-worlds:role director`, `world-requests` (World 1.0) or `support` (Agent Support). New chats in a world folder do this automatically |
| `create-world` | Set up a world in this project or a new folder, from an idea and optional art |
| `world` | **World scope**: open the dashboard, change the idea, art or background, publish a new world version, edit this world's rules (`/alife-worlds:world new city background`). Never changes the plugin |
| `import` | Import an agent, world or plugin-rules definition with a preview and a merge for same-role updates |
| `export` | Save an agent, rules or a bundle as a portable definition file |
| `rule` / `agent` | **Agent scope**: rules for the role this chat plays only (`/alife-worlds:agent always answer in Spanish`) |
| `universal` | Rules for every role in this project |
| `plugin` | **Plugin scope**: versions, plugin rules, and plugin-wide rule changes for every world and chat on this computer (`/alife-worlds:plugin <change>`) |
| `delete` | Plan removing this plugin's own state (needs an exact typed confirmation) |
| `commands` | This menu |

How work flows: the **Director** chat plans a goal, sprint and tasks and issues a handoff; the packet goes to that role's own chat (Director opens the **Agent Support** and **World 1.0** chats first; Agent Support approves new roles); the assignee acknowledges and submits evidence; a reviewer other than the submitter accepts. The dashboard shows only what those receipts prove. This skill changes nothing.
