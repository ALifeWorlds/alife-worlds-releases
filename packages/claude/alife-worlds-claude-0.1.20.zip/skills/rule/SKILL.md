---
name: rule
description: Agent scope. List, read or change rules for the role this chat plays only (/alife-worlds:rule <change>; same as /alife-worlds:agent). Not other roles, not the world, not the plugin.
---

# ALife Worlds: rule (this chat's role)

Change requested with the command: $ARGUMENTS

Scope: **the role this chat plays** (Director, World 1.0, Agent Support or a project-added role) in this project only. It does not change other roles, the world, or the plugin. Rules for every role use `/alife-worlds:universal`; world rules `/alife-worlds:world`; plugin-wide rules `/alife-worlds:plugin`.

1. Find this chat's role: the role this chat took with `/alife-worlds:role <id>` (or that the plugin started it in). Use that `roleId` without asking. Only if this chat has no role yet, ask which role (or offer `/alife-worlds:role`). If the person names another role explicitly, use that one.
2. List: `rules` with `action:"list"`, `scope:"agent"`, `roleId`. Read one: `action:"get"` with its `id`.
3. To add or change: write it as one rule (`id` as a lowercase slug, `title`, `text`), show the exact text and that it applies only to this role, and save after the person agrees with `action:"set"`, `scope:"agent"`, `roleId`, `id`, `title`, `text`, `expectedRevision` from the list.
4. The change takes effect when the role next reads its contract: in this chat, call `get_role_contract` and `acknowledge_role_contract` again now so it applies right away.
