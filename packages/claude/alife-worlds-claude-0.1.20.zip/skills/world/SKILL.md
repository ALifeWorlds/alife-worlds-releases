---
name: world
description: World scope. View or change this project's world (idea, art, background, new world version) or its world rules (/alife-worlds:world <change>). Never changes the plugin.
---

# ALife Worlds: world (this world)

Change requested with the command: $ARGUMENTS

Scope: **this project's world only**. World changes are saved in this project (`.alife-worlds/`) and shipped as a new world version; they never edit or count as plugin changes. Any role chat or the person may change the world (universal rule `world-editing.open-world-editing`); keep one chat editing at a time. Start with `status` (world, plugin and role versions are separate numbers).

- **View**: `open_viewer` (loopback only) and share the URL.
- **Change the look (idea, art, background)**: copy the art in with `world_design` (`idea` and/or `art`: explicit files or one folder the person named). For a new outdoor background pass `background` with that art's id (an art file named like `background`, `backdrop` or `skyline` is used automatically; `background:"none"` goes back to the standard scenery). Then publish it with `world_release` using the next version (for example 1.0.1 to 1.0.2) and a one-line `summary`. The viewer switches to the new version by itself; reload the page to see it. A saved design without a new release is not shown (the viewer then reports that the design differs from the release).
- **New version**: `world_release` with a new, higher `version`. An existing version is immutable.
- **World rules**: `rules` with `scope:"world"`: `list`, `get` (full text) or `set` (id, title, text). Show the exact text before saving. World rules are stored in this project only.
- The world's drawing code itself is shared by the plugin. A change that needs new drawing behavior (not new art, background, idea or rules) is a plugin change: say so and point to `/alife-worlds:plugin` or a new plugin version instead of editing plugin files.

Selecting this skill does not create agents or start a new setup. For a new world in a different folder use `create-world`.
