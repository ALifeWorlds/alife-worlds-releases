---
name: plugin
description: Plugin scope. Show ALife Worlds plugin, world and role versions, list plugin rules, or add or change a plugin-wide rule that applies to every world and chat (/alife-worlds:plugin <change>).
---

# ALife Worlds: plugin (whole plugin)

Change requested with the command: $ARGUMENTS

Scope: **the whole plugin**: every world and every chat that uses ALife Worlds on this computer. Only this command changes plugin scope. World changes belong to `/alife-worlds:world`, rules for one chat's role to `/alife-worlds:rule` (also `/alife-worlds:agent`).

- **No change given:** call `status` and report as **separate** things the plugin version (and the upstream ALife Worlds baseline), the project's world version, and each role's version; whether the evidence ledger passed its integrity check and whether a viewer is running. Then list plugin rules: `rules` with `scope:"plugin"`, `action:"list"` (`get` for full text).
- **A change was given:** read the current plugin rules first (`list`, then `get` the ones it touches). Rewrite the request as one rule (id as a lowercase slug, title, text in "When this applies / Required behavior / Safety and failure behavior" form) without broadening it. Show the person the exact rule and say that it applies to every world and chat on this computer, then save it after they agree with `rules` `action:"set"`, `scope:"plugin"`, `id`, `title`, `text` (pass `expectedRevision` from the list). It is stored in the plugin's own data folder (kept when the plugin updates) and every role chat gets it in its contract from its next contract read. The shipped plugin files are never edited.
- If saving reports `PLUGIN_DATA_UNAVAILABLE`, say so plainly: this Claude Code did not give the plugin a data folder.

Do not claim the project's runtime was updated because a newer plugin is installed, and do not check for or install updates unless the person asks. Unknown stays unknown.
