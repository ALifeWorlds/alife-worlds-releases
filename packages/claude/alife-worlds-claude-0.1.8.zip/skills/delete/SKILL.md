---
name: delete
description: Plan removing this plugin's own state folder (.alife-worlds) from the project. Nothing is deleted without a verified recovery copy and the exact confirmation phrase you type.
---

# ALife Worlds: delete

This can only ever remove the plugin's own `.alife-worlds/` folder in the verified current project. It never touches your other files, other projects, installed plugins or cloud resources.

1. Call `cleanup_plan`. It changes nothing and returns the scope, file count, size and a one-time confirmation phrase.
2. Tell the person exactly what would be removed and that a full recovery copy is made first, inside the project but outside the removed folder.
3. If they want to proceed, ask them to type the exact `confirmationPhrase` themselves. A general "yes", a menu choice or a timeout is not the confirmation.
4. Call `cleanup_apply` with the plan's `inventorySha256` and the phrase they typed. If the folder changed since the plan, it refuses and you plan again.

After removal, tell them where the recovery folder is. They delete it themselves when they no longer need it.
