---
name: export
description: Export an agent, the world rules, or a world bundle as a portable definition file inside this project, keeping its current version and complete authored rules.
---

# ALife Worlds: export

Ask what to export if it is unclear: one agent (which role), world or plugin rules, or a bundle.

Call `export_definition` with `kind` `agent` (plus `roleId`), `rules` (plus `scope` world or plugin) or `bundle`. The file is written inside this project under `.alife-worlds/exports/`; tell the person that path. For an agent, keep the returned `definitionSha256`: it is the baseline for a later `import_merge`.

An export is a portable definition, not an installed plugin or a deployed world. It contains no chats, receipts, tokens, credentials or machine paths. If the person wants it somewhere else, they can copy the file themselves; do not move it outside the project unless they name the destination.
