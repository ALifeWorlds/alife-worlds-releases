---
name: world
description: View or customise this project's ALife World: open the dashboard, change the idea or art, prepare a new world version, or list and change world rules.
---

# ALife Worlds: world

This works on the verified current project only. Start with `status` to see the world, plugin and role versions (they are separate numbers).

- **View**: `open_viewer` (loopback only) and share the URL.
- **Change the idea or art**: `world_design` with the new `idea` and/or `art` (explicit files or one explicit folder the person named). This saves the design but publishes nothing.
- **New version**: `world_release` with a new, higher `version` (for example 1.0.1) and a one-line `summary`. An existing version is immutable; asking for the same version with different content is refused.
- **World rules**: `rules` with `scope:"world"` — action `list`, `get` (full text) or `set` (id, title, text). Show the person the exact rule text before you save it. To share rules use the `export` skill.

Selecting this skill does not create agents or start a new setup. For a new world in a different folder use `create-world`.
