---
name: import
description: Import an agent, world or plugin-rules definition into this project. Shows an exact preview first, keeps incoming versions, and merges same-role updates instead of replacing them.
---

# ALife Worlds: import

Imports only ever apply to the verified current project and only after the person approves an exact preview.

1. Get the definition from the person: pasted text, or a file inside this project's `.alife-worlds/` folder (`projectFile`). Never read paths outside the project. A plain prompt needs its scope (`kind`: world, plugin or agent).
2. Call `import_preview`. Nothing changes. Show the person: the rule effects, any role that would be added, and every item under `requiredReview`.
3. Resolve each review item with them, then call `import_preview` again with their choices in `review` (same `requestId`). For a role: `stage` (add it as a project-local role), `skip`, or `reuse` when an identical role already exists.
4. When `ready` is true and the person approves, call `import_apply` with `planSha256` and `humanConfirmed:true`. A plan for another project, or one that went stale, is rejected.
5. **Same role already exists** (including the three built-in roles): do not replace it. Use `import_merge` with the common base (a baseline hash this project stored, or the base definition) and the incoming definition. It keeps the role's identity, records all three baselines and produces a version newer than both. If it reports conflicts, ask the person which side to keep for each and repeat with `resolutions`. A separate copy is made only when the person explicitly asks (`cloneAs`).

Imported roles are staged for this project only and are not active until they read their contract. Do not import or paste private chats, credentials or tokens.
