---
name: rule
description: List, read or change rules that apply to ONE agent role in this project (not other agents, not the world).
---

# ALife Worlds: rule

Agent-scope rules belong to a single role. Confirm which role (director, world-requests, support, or a project-added role).

- List: `rules` with `action:"list"`, `scope:"agent"`, `roleId`.
- Read one: `action:"get"` with the rule `id`.
- Save: `action:"set"` with `roleId`, `id` (lowercase slug), `title`, `text`. Show the person the exact text first and save only after they agree. Pass `expectedRevision` from the list so you do not overwrite a newer change.

The change takes effect when that role next reads its contract (`get_role_contract` shows a new hash). Rules for all agents use `universal`; the world's rules use `world`; shared plugin rules are read-only.
