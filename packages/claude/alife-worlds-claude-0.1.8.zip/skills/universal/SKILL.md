---
name: universal
description: List, read or change instructions inherited by EVERY agent in this project (the universal agent additions).
---

# ALife Worlds: universal

Universal additions apply to all roles in this project, including project-added ones. Use `rules` with `scope:"universal"`: `list`, `get`, or `set` (`id`, `title`, `text`, optional `expectedRevision`).

Because this affects every agent, show the person the exact text and which roles it reaches (`status` lists the roles) before saving. For one role only, use the `rule` skill; for world design rules, `world`. Roles pick the change up the next time they read their contract.
