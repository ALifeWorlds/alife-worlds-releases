---
name: plugin
description: Show ALife Worlds plugin, world and agent-role versions and this project's setup state; list the read-only shared plugin rules.
---

# ALife Worlds: plugin

Call `status` and report these as **separate** things: the plugin version (and the upstream ALife Worlds baseline it was ported from), the project's world version, and each role's version. Also report whether the evidence ledger passed its integrity check and whether a viewer is running.

Plugin-scope rules are shipped with the plugin and are read-only here: `rules` with `scope:"plugin"` and `list` or `get`. A project can carry an imported plugin-rules definition through the `import` skill; the plugin files themselves are not edited.

Do not claim the project's runtime was updated because a newer plugin is installed, and do not check for or install updates unless the person asks. Unknown stays unknown.
