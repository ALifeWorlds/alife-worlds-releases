---
name: start
description: Run /alife-worlds:start by itself for the bundled Anthill. Sets up the current Claude Code project, adds Director, World 1.0 and Agent Support (in a visible alife-agents folder), and starts this chat as Director. Add a world idea to start with a custom world.
---

# ALife Worlds: start

The person wants ALife Worlds set up in **the current project folder** (the folder Claude Code was opened in) in one go. Use the `alife-worlds` MCP tools; never write `.alife-worlds/` files by hand.

World idea from the command: $ARGUMENTS

1. Call `status`.
   - If `setUp` is true: the world already exists. Call `setup` again with the existing project name (it changes nothing except restoring any missing agent file and refreshing the agent copies), then go to step 3.
2. If `setUp` is false: call `setup` for the current folder with `projectName` set to the folder's name and `idea` set to the idea above. If no idea was given, use the packaged default world (`useDefaultWorld: true`) and do not stop to ask. Do not ask about art; artwork can be added later with the `alife-worlds:world` skill.
3. Call `open_viewer` and give the `operatorUrl` link (it opens in a browser on this computer while Claude Code is running).
4. **This chat becomes the Director.** Setup set `"agent": "director"` in `.claude/settings.json` (see `chatAgent`; if it reports `kept-other-agent`, say which agent the folder already starts as and do not change it). New chats opened in this folder will start as Director automatically. For THIS chat, adopt the role now:
   - call `get_role_contract` with `roleId: "director"`, read the whole contract, then call `acknowledge_role_contract` with that role id and `contractSha256`, and keep the `instanceId`;
   - from here on, act as Director for the rest of this chat: you plan and route, and you do not do the assigned work yourself. Because you are the main session, you start World 1.0 (`world-requests` agent) or Agent Support (`support` agent) yourself with each `delegationPacket` verbatim as its prompt, then review what they submit.
5. Reply briefly with:
   - the world name/version and whether it was created now or already existed;
   - the agents from `agentFiles`: they live in the visible `alife-agents/` folder of the project (`director.md`, `world-requests.md`, `support.md`), which is where the person edits them. Each was created, kept, or moved from an earlier `.claude/agents` copy. Claude Code loads them from copies in `.claude/agents/` that the plugin refreshes at the start of every chat, so an edit in `alife-agents/` applies in the next new chat. Existing files are never overwritten, and agent files the person made themselves in `.claude/agents/` are never touched;
   - that this chat is now the Director, and new chats in this folder start as Director;
   - the dashboard link;
   - one question: what should we build first? If they have no goal, offer the default goal "Create the world" and, when they agree (or say go), set it and plan the first sprint.

Report only what the tools returned. Never claim an agent is active: activity appears only after receipts (Director handoff, then World acknowledgement).
