#!/usr/bin/env node
// Start the loopback viewer for ONE project folder you name explicitly.
//   node scripts/claude-viewer.mjs --project /path/to/project [--port 7491]
//   node scripts/claude-viewer.mjs --demo                      (fictional demo, no project)
// The folder must already have been set up (create-world). Press Ctrl+C to stop.
import {parseArgs} from 'node:util';
import {startViewer, stopAllViewers} from '../lib/claude/viewer.mjs';
import {resolveVerifiedProject} from '../lib/claude/project.mjs';
const {values} = parseArgs({options: {project: {type: 'string'}, port: {type: 'string'}, demo: {type: 'boolean'}}});
try {
  const port = values.port === undefined ? 0 : Number(values.port);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw Error('Invalid --port.');
  const project = values.demo ? {root: process.cwd()} : await resolveVerifiedProject({explicit: values.project});
  if (!values.demo && !values.project) throw Error('Pass --project <folder> (or --demo).');
  const result = await startViewer({root: project.root, port, demo: !!values.demo});
  console.log((result.demo ? 'FICTIONAL DEMO ' : 'ALife World ') + 'viewer: ' + (result.operatorUrl));
  console.log('Loopback only (127.0.0.1). Ctrl+C stops it.');
  process.on('SIGINT', async () => { await stopAllViewers(); process.exit(0); });
} catch (e) { console.error('Viewer not started: ' + e.message); process.exitCode = 1; }
