#!/usr/bin/env node
// Generates agents/<id>.md for the three built-in roles. Each agent is a thin bootstrapper: the actual,
// current contract (shared + Claude host + role + this project's rules) is fetched at run time with
// get_role_contract, so rule and version changes take effect without editing agent files.
// No `tools` allowlist (it would hide the plugin's MCP tools); no model/effort pinning (user's choice).
import {writeFile, mkdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
import {CORE_AGENT_ROLES as ROLES, renderAgent} from '../lib/claude/agent-templates.mjs';
await mkdir(path.join(ROOT, 'agents'), {recursive: true});
for (const r of ROLES) {
  const body = renderAgent(r);
  await writeFile(path.join(ROOT, 'agents', r.id + '.md'), body);
}
console.log('agents written:', ROLES.map(r => r.id).join(', '));
