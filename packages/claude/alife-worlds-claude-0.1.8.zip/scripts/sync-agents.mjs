#!/usr/bin/env node
// SessionStart hook: refresh .claude/agents/ from the project's visible alife-agents/ folder (creating that folder
// once for projects set up by an earlier version).
// Acts only when Claude Code reports a project folder that ALife Worlds already set up. Never fails the session.
import path from 'node:path';
import {lstat} from 'node:fs/promises';
import {exactDirectory} from '../lib/claude/fsx.mjs';
import {FILES} from '../lib/claude/constants.mjs';
import {syncVisibleAgents, ensureVisibleAgents, VISIBLE_AGENTS_DIR} from '../lib/claude/agent-sync.mjs';
try {
  const dir = process.env.CLAUDE_PROJECT_DIR;
  if (dir) {
    const root = await exactDirectory(dir);
    const rec = await lstat(path.join(root, FILES.project)).catch(() => null);
    if (rec?.isFile()) {
      // Projects set up before 0.1.7 have no alife-agents/ yet: create it once (moving earlier copies, edits kept).
      if (!(await lstat(path.join(root, VISIBLE_AGENTS_DIR)).catch(() => null))) await ensureVisibleAgents(root);
      await syncVisibleAgents(root);
    }
  }
} catch { /* never block a session */ }
process.exit(0);
