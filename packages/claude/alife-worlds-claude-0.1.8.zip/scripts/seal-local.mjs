#!/usr/bin/env node
// Seal THIS source copy's current runtime fingerprint into plugin-releases.json (local only; not a public
// release). After sealing, any change to shipped content requires a version bump. Pass --check to only report.
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {rm} from 'node:fs/promises';
import {checkPluginVersion, sealVersion} from '../lib/plugin-version.mjs';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
try {
  const state = await checkPluginVersion(ROOT);
  if (process.argv.includes('--check')) { console.log(JSON.stringify(state, null, 2)); process.exit(0); }
  const sealed = await sealVersion(ROOT, state.contentFingerprint);
  await rm(path.join(ROOT, 'runtime'), {recursive: true, force: true});
  console.log(JSON.stringify({version: sealed.version, releaseState: sealed.releaseState, recorded: sealed.recorded, contentFingerprint: sealed.contentFingerprint}, null, 2));
} catch (e) { console.error('Seal failed: ' + e.message); process.exitCode = 1; }
