#!/usr/bin/env node
// Print plugin/world/role versions for a project: node scripts/claude-status.mjs [--project <folder>]
import {parseArgs} from 'node:util';
import {resolveVerifiedProject, readProjectRecord, pluginVersion} from '../lib/claude/project.mjs';
import {buildRegistry, currentWorldVersion} from '../lib/claude/roles.mjs';
const {values} = parseArgs({options: {project: {type: 'string'}}});
try {
  const out = {plugin: await pluginVersion(), upstreamBaseline: '0.4.30'};
  if (values.project) {
    const p = await resolveVerifiedProject({explicit: values.project}), rec = await readProjectRecord(p.root);
    out.project = rec ? {projectId: rec.projectId, name: rec.projectName, world: await currentWorldVersion(p.root), roles: (await buildRegistry(p.root)).map(r => ({id: r.id, version: r.version}))} : 'not set up';
  }
  console.log(JSON.stringify(out, null, 2));
} catch (e) { console.error(e.message); process.exitCode = 1; }
