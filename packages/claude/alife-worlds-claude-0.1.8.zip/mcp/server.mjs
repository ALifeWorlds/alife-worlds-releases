#!/usr/bin/env node
// ALife Worlds local MCP server (stdio, JSON-RPC 2.0, newline-delimited). No network, no dependencies.
// The project is the one Claude Code reports (CLAUDE_PROJECT_DIR and/or MCP roots); never a guess.
import {createToolset, toolErrorPayload} from '../lib/claude/tools.mjs';
import {resolveVerifiedProject, pluginVersion} from '../lib/claude/project.mjs';
import {stopAllViewers} from '../lib/claude/viewer.mjs';

let clientInfo = {name: 'unknown', version: ''}, clientCaps = {}, roots = [], nextId = 1;
const pending = new Map();
const send = m => process.stdout.write(JSON.stringify({jsonrpc: '2.0', ...m}) + '\n');
const request = (method, params, timeoutMs = 2500) => new Promise(resolve => {
  const id = 's' + nextId++, timer = setTimeout(() => { pending.delete(id); resolve(null); }, timeoutMs);
  pending.set(id, r => { clearTimeout(timer); resolve(r); });
  send({id, method, params});
});
async function refreshRoots() {
  if (!clientCaps.roots) return;
  const r = await request('roots/list', {});
  if (r?.result?.roots) roots = r.result.roots.slice(0, 16);
}
const session = {
  client: () => ({name: clientInfo.name, version: clientInfo.version}),
  project: async () => { if (!roots.length && clientCaps.roots) await refreshRoots(); return resolveVerifiedProject({roots}); },
};
const tools = createToolset(session);

async function handle(msg) {
  const {id, method, params} = msg;
  try {
    if (method === 'initialize') {
      clientInfo = {name: String(params?.clientInfo?.name || 'unknown').slice(0, 80), version: String(params?.clientInfo?.version || '').slice(0, 40)};
      clientCaps = params?.capabilities || {};
      return send({id, result: {protocolVersion: params?.protocolVersion || '2025-06-18', capabilities: {tools: {listChanged: false}}, serverInfo: {name: 'alife-worlds', version: await pluginVersion()}, instructions: 'ALife Worlds: real progress only comes from receipt tools. Never claim a task started or finished without the matching receipt.'}});
    }
    if (method === 'notifications/initialized') { refreshRoots(); return; }
    if (method === 'notifications/roots/list_changed') { refreshRoots(); return; }
    if (method === 'ping') return send({id, result: {}});
    if (method === 'tools/list') return send({id, result: {tools: Object.entries(tools).map(([name, t]) => ({name, description: t.description, inputSchema: t.inputSchema}))}});
    if (method === 'tools/call') {
      const tool = tools[params?.name];
      if (!tool) return send({id, error: {code: -32602, message: 'Unknown tool: ' + params?.name}});
      try {
        const out = await tool.handler(params.arguments || {});
        return send({id, result: {content: [{type: 'text', text: JSON.stringify(out, null, 2)}]}});
      } catch (e) {
        return send({id, result: {isError: true, content: [{type: 'text', text: JSON.stringify(toolErrorPayload(e), null, 2)}]}});
      }
    }
    if (id !== undefined) send({id, error: {code: -32601, message: 'Method not found: ' + method}});
  } catch (e) { if (id !== undefined) send({id, error: {code: -32603, message: 'Internal error'}}); }
}
let buf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => {
  buf += chunk;
  if (buf.length > 4 * 1024 * 1024) { buf = ''; return; }
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
    if (!line) continue;
    let msg; try { msg = JSON.parse(line); } catch { continue; }
    if (msg.id !== undefined && !msg.method && pending.has(msg.id)) { const f = pending.get(msg.id); pending.delete(msg.id); f(msg); continue; }
    handle(msg);
  }
});
process.stdin.on('end', async () => { await stopAllViewers(); process.exit(0); });
