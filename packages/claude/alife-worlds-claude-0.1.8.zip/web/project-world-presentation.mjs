// Presentation only. The existing receiver owns identity, connection, content and navigation.
const closed=(v,keys)=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const hex=v=>typeof v==='string'&&/^#[0-9a-f]{6}$/i.test(v);
const paletteKeys=['sky','ground','foliage','trim','accent'];
const materials=['soil','paper','fabric','clay','metal'],motifs=['pines','leaves','none'];
const neutral=Object.freeze({sky:'#333e48',ground:'#454c50',foliage:'#616967',trim:'#b0ac9d',accent:'#89999e'});
let sequence=0;
export function assertProjectWorldAppearance(value){
 if(value===null)return null;
 if(!closed(value,['schemaVersion','kind','source','material','motif','palette'])||value.schemaVersion!==1||value.kind!=='project-world-style'||!['saved-scene','qualified-scene'].includes(value.source)||!materials.includes(value.material)||!motifs.includes(value.motif)||!closed(value.palette,paletteKeys)||!paletteKeys.every(k=>hex(value.palette[k])))throw Error('Verified project-world appearance required');
 return Object.freeze({...value,palette:Object.freeze({...value.palette})});
}
const hash=text=>[...text].reduce((a,c)=>Math.imul(a^c.charCodeAt(0),16777619)>>>0,2166136261);
function pine(x,y,s,c){return `<g transform="translate(${x} ${y}) scale(${s})"><path d="M-3 43H3V76H-3Z" fill="#594b3a"/><path d="M0 0 7 17 4 17 15 34 9 33 23 53 14 50 29 69 9 63 0 67-9 63-29 69-14 50-23 53-9 33-15 34-4 17-7 17Z" fill="${c}"/><path d="M0 5-5 19-2 18-10 34-6 33-17 53-9 49-18 65 0 59Z" fill="#a5b195" opacity=".29"/></g>`;}
export function projectWorldSVG(appearance,{seed=1,id='pw-art'}={}){
 const a=assertProjectWorldAppearance(appearance),p=a?.palette??neutral;
 if(!Number.isSafeInteger(seed)||seed<0||typeof id!=='string'||!/^[a-z][a-z0-9-]{0,79}$/.test(id))throw Error('Bounded project-world art identity required');
 const dots=Array.from({length:58},(_,i)=>{const n=(Math.imul(seed+i+1,1664525)+1013904223)>>>0,x=34+n%293,y=40+(n>>>9)%295;return `<path d="M${x} ${y}h${1+(n%3)}" stroke="${i%3?p.trim:p.sky}" stroke-opacity="${a?.material==='metal'?'.19':'.27'}"/>`;}).join('');
 const motif=a?.motif==='pines'?pine(95,54,.79,p.foliage)+pine(245,61,.66,p.foliage)+pine(277,103,.46,p.foliage):a?.motif==='leaves'?`<path d="M59 212Q36 163 67 135M300 235Q327 191 304 156" fill="none" stroke="${p.trim}" stroke-width="3"/><path d="M53 183Q22 163 44 150Q68 152 53 183M60 160Q79 128 91 149Q87 171 60 160M310 204Q338 178 341 202Q329 225 310 204M309 179Q286 151 280 175Q288 194 309 179" fill="${p.foliage}"/>`:'';
 const seam=a?.material==='fabric'?`<path d="M55 97Q154 144 309 75M62 295Q173 241 304 297" fill="none" stroke="${p.trim}" stroke-width="2" stroke-dasharray="3 5" opacity=".5"/>`:a?.material==='paper'?`<path d="M62 72 98 69 85 104M271 293 295 286 301 313" fill="none" stroke="${p.trim}" opacity=".38" stroke-width="3"/>`:'';
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 360" fill="none" aria-hidden="true"><defs><clipPath id="${id}-clip"><circle cx="180" cy="193" r="153"/></clipPath></defs><ellipse cx="180" cy="340" rx="107" ry="11" fill="#000000" opacity=".15"/><circle cx="180" cy="34" r="12" fill="${p.sky}" stroke="${p.trim}" stroke-width="5"/><circle cx="180" cy="193" r="155" fill="${p.ground}" stroke="${p.sky}" stroke-width="3"/><g clip-path="url(#${id}-clip)">${dots}<path d="M25 108Q80 75 141 106T330 95V132Q253 123 199 132T25 140Z" fill="${p.foliage}" opacity="${a?'.75':'.09'}"/>${motif}${seam}<path d="M32 279Q88 315 148 300T328 283L333 347H27Z" fill="${p.sky}" opacity=".6"/><path d="M73 313Q110 292 144 313M226 315Q258 294 288 311" stroke="${p.foliage}" stroke-width="7" stroke-linecap="round" opacity="${a?'.85':'.15'}"/></g><circle cx="180" cy="193" r="145" stroke="${p.trim}" stroke-width="1.5" stroke-dasharray="3 7" opacity=".45"/><path d="M152 48Q180 58 208 48" stroke="${p.accent}" stroke-width="5" stroke-linecap="round"/><path d="M61 245 54 258 66 264M295 248 304 258 291 266" stroke="${p.accent}" stroke-width="4" stroke-linecap="round"/></svg>`;
}
export function createProjectWorldShell({document:doc=globalThis.document,project,appearance=null,onSelect=()=>{},savedArt=false}={}){
 if(!doc||typeof doc.createElement!=='function'||typeof onSelect!=='function'||!project||typeof project.id!=='string'||!/^[a-z][a-z0-9-]{0,63}$/.test(project.id)||typeof project.name!=='string'||!project.name.trim()||project.name.length>160)throw Error('Existing registered project required');
 const id=project.id,number=++sequence,seed=hash(id),artId='pw-art-'+number,statusId='pw-status-'+number;let name=project.name;
 const make=(tag,cls,text)=>{const n=doc.createElement(tag);n.className=cls;if(text!==undefined)n.textContent=text;return n;};
 const element=make('article','pw-hanger'),suspended=make('div','pw-suspended'),rope=make('span','pw-rope'),globe=make('div','pw-globe'),art=make('div','pw-art'),screen=make('div','pw-screen'),previewHost=make('div','pw-preview'),placeholder=make('div','pw-empty'),emptyMark=make('span','pw-empty-mark','· · ·'),emptyText=make('span','pw-empty-text','World preview unavailable'),selectButton=make('button','pw-open'),caption=make('div','pw-caption'),nameButton=make('button','pw-name',name),status=make('p','pw-status','Connection unavailable'),styleNote=make('p','pw-style-note');
 element.dataset.projectId=id;element.dataset.motion='paused';element.style.setProperty('--pw-rest-tilt',((seed%25)-12)/10+'deg');element.style.setProperty('--pw-duration',(7600+(seed%1600))+'ms');element.style.setProperty('--pw-delay',-(seed%5400)+'ms');
 rope.setAttribute('aria-hidden','true');art.setAttribute('aria-hidden','true');previewHost.setAttribute('aria-hidden','true');previewHost.inert=true;previewHost.hidden=true;status.id=statusId;
 for(const button of [selectButton,nameButton]){button.type='button';button.disabled=true;button.setAttribute('aria-describedby',statusId);button.title='This project connection is unavailable';}
 selectButton.setAttribute('aria-label','Open project: '+name);nameButton.title=name;placeholder.append(emptyMark,emptyText);screen.append(previewHost,placeholder);globe.append(art,screen,selectButton);suspended.append(rope,globe);caption.append(nameButton,status,styleNote);element.append(suspended,caption);
 if(savedArt){
  const still=make('img','pw-saved-art');still.alt='';still.loading='lazy';still.decoding='async';
  still.addEventListener('load',()=>{element.dataset.savedArt='ready';});
  still.addEventListener('error',()=>still.remove());
  screen.prepend(still);still.src='/api/world-planet-art?'+new URLSearchParams({world:id});
 }
 let disposed=false,running=false,visible=true,canSelect=false;
 const media=doc.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)');
 const syncMotion=()=>{element.dataset.motion=!disposed&&running&&visible&&!doc.hidden&&!media?.matches?'running':'paused';};
 const choose=()=>{if(!disposed&&canSelect)onSelect(id);};selectButton.addEventListener('click',choose);nameButton.addEventListener('click',choose);
 doc.addEventListener?.('visibilitychange',syncMotion);media?.addEventListener?.('change',syncMotion);
 function setAppearance(value){if(disposed)return;const saved=assertProjectWorldAppearance(value),p=saved?.palette??neutral;art.innerHTML=projectWorldSVG(saved,{seed,id:artId});element.dataset.material=saved?.material??'unknown';element.dataset.style=saved?.source??'unavailable';for(const key of paletteKeys)element.style.setProperty('--pw-'+key,p[key]);styleNote.textContent=saved?'':'Style unavailable';styleNote.hidden=!!saved;}
 function setState({state='unavailable',label=null,canSelect:allow=false}={}){if(disposed)return;if(!['live','loading','unconfirmed','unavailable','paused'].includes(state)||label!==null&&(typeof label!=='string'||label.length>180)||typeof allow!=='boolean')throw Error('Actual preview state required');canSelect=allow;element.dataset.preview=state;previewHost.hidden=state!=='live'&&state!=='loading';placeholder.hidden=state==='live';status.textContent=label??({live:'Live world',loading:'Loading own world…',unconfirmed:'Connection unconfirmed',unavailable:'World unavailable',paused:'World preview paused'})[state];emptyText.textContent=state==='loading'?'Loading own world…':state==='paused'?'World preview paused':'World preview unavailable';for(const button of [selectButton,nameButton]){button.disabled=!allow;button.title=allow?'Open '+name:status.textContent;}}
 function setMotion({running:next=false,visible:shown=true}={}){if(typeof next!=='boolean'||typeof shown!=='boolean')throw Error('Actual motion guards required');running=next;visible=shown;syncMotion();}
 function setProjectName(value){if(disposed)return;if(typeof value!=='string'||!value.trim()||value.length>160)throw Error('Registered project name required');name=value;nameButton.textContent=name;selectButton.setAttribute('aria-label','Open project: '+name);for(const button of [selectButton,nameButton])button.title=canSelect?'Open '+name:status.textContent;}
 function dispose(){if(disposed)return;disposed=true;canSelect=false;syncMotion();selectButton.removeEventListener('click',choose);nameButton.removeEventListener('click',choose);doc.removeEventListener?.('visibilitychange',syncMotion);media?.removeEventListener?.('change',syncMotion);}
 setAppearance(appearance);setState();return{element,previewHost,selectButton,nameButton,status,setState,setAppearance,setProjectName,setMotion,dispose};
}
