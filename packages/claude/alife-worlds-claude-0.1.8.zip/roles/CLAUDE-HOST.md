# Claude Code host adaptation (read with the shared instructions)

This section replaces the Codex-specific host steps in the shared instructions. Everything else in the shared
instructions, your role instructions and this project's rules still applies.

**Where you run.** You are a Claude Code subagent (or the main session) in the project folder Claude Code opened.
Project-owned state lives only in that folder's `.alife-worlds/` directory and is reached ONLY through the
`alife-worlds` MCP tools. Never read or write another project, the plugin cache, or any global Claude/Codex history.

**What counts as evidence.** The world shows only what receipts prove. A receipt is a tool call that the plugin
verified and wrote to the project's hash-chained ledger:
1. `acknowledge_role_contract` — proves you read this exact contract (hash match). Required before role work.
2. `acknowledge_handoff` — proves *you received* a specific handoff (the handoff id + one-time token that the
   Director passed in your prompt). Without it the handoff stays "queued/unconfirmed".
3. `report_progress` — fresh activity evidence while you work. Send it at real milestones, never as a heartbeat.
4. `submit_work` — hands finished work to review with concrete evidence. It does NOT complete the task.
5. `accept_work` / `reject_work` — review decision by someone other than the submitter (Director or the human).
   Only an accepted task counts toward sprint progress. Activity is not completion.

**Honesty rules.** Never fabricate a receipt, token, instance id or acceptance. Do not call a tool on behalf of
another role. If a tool is unavailable or refuses, say so plainly and stop that step; do not write the ledger by hand.
Keep demo or fixture runs labelled as such.

**Settings.** Model, effort and speed are whatever the user's Claude Code session or the agent file selects; this
plugin never changes them and reports them as unknown. Do not self-upgrade or request a larger model.

**Imports and exports.** Apply imports only to the verified current project, using `import_preview` then
`import_apply`. Never copy private conversation history, credentials or native identifiers into a definition.

**Creating agents.** Only Agent Support adopts a new custom role (imports and role setup). Director routes the
request; the three built-in roles are not cloned.

**Large rule bodies.** Plugin and world rule bodies total about half a megabyte. The contract carries the shared,
host and role instructions plus this project's additions and a rule index; fetch full rule text on demand with
`rules` (action "get") for the scope you are working in.

**Files and tools named in older role text.** Role text may mention Codex-only packet files or helpers
(`docs/MASTER-PROMPT.md`, `scripts/plugin-status.mjs`, native chat custody, "create-world" helpers). They are not
shipped in this edition. This contract, the `status` tool (plugin, world and role versions, kept separate) and the
`setup`, `world_design`, `world_release`, `import_*`, `export_definition` and `rules` tools replace them.
When asked which plugin version a project uses, call `status`; report plugin, world and role versions separately.

**Delegation.** Subagents cannot start other subagents. Director plans with the planning tools, issues handoffs
with `issue_handoff`, and returns each `delegationPacket` verbatim in its final message so the main session can
start the assigned subagent with it. When Director IS the main session (projects set up by ALife Worlds start new
chats as Director), Director starts the assigned subagent itself with the `delegationPacket` verbatim as its prompt. A project-added role runs as a general-purpose subagent whose prompt is that
packet; it fetches its own contract with `get_role_contract`.
