# Setup

> **Runs only in Claude Code.** Use the **Code** tab in the Claude desktop app (a **Local** session on a folder) or the Claude Code terminal. Regular claude.ai chats and claude.ai **Projects** can't run this plugin: they skip its local tools and agents, so nothing happens there.

Requirements: Claude Code (a version with plugin support) and Node.js 20 or newer. The plugin has no npm dependencies and makes no network requests.

## Install it

```bash
claude plugin marketplace add ALifeWorlds/alife-worlds-releases
claude plugin install alife-worlds@alife-worlds
```

Unzip `alife-worlds-claude-0.1.7.zip` into its own folder. From your project folder, run `claude --plugin-dir /absolute/path/to/that/folder`. Check for `alife-worlds` in `/plugin` and `/mcp`, `alife-worlds:start` in `/skills`, and `director`, `world-requests` and `support` in `/agents`.

Validate the folder: `claude plugin validate /absolute/path/to/the/plugin/folder --strict`.

## First world

1. Make a **new, empty folder** for your world.
2. In the Claude desktop app, open the **Code** tab, start a **Local** session and choose that folder. (Terminal: open the folder and run `claude`.)
3. Install the plugin once, if you haven't (see **Install it** above). Start a new session after installing.
4. Run this command by itself to start with the bundled Anthill:

   ```text
   /alife-worlds:start
   ```

   This sets up the folder, creates the world, adds the **Director**, **World 1.0** and **Agent Support** agents to the folder's `.claude/agents/`, and opens the world viewer link.
5. **That chat becomes the Director.** It asks what to build first. With no goal, its goal is "Create the world". Say go, and it plans the work and starts World 1.0 and Agent Support itself.
6. **Later chats in the same folder:** they are set to start as Director. If a new chat doesn't, type `/alife-worlds:start` in it. That changes nothing in your world; it just makes that chat the Director. (Terminal alternative: `claude --agent director`.)

Open the `http://127.0.0.1:…` link Claude gives you in your browser to see the world. It works while that Claude Code session is open. To use your own art, tell the Director which files or folder to use.

## Dashboard without Claude

```bash
node scripts/claude-viewer.mjs --project /absolute/path/to/your/project
node scripts/claude-viewer.mjs --demo        # fictional demo, touches no project
```

The folder must already be set up. Ctrl+C stops it. The viewer reads and displays; it never messages agents.

## Where things live

`<project>/.alife-worlds/` holds the project record, the hash-chained evidence ledger, the plan, rules, role records, copied art, world releases, imports and exports. It is git-ignored. `delete` removes only this folder, after a recovery copy and a confirmation phrase you type.

## Troubleshooting

- *"Claude Code did not report a project folder"*: start Claude Code inside the project folder; the plugin never guesses one.
- *"belongs to a different folder"*: a `.alife-worlds` folder was copied or moved. It is not adopted silently.
- *Tasks never leave Ready*: no verified receipt exists yet. Director must issue a handoff and the assignee must acknowledge it.
- *Package installs / network*: not needed to run the plugin.
