---
name: commands
description: Show the ALife Worlds skill menu with short descriptions and example requests. Read-only help; changes nothing.
---

# ALife Worlds: commands

Show this menu (Claude Code lists plugin skills as `/alife-worlds:<name>`; the person can type that slash command or just describe what they want):

| Skill | Use it to |
| --- | --- |
| `start` | One step: set up this folder, create the world and add the three agents (`/alife-worlds:start your idea`) |
| `role` | Make this chat a role chat: `/alife-worlds:role director`, `world-requests` (World 1.0) or `support` (Agent Support). New chats in a world folder do this automatically |
| `create-world` | Set up a world in this project or a new folder, from an idea and optional art |
| `world` | Open the dashboard, change the idea or art, prepare a new world version, edit world rules |
| `import` | Import an agent, world or plugin-rules definition with a preview and a merge for same-role updates |
| `export` | Save an agent, rules or a bundle as a portable definition file |
| `rule` | Rules for one agent |
| `universal` | Instructions inherited by every agent |
| `plugin` | Plugin, world and role versions; read-only shared rules |
| `delete` | Plan removing this plugin's own state (needs an exact typed confirmation) |
| `commands` | This menu |

How work flows: the **Director** chat plans a goal, sprint and tasks and issues a handoff; **Agent Support** requests a separate chat for **World 1.0** (or another role) with that packet, and the human opens it with + New on the same folder; the assignee acknowledges and submits evidence; a reviewer other than the submitter accepts. The dashboard shows only what those receipts prove. This skill changes nothing.
