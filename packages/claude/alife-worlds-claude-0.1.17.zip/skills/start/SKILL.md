---
name: start
description: Run /alife-worlds:start by itself for the bundled Anthill. Sets up the current Claude Code project, makes this chat the Director, which opens the Agent Support and World 1.0 chats first; then World 1.0 builds the world. Add a world idea to start with a custom world.
---

# ALife Worlds: start

The person wants ALife Worlds set up in **the current project folder** (the folder Claude Code was opened in) in one go. Use the `alife-worlds` MCP tools; never write `.alife-worlds/` files by hand.

World idea from the command: $ARGUMENTS

Order (as in the Codex edition: the core roles and their chats first, then the world): set up the project and roles, make this chat the Director, **open the Agent Support and World 1.0 chats before anything else**, then set the goal and hand "Create the world" to World 1.0, which builds it as soon as the task arrives.

1. Call `status`.
   - If `setUp` is true: call `setup` again with the existing project name and `worldLater: true` (it changes nothing except restoring any missing role notes file), then go to step 3.
2. If `setUp` is false: call `setup` for the current folder with `projectName` set to the folder's name, `worldLater: true`, and `idea` set to the idea above if one was given (no idea means the bundled Anthill; do not stop to ask). Pass `art` only for files or a folder the person named in this command. This sets up the project and the three roles only and keeps the world request; it does **not** build the world yet. Do not open the viewer yet.
3. **Name this chat "Director".** Load the app's rename tool with `ToolSearch` (query `select:mcp__ccd_session_mgmt__set_session_title`) and call `mcp__ccd_session_mgmt__set_session_title` with title `Director` (for this current session). If that tool is not available, tell the person they can type `/rename Director`.
4. **This chat becomes the Director.** Follow the `alife-worlds:role` skill's steps for `director` now: `get_role_contract` (`roleId:"director"`), read it all, `acknowledge_role_contract`, keep the `instanceId`, and load the world and universal rules with the `rules` tool. From here on this chat is the Director: it plans and routes and does not do assigned work. Roles run in their own chats, never as subagents or helpers in this chat.
5. **Open the Agent Support and World 1.0 chats first, before any goal, plan or task.** This chat is the one the person started, so it is the chat allowed to open other chats (a chat opened by another chat can only offer the person a card). Agent Support and World 1.0 are the built-in core roles that setup created, so Director opens their chats directly at start-up. Skip a chat whose role already has a chat open in this folder (ask the person if unsure).
   a. Call `queue_role_chat` with `roleId:"support"`, `requestedByRoleId:"director"`, your `instanceId` and packet `Start-up: Agent Support chat for this project. No task yet.` Open it with the app's session tools exactly as the `alife-worlds:role` skill's **Opening the chat** section says (start it with `initiation:"user_asked"`, then detach it to the top level). Then call `wait_for_chat_opened` with its `chatId`.
   b. Call `queue_role_chat` with `roleId:"world-requests"`, `requestedByRoleId:"director"`, your `instanceId` and no packet. Open it the same way (start, detach), then call `wait_for_chat_opened` with its `chatId`. The World 1.0 chat reads its contract and waits for its task.
   If the session tools are not available, tell the person to click **+ New** for a Local chat on this folder twice now (the first becomes Agent Support, the second World 1.0), and do not wait.
6. **Then hand "Create the world" to World 1.0** (skip this step if `status` shows the world already has a version, or `read_plan` shows a create-the-world task with an open, submitted or accepted handoff). Running this command is the person's go, so do not ask. With no goal, `set_goal` title "Create the world", goal "Create the world". `add_task` with `taskId:"create-world"`, title "Create the world", `ownerRoleId:"world-requests"`, `planStage:"Ready"`, scope = the world request from `setup` / `status` (`worldRequest`: the idea in the person's words, or the bundled Anthill when `useDefaultWorld` is true), and acceptance: for a custom idea the world design is saved and release 1.0.0 is prepared; for the bundled Anthill the packaged world is kept (no design or release needed); and the viewer link is returned. `plan_sprint` (`sprintId:"sprint-1"`, title "Create the world", that task, `makeCurrent:true`). Then `issue_handoff` to `world-requests` with a brief that repeats the idea verbatim and says: build it now without waiting for a go. Deliver it: call `queue_role_chat` with `roleId:"world-requests"`, `requestedByRoleId:"director"`, your `instanceId`, the `handoffId` and the `delegationPacket` verbatim. Do **not** open another chat for it: the World 1.0 chat you opened in step 5 is waiting for this packet and picks it up by itself, then builds the world right away.
7. Reply briefly with:
   - that the project and roles are set up, and that the world is being built by the World 1.0 chat (it is not built yet in this chat; if it already existed, say so and give its version);
   - that this chat is now the Director and was renamed "Director" (or, if the rename tool was missing, that they can type `/rename Director`);
   - that the Agent Support and World 1.0 chats were opened first (or that they should click + New twice), and that World 1.0 starts building as soon as its task arrives and gives the viewer link when done;
   - that when World 1.0 submits, they come back to this Director chat and say "review" so Director checks and accepts the work;
   - the role notes files are in the visible `alife-agents/` folder (`agentFiles`).

Report only what the tools returned. Never claim a role is active or the world is built: that appears only after receipts (Director handoff, the World 1.0 chat's acknowledgement and submission, then Director's acceptance).
