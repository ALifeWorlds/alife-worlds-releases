import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {projectOutputPath,projectStoragePlan} from '../lib/project-storage.mjs';
async function fixture(fn){await fs.mkdir(path.resolve("runtime/test-fixtures"),{recursive:true});const base=await fs.mkdtemp(path.join(process.cwd(),'runtime/test-fixtures/storage-')),root=path.join(base,'project');await fs.mkdir(root);try{await fn({base,root});}finally{assert.equal(path.dirname(base),path.resolve('runtime/test-fixtures'));await fs.rm(base,{recursive:true,force:true});}}
test('separate project plans remain inside their own roots without creating shared files',()=>fixture(async({base,root})=>{
 const other=path.join(base,'project-two');await fs.mkdir(other);
 const a=await projectStoragePlan(root,randomUUID()),b=await projectStoragePlan(other,randomUUID());
 assert.notEqual(a.locations.helpers,b.locations.helpers);
 assert.equal(a.locations.artwork,path.join(root,'.alife-worlds/artwork'));
 assert.deepEqual(await fs.readdir(root),[]);assert.deepEqual(await fs.readdir(other),[]);
}));
test('parent traversal, absolute/sibling paths and Windows aliases are rejected',()=>fixture(async({base,root})=>{
 for(const relative of ['../project-two/output','..\\project-two\\output',path.join(base,'project-two/file'),'C:\\elsewhere\\file','notes/../../file','assets/link:stream','logs./file','logs/NUL.txt'])await assert.rejects(projectOutputPath(root,relative),{code:'ALIFE_PROJECT_OUTPUT_OUTSIDE'});
}));
test('a linked artwork/helper destination cannot escape through an ancestor',()=>fixture(async({base,root})=>{
 const outside=path.join(base,'outside');await fs.mkdir(outside);await fs.mkdir(path.join(root,'.alife-worlds'));
 await fs.symlink(outside,path.join(root,'.alife-worlds/helpers'),process.platform==='win32'?'junction':'dir');
 await assert.rejects(projectOutputPath(root,'.alife-worlds/helpers/task/log.txt'),{code:'ALIFE_PROJECT_OUTPUT_OUTSIDE'});
 assert.deepEqual(await fs.readdir(outside),[]);
}));
