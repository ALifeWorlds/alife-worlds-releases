# ALife Worlds for Codex

**Version 0.4.32** · [Official downloads](https://github.com/ALifeWorlds/alife-worlds-releases/releases/latest) · [Get help](https://alifeworlds.com/support/)

Give your agents a world you can see. Start from an idea or artwork and use the world to follow agent activity, handoffs, and recorded sprint progress.

## Quick start

[1. Set up Codex](#set-up-codex) · [2. Install the plugin](#install-the-plugin) · [3. Create your first world](#create-your-first-world) · [Check your version](#check-your-version)

### Set up Codex

1. [Install the ChatGPT desktop app](https://learn.chatgpt.com/docs/app) and sign in.
2. Open **Codex**, choose **Local / This computer**, and select the folder where your world should live. This is your project folder.
3. Install [Node.js 20 or newer](https://nodejs.org/en/download) if needed. Reopen Codex after installing Node.js.

### Install the plugin

You can ask Codex to install ALife Worlds for you. Paste this message into your local project chat.

```text
Help me install ALife Worlds for Codex from this official release page:
https://github.com/ALifeWorlds/alife-worlds-releases/releases/tag/v0.4.32

Use my downloaded plugin ZIP if its SHA-256 matches the release checksum.
Otherwise download the named 0.4.32 plugin ZIP. Follow the official
Windows installation guide to install or update my existing plugin.
Verify the installed version and tell me when it is ready.

Keep my projects and settings intact.
Wait for me to ask before creating a world or any agents.
```

[Manual Windows install and update steps](https://github.com/ALifeWorlds/alife-worlds-releases/blob/v0.4.32/INSTALL.md) · [Release checksum](https://github.com/ALifeWorlds/alife-worlds-releases/releases/download/v0.4.32/SHA256SUMS)

### Create your first world

Open a chat in the project folder after installation and send this message.

```text
Use $alife-worlds:create-world to make a moonlit pine village in this project.
```

To use your own art, attach it in that chat or provide the path to its folder. For new worlds with no goal supplied, Director starts with the goal of creating and connecting the world. World files and ordinary working records stay with your project.

See the [command guide](docs/COMMANDS.md#command-menu) for help with customizing a world, importing and exporting, or managing rules.

## Check your version

Open **ALife Worlds** in Codex to see the plugin version above the world. **Check for updates** looks up the latest published release. Ask Director which plugin version created your world and which version last ran it.

If you just installed an update and an existing chat shows the old version, open a new chat in the project. [Codex setup and version details](docs/CODEX.md#plugin-version-updates-and-project-history)

## Documentation

[All documentation](docs/README.md) · [Project storage and privacy](docs/INTEGRATION.md#project-local-files) · [World releases](docs/WORLD_RELEASES.md) · [Artwork and assets](docs/ASSETS.md)

## Development

For a writable source checkout, see [Build and register this source](docs/CODEX.md#build-and-register-this-source) and [Operations](docs/OPERATIONS.md). Keep project data, native records, and credentials outside distributed source and packages.

## Original Creator

Created by: **Itzel Juarez**.

[MIT license](LICENSE) · [Third-party notices](THIRD_PARTY_NOTICES.md) · [Contributing](CONTRIBUTING.md) · [Contributors](CONTRIBUTORS.md) · [Governance](GOVERNANCE.md) · [Branding](BRANDING.md)
