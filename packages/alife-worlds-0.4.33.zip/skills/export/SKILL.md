---
name: export
description: "Export a selected agent, world or plugin definition as a portable file or copied prompt, preserving its current version and complete authored rules."
---

# ALife Worlds: export

Export the selected authored agent, world or plugin definition. Read the packet AGENTS.md and [portable definition commands](../../docs/COMMANDS.md#portable-project-content-commands), then use the qualified packet's existing project-content export or scoped rule-export path from the [world guide](../create-world/references/world-guide.md#portable-definitions-and-selected-folder-cleanup).

Use the actual current project and saved definition. Preserve the complete combined agent definition and its current version. If the target is unclear, ask whether the user wants an agent, world or plugin and which one. Save requested files in this project unless the user names another destination. Never construct a supposedly complete definition from an avatar, native title, receipt or session. Exclude private conversations, native identities, credentials, history and grants. Explain whether the result is a portable definition or a rule prompt; it is not an installed plugin or a deployed world.

This command does not create agents, import content, install software or publish a destination.
