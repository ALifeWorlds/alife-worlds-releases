---
name: import
description: "Import an agent, world or plugin definition into the verified project of this chat. Preserve incoming versions and merge local changes through the existing import workflow."
---

# ALife Worlds: import

Import the supplied portable agent, world or plugin definition into **this chat's verified local project**. Plugin imports transfer definitions and rules; they do not install software or change the shared plugin.

Read the packet AGENTS.md and the [import workflow](../create-world/references/world-guide.md#portable-definitions-and-selected-folder-cleanup), [versioned imports](../create-world/references/world-guide.md#versioned-agent-imports-and-updates) and [command phases](../../docs/COMMANDS.md#portable-project-content-commands). Follow the existing package-owned project-content host and its actual native readback. Keep every new imported file and ordinary record inside this project; never use Dump/Agents or redirect an import to another project.

If no definition or source was provided, request the file, pasted definition or source path before applying anything. Preserve explicit incoming agent versions. Merge an incoming update with local work at a version newer than both baselines, retain prior definitions and resolve actual conflicts. Director routes an authorized new-agent request to Agent Support, which owns genuine native creation and the new agent's full inherited instructions and own receipt. Updating an existing agent preserves its identity, tasks and settings; do not clone it unless requested.

Selecting this menu entry does not create agents or authorize an import before the user submits the request. An unambiguous submitted import with a resolved plan needs no repeated approval. Preserve original operations and applicable real native/import/human holds; unrelated historical world publishing uncertainty is reported separately for agent-only intake.
