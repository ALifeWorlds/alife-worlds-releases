---
name: delete
description: "Plan clearing the verified current project folder contents, retaining the folder itself. Actual deletion requires verified recovery and the exact plan-specific human confirmation."
---

# ALife Worlds: delete

Use the existing selected-project cleanup workflow; never interpret this menu entry as completed deletion. Read the packet AGENTS.md, [selected-folder cleanup](../create-world/references/world-guide.md#portable-definitions-and-selected-folder-cleanup), [command phases](../../docs/COMMANDS.md#portable-project-content-commands) and the owning cleanup custody instructions before planning.

Verify the actual current project folder and full content inventory, including hidden/Git/world files. Retain the folder itself. Preserve original active/unknown effects, obtain each existing participant's own custody and real native idle readback, and verify the required recovery outside the removable contents. Present the helper's exact plan-specific human question through the supported confirmation workflow. A prior general request, menu selection, assistant answer or timeout is not the final deletion confirmation. Reconcile an uncertain original removal instead of replaying it.

This command does not create agents or authorize deleting native chats, global plugin installations, another project or cloud resources.
