---
name: universal
description: "View, export or change the universal instructions inherited by incoming ALife agents and successors, preserving complete shared and role-specific rules."
---

# ALife Worlds: universal

Handle the submitted universal-agent rule request. Read the packet AGENTS.md, [rule authoring](../create-world/references/world-guide.md#rule-authoring-commands) and [invoking-role context and inheritance](../../docs/COMMANDS.md#invoking-role-context-and-inheritance). List and export remain read-only.

Use the existing /universal scope and revision-bound authoring workflow. Preserve complete shared, retirement, universal and own-role instructions. New authorized agents and successors inherit the saved universal additions through Agent Support's existing creation process. Saving a universal rule does not rewrite established homes, replay pending launches or authorize new chats. Existing owners acknowledge any authorized custody update themselves at safe boundaries.

This command does not create agents, change models/settings or provision a world.
