---
name: commands
description: "Show the ALife Worlds command menu with short action descriptions and example requests. This is read-only help, not setup or execution."
---

# ALife Worlds: commands

Read [the command menu](../../docs/COMMANDS.md#command-menu) and show its commands with their short action descriptions. Explain that Codex exposes these as ALife Worlds skill entries; users can search by the command name in the composer picker or attach the exact $alife-worlds:<name> skill. Do not promise that this plugin registers new built-in Codex commands or rewrites the host composer.

Give a relevant example if helpful. Distinguish /rule (this agent), /universal (inherited agent instructions), /world (world design and rules) and /plugin (plugin-wide rules/workflows). /import and /export transfer definitions, not private chat history or credentials. This command does not create agents, change files, import, delete, install or publish anything.
