import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {createPluginStatusReader} from '../lib/plugin-status.mjs';
import {readProjectPluginVersion} from '../lib/project-plugin-version.mjs';
const [command,...args]=process.argv.slice(2),packageRoot=fileURLToPath(new URL('../',import.meta.url));
try{
 if(command!=='status'||args.length>1||args.length===1&&args[0]!=='--check-updates')throw Error('Use plugin-status.mjs status [--check-updates] from the actual project folder');
 const pkg=JSON.parse(await readFile(new URL('../package.json',import.meta.url),'utf8'));
 const plugin=await createPluginStatusReader({pluginVersion:pkg.version})({checkForUpdates:args.length===1});
 let project;try{project=await readProjectPluginVersion(process.cwd());}catch(error){if(error.code!=='ENOENT')throw error;project={schemaVersion:1,status:'not-configured',record:null};}
 console.log(JSON.stringify({schemaVersion:1,plugin,project,note:'Plugin is the invoked packet version. Project current is its last verified runtime activation; world and agent versions are independent. This command writes no project files.'},null,2));
}catch(error){console.error(error.message);process.exitCode=1;}
