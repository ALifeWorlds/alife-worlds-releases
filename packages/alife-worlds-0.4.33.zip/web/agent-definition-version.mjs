// Browser-safe agent version rules. This module never reads prompts, filenames or plugin versions.
const V='(0|[1-9]\\d*)\\.(0|[1-9]\\d*)(?:\\.(0|[1-9]\\d*))?(?:-([0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*))?(?:\\+([0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*))?';
const versionPattern=new RegExp('^'+V+'$'),suffixPattern=new RegExp('(?:^|\\s)(v?)('+V+')$');
export function parseAgentVersion(value){
 if(typeof value!=='string'||value.length>100)throw Error('An explicit numeric agent version is required; clarify an unsupported version instead of resetting it.');
 const m=versionPattern.exec(value);if(!m)throw Error('An explicit numeric agent version is required; clarify an unsupported version instead of resetting it.');
 const parts=[m[1],m[2],m[3]??'0'].map(Number);
 if(!parts.every(Number.isSafeInteger)||m[4]?.split('.').some(p=>/^\d+$/.test(p)&&p.length>1&&p.startsWith('0')))throw Error('Invalid agent version.');
 return {text:value,parts,prerelease:m[4]?.split('.')??[]};
}
export function titleVersionInfo(title){
 const m=suffixPattern.exec(title);if(!m)return null;
 const version=m[2],base=title.slice(0,m.index).trim();parseAgentVersion(version);
 if(!base||suffixPattern.test(base))throw Error('Ambiguous explicit versions in agent title; clarify before importing.');
 return {version,base,prefix:m[1]};
}
export function compareAgentVersions(a,b){
 const x=parseAgentVersion(a),y=parseAgentVersion(b);
 for(let i=0;i<3;i++)if(x.parts[i]!==y.parts[i])return x.parts[i]>y.parts[i]?1:-1;
 if(!x.prerelease.length||!y.prerelease.length)return x.prerelease.length===y.prerelease.length?0:x.prerelease.length?-1:1;
 for(let i=0;i<Math.max(x.prerelease.length,y.prerelease.length);i++){
  const l=x.prerelease[i],r=y.prerelease[i];if(l===r)continue;if(l===undefined||r===undefined)return l===undefined?-1:1;
  const ln=/^\d+$/.test(l),rn=/^\d+$/.test(r);if(ln!==rn)return ln?-1:1;
  if(ln)return l.length===r.length?(l>r?1:-1):l.length>r.length?1:-1;
  return l>r?1:-1;
 }
 return 0;
}
export function agentVersionInfo(definition,{required=false}={}){
 const title=titleVersionInfo(definition.title),explicit=definition.version;
 if(explicit!==undefined){parseAgentVersion(explicit);if(title&&compareAgentVersions(title.version,explicit)!==0)throw Error('Conflicting explicit agent versions; clarify before importing.');}
 const version=explicit??title?.version;
 if(required&&!version)throw Error('Explicit local and incoming agent versions are required before a combined update.');
 return {version,titleVersion:title?.version??null,baseTitle:title?.base??definition.title,prefix:title?.prefix??''};
}
export function portableAgentCreationTitle(definition){
 const info=agentVersionInfo(definition),title=info.titleVersion||!info.version?definition.title:definition.title+' '+info.version;
 if(title.length>160)throw Error('Versioned agent creation title exceeds 160 characters; clarify a shorter title.');
 return title;
}
export function nextCombinedAgentVersion(local,incoming){
 const top=parseAgentVersion(compareAgentVersions(local,incoming)>=0?local:incoming),parts=[...top.parts];
 if(!Number.isSafeInteger(parts[2]+1))throw Error('Agent version patch capacity exceeded; choose an explicit newer version.');
 parts[2]++;return parts.join('.');
}
