---
name: plugin
description: "Check the ALife Worlds plugin version, updates and this project's version history. Also view/export or propose changes to plugin rules and workflows using the canonical source."
---

# ALife Worlds: plugin

For /plugin version, /plugin status or a question about this project's plugin version, run scripts/plugin-status.mjs status from the actual project folder using this qualified packet. It reads creation/current history without changing it. Add --check-updates only when checking the official public release. Keep plugin, last applied project runtime, world and agent versions distinct. This read-only status request needs no rule proposal or team provisioning.

Handle the submitted plugin-rule or workflow request. Read the packet AGENTS.md and [rule authoring](../create-world/references/world-guide.md#rule-authoring-commands). Use the verified canonical writable source for changes; installed/generated packets are read-only inputs. List and export are read-only.

For a rule change, prepare the actual concise human description and detailed AI instructions, present the exact proposal and required analysis, and apply only the user's applicable accepted revision-bound decision. Keep independent compatible requirements and actual native/project authority. Follow the owning Git and release workflow when publication or installation is requested. A plugin update does not silently replace a selected custom world, migrate project data or publish a Site.

Selecting this command does not create agents or grant shared changes, installation or publication before an actual submitted request.
