# ALife Worlds

**A home for your ALife Agents. A world limited only by your imagination.**

ALife Worlds is a local Codex plugin that gives your agent team a shared visual home. Each represented **ALife Agent** has a role and a room; fresh activity and recorded handoffs bring the **ALife World** to life.

![ALife World concept overview](docs/media/alife-worlds-overview.png)

*The illustrated styles are concepts supplied by the project owner. The current procedural world is the working foundation; this image does not promise six included skins.*

[Quick start](#quick-start) · [Documentation](docs/README.md) · [Plugin Rules](docs/PLUGIN_RULES.md) · [World Rules](docs/WORLD_RULES.md) · [Codex setup](docs/CODEX.md) · [Integration](docs/INTEGRATION.md) · [World releases](docs/WORLD_RELEASES.md) · [License](LICENSE)

## Original Creator

Created by: **Itzel Juarez** — original creator, confirmed by the project owner.

Project: **ALife Worlds**.

Official Repository: [ALifeWorlds/alife-worlds](https://github.com/ALifeWorlds/alife-worlds), designated by the owner and verified as the existing Git source.

This project was originally created and developed by the creator identified above and is maintained through an open-source contribution model. Contributors are recognized for their individual contributions. Submitting code does not automatically confer original creator status, ownership of the entire project or authority over official governance. Creator credit does not imply copyright assignment or ownership of every file.

The existing MIT notice, **Copyright (c) 2026 Ant Farm package contributors**, remains intact. Contributors retain applicable rights to their own contributions unless a valid written agreement provides otherwise. Preserve the [license](LICENSE) and [third-party notices](THIRD_PARTY_NOTICES.md).

The human approved publication of the [contribution guidelines](CONTRIBUTING.md), [contributor recognition](CONTRIBUTORS.md), [governance](GOVERNANCE.md) and [branding guidance](BRANDING.md) on official main on 10 November 2026. These policies grant no repository privilege or copyright assignment. See [verified facts and open questions](docs/CREATOR_PROTECTION_REVIEW.md).

## Release status and roadmap

The current base retains the selected earlier maintainer working-source snapshot, bounded static-grass caching and protection against oversized canvas allocation before layout settles from 0.4.6. See the owning Operations provenance and performance limits. The complete prior unsealed draft is preserved; no running world is changed by source integration.

ALife Worlds is a **private alpha**. The canonical source version is in [package.json](package.json). Source **0.4.13** includes the opt-in owner-authenticated, fixed-Director Wake Up request backend on the released 0.4.11 foundation. Source checks do not activate a destination connection or establish native delivery, resumption or consumed status. Installation, selected immutable World, website deployment and human visual acceptance remain separate. Repository access requires an existing invitation; a public marketplace release is not available yet.

This release candidate keeps task cards concise: task name, goal, QA needed and its requirements, blockers and next action. Agent cards retain only the latest Last reported work and latest Observed activity; the separate activity list keeps the three most recent original entries per agent. Unchanged polling creates no entries. The default world keeps blue water and a compact progress sign beside the far-left tree. The later approved woodland room design uses bounded top-contour name plaques, regular 14px names, full-name hover and adjacent text actions with truthful capability/disabled reasons. These defaults and the modular Plugin/World Rules library ship in the reusable packet. See [the candidate contract](docs/INTEGRATION.md#release-candidate-043-task-cards-and-recorded-activity).

An [opt-in Windows connection supervisor](docs/INTEGRATION.md#optional-windows-connection-recovery) can recover this destination's local service and publisher outside an AI turn. Its pairing is protected for the approved Windows user and stays outside Git and every export. Copies require their own private pairing. Reconnect requires an awake computer, signed-in user, network and valid authorization; damaged or ambiguous delivery records stop for explicit repair.

The current rule catalogue contains 82 plugin rules, 73 world rules and two universal onboarding rules. The human-approved `delivery.zero-token-connection-recovery` rule owns automatic reconnect; existing observation, credential and authorization rules retain their own facets. The approved `preservation.creator-and-contributor-rights` rule protects verified creator credit, contributor rights and legitimate notices without inventing ownership or limiting MIT permissions. Human wording approval and actual behavior acceptance remain separate.

The isolated 0.4.2 candidate combines upstream 0.3.6 web/world updates with clearer human labels, separate detailed AI instructions, reviewed rule decisions, recoverable history, serialized native metadata, acceptance-based progress and View diagnostic privacy. The accepted source-version rule tracks the upstream baseline or newer local candidate in the existing World agent title while preserving the actual world artifact version. View hides operational data and native actions; operators retain their permitted modes. There are 80 plugin rules, 73 world rules and two universal onboarding rules. New upstream policies awaiting an exact destination decision are tracked as proposals. Website versions and the installed Codex packet are tracked independently. See [the current source scope and limits](docs/INTEGRATION.md#world-rules-completion-and-source-version-titles--candidate-042).

The packet also includes the [portable private owner Site](docs/INTEGRATION.md#portable-private-owner-site-and-rules-library--042): the dashboard, selected qualified world/assets, exact selected/applied agent settings and a separate Rules section below Sprints. Copy or clone a whole Plugin/World scope, group or individual rule with its human description and full AI instructions. Each destination uses its own private Site, agents and live data; portable definitions contain no private connection or task state.

The 0.3.0 compatible-feature package adds the selected rope-hung project-world presentation and reusable website/preview transport. Existing worlds, installed copies, private audiences and native teams retain their own state; source publication does not automatically change them. See [updating an existing copy](docs/CODEX.md#updating-an-existing-copy) for the separate code-update and definition-import workflows.

The following 0.2.20 milestone is retained as history. The 0.2.20 source combines the current project-content, custom-scene and portable-export safeguards with the responsive colony renderer and cosmetically interactive View. View hides sprint/task inspection and native actions; normal operators retain their existing modes. Plugin rules50 and World rules58 document the current layout, progress, ownership and model/speed contracts. Website versions and the installed Codex packet are tracked independently.

The [release checklist and requested world work](docs/OPERATIONS.md#release-readiness-and-remaining-world-work) distinguishes included source, remaining implementation and unverified acceptance. The selected project’s private canonical plan owns actual sprint progress. The [ALife Worlds website](https://alifeworlds.com) is published separately.

Before a wider release, finish current-host three-core startup and launcher acceptance, complete the selected world refinements, qualify clean install/update/recovery and cross-surface behavior, and prepare the public repository and eligible distribution materials. Native actions, imports/deletion and additional skins retain their separate approved scopes; they are not implied by this documentation release.

## What it does

- Gives ALife Agents recognizable spaces, costumes, tools and roles.
- Visualizes fresh observed activity, addressed handoffs and evidence-backed progress.
- Shows unavailable or stale observations honestly.
- Offers room focus, dragging, Pause and opt-in sound.
- Conceals project detail with Private view while preserving the world layout.
- Runs on your computer, with native messaging controls disabled in this foundation.

Animation follows recorded facts. A delivery, movement or Git publication does not by itself complete a task.

## Quick start

Install Node.js 20 or newer, then clone and run:

```powershell
git clone https://github.com/ALifeWorlds/alife-worlds.git
cd alife-worlds
npm run setup
npm start
```

Open [ALife World locally](http://127.0.0.1:7491). Stop a server you started with Ctrl+C.

In this source checkout, setup creates missing local configuration and an empty local workspace. It currently supports a writable source copy, not arbitrary-project provisioning; do not run setup in the installed plugin cache. It preserves existing configuration, bindings and project records. No dependency installation, API key or native agent creation is required for the unconnected local view.

To use the plugin privately in Codex, follow [Codex setup](docs/CODEX.md). Existing native teams require an explicit private binding configuration; a role shown in the world is not automatically a connected chat.

The plugin ships only **Director, Agent Support and World Requests**, with their complete shared/universal rules and retirement contracts. Its one advertised [create-world entrypoint](docs/COMMANDS.md#user-invoked-new-project-setup) uses the invoking project context and automatically creates or reuses the core and private world without routine setup questions. The invoking chat becomes Director; the guarded first Agent Support bootstrap then hands missing-role creation to Agent Support. Preserve all existing work/settings; new core chats automatically use the human approved core creation baseline or explicit role override without asking again. Complete own receipts, exact identities, durable effect records and mandatory native host permissions remain required. Rule commands and existing-world opening use its bundled world guide without provisioning a team. npm run setup creates missing local source files only.

The advertised entry is alife-worlds:create-world at skills/create-world/SKILL.md. After a real submitted setup request passes context verification and begins preparation, report Building world / alife-worlds:building-world as its truthful progress stage, using the complete workflow at skills/create-world/references/building-world.md. The host owns the original composer invocation chip; do not claim it rewrites dynamically. Existing-world maintenance/open/list/export uses skills/create-world/references/world-guide.md and creates no agents or false building progress.

## Rule commands

Use `/plugin <info>` for plugin policy, `/world <info>` for world behavior, `/rule <info>` for the agent receiving that command, and `/universal <info>` for rules inherited by incoming agents. Related properties merge within their subject; a correction replaces only that property. These scopes stay separate.

Each command supports list and export. See [Universal Agent Rules](docs/UNIVERSAL_AGENT_RULES.md) and [Rules by Agent](docs/AGENT_RULES.md). Creation follows the single policy in universal onboarding.support-owned-creation, including its guarded first Agent Support exception and complete incoming shared/retirement/universal/role contract. The [command workflow](docs/COMMANDS.md) saves rules, updates documentation, checks behavior and syncs Git before pushing completed work. Completed qualified world updates follow the saved existing-site/public-domain preference and actual verification under [site updates](docs/OPERATIONS.md#world-releases-and-site-updates); a Git push alone creates no hosting or audience. Saving text or a launch reservation alone proves neither native creation nor readiness.

## Product goals

- **Truthful living worlds:** show actual ALife Agent activity, addressed handoffs and evidence-backed progress, with stale or missing observations explicit.
- **Useful project access:** resolve registered worlds to the correct project and provide supported Codex-side-panel and sanitized read-only website views.
- **Responsive, accessible presentation:** deliberate portrait and landscape layouts, safe touch areas, browser text/pinch zoom without in-world Pan/Fit/Zoom controls, white world text and licensed UI fonts.
- **Image-led customization:** inspect every supplied reference image and use the coherent style to generate and integrate real sprites and environment images; a full prose brief is optional.
- **Safe work and recovery:** preserve human-selected agent settings, native identity, user files, private records, original task acceptance and verified command boundaries.
- **Portable setup:** user-invoked Codex project setup through create-world and its building-world workflow, with protected existing teams, the approved core creation baseline or explicit human overrides and real three-core access/custody evidence.

These are product goals and selected requirements, not a private sprint board or a claim that every goal is implemented. The [Plugin Rules](docs/PLUGIN_RULES.md) and [World Rules](docs/WORLD_RULES.md) distinguish documented guidance from recorded implementation. Codex installation and source registration require an explicitly authorized, verified refresh; actual native-panel, physical-phone, listening and reference-image generation checks retain their own results and limits.

## How it works

Your authorized project records and bounded native lifecycle observations feed a sanitized projection. The renderer turns those observations into ALife Agent activity, handoffs and progress.

| Part | Purpose |
| --- | --- |
| Local world | Responsive rooms, movement, interaction and controls. |
| Project adapter | Reads the chosen project's authorized records. |
| Native observer | Checks exact project/chat identity and exposes only allowed lifecycle metadata. |
| Projection | Keeps activity, planning, acceptance and freshness distinct. |
| Codex skill | Guides use of the bundled foundation and its current contracts. |

Keep private task plans, native homes, bindings, credentials, journals and recovery records on your machine. The repository and plugin packet contain an empty example rather than this team's working sprint.

## Current capabilities

The source includes the procedural local world, read-only observation, presentation controls and one advertised create-world skill with its preserved building-world workflow, full rule/world reference and private setup journal helper. Explicit setup automatically uses supported current-host native tools; it does not hide a chat API or start an AI monitor. Actual native creation/reuse, own onboarding receipts, applied settings, matching world service and visible rendering require their own evidence. Existing/linked supplemental display and hosted roster generalization are optional separate scopes. Native world-button dispatch and additional skins retain their separate qualification limits.

Private view conceals presentation; it does not sanitize arbitrary input or provide a hosting access policy. Public GitHub distribution is a separate reviewed release step; a public source repository never makes an owner-private world public.

## Development

```powershell
npm test
npm run build:plugin
```

The plugin builder copies an explicit allowlist into a clean local packet and excludes machine state. Source modules, tests and the [integration contract](docs/INTEGRATION.md) describe the actual supported behavior.

Contributions should preserve real task evidence, existing user work and human-selected agent settings. See [operations](docs/OPERATIONS.md) and [agent instructions](AGENTS.md).

[Asset provenance](docs/ASSETS.md) · [Visual behavior](docs/VISUALS.md) · [MIT license](LICENSE)

The Midnight Colony source includes upper-room-rim pixel names without dark plaques, layered woodland and selected pines, six-stage sprint-tree artwork driven by accepted sprint progress, preserved agent artwork, opt-in Sound and volume, and deterministic initial placement. The retained scoped preview passed core artwork and pause behavior only. Actual World 1.1.4 activation, native and hosted delivery, same-version rendered alignment and the remaining original acceptance are tracked separately in the [release checklist](docs/OPERATIONS.md#release-readiness-and-remaining-world-work), [Visuals](docs/VISUALS.md) and [Integration](docs/INTEGRATION.md).

## World releases and saved design

World release numbers, plugin versions and website deployment versions are independent. The neutral starting world definition is **1.0.0** and the world-owning role displays **World 1.0**; source preparation does not claim that version is installed, deployed or rendered. [World release history](docs/WORLD_RELEASES.md) explains the real private per-world ledger, saved art direction, surface versions and recoverable rollback targets.

A supplied image or folder can guide a new world or complete visual reskin. Inspect every reference, preserve functional logic and real records, save the coherent art/lighting/animation/PFX direction and verify routes, layers and actual results. Decorative life never invents busy agents or task progress. See [asset workflow](docs/ASSETS.md#first-use-with-an-image-folder).

The 0.2.21 source updates the sidebar resource identity and current preview validation for verified project roles, retaining the original frozen World 1.1.3 contract as a compatibility record. General role and local appearance bounds are 100 with existing byte limits; current membership is still verified independently. The local entry remains bound to the configured selected world. Backend registration, installed-host refresh and website publication retain separate ownership.

### Room furnishings in 0.4.9

Role-specific pine furniture and selected-room detail extend the shared colony presentation. Generic workers receive deterministic variation. The component preserves the current scrolling, refresh reuse, input handling, scene cache, foreground ordering and exit dust. Both room-label layouts remain supported, and each destination retains its selected presentation. Source qualification is separate from installation, destination-world deployment and human visual acceptance.

## Building your world in Codex

Allow about **20–40 minutes** to generate a world, especially when creating new artwork. You can start directly with your own setting; the ant world is optional. Ask for your custom world to be the main view and keep the default as a backup. Existing selected custom scenes remain separate from default plugin updates. Follow the public [installation and world creation guide](https://github.com/ALifeWorlds/alife-worlds-releases#create-your-private-world).
