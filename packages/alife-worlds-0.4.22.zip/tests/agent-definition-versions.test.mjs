import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {validatePortablePacket,parsePortableImport,portableClipboard,dataHash} from '../lib/portable-definitions.mjs';
import {validatePortablePacket as browserPacket,parsePortableImport as browserParse} from '../web/portable-definitions.mjs';
import {agentDefinitionHash} from '../lib/portable-import-plan.mjs';
import {portableAgentCreationTitle,compareAgentVersions,nextCombinedAgentVersion,parseAgentVersion} from '../lib/agent-definition-version.mjs';
import {mergeAgentDefinitions} from '../lib/agent-definition-merge.mjs';
const role=(version='2.0.0')=>({id:'writer',title:'Writer '+version,prompt:'Write clear notes.',groups:[{id:'notes',title:'Notes',properties:[{id:'style',title:'Style',text:'Use short sentences.'}]}]});
const packet=a=>({format:'alife-portable',schemaVersion:1,kind:'agent',title:a.title,agents:[a]});
const sources=()=>({base:packet(role()),local:packet(role('2.1.0')),incoming:packet(role('2.7.0'))});

test('title and metadata versions survive Node/browser copy, definition hashing and creation naming',()=>{
 for(const a of [role('2.7'),role('2.7.0'),{...role(),title:'Writer',version:'2.7.0'},{...role(),title:'Writer v2.7.0',version:'2.7.0'}]){
  const p=validatePortablePacket(packet(a));assert.deepEqual(browserPacket(p),p);assert.deepEqual(browserParse(portableClipboard(p)),p);
  assert.equal(agentDefinitionHash(p.agents[0]),dataHash(p.agents[0]));
  assert.equal(portableAgentCreationTitle(a),a.title==='Writer'?'Writer 2.7.0':a.title);
 }
 const a={...role(),title:'Writer'};assert.equal(portableAgentCreationTitle(a),'Writer');
 assert.notEqual(agentDefinitionHash({...a,version:'2.7.0'}),agentDefinitionHash(a));
 const prompt=parsePortableImport('Use Node 20.0 and plugin 9.0.0.',{kind:'agent',title:'Writer'});assert.equal(portableAgentCreationTitle(prompt.agents[0]),'Writer');assert.equal(prompt.agents[0].version,undefined);
 const contract=parsePortableImport('# Creation contract for Writer 2.7.0\nWrite concise notes.');assert.equal(portableAgentCreationTitle(contract.agents[0]),'Writer 2.7.0');assert.deepEqual(browserParse('# Creation contract for Writer 2.7.0\nWrite concise notes.'),contract);
});

test('conflicting, ambiguous, malformed and overflowing explicit versions are refused without resets',()=>{
 for(const a of [{...role(),version:'1.0.0'},{...role(),title:'Writer 1.0 2.0'},{...role(),version:'next'},{...role(),title:'x'.repeat(160),version:'2.0.0'}]){
  assert.throws(()=>validatePortablePacket(packet(a)));assert.throws(()=>browserPacket(packet(a)));
 }
 for(const v of ['01.2.0','1.02.0','1.2.03','1.2.3-01','9007199254740992.0.0','1.2/3'])assert.throws(()=>parseAgentVersion(v));
 assert.equal(compareAgentVersions('2.7','2.7.0'),0);assert.ok(compareAgentVersions('2.7.0-rc.10','2.7.0-rc.2')>0);assert.ok(compareAgentVersions('2.7.0','2.7.0-rc.10')>0);
 assert.equal(nextCombinedAgentVersion('3.0.4','2.7.0'),'3.0.5');assert.throws(()=>nextCombinedAgentVersion('1.0.9007199254740991','1.0.0'));
});

test('three-way update preserves local and incoming properties, complete prompts and exact immutable source versions',()=>{
 const input=sources();input.local.agents[0].prompt='Write clear notes and retain local changes.';
 input.local.agents[0].groups[0].properties.push({id:'local',title:'Local',text:'Keep local headings.'});
 input.incoming.agents[0].groups[0].properties[0].text='Use short and precise sentences.';
 input.incoming.agents[0].groups[0].properties.push({id:'incoming',title:'Incoming',text:'Include incoming summary.'});
 const original=structuredClone(input),r=mergeAgentDefinitions(input),a=r.packet.agents[0];
 assert.equal(r.status,'definition-prepared-not-applied');assert.equal(r.effectsPerformed,0);assert.equal(r.nativeEffectsPerformed,0);
 assert.equal(a.title,'Writer 2.7.1');assert.equal(a.version,'2.7.1');assert.equal(a.prompt,input.local.agents[0].prompt);
 assert.deepEqual(a.groups[0].properties.map(p=>p.text),['Use short and precise sentences.','Keep local headings.','Include incoming summary.']);
 assert.deepEqual(input,original);assert.deepEqual(r.sources,original);
 for(const k of ['base','local','incoming'])assert.deepEqual(a.versionBaselines[k],{version:input[k].agents[0].title.split(' ').at(-1),definitionSha256:dataHash(input[k].agents[0])});
 const exported=parsePortableImport(portableClipboard(r.packet));assert.deepEqual(exported,r.packet);assert.deepEqual(browserPacket(exported),exported);assert.equal(agentDefinitionHash(a),dataHash(a));
 const h=r.sha256;r.sources.local.agents[0].prompt='Changed report';assert.notEqual(dataHash(Object.fromEntries(Object.entries(r).filter(([k])=>k!=='sha256'))),h);assert.deepEqual(input,original);
});

test('conflicts produce no export and exact per-field choices retain independent changes',()=>{
 const input=sources();input.local.agents[0].prompt='Local prompt.';input.incoming.agents[0].prompt='Incoming prompt.';
 input.local.agents[0].groups[0].properties[0].text='Local style.';input.incoming.agents[0].groups[0].properties[0].text='Incoming style.';
 let r=mergeAgentDefinitions(input);assert.equal(r.packet,null);assert.equal(r.status,'review-required');assert.deepEqual(r.conflicts.map(c=>c.path),['/prompt','/groups/notes/properties/style/text']);
 r=mergeAgentDefinitions({...input,resolutions:[{path:'/prompt',source:'local'},{path:'/groups/notes/properties/style/text',source:'incoming'}]});
 assert.equal(r.packet.agents[0].prompt,'Local prompt.');assert.equal(r.packet.agents[0].groups[0].properties[0].text,'Incoming style.');
 assert.throws(()=>mergeAgentDefinitions({...input,resolutions:[{path:'/version',source:'incoming'}]}),/Unused/);
 assert.throws(()=>mergeAgentDefinitions({...input,resolutions:[{path:'/prompt',source:'local'},{path:'/prompt',source:'incoming'}]}),/unique/);
});

test('delete versus edit conflicts retain source evidence and new independent groups merge',()=>{
 const input=sources();input.local.agents[0].groups=[];input.incoming.agents[0].groups[0].properties[0].text='Changed style.';
 let r=mergeAgentDefinitions(input);assert.equal(r.packet,null);assert.equal(r.conflicts[0].path,'/groups/notes');assert.deepEqual(r.conflicts[0].local,{present:false});
 r=mergeAgentDefinitions({...input,resolutions:[{path:'/groups/notes',source:'incoming'}]});assert.equal(r.packet.agents[0].groups[0].properties[0].text,'Changed style.');
 const added=sources();added.local.agents[0].groups.push({id:'new',title:'New',properties:[{id:'local',title:'Local',text:'Local.'}]});added.incoming.agents[0].groups.push({id:'new',title:'New',properties:[{id:'incoming',title:'Incoming',text:'Incoming.'}]});
 assert.equal(mergeAgentDefinitions(added).packet.agents[0].groups[1].properties.length,2);
});

test('successive updates advance above both versions, preserving baseline metadata and complete combined export',()=>{
 const first=mergeAgentDefinitions(sources()),input={base:first.packet,local:structuredClone(first.packet),incoming:structuredClone(first.packet)};
 input.local.agents[0].prompt='Current local work.';input.local.agents[0].title='Writer 3.0.0';input.local.agents[0].version='3.0.0';
 input.incoming.agents[0].title='Writer 2.8.0';input.incoming.agents[0].version='2.8.0';input.incoming.agents[0].groups.push({id:'new',title:'New',properties:[{id:'keep',title:'Keep',text:'Incoming improvement.'}]});
 const r=mergeAgentDefinitions(input),a=r.packet.agents[0];assert.equal(a.version,'3.0.1');assert.equal(a.versionBaselines.incoming.version,'2.8.0');assert.equal(a.prompt,'Current local work.');assert.equal(a.groups.length,2);assert.deepEqual(r.sources.base,first.packet);
 const invalid=structuredClone(r.packet);invalid.agents[0].version='2.8.0';invalid.agents[0].title='Writer 2.8.0';assert.throws(()=>validatePortablePacket(invalid),/newer/);
});

test('missing baselines, mismatched identities and private content are never guessed or exported',()=>{
 const missing=sources();missing.local.agents[0].title='Writer';assert.throws(()=>mergeAgentDefinitions(missing),/Explicit/);
 const foreign=sources();foreign.incoming.agents[0].id='another';assert.throws(()=>mergeAgentDefinitions(foreign),/identities differ/);
 const older=sources();older.local.agents[0].title='Writer 1.0';assert.throws(()=>mergeAgentDefinitions(older),/predates/);
 const privateInput=sources();privateInput.local.agents[0].prompt='Read C:/private-project/notes.';assert.throws(()=>mergeAgentDefinitions(privateInput),/Private/);
});

test('merge-agent CLI is data-only and returns the full export without native project access',()=>{
 const result=spawnSync(process.execPath,[fileURLToPath(new URL('../scripts/project-content.mjs',import.meta.url)),'merge-agent'],{input:JSON.stringify(sources()),encoding:'utf8',env:{...process.env,CODEX_THREAD_ID:''},timeout:10000});
 assert.equal(result.status,0,result.stdout+result.stderr);const r=JSON.parse(result.stdout);assert.equal(r.packet.agents[0].version,'2.7.1');assert.equal(r.nativeEffectsPerformed,0);assert.equal(r.status,'definition-prepared-not-applied');
});
