---
name: world
description: "Customize an existing ALife World: its art, layout, interactions, represented behavior and world rules. Also list or export world rules without creating a team."
---

# ALife Worlds: world

Handle the submitted change to the selected world's art, layout, interactions, behavior or rules. Read the packet AGENTS.md, the [world guide](../create-world/references/world-guide.md) and the owning [world release workflow](../../docs/COMMANDS.md#private-world-release-records).

Preserve the project's selected custom artwork, identities, settings, tasks, audience and recovery. For rule changes use the guide's accepted revision-bound proposal workflow; reuse an applicable actual human decision. For artwork or behavior changes maintain the selected world through its actual owner and compatible immutable release. Listing or exporting world rules is read-only. Use this project's verified world when opening it; if a selection is genuinely unclear, show the configured choices without silently switching projects.

Selecting this command does not create agents or start a new setup. Creating or connecting a new world uses the separate create-world entry.
