---
name: plugin
description: "View, export or propose changes to ALife Worlds plugin rules and workflows, using the canonical writable source and the existing review and release process."
---

# ALife Worlds: plugin

Handle the submitted plugin-rule or workflow request. Read the packet AGENTS.md and [rule authoring](../create-world/references/world-guide.md#rule-authoring-commands). Use the verified canonical writable source for changes; installed/generated packets are read-only inputs. List and export are read-only.

For a rule change, prepare the actual concise human description and detailed AI instructions, present the exact proposal and required analysis, and apply only the user's applicable accepted revision-bound decision. Keep independent compatible requirements and actual native/project authority. Follow the owning Git and release workflow when publication or installation is requested. A plugin update does not silently replace a selected custom world, migrate project data or publish a Site.

Selecting this command does not create agents or grant shared changes, installation or publication before an actual submitted request.
