---
name: rule
description: "View, export or change only the rules of the verified agent whose chat receives this command. Use plugin or universal for broader scopes."
---

# ALife Worlds: rule

Apply /rule only to the verified role of **this receiving chat**. Read the packet AGENTS.md, [rule authoring](../create-world/references/world-guide.md#rule-authoring-commands) and [invoking-role context](../../docs/COMMANDS.md#invoking-role-context-and-inheritance). Use list or export without mutations when requested.

For an authorized change use the existing scoped rule-authoring operation with the actual invoking role, original request and expected revision. Preserve universal obligations and current task, settings and effect custody. A bare /rule never means plugin-wide policy; /plugin manages plugin rules and /universal manages inheritance. Do not edit another agent's home or claim another owner's acknowledgment.

This command does not create agents or provision a world.
