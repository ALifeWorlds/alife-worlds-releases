import {createSiteBundleSource} from '../lib/site-sync-source.mjs';
import {createOwnerSitePublisher,assertOwnerSitePairing} from '../lib/site-sync-publisher.mjs';
let publisher=null;const stop=new AbortController();for(const name of ['SIGINT','SIGTERM'])process.on(name,()=>stop.abort());
try{
 let input='';for await(const chunk of process.stdin){input+=chunk;if(input.length>16384)throw Error('Pairing input too large');}const pairing=JSON.parse(input),ownerOrigin=assertOwnerSitePairing(pairing);
 const source=await createSiteBundleSource({projectRoot:process.cwd(),dashboardOrigin:pairing.dashboardOrigin,ownerOrigin,catalogProfile:pairing.catalogProfile,signal:stop.signal});
 publisher=await createOwnerSitePublisher({projectRoot:process.cwd(),source,pairing,log:value=>process.stdout.write(JSON.stringify(value)+'\n')});
 await publisher.run({signal:stop.signal});
}catch(error){process.stderr.write(JSON.stringify({state:'relay-unavailable',code:typeof error.code==='string'&&error.code.startsWith('RELAY_')?error.code:'SOURCE_OR_CONNECTION_UNAVAILABLE'})+'\n');process.exitCode=1;}
finally{if(publisher)try{await publisher.close();}catch{process.stderr.write(JSON.stringify({state:'relay-unavailable',code:'RELAY_CLOSE_UNCONFIRMED'})+'\n');process.exitCode=1;}}
