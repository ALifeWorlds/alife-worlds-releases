import {spawn} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {readConnectionConfig,verifyConnectionCustody,safeJSON,windowsProcessIdentity,processIsOriginal,originalProcessGone,acquireSupervisorLock,recoverOwnedPublisherLock,restartDelay,atomicConnectionJSON} from './connection-runtime.mjs';
const hash=x=>createHash('sha256').update(x).digest('hex');
export const terminalConnectionStatus=value=>['authentication-required','reconciliation-required'].includes(value?.state)?value.state:typeof value?.code==='string'&&/^RELAY_[A-Z_]{1,60}$/.test(value.code)?value.code:null;
export class RestartBudget{
 constructor(){this.entries=[];this.failures=0;this.next=0;}
 ready(now){this.entries=this.entries.filter(at=>now-at<900000);return now>=this.next&&this.entries.length<8;}
 started(now){this.entries.push(now);}
 failed(now){this.next=now+restartDelay(++this.failures);}
 stable(){this.failures=0;}
}
export function compactChildStatus(line){if(typeof line!=='string'||line.length>4096)return null;try{return terminalConnectionStatus(JSON.parse(line));}catch{return null;}}
export async function superviseConnection(c,pairing,{signal,identity=windowsProcessIdentity,spawnChild=spawn,wait=ms=>new Promise(r=>setTimeout(r,ms)),clock=Date.now,stopProcess=pid=>process.kill(pid,'SIGTERM'),versionChecker=null}={}){
 const {qualification}=await verifyConnectionCustody(c,{versionChecker}),scope=hash(JSON.stringify(c)),lock=await acquireSupervisorLock(c,{identity}),directory=lock.directory,recordFile=path.join(directory,'children.json'),holdFile=path.join(directory,'repair-required.json');
 const save=atomicConnectionJSON;
 const children=new Map(),budgets=new Map(['service','publisher'].map(k=>[k,new RestartBudget()]));let halted=null,holdWrite=null;
 const persist=()=>save(recordFile,{schemaVersion:1,kind:'connection-owned-processes',scope,packetFingerprint:qualification.fingerprint,children:[...children.values()].map(({kind,process,captured})=>({kind,process,captured:captured||null}))});
 try{
  try{const hold=(await safeJSON(holdFile)).value;if(hold.scope!==scope)throw Error('Foreign repair hold');throw Error('Explicit connection repair required');}catch(e){if(e.code!=='ENOENT')throw e;}
  try{const prior=(await safeJSON(recordFile)).value;if(prior.scope!==scope||prior.packetFingerprint!==qualification.fingerprint||!Array.isArray(prior.children)||prior.children.length>2)throw Error('Original process ownership requires reconciliation');for(const row of prior.children){if(!['service','publisher'].includes(row.kind)||children.has(row.kind))throw Error('Invalid original process ownership');const current=await identity(row.process.pid);if(!originalProcessGone(row.process,current))children.set(row.kind,{...row,adopted:true,started:clock()});else if(row.kind==='publisher')await recoverOwnedPublisherLock(c,row.captured,{identity});}}catch(e){if(e.code!=='ENOENT')throw e;}
  while(!signal?.aborted&&!halted){
   for(const kind of ['service','publisher']){
    let child=children.get(kind);
    if(child){const current=await identity(child.process.pid);if(originalProcessGone(child.process,current)){if(kind==='publisher')await recoverOwnedPublisherLock(c,child.captured,{identity});children.delete(kind);budgets.get(kind).failed(clock());await persist();child=null;}else if(clock()-child.started>60000)budgets.get(kind).stable();}
    if(!child&&budgets.get(kind).ready(clock())){
     if(kind==='publisher'&&!children.has('service'))continue;
     // A preexisting legacy lock is never inferred dead from a PID alone.
     if(kind==='publisher')try{await safeJSON(path.join(c.projectRoot,'.alife-worlds','site-sync.lock','owner.json'));throw Error('Original publisher lock requires reconciliation');}catch(e){if(e.code!=='ENOENT')throw e;}
     const script=path.join(c.packetRoot,'scripts',kind==='service'?'serve-qualified-connection.mjs':'relay-owner-site.mjs'),args=kind==='service'?[script,'--config-file',path.join(directory,'connection.json')]:[script],p=spawnChild(c.nodePath,args,{cwd:c.projectRoot,shell:false,windowsHide:true,stdio:['pipe','pipe','pipe']});
     let spawnError=false;p.once('error',()=>{spawnError=true;});await new Promise(resolve=>{p.once('spawn',resolve);p.once('error',resolve);});if(spawnError||!p.pid){budgets.get(kind).failed(clock());continue;}
     const own=await identity(p.pid);if(own.state==='absent'){budgets.get(kind).failed(clock());continue;}if(own.state!=='present'||path.resolve(own.exe).toLowerCase()!==path.resolve(c.nodePath).toLowerCase())throw Error('Own spawned process identity unavailable');
     child={kind,process:own,handle:p,captured:null,started:clock()};children.set(kind,child);budgets.get(kind).started(clock());await persist();
     for(const stream of [p.stdout,p.stderr]){let pending='';stream.setEncoding('utf8');stream.on('data',chunk=>{pending+=chunk;if(pending.length>8192){pending='';return;}let n;while((n=pending.indexOf('\n'))>=0){const code=compactChildStatus(pending.slice(0,n));pending=pending.slice(n+1);if(code){halted=code;if(!holdWrite){holdWrite=save(holdFile,{schemaVersion:1,kind:'connection-repair-required',scope,code,observedUtc:new Date(clock()).toISOString()});holdWrite.catch(()=>{});}}}});}
     p.stdin.on('error',()=>{});p.stdin.end(kind==='publisher'?JSON.stringify(pairing):undefined);
    }
    if(kind==='publisher'&&child&&!child.captured){try{const owner=await safeJSON(path.join(c.projectRoot,'.alife-worlds','site-sync.lock','owner.json'),65536),v=owner.value,created=Date.parse(child.process.createdUtc);if(v.pid!==child.process.pid||v.siteOrigin!==c.ownerSiteOrigin||typeof v.ownerNonce!=='string'||Date.parse(v.startedUtc)<created-5000||Date.parse(v.startedUtc)>clock()+5000)throw Error('Publisher original lock receipt differs');child.captured={hash:owner.hash,process:child.process};await persist();}catch(e){if(e.code!=='ENOENT')throw e;}}
   }
   if(!halted&&!signal?.aborted)await wait(5000);
  }
  if(holdWrite)await holdWrite;
  return {state:halted?'repair-required':'stopped',code:halted};
 }finally{
  // Stop only exact originally owned generations; preserve pending/WAL and locks
  // for the next verified recovery. No foreign/reused PID is ever terminated.
  for(const child of children.values())try{if(processIsOriginal(child.process,await identity(child.process.pid)))stopProcess(child.process.pid);}catch{}
  await lock.release();
 }
}
async function main(){
 const [flag,file,...extra]=process.argv.slice(2);if(flag!=='--config-file'||extra.length)throw Error('Explicit config file required');const c=await readConnectionConfig(file);if(process.platform!=='win32')throw Error('Windows only');
 let input='';for await(const chunk of process.stdin){input+=chunk;if(Buffer.byteLength(input)>16384)throw Error('Pairing input bound');}const pairing=JSON.parse(input);input='';const {assertOwnerSitePairing}=await import(pathToFileURL(path.join(c.packetRoot,'lib/site-sync-publisher.mjs')));if(assertOwnerSitePairing(pairing)!==c.ownerSiteOrigin||pairing.dashboardOrigin!=='http://127.0.0.1:'+c.port)throw Error('Exact private pairing required');
 const stop=new AbortController();for(const name of ['SIGINT','SIGTERM'])process.once(name,()=>stop.abort());const result=await superviseConnection(c,pairing,{signal:stop.signal});console.log(JSON.stringify(result));
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(()=>{console.error(JSON.stringify({state:'repair-required',code:'CONNECTION_OWNERSHIP_OR_CONFIGURATION_REQUIRED'}));process.exitCode=1;});
