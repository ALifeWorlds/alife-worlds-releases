import {readFile,writeFile,rename,mkdir,rmdir,unlink} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createAdapter} from '../adapters/native-session-adapter.mjs';
import {loadRegistry} from '../lib/projection.mjs';
import {assertSiteSnapshot} from '../lib/site-sync.mjs';

const root=process.cwd(),packet=fileURLToPath(new URL('../',import.meta.url)),privateRoot=path.join(root,'.alife-worlds'),runtime=path.join(privateRoot,'runtime');
const config=JSON.parse(await readFile(path.join(runtime,'antfarm.config.json'),'utf8'));
if(config.nativeReadOnly!==true||path.resolve(config.nativeWorkspaceRoot)!==root||!config.projectId)throw Error('Only the exact invoking project may be synchronized');
const project='project-'+createHash('sha256').update(config.projectId).digest('hex').slice(0,24);
const registry=await loadRegistry(packet),adapter=createAdapter({root,planningRoot:runtime,config,registry});
const normalized=v=>typeof v==='string'&&Number.isFinite(Date.parse(v))?new Date(v).toISOString():null;
const defaults={director:'Director',support:'Agent Support','world-requests':'World Requests'};
async function observe(revision){
 const value=await adapter.readSnapshot();
 const snapshot={schemaVersion:1,project,revision,observedUtc:value.observedUtc,agents:value.agents.filter(a=>!a.archived).map(a=>({
  role:a.roleId,name:a.nativeDisplayName||defaults[a.roleId],connected:a.connected===true,onboarded:a.onboarded===true,
  selection:{model:a.selectedModel??null,source:a.selectedModelSource??null,observedUtc:normalized(a.selectedModelObservedUtc),state:a.selectedModelState||'unknown'},
  applied:{model:a.model??null,source:a.modelSource??null,observedUtc:normalized(a.modelObservedUtc),state:a.modelState||'unknown',reasoning:a.reasoningEffort??null,speed:a.serviceTier??null,reasoningObservedUtc:normalized(a.reasoningEffortObservedUtc),speedObservedUtc:normalized(a.serviceTierObservedUtc)},
  activity:{state:a.activityState||'unknown',observedUtc:normalized(a.observedUtc),terminal:a.terminal===true,needsHumanInput:a.needsHumanInput===true}
 }))};return assertSiteSnapshot(snapshot,project);
}
if(process.argv.includes('--verify')){const s=await observe(1);console.log(JSON.stringify({state:'verified-local-observation',project,agents:s.agents.length,connected:s.agents.filter(a=>a.connected).length,selectedCurrent:s.agents.filter(a=>a.selection.state==='current').length,originalActivityTimes:true,nativeActions:0,siteWrites:0}));process.exit(0);}

// The caller supplies secrets through a pipe, never arguments or persisted configuration.
let input='';for await(const chunk of process.stdin){input+=chunk;if(input.length>16384)throw Error('Pairing input too large');}const pairing=JSON.parse(input);
const url=new URL(pairing.siteUrl);if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash||url.pathname!=='/'||typeof pairing.syncKey!=='string'||pairing.syncKey.length<32||typeof pairing.serviceToken!=='string'||pairing.serviceToken.length<16)throw Error('Private Site pairing required');
const endpoint=new URL('/api/bridge',url),lock=path.join(privateRoot,'site-sync.lock'),stateFile=path.join(privateRoot,'site-sync-state.json');
await mkdir(lock);await writeFile(path.join(lock,'owner.json'),JSON.stringify({pid:process.pid,startedUtc:new Date().toISOString(),project,siteOrigin:url.origin}));
let state={schemaVersion:1,project,siteOrigin:url.origin,revision:0,pending:null,lastReceipt:null};
try{const prior=JSON.parse(await readFile(stateFile,'utf8'));if(prior.schemaVersion!==1||prior.project!==project||prior.siteOrigin!==url.origin||!Number.isSafeInteger(prior.revision))throw Error('Foreign relay state');state=prior;}catch(e){if(e.code!=='ENOENT')throw e;}
async function save(){const temp=stateFile+'.'+randomUUID()+'.tmp';await writeFile(temp,JSON.stringify(state)+'\n',{flag:'wx'});await rename(temp,stateFile);}
let stopping=false;for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{stopping=true;});
const fingerprint=s=>JSON.stringify(s.agents),sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let lastSignature=null,lastSend=0,lastStatus=null,failures=0;
function status(value){if(value!==lastStatus){console.log(JSON.stringify({state:value,observedUtc:new Date().toISOString(),project}));lastStatus=value;}}
try{while(!stopping){
 try{
  if(!state.pending){const next=await observe(state.revision+1),signature=fingerprint(next);if(signature===lastSignature&&Date.now()-lastSend<10000){await sleep(1000);continue;}state.revision++;state.pending=next;await save();}
  const response=await fetch(endpoint,{method:'PUT',redirect:'error',cache:'no-store',headers:{'Content-Type':'application/json','X-ALife-Sync-Key':pairing.syncKey,'OAI-Sites-Authorization':'Bearer '+pairing.serviceToken},body:JSON.stringify(state.pending),signal:AbortSignal.timeout(10000)});
  const receipt=await response.json();
  if(response.status===400&&receipt.error==='Expired source observation'){state.pending=null;await save();continue;}
  if(!response.ok||receipt.state!=='accepted'||receipt.revision!==state.pending.revision)throw Error('Site exchange unavailable');
  lastSignature=fingerprint(state.pending);state.lastReceipt={revision:receipt.revision,receivedUtc:receipt.receivedUtc};state.pending=null;await save();lastSend=Date.now();failures=0;status('connected');
 }catch{failures++;status('connection-unavailable');}
 await sleep(Math.min(10000,failures?1000*2**Math.min(failures-1,3):1000));
}}finally{await unlink(path.join(lock,'owner.json'));await rmdir(lock);}
