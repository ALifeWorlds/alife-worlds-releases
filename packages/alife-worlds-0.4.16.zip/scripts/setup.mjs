import {withProjectOperation} from '../lib/project-operations.mjs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
async function createMissing(rel,value){
 const target=path.join(root,rel);await mkdir(path.dirname(target),{recursive:true});
 try{await writeFile(target,value,{flag:'wx'});console.log('Created local '+rel);}
 catch(e){if(e.code!=='EEXIST')throw e;console.log('Preserved existing local '+rel);}
}
await withProjectOperation(root,'setup',async()=>{
const snapshot=JSON.parse(await readFile(path.join(root,'data/project-state.example.json'),'utf8'));
if(snapshot.agents.length||snapshot.tasks.length||snapshot.events.length)throw Error('Setup requires an empty example.');
snapshot.observedUtc=new Date().toISOString();
await createMissing('data/project-state.json',JSON.stringify(snapshot,null,2)+'\n');
await createMissing('antfarm.config.json',await readFile(path.join(root,'antfarm.config.example.json'),'utf8'));
console.log('ALife World local setup ready. Native identities remain unconnected until explicitly configured.');

});
