import {fileURLToPath} from 'node:url';
import {bumpVersion,checkPluginVersion,sealVersion} from '../lib/plugin-version.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),[command,...args]=process.argv.slice(2);
try{
 let result;
 if(command==='check'&&args.length===0)result=await checkPluginVersion(root);
 else if(command==='bump'&&args.length===1)result=await bumpVersion(root,args[0]);
 else if(command==='seal'&&args.length===1)result=await sealVersion(root,args[0]);
 else throw Error('Use check, bump patch|minor|major, or seal QUALIFIED_SHA256. These commands never commit, push, install or deploy.');
 console.log(JSON.stringify(result));
}catch(error){console.error(error.message);process.exitCode=1;}
