import {access} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {readRuleCatalogs,exportRulePrompt,ruleDisplay} from '../lib/rules.mjs';
import {proposeRuleChange,decideRuleProposal,applyAcceptedRuleProposal,reconcileRuleProposal} from '../lib/rule-authoring.mjs';
import {archiveRuleHistory} from '../lib/rule-history.mjs';
import {readAgentRuleCatalogs,readRoleDefinitions,getAgentRuleContract,saveScopedRuleChange,generateAllRuleDocuments,checkAllRuleDocuments,generatedAgentRuleFiles} from '../lib/agent-rules.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),action=process.argv[2]||'check',args=process.argv.slice(3);
const pos=args.indexOf('--agent'),agentRoleId=pos<0?undefined:args[pos+1];
if(pos>=0&&(!agentRoleId||agentRoleId.startsWith('--')))throw Error('Use --agent <verified invoking logical role>.');
if(['propose','decide','apply','reconcile','archive-history','generate'].includes(action)){let packet=false;try{await access(path.join(root,'package-provenance.json'));packet=true;}catch(e){if(e.code!=='ENOENT')throw e;}if(packet)throw Error('Built/installed packets are read-only for authoring. Use the human-selected source checkout.');}
const display=c=>({scope:c.scope,...(c.agentRoleId?{agentRoleId:c.agentRoleId}:{}),revision:c.revision,groups:c.groups.map(g=>({id:g.id,title:g.title,properties:g.properties.map(p=>({id:p.id,title:p.title,description:p.description||p.title,text:p.active?p.text:null,active:p.active,implementation:p.implementation}))}))});
if(['propose','decide','apply','reconcile','archive-history'].includes(action)){
 let body='';for await(const chunk of process.stdin){body+=chunk;if(Buffer.byteLength(body)>1024*1024)throw Error('Rule request too large.');}
 const input=JSON.parse(body);
 if(action!=='apply'){const result=await ({propose:proposeRuleChange,decide:decideRuleProposal,reconcile:reconcileRuleProposal,'archive-history':archiveRuleHistory})[action](root,input);console.log(JSON.stringify({...result,...(action==='propose'?{requiresHumanDecision:true,saved:false}:{} )},null,2));}
 else if(input.proposalId){console.log(JSON.stringify(await applyAcceptedRuleProposal(root,input)));}
 else {
 if(!/^\/(?:rule|universal)\s/.test(input.command||''))throw Error('Plugin/world changes require propose, an actual human decision, decide, then apply the exact proposal ID/digest.');
 const result=await saveScopedRuleChange(root,input,{agentRoleId});
 console.log(JSON.stringify({scope:result.scope,...(result.agentRoleId?{agentRoleId:result.agentRoleId}:{}),revision:result.revision,saved:true,documentsUpdated:true,published:false,message:'Saved and documented. Review semantic conflicts, check effects and publish only completed authorized work. Hosted deployment and installation remain separate.'}));
 }
}else if(action==='generate'){await generateAllRuleDocuments(root);console.log('World, plugin, universal and per-agent rule documents generated.');}
else if(action==='check'){await checkAllRuleDocuments(root);console.log('All rule registries and generated documents match.');}
else if(action==='contract'){console.log((await getAgentRuleContract(root,args[0])).text);}
else if(action==='list'){
 const scope=args[0]||'all';if(!['all','world','plugin','universal','agent'].includes(scope))throw Error('Choose all, world, plugin, universal or agent.');
 const base=ruleDisplay(await readRuleCatalogs(root,{allowMissing:false})),extra=await readAgentRuleCatalogs(root);
 if(scope==='agent'){const c=await getAgentRuleContract(root,agentRoleId,extra);console.log(JSON.stringify({roleId:c.roleId,universal:display(c.universal),additional:display(c.own)},null,2));}
 else console.log(JSON.stringify(scope==='all'?{...base,universal:display(extra.universal),agents:Object.fromEntries((await readRoleDefinitions(root)).map(r=>[r.id,extra.agents[r.id]?display(extra.agents[r.id]):{scope:'agent',agentRoleId:r.id,revision:0,groups:[]}]))}:scope==='universal'?display(extra.universal):base[scope],null,2));
}else if(action==='export'||action==='export-world'){
 const scope=action==='export-world'?'world':args[0]||'world';
 if(scope==='agent')console.log((await getAgentRuleContract(root,agentRoleId)).text);
 else if(scope==='universal')console.log((await generatedAgentRuleFiles(root))['prompts/UNIVERSAL_AGENT_RULES_PROMPT.md']);
 else if(['world','plugin'].includes(scope))console.log(exportRulePrompt((await readRuleCatalogs(root,{allowMissing:false}))[scope]));
 else throw Error('Choose world, plugin, universal or agent.');
}else throw Error('Use propose, decide, apply, reconcile, archive-history, list, export, contract <role>, generate or check. /rule requires --agent from the verified invoking chat.');
