import {mkdir,readFile,writeFile,copyFile,lstat,readdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {createApp} from '../server.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),output=path.join(root,'.public-world-build');
await mkdir(output,{recursive:true});if((await lstat(output)).isSymbolicLink())throw Error('Redirected viewer output refused');
const app=await createApp();let snapshot;try{const url=await app.listen(0),r=await fetch(url+'/api/world-view');if(!r.ok)throw Error('Public projection unavailable');snapshot=await r.json();}finally{await new Promise(resolve=>app.server.close(resolve));}
if(snapshot.kind!=='read-only-world')throw Error('Unexpected viewer data');
const serialized=JSON.stringify(snapshot,null,2)+'\n';if(/[A-Za-z]:[\\/]|\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b|codex:\/\/|\.codex[\\/]|sessionPath|nativeWorkspaceRoot/.test(serialized))throw Error('Private identity/path in public viewer');
const sounds=JSON.parse(await readFile(path.join(root,'web/assets/audio/LICENSES.json'),'utf8'));
const files=["agent-outpost/assets/midnight-colony-reference-20261107/woodland-pines.png","agent-outpost/assets/midnight-colony-reference-20261107/sprint-tree-states.png","agent-outpost/assets/midnight-colony-reference-20261107/woodland-scenery.png","agent-outpost/assets/midnight-colony-reference-20261107/sprites.json","agent-outpost/assets/midnight-colony-reference-20261107/art-provenance.json","agent-outpost/assets/midnight-colony-reference-20261107/room-names.ttf","agent-outpost/assets/midnight-colony-reference-20261107/room-names.LICENSE.txt",'world-view.mjs','world-view.css','audio.mjs','agent-outpost/colony-art.js','agent-outpost/agent-outpost.js','agent-outpost/agent-outpost.css','assets/audio/LICENSES.json',...sounds.assets.map(a=>'assets/audio/'+a.file)];
for(const rel of files){const from=path.join(root,'web',rel),to=path.join(output,rel);if((await lstat(from)).isSymbolicLink())throw Error('Redirected asset refused');await mkdir(path.dirname(to),{recursive:true});await copyFile(from,to);}
const html=(await readFile(path.join(root,'web/world-view.html'),'utf8')).replace('__VIEWER_BASE__','/world-assets/').replace('__VIEWER_SOURCE__','world-state.json');await writeFile(path.join(output,'index.html'),html);await writeFile(path.join(output,'world-state.json'),serialized);
const hashes={};for(const rel of ['index.html','world-state.json',...files])hashes[rel]=createHash('sha256').update(await readFile(path.join(output,rel))).digest('hex');
await writeFile(path.join(output,'viewer-manifest.json'),JSON.stringify({schemaVersion:1,kind:'static-read-only-world',observedUtc:snapshot.observedUtc,assetBase:'/world-assets/',routeAliases:['/world/view','/watch?embed=1'],readOnly:true,requiresAI:false,summary:snapshot.summary,files:hashes},null,2)+'\n');
console.log(JSON.stringify({output,readOnly:true,requiresAI:false,roles:snapshot.summary.represented,connected:snapshot.summary.connected,files:Object.keys(hashes).length+1,modelsIncluded:false,privateIdentityScan:'PASS'}));
