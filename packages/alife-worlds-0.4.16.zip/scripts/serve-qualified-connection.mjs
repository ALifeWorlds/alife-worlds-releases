import path from 'node:path';
import {rename} from 'node:fs/promises';
import {readConnectionConfig,serveQualifiedConnection,safeJSON,windowsProcessIdentity,originalProcessGone,atomicConnectionJSON,retireOwnedServiceRecord} from './connection-runtime.mjs';
const [flag,file,...extra]=process.argv.slice(2);if(flag!=='--config-file'||extra.length)throw Error('Use --config-file ABSOLUTE_PRIVATE_CONFIG');
let runningApp=null;
try{
 const c=await readConnectionConfig(file),recordFile=path.join(c.projectRoot,'.alife-worlds','site-runtime-process.json');
 await retireOwnedServiceRecord(c);
 const {app,origin,qualification}=await serveQualifiedConnection(c);runningApp=app;const processIdentity=await windowsProcessIdentity(process.pid);
 await atomicConnectionJSON(recordFile,{schemaVersion:1,kind:'supervised-qualified-world-service',projectId:c.projectId,packetRoot:c.packetRoot,planningRoot:c.planningRoot,nativeRoot:c.projectRoot,process:processIdentity,origin,packageVersion:qualification.version,packageFingerprint:qualification.fingerprint,commandsEnabled:false});
 console.log(JSON.stringify({state:'service-listening',origin,pid:process.pid,nativeReadOnly:true}));for(const name of ['SIGINT','SIGTERM'])process.once(name,()=>app.server.close(()=>process.exit(0)));
}catch{if(runningApp)await new Promise(resolve=>runningApp.server.close(resolve));console.error(JSON.stringify({state:'connection-unavailable',code:'QUALIFIED_SERVICE_UNAVAILABLE'}));process.exitCode=1;}
