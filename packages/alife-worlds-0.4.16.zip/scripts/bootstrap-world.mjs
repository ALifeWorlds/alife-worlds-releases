import {readFile,writeFile,mkdir,lstat,rename,unlink} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash,randomUUID} from 'node:crypto';
import {prepareWorld,acknowledgeRole,reserveCreation,recordCreated,inspectWorld,findNativeSession,runtimeForWorld,recordWorldService,checkWorldIdentity,includeProject,coreResetPlan,privateLauncherProfileTarget,beginWorld,awaitRoleBinding,reserveContinuation,recordContinuation,reserveDirectorTitle,recordDirectorTitle} from '../lib/world-bootstrap.mjs';
import {loadLauncherProfile,DEFAULT_PROFILE,PROFILE_ENV} from '../lib/world-launcher.mjs';
const packageRoot=fileURLToPath(new URL('../',import.meta.url)),command=process.argv[2];
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
function keys(value,allowed){if(!object(value)||Object.keys(value).some(k=>!allowed.includes(k)))throw Error('Unsupported bootstrap input field.');}
async function input(){
 let size=0,text='';for await(const b of process.stdin){size+=b.length;if(size>1024*1024)throw Error('Bootstrap input limit exceeded.');text+=b.toString('utf8');}
 return JSON.parse(text.replace(/^\uFEFF/,''));
}
async function proof(root){
 const threadId=process.env.CODEX_THREAD_ID;if(!threadId)throw Error('Run from the actual Codex project chat; native thread context is missing.');
 return findNativeSession(threadId,root,{codexHome:process.env.CODEX_HOME??path.join(os.homedir(),'.codex')});
}
const output=v=>console.log(JSON.stringify(v,null,2));
async function registerLauncher(root,current,input){
 if(input.explicitRegister!==true)throw Error('Explicit registration of this private world is required.');
 const context=await runtimeForWorld(root,current),status=await inspectWorld(root);if(!status.world)throw Error('Start and verify this world first.');
 await checkWorldIdentity(status.world.origin,context);
 const profileOptions={codexHome:process.env.CODEX_HOME??path.join(os.homedir(),'.codex')};
 const profilePath=await privateLauncherProfileTarget(packageRoot,process.env[PROFILE_ENV]??DEFAULT_PROFILE,profileOptions);
 const folder=path.dirname(profilePath);await mkdir(folder,{recursive:true});
 await privateLauncherProfileTarget(packageRoot,profilePath,profileOptions);
 const dir=await lstat(folder);if(!dir.isDirectory()||dir.isSymbolicLink())throw Error('Redirected private profile folder refused.');
 const lock=profilePath+'.lock';await writeFile(lock,'bootstrap '+process.pid,{flag:'wx'});
 try{
  let before=null,data;try{const st=await lstat(profilePath);if(!st.isFile()||st.isSymbolicLink()||st.size>65536)throw Error('Invalid private launcher profile.');before=await readFile(profilePath);data=JSON.parse(before.toString('utf8').replace(/^\uFEFF/,''));}catch(e){if(e.code!=='ENOENT')throw e;data={schemaVersion:1,worlds:[]};}
  const valid=await loadLauncherProfile({packageRoot,profilePath});if(valid.status==='unavailable')throw Error('Invalid or redirected private launcher profile.');if(before&&valid.status!=='configured'&&!(valid.status==='unconfigured'&&data.worlds.length===0))throw Error('Preserve and reconcile the existing launcher profile.');
  const existing=data.worlds.find(w=>w.projectId===context.projectId||path.resolve(w.projectRoot).toLowerCase()===path.resolve(root).toLowerCase());
  if(existing&&(existing.projectId!==context.projectId||path.resolve(existing.projectRoot).toLowerCase()!==path.resolve(root).toLowerCase()))throw Error('A different private world is already registered for this identity.');
  const id=existing?.id??'world-'+createHash('sha256').update(context.projectId).digest('hex').slice(0,16);
  const row={id,label:existing?.label??context.projectName,projectId:context.projectId,worldId:context.worldId,projectRoot:root,origin:status.world.origin};
  if(existing)data.worlds[data.worlds.indexOf(existing)]=row;else data.worlds.push(row);
  if(data.worlds.length>32||data.worlds.some(w=>w!==row&&(w.id===row.id||w.origin===row.origin||w.worldId===row.worldId)))throw Error('Private world registration would be ambiguous.');
  const text=JSON.stringify(data,null,2)+'\n';if(Buffer.byteLength(text)>65536)throw Error('Private launcher profile limit exceeded.');
  const latest=await readFile(profilePath).catch(e=>{if(e.code==='ENOENT')return null;throw e;});if((before===null)!==(latest===null)||before&&!before.equals(latest))throw Error('Private profile changed concurrently; preserve it and retry only this registration.');
  const tmp=profilePath+'.'+randomUUID()+'.tmp';await writeFile(tmp,text,{flag:'wx'});try{await rename(tmp,profilePath);}finally{await unlink(tmp).catch(e=>{if(e.code!=='ENOENT')throw e;});}
  return {status:'registered',worldId:id,operatorUrl:status.world.operatorUrl,viewerUrl:status.world.viewerUrl,otherWorldsPreserved:data.worlds.length-1};
 }finally{await unlink(lock);}
}
async function startWorld(root){
 const current=await proof(root),context=await runtimeForWorld(root,current);
 if(context.state.world){try{await checkWorldIdentity(context.state.world.origin,context);output({status:'existing-world',...(await inspectWorld(root)).world});return;}catch{}}
 const {createApp}=await import(pathToFileURL(path.join(context.runtimeRoot,'server.mjs')));
 const app=await createApp(),origin=await app.listen(0);
 try{const world=await recordWorldService(root,origin,process.pid,current);output({status:'world-started',...world,commandsEnabled:false});}
 catch(e){await new Promise(resolve=>app.server.close(resolve));throw e;}
 // This is only the explicitly requested local world service, never an AI monitor.
 for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>app.server.close(()=>{process.exitCode=0;}));
}
try{
 if(!command||command==='help'){
  output({command:'bootstrap-world',commands:['begin','prepare','status','reserve-director-title','record-director-title','await-binding','reserve-continuation','record-continuation','acknowledge','reserve','record-created','start-world --project-root ABSOLUTE_ROOT','register-launcher','include-project','reset-plan'],input:'All commands except help/start-world accept one bounded JSON object on stdin. Native actions are performed only by the supported host tools in building-world, not by this CLI.'});
 }else if(command==='start-world'){
  if(process.argv.length!==3&&(process.argv.length!==5||process.argv[3]!=='--project-root'))throw Error('Use start-world in the actual project cwd, or supply its exact --project-root.');
  await startWorld(process.argv[4]??process.cwd());
 }else{
  if(process.argv.length!==3)throw Error('Use structured JSON on stdin, not arbitrary shell flags.');
  const data=await input();
  if(command==='begin'){
   keys(data,['nativeThread','nativeProjects','goal','settings','existingAgents']);
   output(await beginWorld(packageRoot,data,await proof(process.cwd())));
  }else{
  data.projectRoot??=process.cwd();if(typeof data.projectRoot!=='string')throw Error('Actual projectRoot required.');
  if(command==='status'){keys(data,['projectRoot']);output(await inspectWorld(data.projectRoot));}
  else{
   const current=await proof(data.projectRoot);
   if(command==='prepare'){keys(data,['projectRoot','projectId','projectName','goal','explicitSetup','settings','existingAgents','nativeThread']);output(await prepareWorld(packageRoot,data,current));}
   else if(command==='reserve-director-title'){keys(data,['projectRoot','nativeThread']);output(await reserveDirectorTitle(data.projectRoot,data.nativeThread,current));}
   else if(command==='record-director-title'){keys(data,['projectRoot','operationId','status','nativeResult','nativeThread']);output(await recordDirectorTitle(data.projectRoot,data.operationId,{status:data.status,nativeResult:data.nativeResult,nativeThread:data.nativeThread},current));}
   else if(command==='acknowledge'){keys(data,['projectRoot','roleId','fullRead','contractSha256','operationId']);output(await acknowledgeRole(data.projectRoot,data.roleId,current,data));}
   else if(command==='reserve'){keys(data,['projectRoot','roleId']);output(await reserveCreation(data.projectRoot,data.roleId,current,{contractRoot:packageRoot}));}
   else if(command==='await-binding'){keys(data,['projectRoot','roleId','operationId','timeoutMs']);output(await awaitRoleBinding(data.projectRoot,data.roleId,current,data));}
   else if(command==='reserve-continuation'){keys(data,['projectRoot','roleId']);output(await reserveContinuation(data.projectRoot,data.roleId,current,{contractRoot:packageRoot}));}
   else if(command==='record-continuation'){keys(data,['projectRoot','roleId','operationId','nativeResult']);keys(data.nativeResult,['threadId','hostId']);output(await recordContinuation(data.projectRoot,data.roleId,data.operationId,data.nativeResult,current));}
   else if(command==='record-created'){
    keys(data,['projectRoot','roleId','operationId','nativeResult']);keys(data.nativeResult,['threadId','clientThreadId','hostId','projectId','cwd']);
    output(await recordCreated(data.projectRoot,data.roleId,data.operationId,data.nativeResult,current));
   }else if(command==='include-project'){keys(data,['projectRoot','source']);keys(data.source,['projectRoot','projectId','projectName','explicitInclude','members']);output(await includeProject(data.projectRoot,data.source,current));}
   else if(command==='register-launcher'){keys(data,['projectRoot','explicitRegister']);output(await registerLauncher(data.projectRoot,current,data));}
   else if(command==='reset-plan'){keys(data,['projectRoot','explicitReset','projectId']);output(await coreResetPlan(data.projectRoot,data,current));}
   else throw Error('Unknown bootstrap command.');
  }
  }
 }
}catch(error){console.error(error.message);process.exitCode=1;}
