Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class ALifeWorldCredential {
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct CREDENTIAL {
  public uint Flags,Type; public string TargetName,Comment; public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
  public uint CredentialBlobSize; public IntPtr CredentialBlob; public uint Persist,AttributeCount; public IntPtr Attributes; public string TargetAlias,UserName;
 }
 [DllImport("advapi32.dll",EntryPoint="CredWriteW",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool Write(ref CREDENTIAL credential,uint flags);
 [DllImport("advapi32.dll",EntryPoint="CredReadW",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool Read(string target,uint type,uint flags,out IntPtr credential);
 [DllImport("advapi32.dll")] static extern void CredFree(IntPtr pointer);
 const string Marker="ALife Worlds approved exact-project private publisher";
 public static bool ExistsOwned(string target,string origin) {
  IntPtr pointer;if(!Read(target,1,0,out pointer)){int error=Marshal.GetLastWin32Error();if(error==1168)return false;throw new Exception("Credential read refused: "+error);}
  try{var c=(CREDENTIAL)Marshal.PtrToStructure(pointer,typeof(CREDENTIAL));if(c.Comment!=Marker||c.UserName!=origin)throw new Exception("Existing credential ownership mismatch");return true;}finally{CredFree(pointer);}
 }
 public static void Save(string target,string origin,string secret) {
  ExistsOwned(target,origin);byte[] bytes=Encoding.UTF8.GetBytes(secret);if(bytes.Length<20||bytes.Length>2560)throw new Exception("Credential length unsupported");IntPtr blob=Marshal.AllocHGlobal(bytes.Length);
  try{Marshal.Copy(bytes,0,blob,bytes.Length);var c=new CREDENTIAL{Type=1,TargetName=target,Comment=Marker,UserName=origin,CredentialBlobSize=(uint)bytes.Length,CredentialBlob=blob,Persist=2};if(!Write(ref c,0))throw new Exception("Credential write refused: "+Marshal.GetLastWin32Error());}
  finally{Array.Clear(bytes,0,bytes.Length);for(int i=0;i<bytes.Length;i++)Marshal.WriteByte(blob,i,0);Marshal.FreeHGlobal(blob);}
 }
 public static string Load(string target,string origin) {
  IntPtr pointer;if(!Read(target,1,0,out pointer))throw new Exception("Project credential unavailable: "+Marshal.GetLastWin32Error());
  try{var c=(CREDENTIAL)Marshal.PtrToStructure(pointer,typeof(CREDENTIAL));if(c.Comment!=Marker||c.UserName!=origin||c.CredentialBlobSize>2560)throw new Exception("Project credential scope mismatch");byte[] bytes=new byte[c.CredentialBlobSize];try{Marshal.Copy(c.CredentialBlob,bytes,0,bytes.Length);return Encoding.UTF8.GetString(bytes);}finally{Array.Clear(bytes,0,bytes.Length);}}finally{CredFree(pointer);}
 }
}
'@
