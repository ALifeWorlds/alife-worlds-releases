$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$spec=Get-Content -LiteralPath (Join-Path $taskRoot 'supervisor-spec.json') -Raw|ConvertFrom-Json
if([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -ne $spec.ownerSid){throw 'Approved project owner identity required'}
foreach($f in $spec.sourceFiles){if((Get-FileHash -LiteralPath $f.path -Algorithm SHA256).Hash.ToLower() -ne $f.sha256){throw 'Pinned supervisor input changed'}}
$mutex=New-Object Threading.Mutex($false,('Local\ALifeWorlds-'+$spec.worldId.Substring(6)+'-'+$spec.ownerSid))
if(-not $mutex.WaitOne(0)){exit 0}
try{
 . (Join-Path $taskRoot 'credential-vault.ps1')
 $ownerSecret=$null
 if(@($spec.components | Where-Object name -eq 'publisher').Count){$ownerSecret=[ALifeWorldCredential]::Load($spec.credentialTarget,$spec.ownerOrigin)}
 $psi=New-Object Diagnostics.ProcessStartInfo
 $psi.FileName=$spec.node;$psi.Arguments='"'+(Join-Path $taskRoot 'supervisor.mjs')+'"';$psi.WorkingDirectory=$taskRoot;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
 $psi.RedirectStandardInput=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
 $child=New-Object Diagnostics.Process;$child.StartInfo=$psi
 if(-not $child.Start()){throw 'Supervisor did not start'}
 $out=$child.StandardOutput.ReadToEndAsync();$err=$child.StandardError.ReadToEndAsync()
 $child.StandardInput.WriteLine((@{ownerBearer=$ownerSecret}|ConvertTo-Json -Compress));$child.StandardInput.Close();$ownerSecret=$null
 $child.WaitForExit()
 [IO.File]::WriteAllText((Join-Path $taskRoot ('entry-exit-'+[DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff')+'.log')),('exitCode='+$child.ExitCode+"`n"+$err.Result))
 exit $child.ExitCode
}finally{$ownerSecret=$null;$mutex.ReleaseMutex();$mutex.Dispose()}
