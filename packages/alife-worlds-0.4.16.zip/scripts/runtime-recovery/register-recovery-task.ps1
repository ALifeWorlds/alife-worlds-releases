$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$spec=Get-Content -LiteralPath (Join-Path $taskRoot 'supervisor-spec.json') -Raw|ConvertFrom-Json
$taskName='ALifeWorlds-'+$spec.worldId.Substring(6)
if([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -ne $spec.ownerSid){throw 'Approved task owner required'}
if(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue){throw 'Project task already exists; reconcile instead of replacing it'}
foreach($f in $spec.sourceFiles){if((Get-FileHash -LiteralPath $f.path -Algorithm SHA256).Hash.ToLower() -ne $f.sha256){throw 'Qualified supervision code changed'}}
. (Join-Path $taskRoot 'credential-vault.ps1')
if(@($spec.components | Where-Object name -eq 'publisher').Count -and -not [ALifeWorldCredential]::ExistsOwned($spec.credentialTarget,$spec.ownerOrigin)){throw 'Project credential is not paired'}
$action=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy RemoteSigned -File "'+(Join-Path $taskRoot 'task-entry.ps1')+'"') -WorkingDirectory $taskRoot
$trigger=New-ScheduledTaskTrigger -AtLogOn -User $spec.ownerUser
$principal=New-ScheduledTaskPrincipal -UserId $spec.ownerUser -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
$description='Human-approved exact ALife '+$spec.worldId+' local/private runtime recovery; qualified '+$spec.plugin+'/'+$spec.world+'/'+$spec.website+', no AI, public endpoints, installation or agent settings.'
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description $description|Out-Null
Start-ScheduledTask -TaskName $taskName
$task=Get-ScheduledTask -TaskName $taskName
$receipt=[ordered]@{schemaVersion=1;at=[DateTime]::UtcNow.ToString('o');state='EXACT_PROJECT_AUTOMATIC_RECOVERY_TASK_REGISTERED_AND_STARTED';task=$task.TaskName;principal=$task.Principal.UserId;logonType=$task.Principal.LogonType;runLevel=$task.Principal.RunLevel;multipleInstances=$task.Settings.MultipleInstances;trigger='At owner logon plus explicit start now';aiCalls=0;publicEndpoints=0;settingsChanges=0;installationChanges=0;browser=$false}
[IO.File]::WriteAllText((Join-Path $taskRoot 'task-registration-result-v1.json'),($receipt|ConvertTo-Json -Depth 12)+"`n")
$receipt|ConvertTo-Json -Depth 12
