import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createHash,randomUUID} from 'node:crypto';import {spawn,execFileSync} from 'node:child_process';
import {matchesOwnedRuntimeProcess,reconcileRuntimeRecoveryJournal} from './ownership.mjs';
function record(file,max=4*1024*1024){try{const before=fs.lstatSync(file);if(!before.isFile()||before.isSymbolicLink()||before.size>max)throw Error();const bytes=fs.readFileSync(file),after=fs.lstatSync(file);if(bytes.length!==before.size||bytes.includes(0)||before.ino!==after.ino||before.mtimeMs!==after.mtimeMs||before.size!==after.size)throw Error();const value=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));if(!value||typeof value!=='object'||Array.isArray(value))throw Error();return value;}catch{throw Error('Recovery record unavailable');}}
const root=path.dirname(fileURLToPath(import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex'),spec=record(root+'/supervisor-spec.json',1024*1024);
const semver=/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
if(spec.schemaVersion!==1||spec.kind!=='approved-alife-world-runtime-supervisor'||!/^world-[a-z0-9-]{1,58}$/.test(spec.worldId||'')||![spec.plugin,spec.world,spec.website].every(v=>semver.test(v||''))||!Array.isArray(spec.components)||spec.components.length<1||spec.components.length>2||!spec.components.some(c=>c.name==='local')||new Set(spec.components.map(c=>c.name)).size!==spec.components.length||spec.components.some(c=>!['local','publisher'].includes(c.name))||!/^[a-f0-9]{40}$/.test(spec.source||''))throw Error('Exact approved runtime scope required');
const shell=process.env.SystemRoot+'/System32/WindowsPowerShell/v1.0/powershell.exe';
const inspect=pid=>JSON.parse(execFileSync(shell,['-NoProfile','-NonInteractive','-ExecutionPolicy','RemoteSigned','-File',root+'/inspect-process.ps1','-TargetProcessId',String(pid)],{encoding:'utf8',windowsHide:true,timeout:10000}));
const own=inspect(process.pid),lock=root+'/supervisor-lock.json';
if(fs.existsSync(lock)){const previous=record(lock),p=inspect(previous.pid);if(p&&p.createdUtc===previous.createdUtc)throw Error('Original supervisor still exists; no duplicate');fs.renameSync(lock,root+'/retired-lock-'+randomUUID()+'.json');}
fs.writeFileSync(lock,JSON.stringify(own)+'\n',{flag:'wx'});
for(const f of spec.sourceFiles)if(sha(fs.readFileSync(f.path))!==f.sha256)throw Error('Pinned supervision source changed');
if(process.argv.length!==2)throw Error('No arbitrary supervisor arguments');
let secret=await new Promise((resolve,reject)=>{let text='';process.stdin.setEncoding('utf8');process.stdin.on('data',part=>{text+=part;if(text.length>16384)return reject(Error('Pairing limit'));const end=text.indexOf('\n');if(end<0)return;process.stdin.pause();try{const x=JSON.parse(text.slice(0,end));if(Object.keys(x).join(',')!=='ownerBearer'||(spec.components.some(c=>c.name==='publisher')?(typeof x.ownerBearer!=='string'||x.ownerBearer.length<20):x.ownerBearer!==null))throw Error();text='';resolve(x.ownerBearer);}catch{reject(Error('Private owner pairing unavailable'));}});});
const sameTime=(a,b)=>typeof a==='string'&&a===b;
function owned(p,component,record){return matchesOwnedRuntimeProcess(p,{component,record,node:spec.node});}
function pins(component){for(const f of component.pins)if(sha(fs.readFileSync(f.path))!==f.sha256)throw Error(component.name+' qualified input changed');}
function atomic(file,value){const tmp=file+'.'+randomUUID()+'.tmp',handle=fs.openSync(tmp,'wx');try{fs.writeFileSync(handle,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(handle);}finally{fs.closeSync(handle);}fs.renameSync(tmp,file);}
let journal={schemaVersion:1,operations:[]};if(fs.existsSync(root+'/effect-journal.json'))journal=record(root+'/effect-journal.json');
function event(value){journal.operations.push({at:new Date().toISOString(),...value});atomic(root+'/effect-journal.json',journal);}
const state=new Map();for(const c of spec.components){pins(c);let current=null;const previous=fs.existsSync(root+'/status.json')?record(root+'/status.json').components?.find(r=>r.name===c.name):null,recovery=reconcileRuntimeRecoveryJournal(journal,c.name);
 for(const r of [previous?.process,...c.adopt,...recovery.records].filter(Boolean)){const p=inspect(r.pid);if(owned(p,c,r)){if(current&&current.pid!==p.pid)throw Error('Duplicate exact runtime candidates');current=p;}}
 state.set(c.name,{name:c.name,component:c,process:current,status:recovery.unsettledLaunchId?'launch-outcome-unknown':current?'adopted':'missing',unsettledLaunchId:recovery.unsettledLaunchId,failures:0,nextAttempt:0,healthySince:current?Date.now():null,child:null,probeFailures:0});
}
async function start(s){pins(s.component);if(s.failures>=8){s.status='bounded-retry-exhausted';return;}
 if(s.name==='local'){try{const r=await fetch(spec.localOrigin+'/api/world-launcher?project='+spec.projectId,{signal:AbortSignal.timeout(2000)});if(r){s.status='listener-present-not-owned';return;}}catch(e){if(e.cause?.code!=='ECONNREFUSED'){s.status='unconfirmed-listener-no-duplicate';return;}}}
 const id=randomUUID();event({id,component:s.name,state:'launch-reserved',driver:s.component.driver});s.pendingLaunchId=id;
 const out=fs.openSync(root+'/'+s.name+'-'+id+'.stdout.log','wx'),err=fs.openSync(root+'/'+s.name+'-'+id+'.stderr.log','wx');
 const child=spawn(spec.node,[s.component.driver,'--run'],{cwd:path.dirname(s.component.driver),windowsHide:true,stdio:['pipe',out,err]});s.child=child;
 await new Promise((resolve,reject)=>{child.once('error',reject);child.once('spawn',resolve);});
 if(s.name==='publisher')child.stdin.end(JSON.stringify({ownerBearer:secret})+'\n');else child.stdin.end();fs.closeSync(out);fs.closeSync(err);
 const p=inspect(child.pid);if(!p){s.status='launch-outcome-unknown';s.unsettledLaunchId=id;event({id,component:s.name,state:'launch-outcome-unknown',pid:child.pid});return;}s.process=p;s.status='started';s.healthySince=null;s.probeFailures=0;
 event({id,component:s.name,state:'spawned',process:p});s.pendingLaunchId=null;
}
let stopping=false;for(const sig of ['SIGINT','SIGTERM'])process.once(sig,()=>{stopping=true;secret=null;});
const handled=new Set(journal.operations.filter(o=>o.controlRequestId&&['stopped-for-recovery','refused-no-kill'].includes(o.state)).map(o=>o.controlRequestId));
while(!stopping){
 for(const s of state.values()){
  // Unavailable inspection is neither absence nor a new process identity.
  // Retain the original child and defer all start/stop decisions on this tick.
  if(s.process&&(s.inspectionNextAttempt||0)>Date.now()){s.status='inspection-unavailable';continue;}
  let p;try{p=s.process?inspect(s.process.pid):null;s.inspectionFailures=0;s.inspectionNextAttempt=0;}
  catch{s.status='inspection-unavailable';s.healthySince=null;s.inspectionFailures=(s.inspectionFailures||0)+1;
   s.inspectionNextAttempt=Date.now()+Math.min(60000,3000*2**Math.min(s.inspectionFailures-1,5));continue;}
  if(s.process&&!owned(p,s.component,s.process)){event({component:s.name,state:p?'pid-reused-preserved':'owned-child-exited',prior:s.process});s.process=null;s.failures++;s.nextAttempt=Date.now()+Math.min(60000,1000*2**Math.min(s.failures-1,6));s.status='backoff';s.healthySince=null;}
  if(!s.process&&!s.unsettledLaunchId&&Date.now()>=s.nextAttempt&&!['bounded-retry-exhausted','launch-outcome-unknown','owner-authorization-required'].includes(s.status)){try{s.child=null;s.pendingLaunchId=null;await start(s);}catch{if(s.child?.pid){s.status='launch-outcome-unknown';s.unsettledLaunchId=s.pendingLaunchId;event({id:s.pendingLaunchId,component:s.name,state:s.status,pid:s.child.pid});}else{if(s.pendingLaunchId)event({id:s.pendingLaunchId,component:s.name,state:'launch-reconciled-no-child'});s.failures++;s.nextAttempt=Date.now()+Math.min(60000,1000*2**Math.min(s.failures-1,6));s.status=s.failures>=8?'bounded-retry-exhausted':'backoff';event({component:s.name,state:s.status,attempt:s.failures});}}}
  if(s.process){
   if(s.name==='local'){try{const r=await fetch(spec.localOrigin+'/api/world-launcher?project='+spec.projectId,{signal:AbortSignal.timeout(3000)});if(r.ok){const x=await r.json();if(x.projectId!==spec.projectId||x.worldId!==spec.worldId||x.projectRootSha256!==spec.projectRootSha256)throw Error('Foreign identity');s.status='healthy';s.probeFailures=0;s.healthySince??=Date.now();}else s.status='source-unavailable';}catch{s.status='reconnecting';s.probeFailures++;}}
   else{try{const health=JSON.parse(fs.readFileSync(path.join(path.dirname(s.process.commandLine?.includes(s.component.driver)?s.component.driver:s.component.adopt.find(a=>a.pid===s.process.pid)?.driver||s.component.driver),'status.json')));const revoked=health.pid===s.process.pid&&Object.values(health.results||{}).some(v=>[401,403].includes(v.httpStatus));if(revoked){const original=inspect(s.process.pid);if(owned(original,s.component,s.process)){event({component:s.name,state:'authorization-rejected-owned-stop-reserved',process:original});process.kill(original.pid);event({component:s.name,state:'owner-authorization-required',process:original});s.process=null;}s.status='owner-authorization-required';s.healthySince=null;}else if(health.pid===s.process.pid&&Date.now()-Date.parse(health.at)<45000&&Object.values(health.results||{}).length===3&&Object.values(health.results).every(v=>v.httpStatus===200)){s.status='healthy';s.healthySince??=Date.now();}else{s.status='reconnecting';s.healthySince=null;}}catch{s.status='starting';s.healthySince=null;}}
   if(s.healthySince&&Date.now()-s.healthySince>=60000)s.failures=0;
  }
  if(s.unsettledLaunchId)s.status='launch-outcome-unknown';
 }
 if(fs.existsSync(root+'/control-request.json')){let request;try{const bytes=fs.readFileSync(root+'/control-request.json');if(bytes.length<=2048)request=JSON.parse(bytes);}catch{}
  if(request&&typeof request.requestId==='string'&&!handled.has(request.requestId)){
   const s=state.get(request.component);let p=null,inspectionAvailable=true;
   if(s?.process&&(s.inspectionNextAttempt||0)>Date.now())inspectionAvailable=false;
   else try{p=s?.process?inspect(s.process.pid):null;}catch{inspectionAvailable=false;}
   if(!inspectionAvailable){if(s)s.status='inspection-unavailable';}
   else{const valid=request.schemaVersion===1&&request.action==='exercise-owned-recovery'&&s&&!s.unsettledLaunchId&&owned(p,s.component,s.process)&&request.expectedPid===p.pid&&sameTime(request.expectedCreatedUtc,p.createdUtc);
   if(valid){pins(s.component);event({controlRequestId:request.requestId,component:s.name,state:'owned-stop-reserved',process:p});process.kill(p.pid);event({controlRequestId:request.requestId,component:s.name,state:'stopped-for-recovery',process:p});}else event({controlRequestId:request.requestId,state:'refused-no-kill'});handled.add(request.requestId);}
  }
 }
 atomic(root+'/status.json',{schemaVersion:1,at:new Date().toISOString(),state:'approved-runtime-supervision',supervisor:own,source:spec.source,plugin:spec.plugin,world:spec.world,website:spec.website,components:[...state.values()].map(s=>({name:s.name,status:s.status,process:s.process,failures:s.failures,nextAttemptUtc:s.nextAttempt?new Date(s.nextAttempt).toISOString():null})),aiCalls:0,modelOrAgentSettingsChanges:0,publicEndpoints:0,plaintextSecretPersisted:false});
 await new Promise(resolve=>setTimeout(resolve,3000));
}
