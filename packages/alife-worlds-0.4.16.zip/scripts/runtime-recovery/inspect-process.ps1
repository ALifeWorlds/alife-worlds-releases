param([Parameter(Mandatory=$true)][ValidateRange(1,2147483647)][int]$TargetProcessId)
$p=Get-CimInstance Win32_Process -Filter "ProcessId=$TargetProcessId"
if(-not $p){'null';exit 0}
[ordered]@{pid=$p.ProcessId;createdUtc=$p.CreationDate.ToUniversalTime().ToString('o');commandLine=$p.CommandLine;executablePath=$p.ExecutablePath;parentPid=$p.ParentProcessId}|ConvertTo-Json -Compress
