$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$spec=Get-Content -LiteralPath (Join-Path $taskRoot 'supervisor-spec.json') -Raw|ConvertFrom-Json
if([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -ne $spec.ownerSid){throw 'Exact credential owner required'}
. (Join-Path $taskRoot 'credential-vault.ps1')
[Console]::WriteLine('Ready for existing owner credential JSON (input is hidden).')
$builder=New-Object Text.StringBuilder
while($true){$key=[Console]::ReadKey($true);if($key.Key -eq [ConsoleKey]::Enter -or $key.KeyChar -eq "`n"){break};if($builder.Length -ge 16384){throw 'Credential input bound'};[void]$builder.Append($key.KeyChar)}
try{
 try{$payload=$builder.ToString()|ConvertFrom-Json}catch{throw 'Invalid hidden owner pairing'}
 if(@($payload.PSObject.Properties).Count -ne 1 -or -not ($payload.ownerBearer -is [string])){throw 'Exact owner pairing required'}
 [ALifeWorldCredential]::Save($spec.credentialTarget,$spec.ownerOrigin,$payload.ownerBearer)
 $back=[ALifeWorldCredential]::Load($spec.credentialTarget,$spec.ownerOrigin)
 if($back -cne $payload.ownerBearer){throw 'Credential readback mismatch'}
 [ordered]@{schemaVersion=1;at=[DateTime]::UtcNow.ToString('o');state='EXISTING_PROJECT_OWNER_CREDENTIAL_STORED_IN_WINDOWS_VAULT';target=$spec.credentialTarget;ownerSid=$spec.ownerSid;plaintextFile=$false;tokenRotated=$false}|ConvertTo-Json -Compress
}finally{$payload=$null;$back=$null;[void]$builder.Clear()}
