const normalize=value=>value.replaceAll('\\','/').toLowerCase();
const escape=value=>value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const token=value=>/\s/.test(value)?'"'+escape(value)+'"':'(?:"'+escape(value)+'"|'+escape(value)+')';
const timestamp=value=>typeof value==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{7}Z$/.test(value)&&Number.isFinite(Date.parse(value));
// Match the complete three-argument Node invocation, including ordinary paths
// without spaces. Millisecond truncation never substitutes for creation identity.
export function matchesOwnedRuntimeProcess(process,{component,record,node}={}){
 if(!process||!record||!component||!Number.isSafeInteger(process.pid)||process.pid<1||process.pid!==record.pid||!timestamp(process.createdUtc)||process.createdUtc!==record.createdUtc||typeof process.executablePath!=='string'||typeof node!=='string'||normalize(process.executablePath)!==normalize(node)||typeof process.commandLine!=='string'||!Array.isArray(component.adopt))return false;
 const line=normalize(process.commandLine).trim(),executable=token(normalize(node));
 return [component.driver,...component.adopt.map(row=>row.driver)].some(driver=>typeof driver==='string'&&new RegExp('^'+executable+'\\s+'+token(normalize(driver))+'\\s+--run$').test(line));
}

// A crashed supervisor may have spawned a child before saving its status. Reuse
// its exact durable process identity; a reservation alone never permits replay.
export function reconcileRuntimeRecoveryJournal(journal,component){
 if(!journal||journal.schemaVersion!==1||!Array.isArray(journal.operations)||journal.operations.length>10000||!['local','publisher'].includes(component))throw Error('Bounded recovery journal unavailable');
 const reservation=journal.operations.filter(row=>row.component===component&&row.state==='launch-reserved').at(-1);
 if(!reservation)return {records:[],unsettledLaunchId:null};
 if(typeof reservation.id!=='string'||reservation.id.length>100)throw Error('Recovery launch identity unavailable');
 const known=journal.operations.filter(row=>row.id===reservation.id&&row.component===component&&row.state==='spawned').at(-1);
 const process=known?.process;
 if(process&&Number.isSafeInteger(process.pid)&&process.pid>0&&timestamp(process.createdUtc)&&typeof process.commandLine==='string'&&typeof process.executablePath==='string')return {records:[process],unsettledLaunchId:null};
 const settled=journal.operations.some(row=>row.id===reservation.id&&row.component===component&&row.state==='launch-reconciled-no-child');
 return {records:[],unsettledLaunchId:settled?null:reservation.id};
}
