import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {runLauncherStdio,PROFILE_ENV,DEFAULT_PROFILE} from '../lib/world-launcher.mjs';
const packageRoot=fileURLToPath(new URL('../',import.meta.url));
try{
 const {version}=JSON.parse(await readFile(new URL('../package.json',import.meta.url),'utf8'));
 await runLauncherStdio({input:process.stdin,output:process.stdout,errors:process.stderr,packageRoot,profilePath:process.env[PROFILE_ENV]??DEFAULT_PROFILE,version});
}catch{process.stderr.write('ALife World launcher is unavailable.\n');process.exitCode=1;}
