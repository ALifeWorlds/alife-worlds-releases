import {fileURLToPath} from 'node:url';
import {checkAttribution} from '../lib/attribution-check.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),args=process.argv.slice(2);
if(args.length&&!(args.length===2&&args[0]==='--base-ref'))throw Error('Use no arguments or --base-ref FULL_COMMIT');
try{const result=await checkAttribution(root,{baseRef:args[1]??null});console.log(JSON.stringify(result));if(result.status!=='PASS')process.exitCode=1;}catch(error){console.error(error.message);process.exitCode=1;}
