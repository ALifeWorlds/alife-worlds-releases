import fs from 'node:fs/promises';import path from 'node:path';import {fileURLToPath} from 'node:url';import {execFileSync} from 'node:child_process';
import {materializeRuntimeRecovery} from '../lib/runtime-recovery.mjs';
const packageRoot=fileURLToPath(new URL('../',import.meta.url));
try{
 if(process.argv.length!==5||process.argv[2]!=='prepare'||process.argv[3]!=='--project-root')throw Error('Use prepare --project-root ABSOLUTE_ROOT with the already authorized closed recovery recipe on stdin. Preparation creates no task, pairing, service or AI action.');
 if(process.platform!=='win32')throw Error('Windows logon recovery is unavailable on this host');
 let input='',size=0;for await(const part of process.stdin){size+=part.length;if(size>1024*1024)throw Error('Recovery recipe input bound');input+=part.toString('utf8');}
 let recipe;try{recipe=JSON.parse(input);}catch{throw Error('Invalid recovery recipe');}input='';
 const shell=path.join(process.env.SystemRoot,'System32/WindowsPowerShell/v1.0/powershell.exe');
 const owner=JSON.parse(execFileSync(shell,['-NoProfile','-NonInteractive','-Command',"$o=[Security.Principal.WindowsIdentity]::GetCurrent(); @{user=$o.Name;sid=$o.User.Value}|ConvertTo-Json -Compress"],{encoding:'utf8',windowsHide:true,timeout:10000}));
 console.log(JSON.stringify(await materializeRuntimeRecovery({packageRoot,projectRoot:process.argv[4],recipe,owner}),null,2));
}catch(error){console.error(error.message);process.exitCode=1;}
