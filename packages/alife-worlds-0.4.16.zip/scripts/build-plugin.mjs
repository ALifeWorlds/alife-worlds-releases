import {checkAllRuleDocuments as checkRuleDocuments} from '../lib/agent-rules.mjs';
import {checkAttribution} from '../lib/attribution-check.mjs';
import {readFile,writeFile,mkdir,readdir,copyFile,rename,lstat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {readPluginManifests,collectPackageInputs,packageFingerprint,readReleaseLedger,checkReleasedContent,FINGERPRINT_ALGORITHM} from '../lib/plugin-version.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),base=path.join(root,'.plugin-build');
await readPluginManifests(root);
await mkdir(base,{recursive:true});
if((await lstat(base)).isSymbolicLink())throw Error('Redirected build root refused.');
const args=process.argv.slice(2);if(args.some(x=>x!=='--candidate'))throw Error('Use --candidate for an isolated qualification packet.');
const build=path.join(base,'build-'+randomUUID()),output=path.join(base,args.includes('--candidate')?'candidate-'+randomUUID():'alife-worlds');
await mkdir(build);
const inputs=await collectPackageInputs(root);
await checkRuleDocuments(root);
const attribution=await checkAttribution(root);if(attribution.status!=='PASS')throw Error('Required copyright, license or governance documentation checks failed: '+attribution.errors.map(e=>e.code+': '+e.file).join('; '));
async function moveOwnedDirectory(from,to) {
 const parent=path.resolve(base);
 if(path.dirname(path.resolve(from))!==parent||path.dirname(path.resolve(to))!==parent||path.resolve(from)===path.resolve(to))throw Error('Publication move must stay in the exact owned build directory.');
 const baseInfo=await lstat(base);if(!baseInfo.isDirectory()||baseInfo.isSymbolicLink())throw Error('Redirected publication root refused.');
 let original;try{original=await lstat(from,{bigint:true});}catch(e){throw Error('Original publication directory is unavailable; preserve and reconcile it.',{cause:e});}
 if(!original.isDirectory()||original.isSymbolicLink())throw Error('Regular owned publication directory required.');
 const delays=[50,100,200,400,400,400];
 for(let attempt=0;;attempt++){
  let current;try{current=await lstat(from,{bigint:true});}catch(e){throw Error('Publication source changed; reconcile the original move before retry.',{cause:e});}
  if(!current.isDirectory()||current.isSymbolicLink()||current.dev!==original.dev||current.ino!==original.ino||current.birthtimeNs!==original.birthtimeNs)throw Error('Publication source identity changed; preserve both locations.');
  try{await lstat(to);throw Error('Publication destination already exists; preserve both locations.');}catch(e){if(e.code!=='ENOENT')throw e;}
  try{await rename(from,to);return attempt;}
  catch(e){
   if(process.platform!=='win32'||!['EPERM','EBUSY','EACCES'].includes(e.code)||attempt>=delays.length)throw e;
   await new Promise(resolve=>setTimeout(resolve,delays[attempt]));
  }
 }
}
let publicationRetries=0;

async function copy(rel){
 const from=path.join(root,rel),info=await lstat(from);
 if(info.isSymbolicLink()||!info.isFile())throw Error('Nonregular package input refused: '+rel);
 const to=path.join(build,rel);await mkdir(path.dirname(to),{recursive:true});await copyFile(from,to);
}
for(const rel of inputs)await copy(rel);
await checkRuleDocuments(build);
const {manifest}=await readPluginManifests(build);
if(manifest.extensions['com.openai'].interface.shortDescription.length>30)throw Error('Listing subtitle too long.');
const empty=JSON.parse(await readFile(path.join(build,'data/project-state.example.json'),'utf8'));
if(empty.agents.length||empty.tasks.length||empty.events.length)throw Error('Private project data refused.');
const list=await collectPackageInputs(build);
const denied=list.filter(p=>/(^|\/)(runtime|\.git|node_modules)(\/|$)/.test(p)||/(^|\/)(receipt|checkpoint|binding)\.json$/.test(p)||['data/project-state.json','data/agent-bindings.json','antfarm.config.json'].includes(p));
if(denied.length)throw Error('Private files refused: '+denied.join(','));
const contentFingerprint=await packageFingerprint(build,list),releaseState=checkReleasedContent(await readReleaseLedger(build),manifest.version,contentFingerprint);
if(releaseState!=='released'&&!args.includes('--candidate'))throw Error('Plugin version is not sealed. Qualify with --candidate, then run npm run version:seal -- QUALIFIED_SHA256 before updating the marketplace packet.');
const provenance={schemaVersion:1,fingerprintAlgorithm:FINGERPRINT_ALGORITHM,contentFingerprint,releaseState,name:manifest.name,version:manifest.version,repository:'https://github.com/ALifeWorlds/alife-worlds',files:list.sort(),containsPrivatePlan:false};
await writeFile(path.join(build,'package-provenance.json'),JSON.stringify(provenance,null,2)+'\n');
try{
 const old=await lstat(output);if(old.isSymbolicLink()||!old.isDirectory())throw Error('Existing build target is not a regular owned directory.');
 const marker=JSON.parse(await readFile(path.join(output,'package-provenance.json'),'utf8'));
 if(marker.name!==manifest.name)throw Error('Unowned existing build target refused.');
 publicationRetries+=await moveOwnedDirectory(output,path.join(base,'previous-'+randomUUID()));
}catch(e){if(e.code!=='ENOENT')throw e;}
publicationRetries+=await moveOwnedDirectory(build,output);
console.log(JSON.stringify({name:manifest.name,version:manifest.version,output,contentFingerprint,releaseState,files:list.length,containsPrivatePlan:false,publicationRetries}));
