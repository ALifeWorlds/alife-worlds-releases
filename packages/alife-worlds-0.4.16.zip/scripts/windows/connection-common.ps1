Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
# A Node child may inherit PS7 module paths. Load the current Windows host's
# trusted ACL cmdlets explicitly; never resolve a different runtime's module.
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Security/Microsoft.PowerShell.Security.psd1') -ErrorAction Stop
function Assert-LocalPath([string]$Path) {
 if (![IO.Path]::IsPathRooted($Path) -or $Path.StartsWith('\\') -or $Path -match '[\r\n\x00"]') { throw 'Explicit local path required' }
 $cursor=[IO.Path]::GetFullPath($Path)
 while ($cursor) { if (Test-Path -LiteralPath $cursor) { $item=Get-Item -LiteralPath $cursor -Force; if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Redirected path refused' } }; $parent=[IO.Path]::GetDirectoryName($cursor); if ($parent -eq $cursor) { break }; $cursor=$parent }
}
function Read-ConnectionSettings([string]$ConfigFile) {
 Assert-LocalPath $ConfigFile
 $item=Get-Item -LiteralPath $ConfigFile -Force;if($item.Length -gt 262144){throw 'Config bound'}
 $c=[IO.File]::ReadAllText($ConfigFile)|ConvertFrom-Json
 $keys=@('schemaVersion','kind','projectRoot','planningRoot','packetRoot','qualificationFile','configFile','nodePath','port','directorThreadId','projectId','ownerSiteOrigin')
 if(@($c.PSObject.Properties.Name).Count -ne $keys.Count){throw 'Closed config required'};foreach($key in $keys){if($c.PSObject.Properties.Name -notcontains $key){throw 'Missing config field'}}
 if($c.schemaVersion -ne 1 -or $c.kind -ne 'windows-owner-connection' -or $c.port -lt 1024 -or $c.port -gt 65535){throw 'Connection config invalid'}
 foreach($key in @('projectRoot','planningRoot','packetRoot','qualificationFile','configFile','nodePath')){Assert-LocalPath $c.$key}
 $directory=Join-Path $c.projectRoot '.alife-worlds/connection-supervisor';$expected=Join-Path $directory 'connection.json'
 if(![String]::Equals([IO.Path]::GetFullPath($ConfigFile),[IO.Path]::GetFullPath($expected),[StringComparison]::OrdinalIgnoreCase)){throw 'Exact private config path required'}
 $origin=[uri]$c.ownerSiteOrigin;if($origin.Scheme -ne 'https' -or $origin.GetLeftPart([UriPartial]::Authority) -ne $c.ownerSiteOrigin){throw 'Exact owner origin required'}
 return @{Config=$c;Directory=$directory;Credential=(Join-Path $directory 'credentials.dpapi.json');ConfigFile=[IO.Path]::GetFullPath($ConfigFile)}
}
function Set-OwnerOnlyAcl([string]$Path) {
 Assert-LocalPath $Path;$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User;$isDirectory=(Get-Item -LiteralPath $Path).PSIsContainer
 $acl=if($isDirectory){New-Object Security.AccessControl.DirectorySecurity}else{New-Object Security.AccessControl.FileSecurity};$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false)
 $rule=if($isDirectory){New-Object Security.AccessControl.FileSystemAccessRule($sid,'FullControl','ContainerInherit,ObjectInherit','None','Allow')}else{New-Object Security.AccessControl.FileSystemAccessRule($sid,'FullControl','Allow')};$acl.AddAccessRule($rule);Set-Acl -LiteralPath $Path -AclObject $acl
}
function Assert-OwnerOnlyAcl([string]$Path) {
 Assert-LocalPath $Path;$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User;$acl=Get-Acl -LiteralPath $Path
 if($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -ne $sid.Value -or !$acl.AreAccessRulesProtected){throw 'Private current-user ACL required'}
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));if(!$rules.Count){throw 'Private ACL unavailable'}
 foreach($rule in $rules){if($rule.AccessControlType -eq 'Allow' -and $rule.IdentityReference.Value -ne $sid.Value){throw 'Foreign private-file access refused'}}
}
function Get-ConnectionEntropy($c) {return [Text.Encoding]::UTF8.GetBytes('ALife current-user connection|'+$c.projectId+'|'+$c.ownerSiteOrigin)}
function Read-HiddenPairing([switch]$FromStdin) {
 if($FromStdin){if(![Console]::IsInputRedirected){throw 'Hidden redirected stdin required'};return [Console]::In.ReadToEnd()}
 $secure=Read-Host 'Private pairing JSON (hidden)' -AsSecureString;$pointer=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
 try{return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer);$secure.Dispose()}
}
function Assert-PrivatePairing([string]$Text,$c) {
 if([Text.Encoding]::UTF8.GetByteCount($Text) -gt 16384){throw 'Pairing input bound'};$p=$Text|ConvertFrom-Json
 $keys=@('mode','siteUrl','dashboardOrigin','syncKey','serviceToken','catalogProfile');foreach($key in $p.PSObject.Properties.Name){if($keys -notcontains $key){throw 'Unknown pairing field'}}
 if($p.mode -ne 'owner-bundle' -or ([uri]$p.siteUrl).GetLeftPart([UriPartial]::Authority) -ne $c.ownerSiteOrigin -or $p.siteUrl -notin @($c.ownerSiteOrigin,$c.ownerSiteOrigin+'/') -or $p.dashboardOrigin -ne ('http://127.0.0.1:'+$c.port) -or $p.syncKey.Length -lt 32 -or $p.syncKey.Length -gt 4096 -or $p.serviceToken.Length -lt 16 -or $p.serviceToken.Length -gt 8192 -or ($p.syncKey+$p.serviceToken) -match '[\r\n\x00]'){throw 'Exact private pairing required'}
 return $p
}
