[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ConfigFile)
. (Join-Path $PSScriptRoot 'connection-common.ps1')
try {
 $s=Read-ConnectionSettings $ConfigFile;$c=$s.Config;foreach($p in @($s.Directory,$s.ConfigFile,$s.Credential)){Assert-OwnerOnlyAcl $p}
 if((Get-Item -LiteralPath $s.Credential).Length -gt 98304){throw 'Credential file bound'};$record=[IO.File]::ReadAllText($s.Credential)|ConvertFrom-Json
 if($record.schemaVersion -ne 1 -or $record.kind -ne 'current-user-protected-owner-connection' -or $record.ownerSid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -or $record.projectId -ne $c.projectId -or $record.ownerSiteOrigin -ne $c.ownerSiteOrigin -or $record.ciphertext.Length -gt 65536){throw 'Protected credential binding differs'}
 Add-Type -AssemblyName System.Security;$plain=[Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($record.ciphertext),(Get-ConnectionEntropy $c),[Security.Cryptography.DataProtectionScope]::CurrentUser)
 try{$text=[Text.Encoding]::UTF8.GetString($plain);$null=Assert-PrivatePairing $text $c;$entry=Join-Path $c.packetRoot 'scripts/connection-supervisor.mjs';Assert-LocalPath $entry
  $start=[Diagnostics.ProcessStartInfo]::new();$start.FileName=$c.nodePath;$start.Arguments='"'+$entry+'" --config-file "'+$s.ConfigFile+'"';$start.WorkingDirectory=$c.projectRoot;$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardInput=$true
  $child=[Diagnostics.Process]::new();$child.StartInfo=$start;if(!$child.Start()){throw 'Supervisor launch failed'};$child.StandardInput.Write($text);$child.StandardInput.Close();$text=$null;$child.WaitForExit();exit $child.ExitCode
 }finally{[Array]::Clear($plain,0,$plain.Length);$text=$null}
} catch {Write-Error 'Connection supervisor requires explicit ownership, configuration or credential repair.';exit 1}
