[CmdletBinding(SupportsShouldProcess=$true)]
param([Parameter(Mandatory=$true)][string]$ConfigFile,[switch]$FromStdin,[switch]$ResetRepairHold)
. (Join-Path $PSScriptRoot 'connection-common.ps1')
try {
 $s=Read-ConnectionSettings $ConfigFile;$c=$s.Config
 if(!$PSCmdlet.ShouldProcess($s.Directory,'Store current-user protected connection credentials')){return}
 [IO.Directory]::CreateDirectory($s.Directory)|Out-Null;Set-OwnerOnlyAcl $s.Directory;Set-OwnerOnlyAcl $s.ConfigFile
 $text=Read-HiddenPairing -FromStdin:$FromStdin;$null=Assert-PrivatePairing $text $c
 Add-Type -AssemblyName System.Security;$plain=[Text.Encoding]::UTF8.GetBytes($text)
 try{$cipher=[Security.Cryptography.ProtectedData]::Protect($plain,(Get-ConnectionEntropy $c),[Security.Cryptography.DataProtectionScope]::CurrentUser)}finally{[Array]::Clear($plain,0,$plain.Length);$text=$null}
 $value=@{schemaVersion=1;kind='current-user-protected-owner-connection';ownerSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;projectId=$c.projectId;ownerSiteOrigin=$c.ownerSiteOrigin;ciphertext=[Convert]::ToBase64String($cipher)}|ConvertTo-Json -Compress
 $temp=$s.Credential+'.'+[Guid]::NewGuid().ToString('N')+'.new';$bytes=[Text.UTF8Encoding]::new($false).GetBytes($value);$handle=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$handle.Write($bytes,0,$bytes.Length);$handle.Flush($true)}finally{$handle.Dispose()};Set-OwnerOnlyAcl $temp
 if(Test-Path -LiteralPath $s.Credential){Assert-OwnerOnlyAcl $s.Credential;$backup=$s.Credential+'.retained.'+[Guid]::NewGuid().ToString('N');[IO.File]::Replace($temp,$s.Credential,$backup)}else{[IO.File]::Move($temp,$s.Credential)}
 Assert-OwnerOnlyAcl $s.Credential;if([IO.File]::ReadAllText($s.Credential) -ne $value){throw 'Protected credential readback unavailable'}
 if($ResetRepairHold){$hold=Join-Path $s.Directory 'repair-required.json';if(Test-Path -LiteralPath $hold){Assert-LocalPath $hold;Move-Item -LiteralPath $hold -Destination ($hold+'.retained.'+[Guid]::NewGuid().ToString('N'))}}
 Write-Output '{"state":"protected-credentials-stored","taskStarted":false}'
} catch {Write-Error 'Protected credential setup refused; no secret details are logged.';exit 1}
