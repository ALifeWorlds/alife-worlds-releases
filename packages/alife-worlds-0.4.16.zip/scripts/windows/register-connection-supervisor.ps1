[CmdletBinding(SupportsShouldProcess=$true)]
param([Parameter(Mandatory=$true)][string]$ConfigFile,[switch]$Install,[switch]$StartNow)
. (Join-Path $PSScriptRoot 'connection-common.ps1')
try {
 $s=Read-ConnectionSettings $ConfigFile;$c=$s.Config;$user=[Security.Principal.WindowsIdentity]::GetCurrent().Name
 $digest=[Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes([IO.Path]::GetFullPath($c.projectRoot).ToLowerInvariant()));$suffix=([BitConverter]::ToString($digest)).Replace('-','').Substring(0,16).ToLowerInvariant();$name='ALifeWorlds-Connection-'+$suffix
 $entry=Join-Path $c.packetRoot 'scripts/windows/connection-supervisor.ps1';Assert-LocalPath $entry;$powershell=Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell/v1.0/powershell.exe';$arguments='-NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "'+$entry+'" -ConfigFile "'+$s.ConfigFile+'"'
 if(!$Install){Write-Output ('Explicit opt-in required: -Install. Task: '+$name);return}
 foreach($p in @($s.Directory,$s.ConfigFile,$s.Credential)){Assert-OwnerOnlyAcl $p}
 if(!$PSCmdlet.ShouldProcess($name,'Register limited current-user interactive-logon connection supervisor')){return}
 $existing=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
 if($existing){if($existing.Description -ne ('ALife owner connection '+$s.ConfigFile) -or $existing.Principal.UserId -notin @($user,[Security.Principal.WindowsIdentity]::GetCurrent().User.Value)){throw 'Foreign task refused'};Export-ScheduledTask -TaskName $name|Set-Content -LiteralPath (Join-Path $s.Directory ('task-retained-'+[Guid]::NewGuid().ToString('N')+'.xml')) -Encoding utf8}
 $action=New-ScheduledTaskAction -Execute $powershell -Argument $arguments -WorkingDirectory $c.projectRoot;$trigger=New-ScheduledTaskTrigger -AtLogOn -User $user;$principal=New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval ([TimeSpan]::FromMinutes(1))
 Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description ('ALife owner connection '+$s.ConfigFile) -Force|Out-Null
 if($StartNow){Start-ScheduledTask -TaskName $name};Write-Output ('Registered '+$name+'; startNow='+[bool]$StartNow)
} catch {Write-Error 'Task registration refused; existing tasks and credentials require reconciliation.';exit 1}
