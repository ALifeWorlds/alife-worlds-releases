// One-shot wrapper over the same in-process reader used by the shared publisher.
import {createSiteBundleSource} from '../lib/site-sync-source.mjs';
const args=process.argv.slice(2),values=new Map();
for(let i=0;i<args.length;i+=2){if(!['--dashboard-origin','--owner-origin','--revision','--catalog-profile'].includes(args[i])||values.has(args[i])||!args[i+1])throw Error('Use explicit dashboard origin, owner origin and reserved revision.');values.set(args[i],args[i+1]);}
if(![3,4].includes(values.size)||!values.has('--dashboard-origin')||!values.has('--owner-origin')||!/^\d+$/.test(values.get('--revision')||''))throw Error('Explicit reserved revision required');
const revision=Number(values.get('--revision'));if(!Number.isSafeInteger(revision)||revision<1)throw Error('Invalid reserved revision');
const source=await createSiteBundleSource({projectRoot:process.cwd(),dashboardOrigin:values.get('--dashboard-origin'),ownerOrigin:values.get('--owner-origin'),catalogProfile:values.get('--catalog-profile')});
process.stdout.write(JSON.stringify(await source.observe(revision))+'\n');