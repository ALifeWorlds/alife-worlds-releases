import {readFile,lstat,realpath,mkdir,open,rename,unlink} from 'node:fs/promises';
import path from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {execFile} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const hash=x=>createHash('sha256').update(x).digest('hex');
const same=(a,b)=>path.resolve(a).toLowerCase()===path.resolve(b).toLowerCase();
const within=(root,p)=>same(root,p)||path.resolve(p).toLowerCase().startsWith(path.resolve(root).toLowerCase()+path.sep);
const exact=(o,keys)=>o&&typeof o==='object'&&!Array.isArray(o)&&Object.keys(o).length===keys.length&&keys.every(k=>Object.hasOwn(o,k));
export function assertConnectionConfig(c){
 const keys=['schemaVersion','kind','projectRoot','planningRoot','packetRoot','qualificationFile','configFile','nodePath','port','directorThreadId','projectId','ownerSiteOrigin'];
 if(!exact(c,keys)||c.schemaVersion!==1||c.kind!=='windows-owner-connection'||!Number.isSafeInteger(c.port)||c.port<1024||c.port>65535||![c.directorThreadId,c.projectId].every(x=>typeof x==='string'&&/^[a-zA-Z0-9_-]{1,100}$/.test(x)))throw Error('Exact connection configuration required');
 for(const key of ['projectRoot','planningRoot','packetRoot','qualificationFile','configFile','nodePath'])if(typeof c[key]!=='string'||!path.isAbsolute(c[key])||/[\r\n\0"]/.test(c[key])||c[key].startsWith('\\\\'))throw Error('Explicit local absolute paths required');
 if(!within(c.projectRoot,c.planningRoot)||!within(c.planningRoot,c.configFile)||within(c.packetRoot,c.projectRoot)||within(c.packetRoot,c.planningRoot)||within(c.packetRoot,c.qualificationFile))throw Error('Separate qualified packet and original private project required');
 const u=new URL(c.ownerSiteOrigin);if(u.protocol!=='https:'||u.origin!==c.ownerSiteOrigin||u.username||u.password)throw Error('Exact private owner origin required');
 return c;
}
export async function safeJSON(file,limit=262144){
 const absolute=path.resolve(file),parts=absolute.slice(path.parse(absolute).root.length).split(path.sep);let cursor=path.parse(absolute).root;
 for(const part of parts){cursor=path.join(cursor,part);const info=await lstat(cursor);if(info.isSymbolicLink())throw Error('Redirected private source refused');}
 const h=await open(absolute,'r');try{const a=await h.stat();if(!a.isFile()||a.size>limit)throw Error('Private source bound');const text=await h.readFile('utf8'),b=await h.stat(),latest=await lstat(absolute);if(['ino','dev','size','mtimeMs','ctimeMs'].some(k=>a[k]!==b[k])||!same(await realpath(absolute),absolute)||['ino','dev','size','mtimeMs','ctimeMs'].some(k=>b[k]!==latest[k]))throw Error('Private source changed');return {value:JSON.parse(text.replace(/^\uFEFF/,'')),text,hash:hash(text)};}finally{await h.close();}
}
export async function readConnectionConfig(file){const c=assertConnectionConfig((await safeJSON(file)).value);if(!same(file,path.join(c.projectRoot,'.alife-worlds','connection-supervisor','connection.json')))throw Error('Exact private connection configuration path required');return c;}
export async function verifyConnectionCustody(c,{versionChecker=null}={}){
 const q=(await safeJSON(c.qualificationFile)).value,pkg=(await safeJSON(path.join(c.packetRoot,'package.json'))).value;
 if(q.status!=='PASS'||q.releaseState!=='released'||!same(q.packetRoot,c.packetRoot)||q.version!==pkg.version||!/^\d+\.\d+\.\d+$/.test(pkg.version)||!/^[a-f0-9]{64}$/.test(q.fingerprint||''))throw Error('Exact qualified packet required');
 const check=versionChecker||(await import(pathToFileURL(path.join(c.packetRoot,'lib/plugin-version.mjs')).href)).checkPluginVersion;if(typeof check!=='function')throw Error('Packet content verification unavailable');const actual=await check(c.packetRoot);if(actual.contentFingerprint!==q.fingerprint||actual.releaseState!=='released')throw Error('Actual released packet fingerprint required');
 const bootstrap=(await safeJSON(path.join(c.projectRoot,'.alife-worlds','bootstrap.json'))).value,bindings=(await safeJSON(path.join(c.projectRoot,'.alife-worlds','agent-bindings.json'))).value;
 if(bootstrap.projectId!==c.projectId||bindings.projectId!==c.projectId||!same(bindings.projectRoot,c.projectRoot))throw Error('Same original project required');
 const director=bindings.agents?.find(x=>x.id==='director');if(!director||director.threadId!==c.directorThreadId||typeof director.home!=='string')throw Error('Original bound Director required');
 const home=path.resolve(c.projectRoot,director.home);if(!within(c.projectRoot,home)||same(home,c.projectRoot))throw Error('Original Director home required');
 const receipt=(await safeJSON(path.join(home,'receipt.json'))).value;if(receipt.threadId!==c.directorThreadId||receipt.accessVerified!==true||receipt.contractsFullRead!==true||receipt.projectId!==undefined&&receipt.projectId!==c.projectId)throw Error('Existing full-read Director custody required');
 const config=(await safeJSON(c.configFile)).value;if(config.projectId!==c.projectId||config.mode!=='live'||config.nativeReadOnly!==true||config.commandsEnabled!==false||!same(config.nativeWorkspaceRoot,c.projectRoot))throw Error('Original native read-only configuration required');
 return {qualification:q,config};
}
export function restartDelay(failures){if(!Number.isSafeInteger(failures)||failures<1)throw Error('Bounded failure count required');return Math.min(60000,2000*2**Math.min(failures-1,5));}
export function processIsOriginal(record,current){return current?.state==='present'&&record.pid===current.pid&&record.createdUtc===current.createdUtc&&same(record.exe,current.exe);}
export function originalProcessGone(record,current){if(!record||!Number.isSafeInteger(record.pid)||typeof record.createdUtc!=='string'||typeof record.exe!=='string')throw Error('Original process identity required');if(current?.state==='absent')return true;if(current?.state!=='present')throw Error('Process identity unavailable');return !processIsOriginal(record,current);}
export async function windowsProcessIdentity(pid){
 if(process.platform!=='win32'||!Number.isSafeInteger(pid)||pid<1)throw Error('Windows process identity required');
 const script="$ErrorActionPreference='Stop';Import-Module (Join-Path $PSHOME 'Modules/CimCmdlets/CimCmdlets.psd1') -ErrorAction Stop;$p=Get-CimInstance Win32_Process -Filter 'ProcessId="+pid+"';if($null -eq $p){@{state='absent'}|ConvertTo-Json -Compress}else{if(!$p.ExecutablePath -or !$p.CreationDate){throw 'Identity unavailable'};@{state='present';pid=[int]$p.ProcessId;createdUtc=$p.CreationDate.ToUniversalTime().ToString('o');exe=$p.ExecutablePath}|ConvertTo-Json -Compress}";
 return await new Promise((resolve,reject)=>execFile('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','RemoteSigned','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{windowsHide:true,timeout:8000,maxBuffer:32768},(e,out)=>{if(e)return reject(Error('Windows process identity unavailable'));try{resolve(JSON.parse(out));}catch{reject(Error('Windows process identity unavailable'));}}));
}
export async function acquireSupervisorLock(c,{identity=windowsProcessIdentity,selfPid=process.pid}={}){
 const directory=path.join(c.projectRoot,'.alife-worlds','connection-supervisor');await mkdir(directory,{recursive:true});if(!same(await realpath(directory),directory))throw Error('Redirected supervisor directory refused');
 const file=path.join(directory,'supervisor.lock.json'),self=await identity(selfPid);if(self.state!=='present')throw Error('Own OS identity unavailable');const scope=hash(JSON.stringify(c));
 for(let attempt=0;attempt<2;attempt++){
  try{const handle=await open(file,'wx',0o600),record={schemaVersion:1,kind:'windows-connection-supervisor-lock',scope,...self,nonce:randomUUID()};delete record.state;await handle.writeFile(JSON.stringify(record)+'\n');await handle.sync();await handle.close();return{directory,record,async release(){const prior=await safeJSON(file);if(prior.value.nonce!==record.nonce)throw Error('Supervisor ownership changed');await unlink(file);}};}catch(e){if(e.code!=='EEXIST')throw e;const prior=await safeJSON(file),r=prior.value;if(r.kind!=='windows-connection-supervisor-lock'||r.scope!==scope||!originalProcessGone(r,await identity(r.pid)))throw Error('Existing supervisor ownership requires reconciliation');if((await safeJSON(file)).hash!==prior.hash)throw Error('Supervisor lock changed');await rename(file,file+'.retired.'+prior.hash);}
 }
 throw Error('Supervisor lock contention');
}
export async function recoverOwnedPublisherLock(c,captured,{identity=windowsProcessIdentity}={}){
 const directory=path.join(c.projectRoot,'.alife-worlds','site-sync.lock'),file=path.join(directory,'owner.json');let prior;try{prior=await safeJSON(file,65536);}catch(e){if(e.code==='ENOENT')return false;throw e;}
 if(!captured||captured.hash!==prior.hash||captured.process.pid!==prior.value.pid||!originalProcessGone(captured.process,await identity(captured.process.pid)))throw Error('Publisher lock needs original OS ownership reconciliation');
 if((await safeJSON(file,65536)).hash!==prior.hash)throw Error('Publisher lock changed');await rename(directory,directory+'.retired.'+prior.hash);return true;
}
export async function serveQualifiedConnection(c,{versionChecker=null}={}){
 const {qualification,config}=await verifyConnectionCustody(c,{versionChecker}),load=relative=>import(pathToFileURL(path.join(c.packetRoot,relative)).href),{loadRegistry}=await load('lib/projection.mjs'),{createAdapter}=await load('adapters/native-session-adapter.mjs'),{createApp}=await load('server.mjs');
 const registry=await loadRegistry(c.packetRoot,{registrySource:config.registrySource,nativeReadOnly:true,nativeWorkspaceRoot:c.projectRoot}),adapter=createAdapter({root:c.projectRoot,planningRoot:c.planningRoot,config,registry}),app=await createApp({configFile:c.configFile,adapter,journalPath:path.join(c.planningRoot,'Commands','Journal.json')});
 const origin=await app.listen(c.port);return {app,origin,qualification};
}

export async function atomicConnectionJSON(file,value){const temporary=file+'.'+randomUUID()+'.new',h=await open(temporary,'wx',0o600);try{await h.writeFile(JSON.stringify(value)+'\n');await h.sync();}finally{await h.close();}await rename(temporary,file);const saved=await safeJSON(file);if(saved.text!==JSON.stringify(value)+'\n')throw Error('Connection record readback unavailable');}

export async function retireOwnedServiceRecord(c,{identity=windowsProcessIdentity}={}){const file=path.join(c.projectRoot,'.alife-worlds','site-runtime-process.json');let prior;try{prior=await safeJSON(file);}catch(e){if(e.code==='ENOENT')return false;throw e;}const r=prior.value;if(r.kind!=='supervised-qualified-world-service'||r.projectId!==c.projectId||!same(r.packetRoot,c.packetRoot)||!same(r.nativeRoot,c.projectRoot)||!same(r.planningRoot,c.planningRoot)||!originalProcessGone(r.process,await identity(r.process.pid)))throw Error('Original service ownership needs reconciliation');if((await safeJSON(file)).hash!==prior.hash)throw Error('Original service record changed');await rename(file,file+'.retained.'+prior.hash);return true;}
