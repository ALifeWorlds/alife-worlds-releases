import {spawn} from 'node:child_process';
import {openSync,closeSync} from 'node:fs';
import {readFile,writeFile,mkdir,stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const [flag,logDirectory,...extra]=process.argv.slice(2);
if(flag!=='--log-directory'||!path.isAbsolute(logDirectory||'')||extra.length)throw Error('Use --log-directory ABSOLUTE_TASK_FOLDER');
const root=process.cwd(),privateRoot=path.join(root,'.alife-worlds'),record=path.join(privateRoot,'site-relay-process.json');
for(const p of [record,path.join(privateRoot,'site-sync.lock')])try{await stat(p);throw Error('Original relay launch exists; reconcile its PID/lock before another launch');}catch(e){if(e.code!=='ENOENT')throw e;}
await mkdir(logDirectory,{recursive:true});
if(process.stdin.isTTY)process.stdin.setRawMode(true);process.stdin.setEncoding('utf8');
process.stdout.write('Ready for private Site pairing on stdin (input is hidden).\n');
let input='';
const pairing=await new Promise((resolve,reject)=>{
 process.stdin.on('data',chunk=>{
  input+=chunk;
  if(input.length>16384)return reject(Error('Pairing input too large'));
  if(input.includes('\u0003'))return reject(Error('Pairing cancelled'));
  const end=input.search(/[\r\n]/);
  if(end>=0){try{resolve(JSON.parse(input.slice(0,end)));}catch{reject(Error('Invalid pairing input'));}}
 });
 process.stdin.on('error',reject);
});
if(process.stdin.isTTY)process.stdin.setRawMode(false);process.stdin.pause();
if(typeof pairing.siteUrl!=='string'||typeof pairing.syncKey!=='string'||typeof pairing.serviceToken!=='string')throw Error('Private pairing fields required');
if(pairing.mode!==undefined&&!['owner-bundle'].includes(pairing.mode))throw Error('Unsupported explicit relay mode');
const ownerBundle=pairing.mode==='owner-bundle',relayScript=ownerBundle?'relay-owner-site.mjs':'relay-project-site.mjs';
if(ownerBundle)(await import('../lib/site-sync-publisher.mjs')).assertOwnerSitePairing(pairing);
const stdout=openSync(path.join(logDirectory,'site-relay.stdout.log'),'a'),stderr=openSync(path.join(logDirectory,'site-relay.stderr.log'),'a');
try{
 const child=spawn(process.execPath,[fileURLToPath(new URL('./'+relayScript,import.meta.url))],{cwd:root,detached:true,windowsHide:true,stdio:['pipe',stdout,stderr]});
 await new Promise((resolve,reject)=>{child.once('error',reject);child.once('spawn',resolve);});
 await writeFile(record,JSON.stringify({schemaVersion:1,pid:child.pid,startedUtc:new Date().toISOString(),siteOrigin:new URL(pairing.siteUrl).origin,script:'plugin-source/scripts/'+relayScript,...(ownerBundle?{mode:'owner-bundle'}:{}),logDirectory,state:'spawned-awaiting-first-receipt'})+'\n',{flag:'wx'});
 await new Promise((resolve,reject)=>{child.stdin.once('error',reject);child.stdin.end(JSON.stringify(pairing),resolve);});child.unref();
 console.log(JSON.stringify({state:'spawned-awaiting-first-receipt',pid:child.pid,credentialsPersisted:false}));
}finally{closeSync(stdout);closeSync(stderr);}
