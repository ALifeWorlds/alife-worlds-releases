import {prepareCleanupHold,prepareOwnCleanupHold,acknowledgeCleanupHold,prepareCleanupReadback,recordCleanupReadback,releaseCleanupHold,prepareImportReview,recordImportReview,prepareImportedIntake,recordImportedIntake,readImportedNativeStatus,recordDeleteConfirmation,stopSelectedProjectService,reconcileSelectedServiceStop} from '../lib/project-content-host.mjs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {closed} from '../lib/portable-definitions.mjs';
import {parseImport,previewProjectImport,applyProjectImport,reconcileProjectImport,readProjectImportStatus,reserveImportedAgent,recordImportedAgent,acknowledgeImportedAgent} from '../lib/project-content.mjs';
import {resolveProjectContentContext,resolveImportedReceiptContext,awaitImportedRoleBinding,IntegrationRequired} from '../lib/project-content-context.mjs';
import {createDeletePlan,prepareDeleteRecovery,executeProjectDelete,reconcileProjectDelete} from '../lib/project-delete.mjs';

const packageRoot=fileURLToPath(new URL('../',import.meta.url));
const command=process.argv[2],output=v=>console.log(JSON.stringify(v,null,2));
let effectCommandIssued=false;
const mutation=fn=>{effectCommandIssued=true;return fn();};
async function input(){
 const chunks=[];let size=0;
 for await(const chunk of process.stdin){size+=chunk.length;if(size>8*1024*1024)throw Error('Bounded command input exceeded.');chunks.push(chunk);}
 return JSON.parse(Buffer.concat(chunks).toString('utf8').replace(/^\uFEFF/,''));
}
async function host({optional=false}={}){
 // Integration is package-owned and fixed; pasted data/env/URLs cannot load code.
 const target=new URL('../lib/project-content-host.mjs',import.meta.url);
 try{const module=await import(target.href);if(module.integration?.schemaVersion!==1)throw new IntegrationRequired('Current project content host adapter is not qualified.');return module.integration;}
 catch(error){
  if(error.code==='ERR_MODULE_NOT_FOUND'&&(error.url===target.href)){
   if(optional)return null;
   throw new IntegrationRequired('The owning writer, cleanup fence and native intake adapters are not integrated. No effect performed.');
  }
  throw error;
 }
}
async function proof(){
 const threadId=process.env.CODEX_THREAD_ID;
 if(!threadId)throw Error('Actual native project chat context is unavailable.');
 const {findNativeSession}=await import('../lib/world-bootstrap.mjs');
 return findNativeSession(threadId,process.cwd(),{codexHome:process.env.CODEX_HOME??path.join(os.homedir(),'.codex')});
}
try{
 if(process.argv.length>3)throw Error('Use one command and bounded JSON stdin; no target/root/config/code flags.');
 if(!command||command==='help')output({command:'project-content',commands:['parse','preview','prepare-review','record-review','prepare-intake','record-intake','prepare-cleanup-hold','prepare-own-cleanup-hold','acknowledge-cleanup-hold','prepare-cleanup-readback','record-cleanup-readback','release-cleanup-hold','stop-project-service','reconcile-service-stop','record-delete-confirmation','apply','status','reconcile-import','reserve-agent','native-status','record-agent','acknowledge-agent','await-agent-binding','delete-plan','delete-recovery','delete-execute','delete-reconcile'],boundary:'Run in actual selected project cwd/chat. Import application needs the current owning writer. Delete needs an outside verified recovery, exclusive current-writer fence and separate exact-plan human confirmation. Native calls are performed only by the invoking agent through supported host tools. The explicit stop-project-service phase stops only the independently verified original selected service with a durable outside journal; no settings or hosting action is executed.'});
 else{
  const data=await input();
  if(command==='parse'){closed(data,['content','kind','title','agentId'],'parse input');output(parseImport(data.content,data));}
  else{
   const native=await proof();
   if(command==='release-cleanup-hold'){closed(data,['holdDirectory','operationDirectory'],'original outside hold release');output(await mutation(()=>releaseCleanupHold(packageRoot,native,data)));}
   else if(command==='delete-reconcile'){closed(data,['operationDirectory'],'reconcile input');output(await reconcileProjectDelete(packageRoot,native,data));}
   else if(command==='await-agent-binding'){closed(data,['operationId','timeoutMs'],'own original imported binding wait');output(await awaitImportedRoleBinding(packageRoot,native,data));}
   else if(command==='acknowledge-agent'){
    closed(data,['operationId','contractSha256','fullRead'],'own receipt input');
    const c=await resolveImportedReceiptContext(packageRoot,native,data.operationId);output(await mutation(async()=>acknowledgeImportedAgent(c,data,await host())));
   }else{
    const c=await resolveProjectContentContext(packageRoot,native);
    if(command==='status'){closed(data,[],'status input');output(await readProjectImportStatus(c));}
    else if(command==='preview'){closed(data,['content','kind','title','agentId','review'],'preview input');output(await previewProjectImport(c,data,await host()));}
    else if(command==='prepare-review'){closed(data,['plan'],'host review request');output(await prepareImportReview(c,data));}
    else if(command==='record-review'){closed(data,['plan','source','semanticNotes'],'actual host review');output(await mutation(()=>recordImportReview(c,data)));}
    else if(command==='prepare-intake'){closed(data,['importOperationId','roleId'],'Support intake request');output(await prepareImportedIntake(c,data));}
    else if(command==='record-intake'){closed(data,['importOperationId','roleId','sourceSha256','custody'],'actual complete Support intake');output(await mutation(()=>recordImportedIntake(c,data)));}
    else if(command==='prepare-cleanup-hold'){closed(data,['evidenceRoot'],'outside native hold request');output(await mutation(()=>prepareCleanupHold(c,data)));}
    else if(command==='prepare-own-cleanup-hold'){closed(data,['holdDirectory'],'own hold inputs');output(await prepareOwnCleanupHold(c,data));}
    else if(command==='acknowledge-cleanup-hold'){closed(data,['holdDirectory','custodySha256','fullRead'],'actual own hold receipt');output(await mutation(()=>acknowledgeCleanupHold(c,data)));}
    else if(command==='prepare-cleanup-readback'){closed(data,['holdDirectory'],'original native hold lifecycle request');output(await mutation(()=>prepareCleanupReadback(c,data)));}
    else if(command==='record-cleanup-readback'){closed(data,['holdDirectory','requestId'],'actual native hold lifecycle completion');output(await mutation(()=>recordCleanupReadback(c,data)));}
    else if(command==='stop-project-service'){closed(data,['evidenceRoot'],'scoped original service stop');output(await mutation(()=>stopSelectedProjectService(c,data)));}
    else if(command==='reconcile-service-stop'){closed(data,['journal'],'original service reconciliation');output(await mutation(()=>reconcileSelectedServiceStop(c,data)));}
    else if(command==='record-delete-confirmation'){closed(data,['operationDirectory','source'],'actual exact human confirmation');output(await mutation(()=>recordDeleteConfirmation(c,data)));}
    else if(command==='apply'){closed(data,['plan'],'apply input');output(await mutation(async()=>applyProjectImport(c,data.plan,await host())));}
    else if(command==='reconcile-import'){closed(data,['operationId'],'reconcile input');output(await mutation(async()=>reconcileProjectImport(c,data.operationId,await host())));}
    else if(command==='reserve-agent'){closed(data,['importOperationId','roleId'],'intake input');output(await mutation(async()=>reserveImportedAgent(c,data,await host())));}
    else if(command==='native-status'){closed(data,['operationId'],'original completed native evidence status');output(await readImportedNativeStatus(c,data));}
    else if(command==='record-agent'){closed(data,['operationId','evidence'],'actual native evidence reference');output(await mutation(async()=>recordImportedAgent(c,data,await host())));}
    else if(command==='delete-plan'){closed(data,[],'delete plan input');output(await createDeletePlan(c,await host({optional:true})));}
    else if(command==='delete-recovery'){closed(data,['plan','evidenceRoot'],'delete recovery input');output(await mutation(async()=>prepareDeleteRecovery(c,data,await host())));}
    else if(command==='delete-execute'){closed(data,['operationDirectory'],'delete execution input');output(await mutation(async()=>executeProjectDelete(c,data,await host())));}
    else throw Error('Unknown project-content command.');
   }
  }
 }
}catch(error){
 const effect=error.operationEffect;
 output({status:error.code==='ALIFE_HOST_ACTION_REQUIRED'?'host-action-required':error.code==='ALIFE_INTEGRATION_REQUIRED'?'unavailable':effect?'reconciliation-required':'refused',reason:error.message,code:error.code??null,effectsPerformed:effect?.effectsPerformed??(effectCommandIssued?'unknown':0),...(error.hostRequest?{hostRequest:error.hostRequest}:{}),...(error.attemptedSource?{attemptedSource:error.attemptedSource}:{}),...(error.capability?{capability:error.capability}:{}),...(effect?{operation:effect}:{}),nextAction:effect?.nextAction??error.nextAction??'Resolve the stated original dependency. Never replay an unknown effect.'});
 process.exitCode=1;
}
