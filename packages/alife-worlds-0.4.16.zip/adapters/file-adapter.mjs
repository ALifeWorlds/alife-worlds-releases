import {readFile,stat} from 'node:fs/promises';
import path from 'node:path';
export function createAdapter({root,config}){return{async readSnapshot(){const file=path.resolve(root,config.stateFile);if((await stat(file)).size>8388608)throw Error('Snapshot is too large');return JSON.parse((await readFile(file,'utf8')).replace(/^\uFEFF/,''));}};}
