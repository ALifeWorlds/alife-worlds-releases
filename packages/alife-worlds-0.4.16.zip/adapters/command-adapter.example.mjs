// Replace this example with your destination project's supported,authorized integration.
export async function dispatch(targetInstanceId,prompt,requestId){
 // Preserve requestId in your transport's deduplication field. Resolve current ownership
 // and permissions using your project's existing authority;queueing is not completion.
 return {state:'unavailable',message:'Connect your project transport first.'};
}
