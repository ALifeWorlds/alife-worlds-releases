import {applyNativeProgress,validNativeProgress} from '../lib/native-progress.mjs';
import {createNativeMetadataStore,recoverNativeMetadata,metadataFileKey,nativeMetadataProjection,safeNativeName} from '../lib/native-agent-metadata.mjs';
import {readBoundNativeArchiveIndex} from '../lib/native-archive-index.mjs';
import {applyNativeActivity,nativeActivityProjection} from '../lib/native-activity.mjs';
import {open, realpath} from 'node:fs/promises';
import path from 'node:path';

const UUID=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const MAX_JSON=8*1024*1024, HEAD=64*1024, WINDOW=2*1024*1024, FRESH=120000;
const normalized=p=>path.resolve(p).replaceAll('\\','/').replace(/\/$/,'').toLowerCase();
const same=(a,b)=>typeof a==='string'&&typeof b==='string'&&normalized(a)===normalized(b);
const inside=(root,p)=>normalized(p).startsWith(normalized(root)+'/');
const iso=value=>Number.isFinite(Date.parse(value))?new Date(value).toISOString():null;
const blank=()=>({activityState:'unknown',observedUtc:null,terminal:false,needsHumanInput:false,model:null,reasoningEffort:null,serviceTier:null,serviceTierObservedUtc:null,serviceTierSource:null});
async function readJSON(file,max=MAX_JSON){
 const handle=await open(file,'r');
 try{const s=await handle.stat();if(!s.isFile()||s.size>max)throw Error('Invalid local record size');const buf=Buffer.alloc(s.size);const {bytesRead}=await handle.read(buf,0,buf.length,0);if(bytesRead!==s.size)throw Error('Incomplete local record');return JSON.parse(buf.toString('utf8').replace(/^\uFEFF/,''));}finally{await handle.close();}
}
async function verifiedRoot(root){
 if(typeof root!=='string'||!path.isAbsolute(root)||root.startsWith('\\\\')||root.startsWith('//')||root.split(/[\\/]/).includes('..')||!same(root,await realpath(root)))throw Error('Invalid or redirected root');
}
async function localPath(root,relative){
 if(typeof relative!=='string'||!relative||path.isAbsolute(relative)||relative.split(/[\\/]/).includes('..'))throw Error('Expected project-relative path without traversal');
 const file=path.resolve(root,relative);if(!inside(root,file)||!same(file,await realpath(file)))throw Error('Path outside project or redirected');return file;
}
// Retain only lifecycle/model scalars. Never retain content, arguments, output or reasoning.
function consume(state,row,binding,root){
 const p=row?.payload,stamp=iso(row?.timestamp);if(!p||!stamp)return;
 if(p.thread_id&&p.thread_id!==binding.threadId)throw Error('Event identity mismatch');
 if(row.type==='session_meta'){if(p.id!==binding.threadId||!same(p.cwd,root))throw Error('Session identity mismatch');return;}
 if(row.type==='turn_context'){if(!same(p.cwd,root))throw Error('Session cwd changed');return;}
 if(row.type==='event_msg'&&p.type==='thread_settings_applied'){if(p.thread_settings?.cwd&&!same(p.thread_settings.cwd,root))throw Error('Applied cwd changed');return;}
 applyNativeProgress(state,row,{threadId:binding.threadId});
 applyNativeActivity(state,row,{threadId:binding.threadId});
}

export function createAdapter({root,planningRoot=root,config,registry,now=Date.now,nativeIndexReader=readBoundNativeArchiveIndex}){
 const cache=new Map(),baseRegistry=registry.slice(),metadataStore=createNativeMetadataStore({root,projectId:config.projectId,now});let pending=null,pendingMetadata=null,serial=Promise.resolve();const enqueue=fn=>{const result=serial.then(fn);serial=result.catch(()=>{});return result;};
 async function observe(binding,index=null,indexObservedUtc=null){
  const prior=binding?.threadId?await metadataStore.get(binding):null;
  const unknown=reason=>{cache.delete(binding.id);return {...blank(),...(reason==='unavailable'?nativeMetadataProjection(prior):{}),connected:false,connectionState:reason};};
  if(!binding?.threadId||!binding.sessionPath)return unknown('unconfirmed');
  let handle;
  try{
   const file=binding.sessionPath;
   if(!path.isAbsolute(file)||file.startsWith('\\\\')||file.startsWith('//')||path.extname(file)!=='.jsonl'||!same(file,await realpath(file)))return unknown('refused');
   handle=await open(file,'r');const stat=await handle.stat();if(!stat.isFile())return unknown('refused');
   const head=Buffer.alloc(Math.min(stat.size,HEAD));await handle.read(head,0,head.length,0);
   const newline=head.indexOf(10);if(newline<0)return unknown('unavailable');
   const meta=JSON.parse(head.subarray(0,newline).toString('utf8').replace(/^\uFEFF/,''));
   if(meta.type!=='session_meta'||meta.payload?.id!==binding.threadId||!same(meta.payload?.cwd,root))return unknown('refused');
   const key=binding.id,signature=[file,binding.threadId,stat.dev,stat.ino,stat.birthtimeMs].join('|');
   let saved=cache.get(key);
   if(!saved||saved.signature!==signature||stat.size<saved.offset)saved={signature,offset:newline+1,state:blank()};
   let start=saved.offset,state={...saved.state};
   if(stat.size-start>WINDOW){start=stat.size-WINDOW;state=blank();}
   const buf=Buffer.alloc(stat.size-start);const {bytesRead}=await handle.read(buf,0,buf.length,start);
   let from=0;if(start!==saved.offset){const boundary=buf.indexOf(10);from=boundary<0?bytesRead:boundary+1;}
   let offset=start+from;
   while(from<bytesRead){const end=buf.indexOf(10,from);if(end<0||end>=bytesRead)break;const line=buf.subarray(from,end).toString('utf8');from=end+1;offset=start+from;if(!line.trim())continue;
    const row=JSON.parse(line);consume(state,row,binding,root);
   }
   const recovery=await recoverNativeMetadata(handle,{size:stat.size,binding,root,fileKey:metadataFileKey(binding,stat),previous:prior});
   const metadata=await metadataStore.update(binding,{recovery,index,indexObservedUtc});Object.assign(state,nativeMetadataProjection(metadata,{current:true,coverage:recovery.coverage,indexCurrent:!!safeNativeName(index?.name),selectionCurrent:!!index&&Object.hasOwn(index,'selectedModel')}));
   cache.set(key,{signature,offset,state});
   const age=now()-Date.parse(state.observedUtc),fresh=Number.isFinite(age)&&age>=-5000&&age<=FRESH;
   // A currently readable exact-bound source confirms an unresolved request.
   // Keep its original event time; ordinary work still expires after FRESH.
   const pendingInput=state.activityState==='waiting'&&state.needsHumanInput===true&&Number.isFinite(age)&&age>=-5000;
   const activityState=(state.terminal&&age>=-5000)||fresh||pendingInput?state.activityState:'unknown';
   return {...state,activityState,needsHumanInput:activityState==='waiting'&&state.needsHumanInput===true,terminal:state.terminal&&activityState==='idle',connected:true,connectionState:activityState==='unknown'?'unavailable':'connected'};
  }catch{cache.delete(binding.id);return unknown('unavailable');}finally{if(handle)await handle.close();}
 }
 async function readSnapshot({projectContent}={}){
  await verifiedRoot(root);await verifiedRoot(planningRoot);
  const bindings=await readJSON(await localPath(root,config.bindingsFile));
  if(bindings.schemaVersion!==1||bindings.projectId!==config.projectId||!same(bindings.projectRoot,root)||!Array.isArray(bindings.agents)||bindings.agents.length>100)throw Error('Invalid project bindings');
  // Definitions alone do not create native roles. Re-read the original binding and own receipt.
  const registry=baseRegistry.slice();
  if(projectContent?.projectId===config.projectId&&['defaults','overrides'].includes(projectContent.status))for(const candidate of projectContent.agents||[]){
   if(registry.length>=100)break;
   if(!candidate||!/^([a-z][a-z0-9-]{0,63})$/.test(candidate.id)||registry.some(r=>r.id===candidate.id)||candidate.onboarded!==true||candidate.contractsFullRead!==true||candidate.accessVerified!==true||!/^[a-f0-9]{64}$/.test(candidate.definitionSha256||'')||typeof candidate.operationId!=='string'||!candidate.operationId||candidate.operationId.length>160||!UUID.test(candidate.threadId||'')||typeof candidate.sessionPath!=='string'||typeof candidate.title!=='string'||!candidate.title.trim()||candidate.title.length>160)continue;
   const b=bindings.agents.find(b=>b.id===candidate.id);if(!b||b.hostId!=='local'||b.threadId!==candidate.threadId||b.sessionPath!==candidate.sessionPath||typeof b.home!=='string'||typeof candidate.home!=='string'||!(same(candidate.home,path.resolve(root,b.home))||candidate.home===b.home))continue;
   try{const receipt=await readJSON(await localPath(root,path.join(b.home,'receipt.json')),256*1024);
    if(receipt.schemaVersion!==1||receipt.roleId!==candidate.id||receipt.threadId!==b.threadId||receipt.projectId!==config.projectId||!same(receipt.workspacePath,root)||!same(receipt.homePath,path.resolve(root,b.home))||receipt.accessVerified!==true||receipt.contractsFullRead!==true||receipt.retirementVersion!==1)continue;
    registry.push({id:candidate.id,title:candidate.title,role:'worker',responsibility:'Imported specialist with verified original onboarding.',tree:false,instanceId:null,serviceTier:'default',imported:true});
   }catch{}
  }
  const ids=new Set(),threads=new Set(),homes=new Set(),sessions=new Set();
  for(const b of bindings.agents){
   if(typeof b.id!=='string'||!/^([a-z][a-z0-9-]{0,63})$/.test(b.id)||ids.has(b.id)||typeof b.home!=='string'||path.isAbsolute(b.home)||!inside(root,path.resolve(root,b.home)))throw Error('Invalid role binding');ids.add(b.id);
   const home=normalized(path.resolve(root,b.home));if(homes.has(home))throw Error('Duplicate home');homes.add(home);
   if(b.threadId!=null){if(!UUID.test(b.threadId)||threads.has(b.threadId.toLowerCase())||b.hostId!=='local')throw Error('Invalid or duplicate native identity');threads.add(b.threadId.toLowerCase());}
   if(b.sessionPath!=null){if(typeof b.sessionPath!=='string'||sessions.has(normalized(b.sessionPath)))throw Error('Duplicate session');sessions.add(normalized(b.sessionPath));}
  }
  for(const key of cache.keys())if(!ids.has(key))cache.delete(key);
  const snapshot=await readJSON(await localPath(planningRoot,config.stateFile));
  if((snapshot.projectId&&snapshot.projectId!==config.projectId)||(snapshot.projectRoot&&!same(snapshot.projectRoot,planningRoot)))throw Error('Foreign canonical snapshot');
  const indexObservedUtc=new Date(now()).toISOString(),archiveFlags=await nativeIndexReader({root,bindings:bindings.agents});
  const agents=[];
  // Sequential bounded reads avoid flooding the host; no discovery or directory scan.
  for(const role of registry){
   const b=bindings.agents.find(b=>b.id===role.id),stored=b&&UUID.test(b.threadId||'')?await metadataStore.update(b,{index:archiveFlags.get(role.id),indexObservedUtc}):null,archived=(archiveFlags.get(role.id)?.archived??stored?.archived?.value)===true,native=b&&!archived?await observe(b,archiveFlags.get(role.id),indexObservedUtc):{...blank(),connected:false,connectionState:archived?'archived':'unconfirmed'};
   const canonical=(snapshot.agents||[]).find(a=>a.roleId===role.id)||{};
   let receipt=null,checkpoint=null;
   if(b&&native.connected){
    try{receipt=await readJSON(await localPath(root,path.join(b.home,'receipt.json')),256*1024);}catch{}
    try{checkpoint=await readJSON(await localPath(root,path.join(b.home,'checkpoint.json')),MAX_JSON);}catch{}
   }
   const onboarded=receipt?.schemaVersion===1&&receipt.roleId===role.id&&receipt.threadId===b?.threadId&&receipt.projectId===config.projectId&&same(receipt.workspacePath,root)&&same(receipt.homePath,path.resolve(root,b.home))&&receipt.accessVerified===true&&receipt.contractsFullRead===true&&receipt.retirementVersion===1;
   const checkpointValid=checkpoint?.roleId===role.id&&checkpoint.projectId===config.projectId&&same(checkpoint.workspacePath,root)&&same(checkpoint.homePath,path.resolve(root,b.home));
   const taskIds=Array.isArray(canonical.taskIds)&&canonical.taskIds.length?canonical.taskIds:checkpointValid&&Array.isArray(checkpoint.taskIds)?checkpoint.taskIds:[];
   agents.push({roleId:role.id,instanceId:native.connected?b.threadId:null,connected:native.connected,connectionState:native.connectionState,
    ...nativeActivityProjection(native),progressUpdate:validNativeProgress(native.progressUpdate)?{...native.progressUpdate}:null,activityState:native.activityState,observedUtc:native.observedUtc,terminal:native.terminal,needsHumanInput:native.needsHumanInput===true,onboarded,
    selectedModel:native.selectedModel??null,selectedModelSource:native.selectedModelSource||null,selectedModelObservedUtc:native.selectedModelObservedUtc||null,selectedModelState:native.selectedModelState||'unknown',nativeDisplayName:native.nativeDisplayName||null,nameSource:native.nameSource||'registry-fallback',nameObservedUtc:native.nameObservedUtc||null,nameState:native.nameState||'unknown',modelState:native.modelState||'unknown',modelSource:native.modelSource||null,modelObservedUtc:native.modelObservedUtc||null,model:native.model,reasoningEffort:native.reasoningEffort,reasoningEffortObservedUtc:native.reasoningEffortObservedUtc||null,serviceTier:native.serviceTier,serviceTierObservedUtc:native.serviceTierObservedUtc,serviceTierSource:native.serviceTierSource,
    taskIds,archived,paused:canonical.paused===true||archived,report:typeof canonical.report==='string'&&canonical.report?canonical.report:onboarded?'Onboarding complete; ready for assigned work.':'Awaiting verified onboarding.',
    latestUpdate:native.activityState==='idle'?'Native turn ended; no active turn observed.':native.activityState==='working'?'Fresh native turn activity observed.':native.activityState==='waiting'?'Native turn is waiting.':'Current native activity unavailable.',
    checkpointStatus:checkpointValid&&['ready','idle','working','waiting','blocked','complete','awaiting-onboarding'].includes(checkpoint.status)?checkpoint.status:null});
  }
  return {...snapshot,registry,observedUtc:new Date(now()).toISOString(),snapshotObservedUtc:snapshot.observedUtc,nativeMetadata:metadataStore.status(),agents};
 }
 async function readMetadataRevision({projectContent}={}){
  await verifiedRoot(root);await verifiedRoot(planningRoot);
  const bindings=await readJSON(await localPath(root,config.bindingsFile));
  if(bindings.schemaVersion!==1||bindings.projectId!==config.projectId||!same(bindings.projectRoot,root)||!Array.isArray(bindings.agents)||bindings.agents.length>100)throw Error('Invalid project bindings');
  // Definitions alone do not create native roles. Re-read the original binding and own receipt.
  const registry=baseRegistry.slice();
  if(projectContent?.projectId===config.projectId&&['defaults','overrides'].includes(projectContent.status))for(const candidate of projectContent.agents||[]){
   if(registry.length>=100)break;
   if(!candidate||!/^([a-z][a-z0-9-]{0,63})$/.test(candidate.id)||registry.some(r=>r.id===candidate.id)||candidate.onboarded!==true||candidate.contractsFullRead!==true||candidate.accessVerified!==true||!/^[a-f0-9]{64}$/.test(candidate.definitionSha256||'')||typeof candidate.operationId!=='string'||!candidate.operationId||candidate.operationId.length>160||!UUID.test(candidate.threadId||'')||typeof candidate.sessionPath!=='string'||typeof candidate.title!=='string'||!candidate.title.trim()||candidate.title.length>160)continue;
   const b=bindings.agents.find(b=>b.id===candidate.id);if(!b||b.hostId!=='local'||b.threadId!==candidate.threadId||b.sessionPath!==candidate.sessionPath||typeof b.home!=='string'||typeof candidate.home!=='string'||!(same(candidate.home,path.resolve(root,b.home))||candidate.home===b.home))continue;
   try{const receipt=await readJSON(await localPath(root,path.join(b.home,'receipt.json')),256*1024);
    if(receipt.schemaVersion!==1||receipt.roleId!==candidate.id||receipt.threadId!==b.threadId||receipt.projectId!==config.projectId||!same(receipt.workspacePath,root)||!same(receipt.homePath,path.resolve(root,b.home))||receipt.accessVerified!==true||receipt.contractsFullRead!==true||receipt.retirementVersion!==1)continue;
    registry.push({id:candidate.id,title:candidate.title,role:'worker',responsibility:'Imported specialist with verified original onboarding.',tree:false,instanceId:null,serviceTier:'default',imported:true});
   }catch{}
  }
  const ids=new Set(),threads=new Set(),homes=new Set(),sessions=new Set();
  for(const b of bindings.agents){
   if(typeof b.id!=='string'||!/^([a-z][a-z0-9-]{0,63})$/.test(b.id)||ids.has(b.id)||typeof b.home!=='string'||path.isAbsolute(b.home)||!inside(root,path.resolve(root,b.home)))throw Error('Invalid role binding');ids.add(b.id);
   const home=normalized(path.resolve(root,b.home));if(homes.has(home))throw Error('Duplicate home');homes.add(home);
   if(b.threadId!=null){if(!UUID.test(b.threadId)||threads.has(b.threadId.toLowerCase())||b.hostId!=='local')throw Error('Invalid or duplicate native identity');threads.add(b.threadId.toLowerCase());}
   if(b.sessionPath!=null){if(typeof b.sessionPath!=='string'||sessions.has(normalized(b.sessionPath)))throw Error('Duplicate session');sessions.add(normalized(b.sessionPath));}
  }
  for(const key of cache.keys())if(!ids.has(key))cache.delete(key);
  const indexObservedUtc=new Date(now()).toISOString(),flags=await nativeIndexReader({root,bindings:bindings.agents});
  for(const role of registry){const binding=bindings.agents.find(b=>b.id===role.id);if(binding&&UUID.test(binding.threadId||''))await metadataStore.update(binding,{index:flags.get(role.id),indexObservedUtc});}
  return {...metadataStore.status(),sourceState:flags.size?'current':'unavailable',observedUtc:new Date(now()).toISOString()};
 }
 // The dashboard and retained renderer can request the feed together. Share only
 // the in-flight read, never a refreshed activity timestamp or an old snapshot.
 return {readSnapshot(options){if(!pending)pending=enqueue(()=>readSnapshot(options)).finally(()=>{pending=null;});return pending;},readMetadataRevision(options){if(!pendingMetadata)pendingMetadata=enqueue(()=>readMetadataRevision(options)).finally(()=>{pendingMetadata=null;});return pendingMetadata;}};
}
