# Contributing to ALife Worlds

**Approved project contribution guidelines.** The human authorized publication on official main on 10 November 2026. These guidelines grant no repository access and create no agreement retroactively. Existing license permissions continue unchanged.

We welcome bug reports, fixes, documentation, accessibility improvements and clearly scoped features. Read [governance](GOVERNANCE.md), [branding](BRANDING.md), [contributor recognition](CONTRIBUTORS.md) and the existing repository instructions first.

## Rights and licenses

- Submit work you own or are authorized to contribute. Check employer, client, coauthor and third-party obligations. Clearly identify reused material and its source, license and required notices.
- Offer original contributions for distribution under the project's applicable MIT license when intentionally submitting them under an adopted contribution policy. Separately licensed components must be clearly identified and reviewed for compatibility. Do not assume an earlier submission accepted a later policy.
- Preserve existing copyright, permission, attribution and third-party notices. The [MIT license](LICENSE) permits copying, modification, redistribution and commercial use subject to its terms; this contribution process does not add conditions to those existing grants.
- Contributors retain applicable rights to their own work unless a valid written agreement provides otherwise. Acceptance does not transfer copyright, create ownership of the entire project, or confer founder status, maintainer privileges or administrative control.
- No copyright-assignment agreement, CLA or mandatory DCO is established by these guidelines. Any later agreement requires explicit approval, appropriate legal review and the actual contributor's agreement. It cannot be inferred from Git authorship, a PR merge or an AI agent's statement.

## Submit a focused change

Use a review branch and PR against the verified official repository. Describe the problem, final behavior, affected files, tests and material limits. Discuss substantial API, security, licensing or branding changes with the authorized owner before implementation. Do not bundle unrelated refactors or erase history.

Run applicable existing tests, `npm run rules:check`, `npm run attribution:check` and the plugin build in candidate mode. For a change relative to a known base, use `node scripts/check-attribution.mjs --base-ref <commit>` to surface changed notices/dependencies for human review. A formatting-only notice change should not fail. New third-party terms or uncertain rights require review, not an invented license.

Keep credentials, private agent homes/settings, native metadata, live tasks, personal information and machine evidence out of Git, packets and PR text. Do not post exploitable security details or secrets publicly. Use a verified private reporting route; if none is available, request one without publishing the sensitive details. No support email, security program or response guarantee is invented here.

## Review and recognition

Authorized maintainers review scope, quality, security, compatibility and provenance. The release owner records exact source and package checks; technical checks do not replace required human acceptance. Only explicitly authorized repository administrators grant access.

Preserve accurate creator credit and acknowledge individual contributions through accepted PRs, commit history and release notes. Use accurate descriptions and optional public profiles with consent. Do not misrepresent yourself or an independent distribution as the original creator or an officially endorsed release. These rules govern official contribution/release processes; they do not withdraw lawful MIT fork rights.
