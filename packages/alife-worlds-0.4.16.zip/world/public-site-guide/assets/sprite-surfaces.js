/* Reused from the reviewed public Site; run after existing panel markup. */
(() => {
'use strict';
// Only filled panel sprites qualify; controls and plain reading surfaces keep their colors.
for(const panel of document.querySelectorAll('section,article,aside,header,div,dialog')){
 const style=getComputedStyle(panel);
 if(style.borderImageSource!=='none'&&/\bfill\b/.test(style.borderImageSlice))panel.classList.add('sprite-surface');
}
})();
