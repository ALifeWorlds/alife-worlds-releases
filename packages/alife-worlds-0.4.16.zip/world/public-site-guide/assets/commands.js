'use strict';
const pluginCommandCatalog=[
  {
    "code": "/Alife worlds",
    "title": "Create or connect",
    "desc": "Begin a world request in your selected project chat. The prompt builder already includes this line.",
    "actions": [
      [
        "Copy",
        "/Alife worlds\nCreate or connect an owner-private world for this project."
      ]
    ]
  },
  {
    "code": "/world <rule>",
    "title": "World rules",
    "desc": "Save rules for world behavior or appearance. Example: agents avoid obstacles and stay on walkable routes.",
    "actions": [
      [
        "Copy",
        "/world Make agents avoid obstacles and use safe, walkable routes."
      ],
      [
        "List",
        "/world list"
      ],
      [
        "Export",
        "/world export"
      ]
    ]
  },
  {
    "code": "/plugin <rule>",
    "title": "Plugin rules",
    "desc": "Change plugin-wide operating rules and workflow.",
    "actions": [
      [
        "Copy",
        "/plugin Preserve custom world artwork and settings when updating the plugin."
      ],
      [
        "List",
        "/plugin list"
      ],
      [
        "Export",
        "/plugin export"
      ]
    ]
  },
  {
    "code": "/rule <rule>",
    "title": "This agent's rules",
    "desc": "Give a rule to the agent whose chat receives it.",
    "actions": [
      [
        "Copy",
        "/rule Keep your task, evidence and next action current in your own checkpoint."
      ],
      [
        "List",
        "/rule list"
      ],
      [
        "Export",
        "/rule export"
      ]
    ]
  },
  {
    "code": "/universal <rule>",
    "title": "Incoming agent rules",
    "desc": "Rules inherited by incoming agents and successors; existing agents are not rewritten automatically.",
    "actions": [
      [
        "Copy",
        "/universal Preserve the selected project's existing work, privacy and approved agent settings."
      ],
      [
        "List",
        "/universal list"
      ],
      [
        "Export",
        "/universal export"
      ]
    ]
  },
  {
    "code": "/import <content>",
    "title": "Import a definition",
    "desc": "Bring portable world, plugin or agent content into this selected project.",
    "badge": "Alpha · qualification pending",
    "actions": [
      [
        "Copy template",
        "/import [paste the complete portable definition or a clearly scoped world, plugin or agent prompt]"
      ]
    ]
  },
  {
    "code": "/delete",
    "title": "Delete the ALife base team",
    "desc": "Remove the ALife base agents added for this project, including the plugin’s default team, together with their chats and agent folders from the project and computer.",
    "badge": "Proposed behavior",
    "actions": [
      [
        "Copy",
        "/delete"
      ]
    ]
  },
  {
    "code": "/reset <new goal>",
    "title": "Reset the plan and start again",
    "desc": "Stop current agent work and clear tasks, goals, epics and sprints. Begin again from step 1 in the current world, using the new goal written after /reset.",
    "badge": "Planned command",
    "actions": [
      [
        "Copy example",
        "/reset Our new goal will focus on visuals. Make the current world a pixel-art world."
      ]
    ]
  }
];
function manualCommandCopy(value){
 let dialog=document.getElementById('command-copy-dialog');
 if(!dialog){
  dialog=document.createElement('dialog');dialog.id='command-copy-dialog';dialog.className='command-copy-dialog';dialog.setAttribute('aria-labelledby','command-copy-title');
  const close=document.createElement('button');close.className='dialog-close';close.type='button';close.setAttribute('aria-label','Close');close.textContent='×';close.addEventListener('click',()=>{if(typeof dialog.close==='function')dialog.close();else dialog.removeAttribute('open');});
  const heading=document.createElement('h2');heading.id='command-copy-title';heading.textContent='Copy this command';
  const help=document.createElement('p');help.textContent='Clipboard access is unavailable. Select the text below and copy it into your project chat.';
  const field=document.createElement('textarea');field.readOnly=true;field.setAttribute('aria-label','Command to copy');
  dialog.append(close,heading,help,field);document.body.append(dialog);
 }
 const field=dialog.querySelector('textarea');field.value=value;
 if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');
 field.focus();field.select();
}
for(const button of document.querySelectorAll('[data-command-copy]')){
 button.addEventListener('click',async()=>{
  const [row,action]=button.dataset.commandCopy.split('-').map(Number);
  const value=pluginCommandCatalog[row]?.actions[action]?.[1];if(!value)return;
  const status=button.closest('.command-reference-item,.compact-command-row')?.querySelector('.command-copy-status');
  try{
   if(!navigator.clipboard?.writeText)throw Error('Clipboard unavailable');
   await navigator.clipboard.writeText(value);
   if(status)status.textContent='Copied. Paste into your project chat.';
  }catch{
   manualCommandCopy(value);
   if(status)status.textContent='Select and copy the command in the dialog.';
  }
 });
}
for(const drawer of document.querySelectorAll('.compact-command-drawer')){
 const label=drawer.querySelector('.command-toggle-label');
 const update=()=>{if(label)label.textContent=drawer.open?'Hide commands ⌃':'Show commands ⌄';};
 drawer.addEventListener('toggle',update);update();
}
