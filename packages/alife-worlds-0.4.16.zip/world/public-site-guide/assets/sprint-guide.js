/* Local goal planner and an explicitly fictional progress example. No project writes. */
(() => {
  'use strict';
  const host=document.getElementById('sprints');if(!host)return;
  const create=(tag,className,text)=>{const node=document.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node;};
  const state={step:0,goal:'',done:'',sprints:['Shape the world','Build the interactions','Review and finish'],checked:[]};
  host.innerHTML=[
    '<header class="guide-section-heading"><p class="eyebrow">GIVE YOUR WORLD A DIRECTION</p><h2 id="goal-title">One goal. A plan you can follow.</h2><p>Describe the outcome, break it into sprints, then see how the pieces fit together.</p></header>',
    '<div class="guide-planner"><ol class="guide-stage-nav" aria-label="Planning steps"><li><span class="guide-step-number">1</span> Set the goal</li><li><span class="guide-step-number">2</span> Name the sprints</li><li><span class="guide-step-number">3</span> See the plan</li></ol>',
    '<section class="guide-stage" data-plan-stage="0"><h3>What do you want to make?</h3><p>Describe one outcome. Focus on what someone will be able to do when it is finished.</p><label for="plan-goal">Your goal<textarea id="plan-goal" rows="3" placeholder="Build an interactive storybook with three chapters and a working page-turn interaction."></textarea></label><label for="plan-done">What will “done” look like? <span class="guide-help">Optional</span><textarea id="plan-done" rows="2" placeholder="All three chapters open, pages turn, and the controls work on mobile."></textarea></label><button type="button" class="button quiet-button" data-example-goal>Use the storybook example</button></section>',
    '<section class="guide-stage" data-plan-stage="1" hidden><h3>Break the goal into sprints.</h3><p>Each sprint should finish one useful part. Start with a few short names; Director can turn them into tasks and smaller steps.</p><div class="guide-sprint-list" aria-label="Your planned sprints"></div><button type="button" class="button quiet-button" data-add-sprint>Add a sprint</button></section>',
    '<section class="guide-stage" data-plan-stage="2" hidden><h3>See how the plan fits together.</h3><p class="guide-example-label">Interactive example · not your project’s live progress</p><p>Tick the example tasks below. Finished tasks advance a sprint; finished sprints advance the overall goal.</p><div class="guide-plan-summary" aria-live="polite"><div><span>Overall goal</span><strong data-example-epic-percent>0%</strong><progress data-example-epic max="100" value="0" aria-label="Example goal completion"></progress><span data-example-epic-count></span></div><div><span data-example-current-title>Current sprint</span><strong data-example-current-percent>0%</strong><progress data-example-current max="100" value="0" aria-label="Example current sprint completion"></progress><span data-example-current-count></span></div></div><div class="guide-plan-tree"><div class="guide-tree-goal"><span class="guide-example-label">Your goal</span><h4 data-example-goal-title></h4></div><div class="guide-demo-sprints"></div></div><p class="guide-help">This example changes only in your browser. In your real project, only accepted completed work counts.</p><div class="prompt-box guide-generated-prompt"><label for="goal-plan-prompt">Your goal and sprint prompt</label><textarea id="goal-plan-prompt" readonly rows="7"></textarea><button type="button" class="button green" data-copy-plan>Copy planning prompt</button><p class="copy-status" role="status"></p></div></section>',
    '<div class="guide-plan-actions"><button type="button" class="button quiet-button" data-plan-back hidden>Back</button><button type="button" class="button green" data-plan-next>Next: name the sprints →</button><span class="guide-help" data-plan-step-label>Step 1 of 3</span></div></div>'
  ].join('');
  const box=host.querySelector('.guide-planner'),goal=box.querySelector('#plan-goal'),done=box.querySelector('#plan-done'),output=box.querySelector('#goal-plan-prompt'),list=box.querySelector('.guide-sprint-list'),cards=box.querySelector('.guide-demo-sprints');
  function prompt(){
    state.goal=goal.value.trim();state.done=done.value.trim();
    const lines=['/Alife worlds','Director, set our goal to: '+(state.goal||'[describe the outcome I want]')+'.'];
    if(state.done)lines.push('Done means: '+state.done+'.');
    lines.push('Use this starting sprint plan:\n'+state.sprints.map((s,i)=>(i+1)+'. '+(s.trim()||'Sprint '+(i+1))).join('\n'));
    lines.push('Turn each sprint into clear tasks, smaller steps and acceptance checks. Reuse this project’s suitable agents and preserve current work, models, settings, artwork and privacy. Ask before replacing existing work or creating roles outside the approved setup.');
    lines.push('Keep recorded assignments separate from observed activity. Track real accepted work: completed tasks advance a sprint, and completed sprints advance the overall goal. Do not treat this website’s example as real progress.');
    output.value=lines.join('\n\n');
  }
  function renderSprints(){
    list.replaceChildren();list.dataset.long=String(state.sprints.length>5);
    state.sprints.forEach((title,index)=>{
      const row=create('div','guide-sprint-row'),label=create('label','', 'Sprint '+(index+1)),input=document.createElement('input');input.type='text';input.value=title;input.maxLength=160;input.setAttribute('aria-label','Name for sprint '+(index+1));input.addEventListener('input',()=>{state.sprints[index]=input.value;prompt();});
      label.append(input);row.append(label);
      if(state.sprints.length>1){const remove=create('button','', 'Remove');remove.type='button';remove.setAttribute('aria-label','Remove sprint '+(index+1));remove.addEventListener('click',()=>{state.sprints.splice(index,1);state.checked.splice(index,1);renderSprints();prompt();});row.append(remove);}
      list.append(row);
    });
    const add=box.querySelector('[data-add-sprint]');add.disabled=state.sprints.length>=10;prompt();
  }
  function counts(){
    const complete=state.sprints.map((_,i)=>(state.checked[i]||[]).filter(Boolean).length),finished=complete.filter(n=>n===3).length;
    const current=Math.max(0,complete.findIndex(n=>n<3)===-1?complete.length-1:complete.findIndex(n=>n<3));
    const epicPercent=Math.round(finished/state.sprints.length*100),sprintPercent=Math.round((complete[current]||0)/3*100);
    box.querySelector('[data-example-epic-percent]').textContent=epicPercent+'%';box.querySelector('[data-example-epic]').value=epicPercent;box.querySelector('[data-example-epic-count]').textContent=finished+' / '+state.sprints.length+' sprints finished';
    box.querySelector('[data-example-current-title]').textContent='Sprint '+(current+1);box.querySelector('[data-example-current-percent]').textContent=sprintPercent+'%';box.querySelector('[data-example-current]').value=sprintPercent;box.querySelector('[data-example-current-count]').textContent=(complete[current]||0)+' / 3 example tasks finished';
    cards.querySelectorAll('[data-demo-count]').forEach((node,i)=>node.textContent=complete[i]+' / 3 example tasks');
  }
  function renderExample(){
    box.querySelector('[data-example-goal-title]').textContent=state.goal||'Build an interactive storybook';
    cards.replaceChildren();cards.dataset.long=String(state.sprints.length>5);
    state.sprints.forEach((title,index)=>{
      state.checked[index]??=[false,false,false];
      const card=create('section','guide-demo-sprint');card.append(create('p','guide-example-label','Sprint '+(index+1)),create('h4','',title.trim()||'Sprint '+(index+1)));
      const count=create('small','');count.dataset.demoCount='';card.append(count);
      const tasks=index===0?['Choose references','Sketch the first scene','Review the direction']:index===1?['Build one interaction','Connect the scenes','Review the experience']:['Check the result','Polish the details','Accept the sprint'];
      tasks.forEach((title,taskIndex)=>{
        const label=create('label'),input=document.createElement('input');input.type='checkbox';input.checked=!!state.checked[index][taskIndex];input.setAttribute('aria-label','Example sprint '+(index+1)+': '+title);
        input.addEventListener('change',()=>{state.checked[index][taskIndex]=input.checked;counts();});label.append(input,create('span','',title));card.append(label);
      });
      if(index===0){const details=create('details'),summary=create('summary','','What are smaller steps?'),steps=create('ol');steps.append(create('li','','Gather the reference images'),create('li','','Choose the details to keep'));details.append(summary,steps,create('p','guide-help','Smaller steps explain a task. The task counts once it is finished and accepted.'));card.append(details);}
      cards.append(card);
    });counts();
  }
  function show(){
    prompt();box.querySelectorAll('[data-plan-stage]').forEach((node,i)=>node.hidden=i!==state.step);box.querySelectorAll('.guide-stage-nav li').forEach((node,i)=>{if(i===state.step)node.setAttribute('aria-current','step');else node.removeAttribute('aria-current');});
    const back=box.querySelector('[data-plan-back]'),next=box.querySelector('[data-plan-next]');back.hidden=state.step===0;next.hidden=state.step===2;next.textContent=state.step===0?'Next: name the sprints →':'Next: see the plan →';box.querySelector('[data-plan-step-label]').textContent='Step '+(state.step+1)+' of 3';
    if(state.step===2)renderExample();
  }
  goal.addEventListener('input',prompt);done.addEventListener('input',prompt);
  box.querySelector('[data-example-goal]').addEventListener('click',()=>{goal.value='Build an interactive storybook with three chapters and a working page-turn interaction';done.value='Every chapter opens, pages turn, and the controls work on mobile';prompt();goal.focus();});
  box.querySelector('[data-add-sprint]').addEventListener('click',()=>{if(state.sprints.length>=10)return;state.sprints.push('');state.checked.push([false,false,false]);renderSprints();list.querySelectorAll('input')[state.sprints.length-1].focus();});
  box.querySelector('[data-plan-next]').addEventListener('click',()=>{state.step=Math.min(2,state.step+1);show();box.querySelector('[data-plan-stage="'+state.step+'"] h3').tabIndex=-1;box.querySelector('[data-plan-stage="'+state.step+'"] h3').focus();});
  box.querySelector('[data-plan-back]').addEventListener('click',()=>{state.step=Math.max(0,state.step-1);show();});
  box.querySelector('[data-copy-plan]').addEventListener('click',async()=>{prompt();const status=box.querySelector('.copy-status');try{await navigator.clipboard.writeText(output.value);status.textContent='Copied. Paste it into your project’s Codex chat.';}catch{output.focus();output.select();status.textContent='Select and copy your planning prompt.';}});
  renderSprints();show();
})();