import path from 'node:path';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {buildHostedOwnerSite} from '../vendor/alife-worlds/lib/hosted-site-build.mjs';
const siteRoot=fileURLToPath(new URL('../',import.meta.url));
const config=JSON.parse(await readFile(path.join(siteRoot,'site.config.json'),'utf8'));
console.log(JSON.stringify(await buildHostedOwnerSite({siteRoot,packageRoot:path.join(siteRoot,'vendor/alife-worlds'),config})));
