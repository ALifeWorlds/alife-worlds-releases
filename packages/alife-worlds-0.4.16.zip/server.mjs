import http from 'node:http';
import {readFile,stat,realpath} from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {randomBytes} from 'node:crypto';
import {createProjection,loadRegistry} from './lib/projection.mjs';
import {createDemo} from './lib/demo.mjs';
import {readRuleCatalogs,ruleDisplay,exportRulePrompt} from './lib/rules.mjs';
import {publicWorldSnapshot,publicWorldId} from './lib/public-world.mjs';
import {worldProjects,ownerWorldProjects,openOwnerWorld} from './lib/world-projects.mjs';
import {projectRootIdentity,PROFILE_ENV,DEFAULT_PROFILE} from './lib/world-launcher.mjs';
import {readPrivateWorldCatalog} from './lib/private-world-catalog.mjs';
import {privateWorldCatalogEnvelope} from './lib/private-world-catalog-contract.mjs';
import {createOwnerWorkspaceContract} from './lib/owner-workspace-contract.mjs';
import {createWorkspaceProjector} from './lib/owner-workspace-projection.mjs';
import {createOwnerRuleLibrary} from './lib/owner-rule-library.mjs';
import {readOwnerPreviewQualification,ownerPreviewProfileMatches} from './lib/owner-preview-qualification.mjs';
import {createSiteAgentMetadataContract,createSiteAgentMetadataProjector} from './lib/site-agent-metadata.mjs';
import {createOwnerSiteHandler} from './lib/owner-site-http.mjs';
import {createLocalOwnerFrameHandler} from './lib/owner-frame-http.mjs';
import {customWorldAsset} from './lib/world-customization.mjs';
import {createDefaultWorldBackup} from './lib/default-world-backup.mjs';
import {createLocalOwnerFrameProvider} from './lib/owner-frame-local.mjs';
import {createOwnerPreviewProjector} from './lib/owner-preview-handler.mjs';
import {assertPublicWorldSnapshot} from './lib/public-world-contract.mjs';
import {createLocalAppearance,LOCAL_PALETTE} from './lib/local-world-appearance.mjs';
import {PREVIEW_DESCRIPTOR} from './lib/world-preview.mjs';
import {readWorldProfile,worldProfileDisplay,createServedWorldResource,WORLD_SCENE_FILES,WORLD_OPTIONAL_SCENE_FILES,readWorldSceneFile} from './lib/world-profile.mjs';
// Fixed package-owned provider only. An unavailable provider is never replaced by guessed effective rules.
async function contentProvider(){try{return await import('./lib/project-content-host.mjs');}catch{return null;}}
function effectiveCatalogs(content,defaults){
 if(!['defaults','overrides'].includes(content?.status)||!content.rules)return null;
 const result={};for(const scope of ['world','plugin']){const current=content.rules[scope];if(!current||!Number.isSafeInteger(current.revision)||!Array.isArray(current.groups))throw Error('Effective rules unavailable');result[scope]={schemaVersion:1,ruleFormatVersion:2,scope,revision:current.revision,updatedAt:null,requests:[],groups:current.groups.map(g=>({id:g.id,title:g.title,properties:g.properties.map(p=>{const base=defaults[scope].groups.find(x=>x.id===g.id)?.properties.find(x=>x.id===p.id);return {id:p.id,title:p.title,description:p.description||p.title,text:p.text,active:true,implementation:base?.active&&base.title===p.title&&base.description===p.description&&base.text===p.text?base.implementation:'documented',origin:base?.active&&base.text===p.text?base.origin:'human'};})}))};}
 return result;
}
const require=createRequire(import.meta.url),{createFarmCommandGateway}=require('./lib/farm-command-gateway.cjs');
const ROOT=path.dirname(fileURLToPath(import.meta.url));
const readJSON=async p=>JSON.parse((await readFile(p,'utf8')).replace(/^\uFEFF/,''));
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export async function createApp(overrides={}){
 const {configFile=path.join(ROOT,'antfarm.config.json'),worldProjectsProfilePath=process.env[PROFILE_ENV]??DEFAULT_PROFILE,humanQaService=null,humanQaEnvironment=null,ownerFrameService=null,...options}=overrides;
 if(ownerFrameService!==null&&typeof ownerFrameService!=='function'&&typeof ownerFrameService?.ownerFrameResponse!=='function')throw Error('Configured owner frame service required');
 const config={...(await readJSON(configFile)),...options},registry=await loadRegistry(ROOT,{registrySource:config.registrySource,nativeReadOnly:config.nativeReadOnly,nativeWorkspaceRoot:config.nativeWorkspaceRoot});
 if(!['demo','live'].includes(config.mode))throw Error('Mode must be demo or live.');
 if(config.nativeWorkspaceRoot!==undefined&&config.nativeReadOnly!==true)throw Error('nativeWorkspaceRoot requires nativeReadOnly mode.');
 const adapter=overrides.adapter||(await import(config.nativeReadOnly?'./adapters/native-session-adapter.mjs':'./adapters/file-adapter.mjs')).createAdapter({root:config.nativeReadOnly?(config.nativeWorkspaceRoot??ROOT):ROOT,planningRoot:ROOT,config,registry});
 const commands=config.nativeReadOnly?null:overrides.commandAdapter||(config.commandAdapter?await import(pathToFileURL(path.resolve(ROOT,config.commandAdapter))):null);
 const transportEnabled=!config.nativeReadOnly&&config.mode==='live'&&config.commandsEnabled===true&&typeof commands?.dispatch==='function';
 const sharedWorldId=publicWorldId(config.projectId||ROOT),projectRoot=config.nativeReadOnly?(config.nativeWorkspaceRoot??ROOT):ROOT,projectId=config.projectId||sharedWorldId;const baseRegistry=registry.slice();let origin='',scenario='working';
 const planningInputs=new WeakMap();
 let ownerMetadataCache=null;
 const resources=createServedWorldResource({projectId,descriptor:PREVIEW_DESCRIPTOR,readProfile:()=>readWorldProfile({packageRoot:ROOT,projectRoot,projectId}),qualifyProfile:previewCompatible});
 const profile=async()=>(await resources.read()).served;
 async function content(){const provider=await contentProvider();if(typeof provider?.resolveProjectContent!=='function')return {schemaVersion:1,projectId,status:'unavailable',revision:null,rules:null,definitions:[],agents:[]};try{const value=await provider.resolveProjectContent({packageRoot:ROOT,projectRoot,projectId});if(value?.schemaVersion!==1||value.projectId!==projectId||!['defaults','overrides','unavailable','reconciliation-required'].includes(value.status))throw Error('Foreign project content');return value;}catch{return {schemaVersion:1,projectId,status:'unavailable',revision:null,rules:null,definitions:[],agents:[]};}}
 const scenarios=new Set(['working','blocked','support','retirement','accepted','sleeping','stale']);
 async function readCurrentState(){
  const projectContent=await content(),input=config.mode==='demo'?createDemo(baseRegistry,scenario):await adapter.readSnapshot({projectContent});
  const activeRegistry=config.nativeReadOnly&&Array.isArray(input.registry)?input.registry:baseRegistry;
  const state=await createProjection(activeRegistry,input,Date.now(),{worldId:sharedWorldId});registry.splice(0,registry.length,...activeRegistry);state.registry=activeRegistry;state.mode=config.mode;state.projectContent=projectContent;const resource=await resources.read();state.worldProfile=resource.served;state.worldUpdate={state:resource.state,selected:worldProfileDisplay(resource.selected)};const catalogs=effectiveCatalogs(projectContent,await readRuleCatalogs(ROOT));state.ruleCatalog=catalogs?ruleDisplay(catalogs):null;state.effectiveCatalogs=catalogs;
  state.feed.farmFacts.commands=gateway.getAvailability(state);
  const enabled=transportEnabled;
  state.feed.farmFacts.commands.transportEnabled=enabled;
  if(!enabled)for(const entry of Object.values(state.feed.farmFacts.commands.agents)){entry.wake=false;entry.retire=false;entry.unblockTaskIds=[];}
  planningInputs.set(state,input);
  return state;
 }
 const gateway=createFarmCommandGateway({getOrigin:()=>origin,journalPath:overrides.journalPath||path.join(ROOT,'runtime/Commands/Journal.json'),readCurrentState,
  dispatch:async(target,prompt,requestId)=>{
   if(!transportEnabled)return{state:'unavailable',message:'No destination-project command connector is enabled.'};
   const current=await readCurrentState();if(!current.roster.some(a=>a.threadId===target&&a.connected))return{state:'unavailable',message:'The current target is not connected.'};
   return commands.dispatch(target,prompt,requestId);
  }});
 function reply(res,code,value){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(value));}
 function rolesForSite(){return registry.map(({id,title,role})=>({id,title,role}));}
 async function previewCompatible(selected){if(selected?.status!=='ready'||selected.selection?.renderer!=='midnight-colony')return false;try{return ownerPreviewProfileMatches(selected,await readOwnerPreviewQualification(ROOT));}catch{return false;}}
 async function qualifiedPreview(state,includeMetadata=true){
  const selected=state.worldProfile;
  if(!await previewCompatible(selected))return null;
  try{return createOwnerPreviewProjector({registry:state.registry,worldId:sharedWorldId,publicWorldSnapshot,assertPublicWorldSnapshot,createLocalAppearance,oracle:globalThis.AgentOutpost,descriptor:PREVIEW_DESCRIPTOR,includeMetadata,palette:LOCAL_PALETTE})(state);}catch{return null;}
 }
 async function cacheWorkspaceMetadata(state,envelope){
  const observedUtc=envelope.snapshot?.observedUtc;if(!observedUtc||ownerMetadataCache&&Date.parse(observedUtc)<Date.parse(ownerMetadataCache.observedUtc))return;
  let metadata=null;try{if(envelope.state==='current'){const ownerPreview=await qualifiedPreview(state,true),roles=state.registry.map(({id,title,role})=>({id,title,role}));metadata=createSiteAgentMetadataProjector({worldId:sharedWorldId,roles})({dashboard:state,ownerPreview});}}catch{}
  if(ownerMetadataCache&&Date.parse(observedUtc)<Date.parse(ownerMetadataCache.observedUtc))return;
  if(ownerMetadataCache?.observedUtc===observedUtc&&JSON.stringify(ownerMetadataCache.metadata)===JSON.stringify(metadata))return;
  ownerMetadataCache={observedUtc,receivedUtc:envelope.receivedUtc,metadata};
 }
 async function ownerContext(){
  const selected=await profile(),supported=await previewCompatible(selected);
  return{schemaVersion:1,access:'local-owner',worldId:sharedWorldId,roles:rolesForSite(),websiteVersion:config.websiteVersion||'1.0.0',worldVersion:selected.status==='ready'&&selected.source==='project'?selected.worldVersion:null,ownerOrigin:origin,publicOrigin:null,framePath:supported?'/world-frame/'+PREVIEW_DESCRIPTOR.artifactSha256+'/':'/operator',projectName:config.projectName||'ALife World',creatorLabel:'Created by Itzel Juarez',renderer:supported?PREVIEW_DESCRIPTOR:null,qualifiedGalleryRenderer:PREVIEW_DESCRIPTOR};
 }
 const ownerSite=createOwnerSiteHandler({isOwner:request=>new URL(request.url).origin===origin,getContext:ownerContext});

 async function respondWeb(res,response,head=false){res.writeHead(response.status,Object.fromEntries(response.headers));res.end(head?undefined:Buffer.from(await response.arrayBuffer()));}
 const localFrames=createLocalOwnerFrameProvider({worldId:sharedWorldId,websiteVersion:config.websiteVersion||'1.0.0',getOrigin:()=>origin,descriptor:PREVIEW_DESCRIPTOR,
  readProfile:profile,qualifyProfile:previewCompatible,readAsset:(selected,row)=>readWorldSceneFile(selected,row.path.slice(4)),
  readSnapshot:async()=>{const state=await readCurrentState();const value=await qualifiedPreview(state,true);if(!value)throw Error('Current qualified preview unavailable');return value;}});
 const ownerFrames=createLocalOwnerFrameHandler({getOrigin:()=>origin,isOwner:req=>req.headers.host===new URL(origin).host&&['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket?.remoteAddress),getService:()=>typeof ownerFrameService==='function'?ownerFrameService({origin,projectId,worldId:sharedWorldId,registry,readCurrentState}):ownerFrameService??localFrames()});
 const defaultBackup=createDefaultWorldBackup({packageRoot:ROOT,worldId:sharedWorldId,
  readDefault:()=>readWorldProfile({packageRoot:ROOT,projectRoot,projectId,defaultBackup:true}),
  readSnapshot:async()=>{const state=await readCurrentState();return publicWorldSnapshot(state,state.registry,{worldId:sharedWorldId});}});
 const server=http.createServer(async(req,res)=>{
  try{
   if(req.headers.host!==new URL(origin).host||!['127.0.0.1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress)){reply(res,403,{error:'Local host required'});return;}
   const u=new URL(req.url,origin);
   if(!String(req.url).startsWith('/')||u.origin!==origin){reply(res,403,{error:'Exact local origin required'});return;}
   if(u.pathname==='/default-world'||u.pathname.startsWith('/default-world/')){const response=await defaultBackup(new Request(u,{method:req.method}));await respondWeb(res,response,req.method==='HEAD');return;}
   if(await ownerFrames(req,res))return;
   const ownProjectId=config.projectId||sharedWorldId;
   if(['/api/workspace','/api/world-catalog','/api/owner-world-preview','/api/owner-world-presentation','/api/rule-library','/api/agent-metadata'].includes(u.pathname)){
    if(u.pathname==='/api/rule-library'&&req.method!=='GET'){reply(res,405,{error:'Read-only owner rule library'});return;}
    if(!['GET','HEAD'].includes(req.method)){reply(res,405,{error:'Read-only owner display'});return;}
    if(req.headers.origin!==undefined&&req.headers.origin!==origin||req.headers['sec-fetch-site']!==undefined&&!['same-origin','none'].includes(req.headers['sec-fetch-site'])){reply(res,403,{error:'Local same-origin display required'});return;}
    if([...u.searchParams.keys()].some(k=>k!=='project')||u.searchParams.getAll('project').length>1||u.searchParams.has('project')&&u.searchParams.get('project')!==sharedWorldId){reply(res,404,{error:'World unavailable'});return;}
    if(u.pathname==='/api/agent-metadata'){
     const contract=createSiteAgentMetadataContract({worldId:sharedWorldId,roles:rolesForSite()});let value=contract.response(null,null);try{if(ownerMetadataCache?.metadata){const cached=contract.response(ownerMetadataCache.metadata,ownerMetadataCache.receivedUtc);if(cached.state==='current')value=cached;}}catch{}reply(res,200,value);return;
    }
    if(u.pathname==='/api/rule-library'){
     try{const catalogs=effectiveCatalogs(await content(),await readRuleCatalogs(ROOT));reply(res,200,createOwnerRuleLibrary(catalogs,{worldId:sharedWorldId}));}catch{reply(res,503,{error:'Effective project rules unavailable; reconcile the original content operation.'});}return;
    }
    if(u.pathname==='/api/world-catalog'){
     const raw=await readPrivateWorldCatalog({packageRoot:ROOT,profilePath:worldProjectsProfilePath,projectRoot,projectId,worldId:sharedWorldId,origin,currentOnly:true,localOnly:true});
     reply(res,200,privateWorldCatalogEnvelope(raw,new Date().toISOString()));return;
    }
    const state=await readCurrentState();
    if(['/api/owner-world-preview','/api/owner-world-presentation'].includes(u.pathname)){const preview=await qualifiedPreview(state,u.pathname==='/api/owner-world-presentation');if(!preview){reply(res,503,{error:'Qualified owner preview unavailable'});return;}reply(res,200,preview);return;}
    const contract=createOwnerWorkspaceContract({worldId:sharedWorldId,roles:rolesForSite()}),projector=createWorkspaceProjector({worldId:sharedWorldId,projectId:ownProjectId,roles:rolesForSite(),contract}),input=planningInputs.get(state);
    const dashboard={...state,project:{...state.project,id:ownProjectId,name:config.projectName||state.project.name}},plan={...input,observedUtc:input.snapshotObservedUtc??input.observedUtc};
    const pair=projector.projectWorkspace({dashboard,plan}),envelope=contract.workspaceEnvelope(pair.owner,new Date().toISOString());await cacheWorkspaceMetadata(state,envelope);reply(res,200,envelope);return;
   }
   if(u.pathname==='/api/qa-goals'||u.pathname==='/api/qa-verifications'||u.pathname.startsWith('/api/qa-verifications/')){
    if(req.headers.origin!==undefined&&req.headers.origin!==origin||req.headers['sec-fetch-site']!==undefined&&!['same-origin','none'].includes(req.headers['sec-fetch-site'])){reply(res,403,{error:'Local same-origin QA required'});return;}
    if(!humanQaService||typeof humanQaService.handle!=='function'||!humanQaEnvironment){reply(res,503,{error:'Human QA service is not configured for this project'});return;}
    const headers=new Headers();for(const [name,value]of Object.entries(req.headers))if(typeof value==='string')headers.set(name,value);
    const chunks=[];let size=0;if(!['GET','HEAD'].includes(req.method))for await(const chunk of req){size+=chunk.length;if(size>65536){reply(res,413,{error:'Request too large'});return;}chunks.push(chunk);}
    const request=new Request(u,{method:req.method,headers,...(!['GET','HEAD'].includes(req.method)?{body:Buffer.concat(chunks)}:{})});const response=await humanQaService.handle(request,humanQaEnvironment);if(!response){reply(res,404,{error:'Not found'});return;}await respondWeb(res,response,req.method==='HEAD');return;
   }
   if(['/', '/workspace.css','/workspace.js','/owner-operator-viewport.mjs','/owner-world-viewport.css'].includes(u.pathname)){
    if(u.searchParams.has('project')&&(u.searchParams.getAll('project').length!==1||u.searchParams.get('project')!==ownProjectId)){reply(res,404,{error:'Project unavailable'});return;}
    const target=new URL(u);target.searchParams.delete('project');const response=await ownerSite(new Request(target,{method:req.method}));
    if(response){const headers=new Headers(response.headers);headers.set('Content-Security-Policy',headers.get('Content-Security-Policy').replace("frame-ancestors 'self'","frame-ancestors 'none'"));await respondWeb(res,new Response(response.body,{status:response.status,headers}),req.method==='HEAD');return;}
   }
   if((u.pathname==='/operator'||['/api/dashboard','/api/active-work','/api/world-projects','/api/world-prompt','/api/rule-export','/api/portable-export'].includes(u.pathname))&&u.searchParams.has('project')&&(u.searchParams.getAll('project').length!==1||u.searchParams.get('project')!==ownProjectId)){reply(res,404,{error:'Project unavailable'});return;}
   if(u.pathname==='/api/world-launcher'){if(req.method!=='GET'){reply(res,405,{error:'Read-only world identity'});return;}if(u.searchParams.get('project')!==ownProjectId||u.searchParams.getAll('project').length!==1){reply(res,404,{error:'Project unavailable'});return;}reply(res,200,{schemaVersion:1,kind:'alife-world-launcher',projectId:ownProjectId,worldId:sharedWorldId,projectRootSha256:await projectRootIdentity(config.nativeWorkspaceRoot??ROOT),origin:new URL(origin).origin});return;}
   if(u.pathname==='/api/private-world-catalog'){
    if(!config.ownerSiteOrigin){reply(res,404,{error:'Owner catalog is not configured'});return;}
    if(req.method!=='GET'){reply(res,405,{error:'Read-only private world catalog'});return;}
    if(req.headers.origin!==undefined&&req.headers.origin!==origin||req.headers['sec-fetch-site']!==undefined&&!['same-origin','none'].includes(req.headers['sec-fetch-site'])){reply(res,403,{error:'Same-origin operator required'});return;}
    if([...u.searchParams.keys()].some(key=>key!=='project')||u.searchParams.getAll('project').length!==1||u.searchParams.get('project')!==ownProjectId){reply(res,404,{error:'Project unavailable'});return;}
    const controller=new AbortController(),cancel=()=>controller.abort();req.once('aborted',cancel);res.once('close',cancel);
    try{const result=await readPrivateWorldCatalog({packageRoot:ROOT,profilePath:worldProjectsProfilePath,projectRoot,projectId,worldId:sharedWorldId,origin,ownerSiteOrigin:config.ownerSiteOrigin,signal:controller.signal});if(!res.destroyed)reply(res,200,result);}
    finally{req.removeListener('aborted',cancel);res.removeListener('close',cancel);}return;
   }
   if(u.pathname==='/api/world-projects'||u.pathname==='/api/world-projects/open'){
    if(req.method!=='GET'){reply(res,405,{error:'Read-only project registry'});return;}
    if(req.headers.origin!==undefined&&req.headers.origin!==origin||req.headers['sec-fetch-site']!==undefined&&!['same-origin','none'].includes(req.headers['sec-fetch-site'])){reply(res,403,{error:'Same-origin operator required'});return;}
    const opening=u.pathname.endsWith('/open'),allowed=opening?['project','worldId']:['project'];
    if([...u.searchParams.keys()].some(key=>!allowed.includes(key))||u.searchParams.getAll('project').length>1||opening&&(u.searchParams.getAll('project').length!==1||u.searchParams.getAll('worldId').length!==1||!/^[a-z][a-z0-9-]{0,63}$/.test(u.searchParams.get('worldId')||''))){reply(res,400,{error:'Choose one configured world alias'});return;}
    if(u.searchParams.has('project')&&u.searchParams.get('project')!==ownProjectId){reply(res,404,{error:'Project unavailable'});return;}
    const options={packageRoot:ROOT,profilePath:worldProjectsProfilePath,projectRoot,projectId,worldId:sharedWorldId,origin,config};
    if(!opening){reply(res,200,await ownerWorldProjects(options));return;}
    const controller=new AbortController(),cancel=()=>controller.abort();req.once('aborted',cancel);res.once('close',cancel);
    try{const result=await openOwnerWorld(u.searchParams.get('worldId'),{...options,signal:controller.signal});if(!res.destroyed)reply(res,200,result);}
    finally{req.removeListener('aborted',cancel);res.removeListener('close',cancel);}return;
   }
   if(['/api/world-view','/world/view','/watch'].includes(u.pathname)){
    if(!['GET','HEAD'].includes(req.method)){reply(res,405,{error:'Read-only world display'});return;}
    if(u.searchParams.has('project')&&u.searchParams.get('project')!==sharedWorldId){reply(res,404,{error:'World unavailable'});return;}
    if(u.pathname==='/api/world-view'){try{const state=await readCurrentState();if(state.worldProfile.status!=='ready')throw Error('Selected scene unavailable');reply(res,200,publicWorldSnapshot(state,state.registry,{worldId:sharedWorldId}));}catch{reply(res,503,{error:'World display unavailable'});}return;}
    const html=(await readFile(path.join(ROOT,'web/world-view.html'),'utf8')).replace('__VIEWER_BASE__','/').replace('__VIEWER_SOURCE__','/api/world-view');res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors *; object-src 'none'; base-uri 'self'"});res.end(req.method==='HEAD'?undefined:html);return;
   }
   if(!transportEnabled&&u.pathname==='/api/ant-farm-command'){reply(res,503,{state:'unavailable',message:'Native commands are disabled for this read-only world.'});return;}
   if(await gateway.handle(req,res))return;
   if(req.method==='GET'&&u.pathname==='/api/portable-export'){
    if(u.searchParams.getAll('project').length!==1||u.searchParams.get('project')!==ownProjectId||u.searchParams.get('kind')!=='agent'||u.searchParams.getAll('agent').length!==1||!/^[a-z][a-z0-9-]{0,63}$/.test(u.searchParams.get('agent')||'')){reply(res,400,{error:'Choose one logical agent in this project.'});return;}
    const provider=await contentProvider();if(typeof provider?.readPortableDefinition!=='function'){reply(res,503,{error:'The portable definition reader is unavailable. Ask Agent Support to reconcile the original authored definition.'});return;}
    try{
     const roleId=u.searchParams.get('agent'),state=await readCurrentState(),roles=state.registry.filter(r=>r.id===roleId),represented=state.model.agents.filter(a=>a.roleId===roleId);
     if(roles.length!==1||represented.length!==1)throw Error('Runtime role is not a selected project member');
     const definition=await provider.readPortableDefinition({packageRoot:ROOT,projectRoot,projectId,roleId});
     const {validatePortablePacket,dataHash,closed}=await import('./lib/portable-definitions.mjs');
     closed(definition,['schemaVersion','projectId','roleId','definitionSha256','packet'],'private portable definition result');
     if(definition.schemaVersion!==1||definition.projectId!==projectId||definition.roleId!==roleId||!/^[a-f0-9]{64}$/.test(definition.definitionSha256||''))throw Error('Definition selector mismatch');
     const packet=validatePortablePacket(definition.packet);if(packet.kind!=='agent'||packet.agents?.length!==1)throw Error('One original authored agent is required');
     const authored=packet.agents[0],digest=dataHash(authored);if(digest!==definition.definitionSha256)throw Error('Original authored definition changed');
     if(roles[0].imported===true){
      const members=(state.projectContent.agents||[]).filter(a=>a.id===roleId);
      if(members.length!==1||members[0].definitionSha256!==digest)throw Error('Original imported role mapping is unavailable');
     }else{
      const mappings=(state.projectContent.definitions||[]).filter(a=>a.id===roleId);
      if(authored.id!==roleId||mappings.length!==1||mappings[0].definitionSha256!==digest)throw Error('Original authored role mapping is unavailable');
     }
     // The private runtime-selector envelope is never returned to the client.
     reply(res,200,packet);
    }catch{reply(res,503,{error:'A complete safe authored definition is unavailable for this agent. Live chats and private instructions are never copied.'});}return;
   }
   if(req.method==='GET'&&['/api/world-prompt','/api/rule-export'].includes(u.pathname)){const scope=u.pathname==='/api/world-prompt'?'world':u.searchParams.get('scope');if(!['world','plugin'].includes(scope)){reply(res,400,{error:'Choose world or plugin.'});return;}const state=await readCurrentState();if(!state.effectiveCatalogs){reply(res,503,{error:'Effective project rules are unavailable; reconcile the original content operation.'});return;}const prompt=exportRulePrompt(state.effectiveCatalogs[scope]);res.writeHead(200,{'Content-Type':'text/markdown; charset=utf-8','Content-Disposition':'attachment; filename="'+scope+'-rules-prompt.md"','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(prompt);return;}
   if(req.method==='GET'&&u.pathname.startsWith('/api/')){
    if(!['/api/dashboard','/api/active-work'].includes(u.pathname)){reply(res,404,{error:'Not found'});return;}
    if(config.mode==='demo'&&scenarios.has(u.searchParams.get('scene')))scenario=u.searchParams.get('scene');
    const s=await readCurrentState();
    if(u.pathname==='/api/active-work')reply(res,200,s.feed);
    else reply(res,200,{model:s.model,feed:s.feed,project:{...s.project,id:ownProjectId,name:worldProjects(config,origin,ROOT,sharedWorldId).projects[0].name},mode:s.mode,worldProfile:worldProfileDisplay(s.worldProfile),worldUpdate:s.worldUpdate,ruleCatalog:s.ruleCatalog,ownerPreview:await qualifiedPreview(s),rendererVersion:'3.22.0',pollMs:Math.max(1000,Number(config.pollMs)||5000)});
    return;
   }
   if(!['GET','HEAD'].includes(req.method)){reply(res,405,{error:'Method not allowed'});return;}
   if(u.pathname==='/operator'){
    if(u.searchParams.has('worldId')&&(u.searchParams.getAll('worldId').length!==1||u.searchParams.get('worldId')!==sharedWorldId)){reply(res,404,{error:'World unavailable'});return;}
    let html=await readFile(path.join(ROOT,'web/index.html'),'utf8');const nonce=randomBytes(18).toString('base64');
    const context=JSON.stringify(await ownerContext()).replaceAll('<','\\u003c').replaceAll('\u2028','\\u2028').replaceAll('\u2029','\\u2029');
    html=html.replaceAll('__PROJECT_NAME_HTML__',escape(config.projectName||'Your Project')).replaceAll('__PAGE_NONCE__',nonce).replaceAll('__ALIFE_OWNER_SITE_CONTEXT__',context);html=gateway.renderPage(html);
    const ownFrame=u.searchParams.get('hostOrigin')===origin&&u.searchParams.get('worldViewport')==='1'&&u.searchParams.get('worldId')===sharedWorldId;
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':`default-src 'self';script-src 'self' 'nonce-${nonce}';style-src 'self' 'unsafe-inline';img-src 'self' data:;connect-src 'self';frame-src 'self' http://127.0.0.1:* http://localhost:* http://[::1]:*;object-src 'none';base-uri 'none';frame-ancestors ${ownFrame?"'self'":"'none'"}`,'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});res.end(req.method==='HEAD'?undefined:html);return;
   }
   let rel;try{rel=decodeURIComponent(u.pathname.slice(1));}catch{reply(res,400,{error:'Invalid path'});return;}
   const web=path.resolve(ROOT,'web'),file=path.resolve(web,rel);
   const publicFiles=new Set([...WORLD_OPTIONAL_SCENE_FILES,"project-world-presentation.mjs","project-world-presentation.css","project-world-appearance.mjs","project-world-gallery.mjs",'app.mjs','portable-definitions.mjs','world-shell.mjs','world-shell-model.mjs','world-view.mjs','world-view.css','audio.mjs','dashboard-model.mjs','boot.js','command-exchange.js','dashboard.css','portable.css',"agent-outpost/assets/midnight-colony-reference-20261107/woodland-pines.png","agent-outpost/assets/midnight-colony-reference-20261107/sprint-tree-states.png","agent-outpost/assets/midnight-colony-reference-20261107/woodland-scenery.png","agent-outpost/assets/midnight-colony-reference-20261107/sprites.json","agent-outpost/assets/midnight-colony-reference-20261107/art-provenance.json","agent-outpost/assets/midnight-colony-reference-20261107/room-names.ttf","agent-outpost/assets/midnight-colony-reference-20261107/room-names.LICENSE.txt",'agent-outpost/colony-art.js','agent-outpost/agent-outpost.js','agent-outpost/agent-outpost.css','assets/worker-atlas.png','assets/outpost-base.png','assets/audio/gem-hit.mp3','assets/audio/gem-break.mp3','assets/audio/sand-step.mp3','assets/audio/rock-hit.mp3','assets/audio/water-drop.mp3','assets/audio/grass-rustle.mp3','assets/audio/ui-pop.mp3','assets/audio/rain-loop.mp3','assets/audio/lofi-schmoop.mp3','assets/audio/LICENSES.json']);
   const customScene=customWorldAsset(rel);
   if((!publicFiles.has(rel)&&!customScene)||!file.startsWith(web+path.sep)){reply(res,404,{error:'Not found'});return;}
   if(!customScene&&(path.resolve(await realpath(file))!==file||!(await stat(file)).isFile())){reply(res,404,{error:'Not found'});return;}
   const mime={'.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.svg':'image/svg+xml','.mp3':'audio/mpeg','.wav':'audio/wav','.ogg':'audio/ogg','.json':'application/json','.ttf':'font/ttf','.woff':'font/woff','.woff2':'font/woff2','.txt':'text/plain; charset=utf-8'}[path.extname(file).toLowerCase()];
   const optionalScene=WORLD_OPTIONAL_SCENE_FILES.includes(rel),selected=WORLD_SCENE_FILES.includes(rel)||optionalScene||customScene?await profile():null;
   if(WORLD_SCENE_FILES.includes(rel)&&selected?.status!=='ready'){reply(res,503,{error:'Compatible world resource unavailable'});return;}
   if(optionalScene&&(selected?.status!=='ready'||!selected.selection.files.some(row=>row.path==='web/'+rel))){reply(res,404,{error:'Not found'});return;}
   if(customScene&&(selected?.status!=='ready'||!selected.selection.files.some(row=>row.path==='web/'+rel))){reply(res,404,{error:'Not found'});return;}
   const data=selected?.status==='ready'?await readWorldSceneFile(selected,rel):await readFile(file);res.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:data);
  }catch(e){if(!res.headersSent)reply(res,e.code==='ENOENT'?404:500,{error:e.code==='ENOENT'?'Not found':'Project feed unavailable;check your adapter and source schema.'});else res.end();}
 });
 return{server,config,registry,gateway,readCurrentState,listen(port=Number(process.env.ANTFARM_PORT??config.port??7486)){return new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',()=>{origin='http://127.0.0.1:'+server.address().port;resolve(origin);});});}};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){const app=await createApp();const address=await app.listen();console.log(`ALife Worlds / ${app.config.mode} / ${app.registry.length} roles\n${address}\nCtrl+C stops this local server.`);}
