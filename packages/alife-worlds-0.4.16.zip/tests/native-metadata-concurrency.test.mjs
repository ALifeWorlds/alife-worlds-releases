import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {spawn} from 'node:child_process';
import {createNativeMetadataStore,blankNativeMetadata,nativeMetadataProjection} from '../lib/native-agent-metadata.mjs';
import {acquireProjectOperation,releaseProjectOperation} from '../lib/project-operations.mjs';

const projectId='10000000-0000-0000-0000-000000000001',t0=Date.parse('2026-11-09T10:00:00.000Z'),at=n=>new Date(t0+n).toISOString();
const metadataURL=new URL('../lib/native-agent-metadata.mjs',import.meta.url).href;
const binding=(root,id='director',suffix='1')=>({id,threadId:'20000000-0000-0000-0000-'+suffix.padStart(12,'0'),sessionPath:path.join(root,id+'.jsonl')});
const file=root=>path.join(root,'.alife-worlds/native-agent-metadata-v2.json');
const read=async root=>JSON.parse(await readFile(file(root),'utf8'));
const recovery=(metadata,size=200,fileKey='f'.repeat(64))=>({fileKey,size,coverage:'current',metadata:{...blankNativeMetadata(),...metadata}});
const cell=(value,n)=>({value,source:'thread_settings_applied',observedUtc:at(n)});
async function fixture(fn){const parent=process.env.ALIFE_METADATA_TEST_ROOT||path.join(os.tmpdir(),'alife-metadata-concurrency');await mkdir(parent,{recursive:true});const root=await mkdtemp(path.join(parent,'case-'));try{await fn(root);}finally{assert(path.resolve(root).startsWith(path.resolve(parent)+path.sep));await rm(root,{recursive:true,force:true});}}

test('independent loaded stores retain both roles and advance from the current disk revision',()=>fixture(async root=>{
 let time=t0;const director=binding(root),support=binding(root,'support','2'),a=createNativeMetadataStore({root,projectId,now:()=>time}),b=createNativeMetadataStore({root,projectId,now:()=>time});
 await a.get(director);await b.get(support);
 await a.update(director,{index:{name:'Director',selectedModel:'gpt-6.1-sol',archived:false}});time++;
 await a.update(director,{index:{selectedModel:'gpt-6-astra'}});time++;
 await b.update(support,{index:{name:'Agent Support',selectedModel:'gpt-6.1-sol',archived:false}});
 const saved=await read(root);assert.equal(saved.revision,3);assert.deepEqual(saved.agents.map(r=>r.roleId),['director','support']);assert.equal(saved.agents[0].selectedModel.value,'gpt-6-astra');assert.equal(saved.agents[0].selectedModel.observedUtc,at(1));
 assert.equal((await a.get(support)).name.value,'Agent Support');assert.equal(a.status().revision,3);
}));

test('concurrent local instances serialize rather than lose a role or regress the revision',()=>fixture(async root=>{
 const ids=['director','support','world-requests'],stores=ids.map(()=>createNativeMetadataStore({root,projectId,now:()=>t0}));
 await Promise.all(stores.map((s,i)=>s.get(binding(root,ids[i],String(i+1)))));
 await Promise.all(stores.map((s,i)=>s.update(binding(root,ids[i],String(i+1)),{index:{name:ids[i],selectedModel:'gpt-6.1-sol',archived:false}})));
 const saved=await read(root);assert.equal(saved.revision,3);assert.equal(saved.agents.length,3);
}));

test('same-role competing recovery merges each field by original observation time, including explicit nulls',()=>fixture(async root=>{
 const role=binding(root),a=createNativeMetadataStore({root,projectId,now:()=>t0+4000}),b=createNativeMetadataStore({root,projectId,now:()=>t0+5000});await a.get(role);await b.get(role);
 await a.update(role,{recovery:recovery({model:cell('gpt-6-astra',2000),reasoningEffort:cell('high',2000),serviceTier:cell('default',2000)})});
 const merged=await b.update(role,{recovery:recovery({model:cell('gpt-6.1-sol',1000),reasoningEffort:cell('xhigh',3000)})});
 assert.equal(merged.metadata.model.value,'gpt-6-astra');assert.equal(merged.metadata.model.observedUtc,at(2000));assert.equal(merged.metadata.reasoningEffort.value,'xhigh');assert.equal(merged.metadata.serviceTier.value,'default');
 await a.update(role,{recovery:recovery({model:cell(null,4000)})});
 const retained=await b.update(role,{recovery:recovery({model:cell('gpt-6.1-sol',3000)})});assert.equal(retained.metadata.model.value,null);assert.equal(retained.metadata.model.observedUtc,at(4000));assert.equal(nativeMetadataProjection(retained).modelState,'unknown');
}));

test('older index observations cannot overwrite newer selection, name or archive evidence',()=>fixture(async root=>{
 const role=binding(root),a=createNativeMetadataStore({root,projectId,now:()=>t0+3000}),b=createNativeMetadataStore({root,projectId,now:()=>t0+4000});await a.get(role);await b.get(role);
 await a.update(role,{index:{selectedModel:'gpt-6-astra',name:'Director 2',archived:true},indexObservedUtc:at(2000)});
 const before=await readFile(file(root),'utf8'),value=await b.update(role,{index:{selectedModel:'gpt-6.1-sol',name:'Old Director',archived:false},indexObservedUtc:at(1000)});
 assert.equal(value.selectedModel.value,'gpt-6-astra');assert.equal(value.name.value,'Director 2');assert.equal(value.archived.value,true);assert.equal(value.selectedModel.observedUtc,at(2000));assert.equal(await readFile(file(root),'utf8'),before);
}));

test('equal-time changes from a current reader work, while a stale peer cannot win a timestamp tie',()=>fixture(async root=>{
 const role=binding(root),a=createNativeMetadataStore({root,projectId,now:()=>t0}),b=createNativeMetadataStore({root,projectId,now:()=>t0});
 await a.update(role,{index:{selectedModel:'gpt-6.1-sol'}});await b.get(role);
 await a.update(role,{index:{selectedModel:'gpt-6-astra'}});
 assert.equal((await b.update(role,{index:{selectedModel:'gpt-6-luna'}})).selectedModel.value,'gpt-6-astra');
 assert.equal((await a.update(role,{index:{selectedModel:'gpt-6.1-terra'}})).selectedModel.value,'gpt-6.1-terra');
 const before=await readFile(file(root),'utf8'),revision=a.status().revision;await a.update(role,{index:{selectedModel:'gpt-6.1-terra'}});assert.equal(await readFile(file(root),'utf8'),before);assert.equal(a.status().revision,revision);
}));

test('memory-only offset advances survive a peer refresh without heartbeat writes',()=>fixture(async root=>{
 const role=binding(root),other=binding(root,'support','2'),a=createNativeMetadataStore({root,projectId,now:()=>t0}),b=createNativeMetadataStore({root,projectId,now:()=>t0+1}),metadata={model:cell('gpt-6.1-sol',0)};
 await a.update(role,{recovery:recovery(metadata,100)});const original=await readFile(file(root),'utf8');await a.update(role,{recovery:recovery(metadata,200)});assert.equal(await readFile(file(root),'utf8'),original);
 await b.update(other,{index:{name:'Support'}});const peer=await readFile(file(root),'utf8');assert.equal((await a.get(role)).size,200);await a.update(role,{recovery:recovery(metadata,200)});assert.equal(await readFile(file(root),'utf8'),peer);
 assert.equal((await createNativeMetadataStore({root,projectId}).get(role)).size,100);
}));

test('stale binding/file generations are refused instead of resurrecting replaced metadata',()=>fixture(async root=>{
 const old=binding(root),next={...binding(root,'director','2'),sessionPath:path.join(root,'successor.jsonl')},a=createNativeMetadataStore({root,projectId,now:()=>t0}),b=createNativeMetadataStore({root,projectId,now:()=>t0+2});
 await a.update(old,{recovery:recovery({model:cell('gpt-6.1-sol',0)},100,'a'.repeat(64))});await b.get(old);
 await a.update(next,{recovery:recovery({model:cell('gpt-6-astra',1)},100,'b'.repeat(64))});const before=await readFile(file(root),'utf8');
 await assert.rejects(b.update(old,{index:{name:'Old Director'}}),/binding changed/);assert.equal(await readFile(file(root),'utf8'),before);assert.equal(await b.get(old),null);assert.equal((await b.get(next)).metadata.model.value,'gpt-6-astra');
 const c=createNativeMetadataStore({root,projectId,now:()=>t0+3});await c.get(next);await a.get(next);await a.update(next,{recovery:recovery({model:cell('gpt-6.1-terra',2)},100,'c'.repeat(64))});
 await assert.rejects(c.update(next,{recovery:recovery({model:cell('gpt-6-luna',0)},100,'b'.repeat(64))}),/file identity/);assert.equal((await read(root)).agents[0].metadata.model.value,'gpt-6.1-terra');
}));

test('the project gate is respected; an unresolved lease is not removed and later admission recovers',()=>fixture(async root=>{
 const role=binding(root),store=createNativeMetadataStore({root,projectId,now:()=>t0});await store.update(role,{index:{name:'Director'}});const before=await readFile(file(root),'utf8'),lease=await acquireProjectOperation(root,'metadata-test-owner');
 try{await assert.rejects(store.update(role,{index:{name:'Director 2'}}),e=>e.code==='ALIFE_PROJECT_BUSY');assert.equal(await readFile(file(root),'utf8'),before);assert.equal(JSON.parse(await readFile(lease.file,'utf8')).token,lease.token);}finally{await releaseProjectOperation(lease);}
 assert.equal((await store.update(role,{index:{name:'Director 2'}})).name.value,'Director 2');assert.equal(store.status().persistence,'available');
}));

test('a corrupted warm store stays untouched and retains only last-verified memory as unavailable',()=>fixture(async root=>{
 const role=binding(root),store=createNativeMetadataStore({root,projectId,now:()=>t0});await store.update(role,{index:{name:'Director'}});await writeFile(file(root),'{invalid}');
 assert.equal((await store.get(role)).name.value,'Director');assert.equal(store.status().persistence,'unavailable');await assert.rejects(store.update(role,{index:{name:'Changed'}}));assert.equal(await readFile(file(root),'utf8'),'{invalid}');
}));

test('warm revision rollback and invalid source times fail closed without rewriting retained evidence',()=>fixture(async root=>{
 let now=t0;const role=binding(root),store=createNativeMetadataStore({root,projectId,now:()=>now});await store.update(role,{index:{selectedModel:'gpt-6.1-sol'}});const older=await readFile(file(root),'utf8');now++;
 await store.update(role,{index:{selectedModel:'gpt-6-astra'}});await writeFile(file(root),older);
 assert.equal((await store.get(role)).selectedModel.value,'gpt-6-astra');assert.equal(store.status().persistence,'unavailable');await assert.rejects(store.update(role,{index:{selectedModel:'gpt-6-luna'}}),/revision regressed/);assert.equal(await readFile(file(root),'utf8'),older);
 await assert.rejects(store.update(role,{index:{selectedModel:'gpt-6-luna'},indexObservedUtc:'invalid'}),/observation time/);await assert.rejects(store.update(role,{index:{selectedModel:'gpt-6-luna'},indexObservedUtc:at(6000)}),/observation time/);assert.equal(await readFile(file(root),'utf8'),older);
}));

test('separate processes loaded before writes retain all roles with globally monotonic revisions',{timeout:15000},()=>fixture(async root=>{
 const childSource=`import {createNativeMetadataStore} from ${JSON.stringify(metadataURL)};const c=JSON.parse(process.argv[1]);let tick=0;const store=createNativeMetadataStore({root:c.root,projectId:c.projectId,now:()=>c.now+tick++});await store.get(c.binding);process.send({state:'ready'});await new Promise(r=>process.once('message',r));const revisions=[];for(const model of c.models){await store.update(c.binding,{index:{name:c.binding.id,selectedModel:model}});revisions.push(store.status().revision);}process.send({state:'done',revisions});process.disconnect();`;
 function worker(config){const child=spawn(process.execPath,['--input-type=module','-e',childSource,JSON.stringify(config)],{stdio:['ignore','pipe','pipe','ipc']});let stderr='',result,readyResolve,readyReject;const ready=new Promise((r,j)=>{readyResolve=r;readyReject=j;});child.stderr.on('data',d=>stderr+=d);child.on('message',m=>{if(m.state==='ready')readyResolve();else if(m.state==='done')result=m;});const done=new Promise((resolve,reject)=>{child.once('error',e=>{readyReject(e);reject(e);});child.once('exit',code=>{if(code!==0||!result){const e=Error(stderr||'Metadata worker did not finish');readyReject(e);reject(e);}else resolve(result);});});return{child,ready,done};}
 const workers=[worker({root,projectId,binding:binding(root),models:['gpt-6.1-sol','gpt-6-astra'],now:t0}),worker({root,projectId,binding:binding(root,'support','2'),models:['gpt-6.1-sol'],now:t0+10})];
 try{await Promise.all(workers.map(w=>w.ready));for(const w of workers)w.child.send('go');const results=await Promise.all(workers.map(w=>w.done)),saved=await read(root);assert.equal(saved.revision,3);assert.deepEqual(saved.agents.map(r=>r.roleId),['director','support']);assert.deepEqual(results.flatMap(r=>r.revisions).sort(),[1,2,3]);assert.equal(saved.agents[0].selectedModel.value,'gpt-6-astra');}
 finally{for(const w of workers)if(w.child.exitCode===null)w.child.kill();await Promise.allSettled(workers.map(w=>w.done));}
}));
