import test from 'node:test';import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,rm} from 'node:fs/promises';import os from 'node:os';import path from 'node:path';
import {readBoundNativeArchiveIndex} from '../lib/native-archive-index.mjs';
const id='10000000-0000-0000-0000-000000000001';
test('only exact registered native identity/cwd yields read-only positive archive evidence',async()=>{
 const {DatabaseSync}=await import('node:sqlite'),base=await mkdtemp(path.join(os.tmpdir(),'alife-index-')),home=path.join(base,'codex'),root=path.join(base,'project');await mkdir(home);await mkdir(root);
 const file=path.join(home,'state_5.sqlite'),db=new DatabaseSync(file);db.exec('CREATE TABLE threads(id TEXT PRIMARY KEY,cwd TEXT,archived INTEGER)');db.prepare('INSERT INTO threads VALUES(?,?,?)').run(id,root,1);db.close();const before=await readFile(file);
 try{const bindings=[{id:'qa',threadId:id,hostId:'local'}];let value=await readBoundNativeArchiveIndex({root,bindings,codexHome:home});assert.equal(value.get('qa').archived,true);assert.deepEqual(await readFile(file),before);
  value=await readBoundNativeArchiveIndex({root:path.join(base,'foreign'),bindings,codexHome:home});assert.equal(value.size,0);
  value=await readBoundNativeArchiveIndex({root,bindings:[{...bindings[0],threadId:'20000000-0000-0000-0000-000000000001'}],codexHome:home});assert.equal(value.size,0);
  value=await readBoundNativeArchiveIndex({root,bindings,codexHome:path.join(base,'missing')});assert.equal(value.size,0);
 }finally{assert(path.resolve(base).startsWith(path.resolve(os.tmpdir())+path.sep));await rm(base,{recursive:true,force:true});}
});
