import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

const source=await readFile(new URL('../web/agent-outpost/colony-art.js',import.meta.url),'utf8');
const manifest=JSON.parse(await readFile(new URL('../web/agent-outpost/assets/midnight-colony-reference-20261107/sprites.json',import.meta.url),'utf8'));
// These typed fixtures exercise the art API; actual browser decoding/font loading
// and pinned-byte verification belong to the host transport's acceptance.
class ImageFixture {
 constructor(){this.complete=true;this.naturalWidth=1536;this.naturalHeight=1024;}
 async decode(){}
}
class BitmapFixture {constructor(){this.width=1536;this.height=1024;}}
function load(extras={}){
 const context=vm.createContext({module:{exports:{}},URL,Image:ImageFixture,ImageBitmap:BitmapFixture,...extras});
 vm.runInContext(source,context);
 return context.module.exports;
}
function input(Kind=ImageFixture){return {manifest:structuredClone(manifest),images:Object.fromEntries(Object.keys(manifest.atlases).map(key=>[key,new Kind()])),fontReady:true};}
function canvas(){
 const images=[];
 const ctx=new Proxy({drawImage:(...args)=>images.push(args)},{get:(target,key)=>key in target?target[key]:(()=>{}),set:(target,key,value)=>{target[key]=value;return true;}});
 return {ctx,images};
}

for(const Kind of [ImageFixture,BitmapFixture])test(`injected ${Kind.name} renders all six actual growth frames without fetching`,async()=>{
 const api=load({fetch:()=>{throw Error('Injected art must not fetch');}}),value=input(Kind);
 const status=api.provideReferenceAssets(value);
 assert.equal(status.state,'ready');assert.equal(status.source,'injected');assert.equal(status.fontReady,true);
 const painter=api.create();assert.equal(await painter.ready,true);assert.equal(painter.loaded(),true);
 const {ctx,images}=canvas();
 for(const [i,percent] of [0,10,25,50,75,100].entries()){
  images.length=0;painter.paintTree(ctx,{season:'summer'},0,percent,123,280,1);
  assert.equal(images.length,1);assert.equal(images[0][0],value.images.trees);
  assert.deepEqual(images[0].slice(1,5),manifest.atlases.trees.frames[i].rect);
 }
 images.length=0;painter.paintTree(ctx,{season:'summer'},0,null,123,280,1);assert.equal(images.length,0);
});

test('injection snapshots manifest records and image mapping',async()=>{
 const api=load(),value=input(),treeImage=value.images.trees;
 api.provideReferenceAssets(value);
 value.manifest.atlases.trees.frames[0].rect.fill(0);value.manifest.atlases.trees.frames[0].id='complete';value.images.trees=new ImageFixture();
 const painter=api.create();await painter.ready;const {ctx,images}=canvas();painter.paintTree(ctx,{season:'summer'},0,0,123,280,1);
 assert.equal(images[0][0],treeImage);assert.deepEqual(images[0].slice(1,5),manifest.atlases.trees.frames[0].rect);
});

test('incomplete or invalid injection fails as one explicit fallback family',async()=>{
 const invalid=[
  value=>{value.fontReady=false;},
  value=>{value.extra=true;},
  value=>{value.images.extra=new ImageFixture();},
  value=>{delete value.images.pines;},
  value=>{delete value.images.props;},
  value=>{value.images.trees={complete:true,naturalWidth:1536,naturalHeight:1024};},
  value=>{value.images.scenery.complete=false;},
  value=>{value.images.pines.naturalWidth=1;},
  value=>{value.images.scenery=new BitmapFixture();value.images.scenery.height=0;},
  value=>{value.manifest.schemaVersion=2;},
  value=>{delete value.manifest.atlases.pines;},
  value=>{value.manifest.atlases.trees.file='../other.png';},
  value=>{value.manifest.atlases.trees.width=1024;},
  value=>{value.manifest.atlases.trees.frames[1].id='seed';},
  value=>{value.manifest.atlases.trees.frames[0].rect=[1530,0,20,10];},
  value=>{value.manifest.atlases.trees.frames[0].rect[0]=.5;},
  value=>{value.manifest.atlases.trees.frames[0].pivot=[234,0];},
  value=>{value.manifest.atlases.props.frames[0].id='unknown-house';}
 ];
 for(const corrupt of invalid){
  const api=load({fetch:()=>{throw Error('Invalid injection must not fetch');}}),value=input();corrupt(value);
  const status=api.provideReferenceAssets(value);assert.equal(status.state,'fallback');assert.equal(status.fontReady,false);assert.equal(typeof status.error,'string');
  const painter=api.create();assert.equal(await painter.ready,false);assert.equal(painter.loaded(),false);assert.equal(painter.artStatus().source,'injected');assert.equal(painter.artStatus().state,'fallback');
 }
});

test('assets can be corrected before mounting and cannot replace a mounted painter',async()=>{
 const api=load(),bad=input();bad.fontReady=false;
 assert.equal(api.provideReferenceAssets(bad).state,'fallback');assert.equal(api.provideReferenceAssets(input()).state,'ready');
 const painter=api.create();assert.equal(await painter.ready,true);
 assert.throws(()=>api.provideReferenceAssets(bad),/before creating/);assert.equal(painter.loaded(),true);
 const withoutInjection=load(),alreadyStarted=withoutInjection.create();assert.equal(await alreadyStarted.ready,false);
 assert.throws(()=>withoutInjection.provideReferenceAssets(input()),/before creating/);assert.equal(alreadyStarted.artStatus().source,'same-origin');
});

function sameOrigin({missing=null,badManifest=false,crossOrigin=false}={}){
 const requests=[];
 class NetworkImage extends ImageFixture {
  set src(value){const name=new URL(value).pathname.split('/').at(-1);requests.push(name);Promise.resolve().then(()=>name===missing?this.onerror():this.onload());}
 }
 const api=load({Image:NetworkImage,location:{origin:'https://world.invalid'},document:{baseURI:'https://world.invalid/',querySelectorAll:()=>[{href:`https://${crossOrigin?'other.invalid':'world.invalid'}/agent-outpost/agent-outpost.css`}]},fetch:async url=>{requests.push(new URL(url).pathname);return {ok:true,text:async()=>JSON.stringify(badManifest?{...manifest,schemaVersion:2}:manifest)};}});
 return {painter:api.create(),requests};
}
test('same-origin sites still load the complete selected family',async()=>{
 const {painter,requests}=sameOrigin();assert.equal(await painter.ready,true);assert.equal(painter.loaded(),true);assert.equal(painter.artStatus().source,'same-origin');
 assert.equal(requests.length,1+Object.keys(manifest.atlases).length);
 for(const atlas of Object.values(manifest.atlases))assert.ok(requests.includes(atlas.file));
});
test('same-origin loader reports fallback for missing, invalid or cross-origin assets',async()=>{
 for(const options of [{missing:'woodland-pines.png'},{missing:manifest.atlases.props.file},{badManifest:true},{crossOrigin:true}]){
  const {painter}=sameOrigin(options);assert.equal(await painter.ready,false);assert.equal(painter.loaded(),false);assert.equal(painter.artStatus().state,'fallback');assert.equal(typeof painter.artStatus().error,'string');
 }
});

test('launcher aliases carry exactly the same shared art, renderer and styling',async()=>{
 for(const [shared,alias] of [['agent-outpost.js','renderer.js'],['agent-outpost.css','renderer.css'],['colony-art.js','art.js']]){
  assert.deepEqual(await readFile(new URL('../web/agent-outpost/'+shared,import.meta.url)),await readFile(new URL('../web/launcher-world113/'+alias,import.meta.url)));
 }
});
