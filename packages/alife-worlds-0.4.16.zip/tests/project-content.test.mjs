// Authored fixture cases only. NOT RUN in the private staging authoring pass.
import test from 'node:test';
import assert from 'node:assert/strict';
import {PORTABLE_FORMAT,PORTABLE_MAX_BYTES,validatePortablePacket,portableClipboard,parsePortableImport,portablePacketHash,portablePacketFromCatalog,dataHash} from '../lib/portable-definitions.mjs';
import {planPortableImport,assertCurrentImportPlan,expectedRuleReadback,agentDefinitionHash} from '../lib/portable-import-plan.mjs';
import {applyProjectImport} from '../lib/project-content.mjs';
import {prepareDeleteRecovery,executeProjectDelete} from '../lib/project-delete.mjs';

const property=(id,text)=>({id,title:id,text});
const packet={format:PORTABLE_FORMAT,schemaVersion:1,kind:'world',title:'Neutral test world',world:{groups:[{id:'sound',title:'Sound',properties:[property('default','Start muted.')]}]}};
const destination=()=>({schemaVersion:1,projectId:'fixture-project',revision:'a'.repeat(64),rules:{world:{revision:2,groups:[{id:'floor',title:'Floor',properties:[property('color','Green'),property('perspective','Side view')]}]},plugin:{revision:3,groups:[]}},agents:[]});

test('Copy/Clone wire round trip preserves active definitions and excludes registry history',()=>{
 const copy=portableClipboard(packet);
 assert.deepEqual(parsePortableImport(copy),validatePortablePacket(packet));
 const catalog={scope:'world',groups:[{id:'floor',title:'Floor',properties:[{...property('color','Green'),active:true,history:[{text:'Earlier private work'}]},{...property('discarded','Old'),active:false}]}]};
 const exported=portablePacketFromCatalog('world','Neutral',catalog);
 assert.equal(exported.world.groups[0].properties.length,1);
 assert.equal(JSON.stringify(exported).includes('history'),false);
 assert.equal(portablePacketHash(exported),portablePacketHash(JSON.parse(JSON.stringify(exported))));
});

test('closed portable data rejects foreign authority, private endpoints and byte overflow',()=>{
 for(const field of ['threadId','projectRoot','settings','approvedByHuman','credentials','script'])assert.throws(()=>validatePortablePacket({...packet,[field]:'synthetic'}));
 assert.throws(()=>validatePortablePacket({...packet,world:{prompt:'Read https://example.invalid/?access_token=synthetic',groups:[]}}));
 assert.throws(()=>parsePortableImport('x'.repeat(PORTABLE_MAX_BYTES+1),{kind:'world'}));
 assert.throws(()=>validatePortablePacket(JSON.parse('{"format":"alife-portable","schemaVersion":1,"kind":"world","title":"x","world":{"prompt":"Safe","groups":[]},"__proto__":{}}')));
});

test('plain text remains review-required until explicit exact prompt interpretation',()=>{
 const p=parsePortableImport('Use a green floor.',{kind:'world'}),d=destination();
 const pending=planPortableImport(p,d,{requestId:'plain-request'});
 assert.equal(pending.ready,false);assert.equal(pending.changes.length,0);
 const reviewed=planPortableImport(p,d,{requestId:'plain-request',promptReviews:[{scope:'world',promptSha256:dataHash(p.world.prompt),groups:[{id:'decor',title:'Decor',properties:[property('accent','Green')]}]}]});
 assert.equal(reviewed.ready,true);assert.equal(reviewed.changes[0].scope,'world');
 assert.equal(dataHash(d),dataHash(destination()));
});

test('same-property correction preserves independent facets and needs an explicit choice',()=>{
 const p={...packet,world:{groups:[{id:'floor',title:'Floor',properties:[property('color','Blue')]}]}},d=destination();
 assert.equal(planPortableImport(p,d,{requestId:'color-request'}).ready,false);
 const chosen=planPortableImport(p,d,{requestId:'color-request',ruleChoices:[{scope:'world',groupId:'floor',propertyId:'color',action:'set'}]});
 const expected=expectedRuleReadback(chosen,d);
 assert.deepEqual(expected.world.groups[0].properties,[property('color','Blue'),property('perspective','Side view')]);
 assert.deepEqual(d,destination());
 assert.equal(chosen.changes.length,1);
});

test('plan cannot be reused after a destination revision or selected effect changes',()=>{
 const d=destination(),plan=planPortableImport(packet,d,{requestId:'versioned-request'});
 assert.equal(assertCurrentImportPlan(plan,d).sha256,plan.sha256);
 assert.throws(()=>assertCurrentImportPlan(plan,{...d,revision:'b'.repeat(64)}));
 assert.throws(()=>assertCurrentImportPlan({...plan,changes:[]},d));
});

test('agent import stages intake only after exact review and never creates a native identity',()=>{
 const role={id:'writer',title:'Writer',prompt:'Write concise project notes.',groups:[]},p={format:PORTABLE_FORMAT,schemaVersion:1,kind:'agent',title:'Writer',agents:[role]},d=destination();
 assert.equal(planPortableImport(p,d,{requestId:'agent-request'}).ready,false);
 const planned=planPortableImport(p,d,{requestId:'agent-request',agentChoices:[{id:'writer',action:'stage',definitionSha256:agentDefinitionHash(role)}]});
 assert.equal(planned.roleIntents[0].kind,'intake-required');
 assert.equal(planned.effectsPerformed,0);
 assert.equal(JSON.stringify(planned).includes('threadId'),false);
});

test('absent owning writer, exclusive fence or recovery adapter refuses before any effects',async()=>{
 // Deliberately unusable context: integration must be rejected before files/native state are accessed.
 await assert.rejects(applyProjectImport({},null,null),{code:'ALIFE_INTEGRATION_REQUIRED'});
 await assert.rejects(prepareDeleteRecovery({},{plan:null,evidenceRoot:null},null),{code:'ALIFE_INTEGRATION_REQUIRED'});
 await assert.rejects(executeProjectDelete({},{operationDirectory:null},null),{code:'ALIFE_INTEGRATION_REQUIRED'});
});


// This one integration fixture uses only synthetic sessions/approvals in an isolated
// child process. It proves source behavior, never actual native or human acceptance.
async function syntheticContentFixture(sourceRoot){
 const assert=(await import('node:assert/strict')).default;
 const fs=await import('node:fs/promises'),path=(await import('node:path')).default,os=await import('node:os'),{pathToFileURL}=await import('node:url'),{createHash}=await import('node:crypto');
 const box=await fs.mkdtemp(path.join(os.tmpdir(),'alife-content-synthetic-')),root=path.join(box,'project'),packetRoot=path.join(box,'packet'),evidence=path.join(box,'evidence');
 process.env.CODEX_HOME=path.join(box,'codex');
 const load=rel=>import(pathToFileURL(path.join(sourceRoot,rel)).href);
 const content=await load('lib/project-content.mjs'),contexts=await load('lib/project-content-context.mjs'),provider=await load('lib/project-content-host.mjs'),portable=await load('lib/portable-definitions.mjs'),planner=await load('lib/portable-import-plan.mjs'),operations=await load('lib/project-operations.mjs'),bootstrap=await load('lib/world-bootstrap.mjs'),deletion=await load('lib/project-delete.mjs');
 const projectId='11111111-1111-4111-8111-111111111111',supportId='22222222-2222-4222-8222-222222222222',importedId='33333333-3333-4333-8333-333333333333';
 const write=async(file,value)=>{await fs.mkdir(path.dirname(file),{recursive:true});await fs.writeFile(file,typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');};
 const read=async file=>JSON.parse(await fs.readFile(file,'utf8'));
 const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
 const p=(id,text)=>({id,title:id,text}),catalog=(scope,groups=[],revision=0)=>({schemaVersion:1,scope,revision,updatedAt:null,requests:[],groups:groups.map(g=>({...g,properties:g.properties.map(x=>({...x,active:true,implementation:'documented',origin:'human'}))}))});
 const supportHome='.alife-worlds/agents/support',full='Synthetic full support contract. '+'Long inherited fixture duty. '.repeat(16000),retirement='Synthetic retained retirement custody.',supportSession=path.join(process.env.CODEX_HOME,'sessions','2026','01','01','synthetic-'+supportId+'.jsonl'),importedSession=path.join(process.env.CODEX_HOME,'sessions',String(new Date().getUTCFullYear()),String(new Date().getUTCMonth()+1).padStart(2,'0'),String(new Date().getUTCDate()).padStart(2,'0'),'synthetic-'+importedId+'.jsonl');
 const session=(id)=>JSON.stringify({type:'session_meta',timestamp:'2026-01-01T00:00:02Z',payload:{id,cwd:root}})+'\n';
 const originalCwd=process.cwd();
 try{
  await fs.mkdir(root);await fs.mkdir(packetRoot);await fs.mkdir(evidence);
  const roles=[{id:'director',title:'Director'},{id:'support',title:'Agent Support'},{id:'world-requests',title:'World Requests'}];
  await write(path.join(process.env.CODEX_HOME,'alife-worlds/core-creation-profile.json'),{schemaVersion:1,approvedByHuman:true,model:'synthetic-model',thinking:'low'});await write(path.join(packetRoot,'docs/MASTER-PROMPT.md'),'Complete synthetic master duties; this fixture creates no real agent. '.repeat(1500));
  await write(path.join(packetRoot,'data/roles.json'),roles);await write(path.join(packetRoot,'roles/SHARED.md'),'Preserve current authority and custody.');
  for(const role of roles)await write(path.join(packetRoot,'roles',role.id+'.md'),'Perform the authored '+role.title+' duties.');
  const baseWorld=catalog('world',[{id:'floor',title:'Floor',properties:[p('color','Green'),p('perspective','Side view')]}],1);
  for(const scope of ['world','plugin','universal'])await write(path.join(packetRoot,'rules',scope+'.json'),scope==='world'?baseWorld:catalog(scope));
  await write(path.join(packetRoot,'rules/agents.json'),{schemaVersion:1,scope:'agents',agents:{}});
  await write(supportSession,session(supportId));await write(importedSession,session(importedId));
  await write(path.join(root,supportHome,'AGENT.md'),full);await write(path.join(root,supportHome,'RETIREMENT.md'),retirement);await write(path.join(root,supportHome,'checkpoint.json'),{fullInstructions:full,tasks:['synthetic-custody-task'],helpers:[],schedules:[],effects:{active:[],settled:[],unknown:[]},preservedFixtureHistory:'x'.repeat(1024*1024+128)});
  const ownReceipt={schemaVersion:1,roleId:'support',threadId:supportId,projectId,workspacePath:root,homePath:path.join(root,supportHome),contractsFullRead:true,accessVerified:true,retirementVersion:1,contractSha256:sha(full)};
  await write(path.join(root,supportHome,'receipt.json'),ownReceipt);
  const agents=roles.map(r=>({id:r.id,home:'.alife-worlds/agents/'+r.id,threadId:r.id==='support'?supportId:null,hostId:'local',sessionPath:r.id==='support'?supportSession:null}));
  await write(path.join(root,'.alife-worlds/agent-bindings.json'),{schemaVersion:1,projectId,projectRoot:root,agents});
  await write(path.join(root,'.alife-worlds/bootstrap.json'),{schemaVersion:1,projectId,projectRoot:root,roles:Object.fromEntries(agents.map(a=>[a.id,{...a,contractSha256:a.id==='support'?sha(full):'0'.repeat(64),creation:{reservedUtc:'2026-01-01T00:00:00Z'}}])),effects:[]});
  process.chdir(root);process.env.CODEX_THREAD_ID=supportId;
  const c=await contexts.resolveProjectContentContext(packetRoot,{threadId:supportId,sessionPath:supportSession}),query={packageRoot:packetRoot,projectRoot:root,projectId};
  const initial=await provider.resolveProjectContent(query);assert.equal(initial.status,'defaults');assert.equal(initial.definitions[0].id,'support');
  const core=await provider.readPortableDefinition({...query,roleId:'support'});assert.equal(core.packet.agents[0].id,'support');assert.equal(core.definitionSha256,portable.dataHash(core.packet.agents[0]));
  const authored={id:'writer',title:'Writer',prompt:'Write concise project notes.',groups:[]},definitionSha256=portable.dataHash(authored),packet={format:'alife-portable',schemaVersion:1,kind:'bundle',title:'Synthetic reviewed content',world:{groups:[{id:'floor',title:'Floor',properties:[p('color','Blue')]}]},agents:[authored]};
  const review={requestId:'synthetic-import-only',ruleChoices:[{scope:'world',groupId:'floor',propertyId:'color',action:'set'}],agentChoices:[{id:'writer',action:'stage',definitionSha256}]};
  const plan=await content.previewProjectImport(c,{content:packet,review},provider.integration);
  await assert.rejects(content.applyProjectImport(c,plan,provider.integration),e=>e.code==='ALIFE_HOST_ACTION_REQUIRED'&&e.operationEffect.effectsPerformed===0);
  // A synthetic direct-user record exercises the SHIPPED default verifier; there
  // is no real host question, human approval or native tool call in this test.
  const nativeEvent=async(payload)=>fs.appendFile(supportSession,JSON.stringify({timestamp:new Date().toISOString(),...payload})+'\n');
  await nativeEvent({type:'event_msg',payload:{type:'user_message',message:portable.portableClipboard(packet)}});
  const host=provider.integration,saved=await content.applyProjectImport(c,plan,host);assert.equal(saved.rulesSaved,true);
  const syntheticHold={requestId:'synthetic-hold',nonce:'synthetic-hold-nonce'};const adapters={readCleanupParticipants:async()=>syntheticHold,captureRecoveryMetadata:async()=>({schemaVersion:1,provider:'synthetic-only',rows:[],unsupported:[]}),prepareRecoveryMetadata:async()=>({state:'synthetic-only-unverified'})};
  const applied=await provider.resolveProjectContent(query);assert.equal(applied.rules.world.groups[0].properties[0].text,'Blue');assert.equal(applied.rules.world.groups[0].properties[1].text,'Side view');assert.deepEqual(await read(path.join(packetRoot,'rules/world.json')),baseWorld);
  const intake=await provider.prepareImportedIntake(c,{importOperationId:saved.operationId,roleId:'writer'});
  await provider.recordImportedIntake(c,{importOperationId:saved.operationId,roleId:'writer',sourceSha256:intake.sourceSha256,custody:{goal:'Synthetic fixture goal.',acceptance:['Synthetic only.'],tasks:['fixture'],permissions:[],pauses:[],helpers:[],schedules:[],effects:{active:[],settled:[],unknown:[]}}});
  const reserved=await content.reserveImportedAgent(c,{importOperationId:saved.operationId,roleId:'writer'},host);assert.equal(reserved.canCreate,true);assert.equal(reserved.nativeEffectsPerformed,0);
  const incoming=await fs.readFile(path.join(root,'.alife-worlds/imports/role-homes','import-'+definitionSha256.slice(0,20),'checkpoint.json'));assert.ok(incoming.length>1024*1024&&incoming.length<8*1024*1024);
  await assert.rejects(host.verifyNativeCreation(c,{operationId:reserved.operationId,nativeResult:{threadId:importedId}}),e=>e.code==='ALIFE_HOST_ACTION_REQUIRED');
  await write(importedSession,JSON.stringify({type:'session_meta',timestamp:new Date().toISOString(),payload:{id:importedId,cwd:root}})+'\n');
  const nativeCallId='call_synthetic_native_creation',exchange=reserved.hostRequest;
  await nativeEvent({type:'response_item',payload:{type:'custom_tool_call',name:'exec',call_id:nativeCallId,input:exchange.toolRequest.input}});
  await nativeEvent({type:'response_item',payload:{type:'custom_tool_call_output',call_id:nativeCallId,output:JSON.stringify({alifeHostRequest:{requestId:exchange.requestId,nonce:exchange.nonce},result:{threadId:importedId,hostId:'local',projectId,cwd:root}})}});
  const completed=await provider.readImportedNativeStatus(c,{operationId:reserved.operationId});assert.equal(completed.actualCompletedEvidence.callId,nativeCallId);
  await content.recordImportedAgent(c,{operationId:reserved.operationId,evidence:completed.actualCompletedEvidence},host);
  assert.equal((await provider.resolveProjectContent(query)).agents.some(a=>a.id.startsWith('import-')),false);
  const row=await read(path.join(root,'.alife-worlds/imports/agents',reserved.operationId+'.json'));
  process.env.CODEX_THREAD_ID=importedId;
  const importedContext=await contexts.resolveImportedReceiptContext(packetRoot,{threadId:importedId,sessionPath:importedSession},reserved.operationId);
  await content.acknowledgeImportedAgent(importedContext,{operationId:reserved.operationId,contractSha256:row.contractSha256,fullRead:true},host);
  const bound=await provider.resolveProjectContent(query),runtimeId='import-'+definitionSha256.slice(0,20);assert.equal(bound.agents.find(a=>a.id===runtimeId).threadId,importedId);
  const envelope=await provider.readPortableDefinition({...query,roleId:runtimeId});assert.deepEqual(Object.keys(envelope).sort(),['schemaVersion','projectId','roleId','definitionSha256','packet'].sort());assert.equal(envelope.roleId,runtimeId);assert.deepEqual(envelope.packet.agents,[authored]);assert.equal(envelope.definitionSha256,definitionSha256);assert.notEqual(authored.id,runtimeId);
  await assert.rejects(provider.readPortableDefinition({...query,roleId:'writer'}));
  process.env.CODEX_THREAD_ID=supportId;
  await bootstrap.acknowledgeRole(root,'support',{threadId:supportId,sessionPath:supportSession},{fullRead:true,contractSha256:sha(full)});
  assert.equal((await read(path.join(root,'.alife-worlds/agent-bindings.json'))).agents.filter(a=>a.id===runtimeId&&a.threadId===importedId).length,1);
  const current=await host.readDestination(c),reuse=planner.planPortableImport(envelope.packet,current,{requestId:'synthetic-reuse-only',agentChoices:[{id:'writer',action:'reuse',existingRoleId:runtimeId,definitionSha256}]});assert.equal(reuse.roleIntents[0].existingRoleId,runtimeId);
  await assert.rejects(host.readCleanupParticipants(c),e=>e.code==='ALIFE_HOST_ACTION_REQUIRED');
  await nativeEvent({type:'event_msg',payload:{type:'user_message',message:'/delete'}});
  const holdActor=await contexts.resolveProjectContentContext(packetRoot,{threadId:supportId,sessionPath:supportSession}),holdBase=path.join(box,'native-holds');await fs.mkdir(holdBase);
  const hold=await provider.prepareCleanupHold(holdActor,{evidenceRoot:holdBase});assert.equal(hold.requiresActualNativeMessagingAuthority,true);assert.equal(hold.nativeEffectsPerformed,0);assert.equal(hold.toolRequests.length,1);
  // No native message is sent. The synthetic original participant performs its
  // own context-bound receipt and the synthetic actual readback is recorded.
  process.env.CODEX_THREAD_ID=importedId;const participant=await contexts.resolveProjectContentContext(packetRoot,{threadId:importedId,sessionPath:importedSession});
  const ownHold=await provider.prepareOwnCleanupHold(participant,{holdDirectory:hold.holdDirectory});await provider.acknowledgeCleanupHold(participant,{holdDirectory:hold.holdDirectory,custodySha256:ownHold.custodySha256,fullRead:true});
  const heldRules=await load('lib/rules.mjs');await assert.rejects(heldRules.saveRuleChange(root,{}),{code:'ALIFE_PROJECT_CLEANUP_HOLD'});
  process.env.CODEX_THREAD_ID=supportId;
  const staleLifecycle=await provider.prepareCleanupReadback(holdActor,{holdDirectory:hold.holdDirectory}),staleCall='call_synthetic_stale_hold_readback';
  await fs.appendFile(importedSession,JSON.stringify({type:'event_msg',payload:{type:'task_started',turn_id:'synthetic-later-activity'}})+'\n');
  await nativeEvent({type:'response_item',payload:{type:'custom_tool_call',name:'exec',call_id:staleCall,input:staleLifecycle.hostRequest.toolRequest.input}});
  await nativeEvent({type:'response_item',payload:{type:'custom_tool_call_output',call_id:staleCall,output:JSON.stringify({alifeHostRequest:{requestId:staleLifecycle.hostRequest.requestId,nonce:staleLifecycle.hostRequest.nonce},result:[{id:importedId,kind:'codex',hostId:'local',cwd:root,status:{type:'idle',activeFlags:[]},turn:{id:'synthetic-held-turn',status:'completed',completedAt:Date.now()/1000}}]})}});
  await assert.rejects(provider.recordCleanupReadback(holdActor,{holdDirectory:hold.holdDirectory,requestId:staleLifecycle.hostRequest.requestId}),e=>e.code==='ALIFE_HOST_ACTION_REQUIRED'&&/native activity after this readback/.test(e.message));
  const lifecycle=await provider.prepareCleanupReadback(holdActor,{holdDirectory:hold.holdDirectory}),lifecycleCall='call_synthetic_hold_readback';
  await nativeEvent({type:'response_item',payload:{type:'custom_tool_call',name:'exec',call_id:lifecycleCall,input:lifecycle.hostRequest.toolRequest.input}});
  await nativeEvent({type:'response_item',payload:{type:'custom_tool_call_output',call_id:lifecycleCall,output:JSON.stringify({alifeHostRequest:{requestId:lifecycle.hostRequest.requestId,nonce:lifecycle.hostRequest.nonce},result:[{id:importedId,kind:'codex',hostId:'local',cwd:root,status:{type:'idle',activeFlags:[]},turn:{id:'synthetic-held-turn',status:'completed',completedAt:Date.now()/1000}}]})}});
  assert.equal((await provider.recordCleanupReadback(holdActor,{holdDirectory:hold.holdDirectory,requestId:lifecycle.hostRequest.requestId})).status,'all-original-native-participants-held-and-idle');
  const actualSyntheticHold=await host.readCleanupParticipants(holdActor);assert.equal(actualSyntheticHold.participants.length,1);adapters.readCleanupParticipants=async()=>actualSyntheticHold;
  const lease=await operations.acquireProjectOperation(root,'project-delete',{exclusive:true});
  try{for(const writer of deletion.REQUIRED_DELETE_WRITERS.filter(id=>id!=='selected-service-and-external-observers'))await assert.rejects(operations.withProjectOperation(root,writer,()=>assert.fail('exclusive admission bypassed')),{code:'ALIFE_PROJECT_BUSY'});
   const rules=await load('lib/rules.mjs'),planning=await load('lib/operator-planning.mjs');await assert.rejects(rules.saveRuleChange(root,{}),{code:'ALIFE_PROJECT_BUSY'});await assert.rejects(bootstrap.acknowledgeRole(root,'support',{}),{code:'ALIFE_PROJECT_BUSY'});await assert.rejects(planning.applyOwnerPlanIntent({root},{}),{code:'ALIFE_PROJECT_BUSY'});
  }finally{await operations.releaseProjectOperation(lease);}
  const cleanupHost=provider.createProjectContentHost(adapters),deletePlan=await deletion.createDeletePlan(c,cleanupHost);assert.deepEqual(deletePlan.blockers,[]);
  await assert.rejects(deletion.prepareDeleteRecovery(c,{plan:deletePlan,evidenceRoot:evidence},cleanupHost),e=>e.code==='ALIFE_INTEGRATION_REQUIRED'&&e.operationEffect.effectsPerformed===0);
  assert.deepEqual(await fs.readdir(evidence),[]);
  const partialHost=provider.createProjectContentHost({...adapters,verifyRecovery:async()=>{throw new contexts.IntegrationRequired('Synthetic metadata API failure after copy; never actual Windows proof.');},
   verifyCleanupQuiescence:async(context,arg)=>({state:'quiescent',nativeHolds:actualSyntheticHold,projectId,projectRoot:root,operationId:arg.operationId,planSha256:arg.planSha256}),
   inspectCleanupFence:async(context,{fence})=>({state:'exclusive',projectId,projectRoot:root,operationId:fence.operationId,planSha256:fence.planSha256,participants:deletion.REQUIRED_DELETE_WRITERS.map(id=>({id,state:'quiescent',receiptSha256:'f'.repeat(64)}))})
  });
  await assert.rejects(deletion.prepareDeleteRecovery(c,{plan:deletePlan,evidenceRoot:evidence},partialHost),e=>e.code==='ALIFE_INTEGRATION_REQUIRED'&&e.operationEffect.state==='partial-recovery'&&e.operationEffect.effectsPerformed==='unknown'&&e.operationEffect.removed===0);
  const retained=await read(path.join(evidence,'delete-'+deletePlan.sha256.slice(0,32),'journal.json'));assert.equal(retained.status,'stopped-reconcile-original-operation');assert.deepEqual(retained.removed,[]);assert.equal((await read(path.join(root,'.alife-worlds/agent-bindings.json'))).agents.length,4);
  // Concrete async reply envelope, actual normalized question-call name, and
  // resolved-without-answer behavior live in this same focused fixture.
  const consentBase=path.join(box,'consent');await fs.mkdir(consentBase);const consentFolder=path.join(consentBase,'delete-'+deletePlan.sha256.slice(0,32));await fs.mkdir(consentFolder);
  const consentRow={schemaVersion:1,kind:'delete-operation',operationId:'delete-'+deletePlan.sha256.slice(0,32),projectId,projectRoot:root,actorThreadId:supportId,planSha256:deletePlan.sha256,nativeHold:deletePlan.nativeCleanupHold,status:'recovery-ready-awaiting-exact-human-confirmation',recoveryReadyAt:new Date(Date.now()-1000).toISOString(),recoveryProof:{receiptSha256:'e'.repeat(64)},confirmationNonce:'synthetic-question-nonce',removed:[]};
  const confirmation=provider.deleteConfirmationRequest(c,deletePlan,consentRow,consentFolder);consentRow.confirmationRequest=confirmation;
  await write(path.join(consentFolder,'plan.json'),deletePlan);await write(path.join(consentFolder,'journal.json'),consentRow);await nativeEvent({type:'event_msg',payload:{type:'user_message',message:'/delete'}});
  const questionCall='call_synthetic_question';await nativeEvent({type:'response_item',payload:{type:'function_call',name:'request_user_input_async',call_id:questionCall,arguments:JSON.stringify(confirmation.toolRequest.arguments)}});
  await nativeEvent({type:'response_item',payload:{type:'function_call_output',call_id:questionCall,output:JSON.stringify({serverRequest:'resolved'})}});
  await assert.rejects(provider.recordDeleteConfirmation(c,{operationDirectory:consentFolder}),e=>e.code==='ALIFE_HOST_ACTION_REQUIRED');
  const questionReply=answer=>'<send_user_message_question_reply> '+JSON.stringify([{questionItemId:JSON.stringify(['request_user_input_async',questionCall,0]),question:confirmation.toolRequest.arguments.questions[0].title,answer}])+' </send_user_message_question_reply>';
  await nativeEvent({type:'event_msg',payload:{type:'user_message',message:questionReply('Confirm')}});
  assert.equal((await provider.recordDeleteConfirmation(c,{operationDirectory:consentFolder})).status,'exact-human-confirmation-recorded');
  const actualConsent=await read(path.join(consentFolder,'confirmation.json'));assert.equal(actualConsent.question.callId,questionCall);assert.equal(actualConsent.decision.format,'structured-native-question-reply');
  const verifiedConsent=await host.verifyDeleteConfirmation(c,{operationId:consentRow.operationId,planSha256:deletePlan.sha256,recoveryReceiptSha256:consentRow.recoveryProof.receiptSha256,operationDirectory:consentFolder});assert.equal(verifiedConsent.scope,'clear-exact-folder-contents');
  await nativeEvent({type:'event_msg',payload:{type:'user_message',message:questionReply('Keep contents')}});
  assert.equal((await provider.recordDeleteConfirmation(c,{operationDirectory:consentFolder})).status,'human-declined-no-removal');
  await assert.rejects(host.verifyDeleteConfirmation(c,{operationId:consentRow.operationId,planSha256:deletePlan.sha256,recoveryReceiptSha256:consentRow.recoveryProof.receiptSha256,operationDirectory:consentFolder}));
  const released=await provider.releaseCleanupHold(packetRoot,{threadId:supportId,sessionPath:supportSession},{holdDirectory:hold.holdDirectory,operationDirectory:consentFolder});assert.equal(released.status,'original-cleanup-hold-released');assert.equal(released.nativeEffectsPerformed,0);
  await nativeEvent({type:'event_msg',payload:{type:'user_message',message:'/pause'}});
  await assert.rejects(provider.prepareImportedIntake(c,{importOperationId:saved.operationId,roleId:'writer'}),/later actual human hold/);
  await assert.rejects(provider.prepareCleanupHold(holdActor,{evidenceRoot:holdBase}),/later actual human hold/);
  // The WR producer must retain original ownership and omit all references to a
  // task whose canonical owner is absent from this partial/core roster.
  const {publicWorldSnapshot}=await load('lib/public-world.mjs'),{assertPublicWorldSnapshot}=await load('lib/public-world-contract.mjs'),now=new Date().toISOString();
  const partial={model:{agents:[{roleId:'support',role:'support',threadId:supportId,connected:true,onboarded:true,paused:false}],tasks:[{id:'hidden-private-task',title:'PRIVATE HIDDEN TITLE',ownerRoleId:'writer',ownerIds:[importedId],stage:'Ready',state:'progress',milestone:{steps:[],delivered:false}},{id:'shown-task',title:'PRIVATE SHOWN TITLE',ownerRoleId:'support',ownerIds:[supportId],stage:'Ready',state:'progress',milestone:{steps:[],delivered:false}}],cfg:{paused:false,cards:{},antGardenSprint:{id:'fixture',taskIds:['hidden-private-task','shown-task']}},presentation:{id:'fixture',taskIds:['hidden-private-task','shown-task']}},feed:{observedUtc:now,items:[{id:supportId,taskIds:['hidden-private-task','shown-task']}],agentHealth:[]}};
  const sanitized=publicWorldSnapshot(partial,[{id:'support',title:'Agent Support',role:'support'},{id:'writer',title:'PRIVATE HIDDEN ROLE',role:'worker'}],{worldId:'synthetic-public'});assertPublicWorldSnapshot(sanitized,{expectedWorldId:'synthetic-public'});assert.equal(sanitized.model.tasks.length,1);assert.equal(JSON.stringify(sanitized).includes('PRIVATE'),false);assert.equal(JSON.stringify(sanitized).includes('hidden-private-task'),false);assert.equal(sanitized.feed.farmFacts.commands.transportEnabled,false);
  const upgraded=structuredClone(baseWorld);upgraded.revision++;upgraded.groups[0].properties[1].text='Front view';await write(path.join(packetRoot,'rules/world.json'),upgraded);
  const compatible=await provider.resolveProjectContent(query);assert.equal(compatible.status,'overrides');assert.equal(compatible.rules.world.groups[0].properties[0].text,'Blue');assert.equal(compatible.rules.world.groups[0].properties[1].text,'Front view');assert.notEqual(compatible.revision,applied.revision);
  upgraded.revision++;upgraded.groups[0].properties[0].text='Red';await write(path.join(packetRoot,'rules/world.json'),upgraded);
  const conflicted=await provider.resolveProjectContent(query);assert.equal(conflicted.status,'reconciliation-required');assert.equal(conflicted.rules,null);assert.equal(conflicted.revision,null);
  console.log('Synthetic source fixture passed; no real native calls, imports, removal or human acceptance.');
 }finally{process.chdir(originalCwd);const resolved=path.resolve(box);if(path.dirname(resolved)!==path.resolve(os.tmpdir())||!path.basename(resolved).startsWith('alife-content-synthetic-'))throw Error('Synthetic cleanup target escaped its owned temporary folder.');await fs.rm(resolved,{recursive:true,force:true});}
}

test('synthetic overlay, original binding/export, exclusive fence and partial recovery retain their boundaries',async()=>{
 const {spawnSync}=await import('node:child_process'),{fileURLToPath}=await import('node:url');
 const sourceRoot=fileURLToPath(new URL('../',import.meta.url));
 const result=spawnSync(process.execPath,['--input-type=module','-e','await ('+syntheticContentFixture.toString()+')('+JSON.stringify(sourceRoot)+');'],{encoding:'utf8',timeout:60000});
 assert.equal(result.status,0,String(result.stderr||result.error||result.stdout));
});
