import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

const source=await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8');
// Exercise the production timer and paint entry together, without mounting a
// browser or replacing the world's navigation/status projection.
const start=source.indexOf('function travelWaitIntent('),end=source.indexOf('\n function wallpaperState(',start);
assert(start>=0&&end>start,'production travel-wait functions are present');
const active=source.match(/function active\(s\)\{[^\r\n]+/)[0];
function fixture(){
 const s={key:'qa',status:'Working',working:true,sleeping:false,blocker:'',needsHumanInput:false};
 const a={walking:false,hasTravelled:true,stationarySeconds:0,roadWait:false,work:{mode:'supplies',pose:{leg:'out'}}};
 const calls=[],p={x:60,y:60},context={agentMotion:new Map([[s.key,a]]),antDrag:null,inside:false,antInsideRoom:()=>context.inside,workPose:()=>a.work?.pose,paused:false,media:{matches:false},document:{hidden:false},layout:{bodyRadius:10},line(){},ctx:new Proxy({fillRect:(...args)=>calls.push(args)},{get:(target,key)=>key in target?target[key]:(()=>{}),set:(target,key,value)=>{target[key]=value;return true;}})};
 vm.createContext(context);vm.runInContext(active+'\n'+source.slice(start,end),context);
 return {s,a,p,calls,context,update:dt=>context.updateTravelWait(a,s,p,dt),paint:()=>context.drawTravelWait(s,p)};
}

test('idle after prior travel clears the false barricade and rejects a retained flag immediately',()=>{
 const f=fixture();f.s.status='Idle';f.s.working=false;f.a.work=null;f.a.roadWait=true;f.a.stationarySeconds=5;
 f.paint();assert.equal(f.calls.length,0);
 f.update(1.5);assert.equal(f.a.roadWait,false);assert.equal(f.a.stationarySeconds,0);assert.equal(f.s.blocker,'');
});
test('an actual active travel hold keeps its threshold and clears when movement resumes',()=>{
 const f=fixture();f.update(1.39);f.paint();assert.equal(f.calls.length,0);assert.equal(f.a.roadWait,false);
 f.update(.02);f.paint();assert.equal(f.a.roadWait,true);assert.equal(f.calls.length,1);
 f.a.walking=true;f.update(.1);assert.equal(f.a.roadWait,false);assert.equal(f.a.stationarySeconds,0);assert.equal(f.a.hasTravelled,true);
});
test('no-intent and stationary work phases never produce a travel barricade',()=>{
 for(const leg of [null,'local','console','dispatch','pick','water','inspect','defend','dispose','tidy']){
  const f=fixture();f.a.work=leg?{mode:'local',pose:{leg}}:null;f.a.roadWait=true;f.a.stationarySeconds=5;
  f.paint();assert.equal(f.calls.length,0,leg);f.update(1.5);assert.equal(f.a.roadWait,false,leg);assert.equal(f.a.stationarySeconds,0,leg);
 }
});
test('unfinished routes and verified work travel retain their hold cue, completed routes clear it',()=>{
 for(const kind of ['relocation','returning']){
  const f=fixture();f.a.work=null;f.a[kind]=kind==='relocation'?{elapsed:1,seconds:2}:{elapsed:1,duration:2};
  f.update(1.5);assert.equal(f.a.roadWait,true,kind);f.paint();assert.equal(f.calls.length,1);
  f.a[kind].elapsed=2;f.update(.1);assert.equal(f.a.roadWait,false,kind);
 }
 for(const leg of ['out','back','dock']){const f=fixture();f.a.work.pose.leg=leg;f.update(1.5);assert.equal(f.a.roadWait,true,leg);}
 const rescue=fixture();rescue.a.work={mode:'rescue',arriving:false,pose:{leg:'rescue'}};rescue.update(1.5);assert.equal(rescue.a.roadWait,true);rescue.a.work.arriving=true;rescue.update(.1);assert.equal(rescue.a.roadWait,false);
 const repair=fixture();repair.s.working=false;repair.s.repairActive=true;repair.update(1.5);assert.equal(repair.a.roadWait,true);
});
test('intentional rest, attention and inactive states suppress retained travel markers without changing blockers',()=>{
 const changes=[f=>{f.context.inside=true;},f=>{f.context.antDrag={key:'qa'};},f=>{f.s.needsHumanInput=true;},f=>{f.s.sleeping=true;},f=>{f.s.status='Retirement Needed';},...['Idle','Sleeping','Waiting','Failure','Paused','Unconfirmed','Activity unavailable','Blocked'].map(status=>f=>{f.s.status=status;f.s.working=false;})];
 for(const change of changes){const f=fixture();f.s.blocker='preserved genuine blocker';f.a.roadWait=true;f.a.stationarySeconds=5;change(f);f.paint();assert.equal(f.calls.length,0);f.update(1.5);assert.equal(f.a.roadWait,false);assert.equal(f.s.blocker,'preserved genuine blocker');}
});
test('launcher and shared renderer stay byte-identical',async()=>{
 assert.equal(source,await readFile(new URL('../web/launcher-world113/renderer.js',import.meta.url),'utf8'));
});
