import test from 'node:test';
import assert from 'node:assert/strict';
import {createSiteBundleContract,SITE_BUNDLE_LIMIT} from '../lib/site-sync-bundle.mjs';
import {createOwnerRuleLibrary} from '../lib/owner-rule-library.mjs';
import {portableClipboard,parsePortableImport} from '../lib/portable-definitions.mjs';
import {createSiteBundleProducer} from '../lib/site-sync-producer.mjs';
import {configuration,siteBundleFixture,projectId,project,worldId,renderer,ownerOrigin} from './site-sync-fixture.mjs';

test('one actual source observation produces owner workspace5, world3 and catalog without native identity or new work time',async()=>{
 const f=await siteBundleFixture(),b=f.bundle;assert.ok(b.workspace.agents.length>3);assert.equal(b.workspace.schemaVersion,5);assert.equal(b.ownerPreview.schemaVersion,3);
 assert.equal(b.observedUtc,f.dashboard.feed.observedUtc);assert.equal(b.workspace.observedUtc,b.observedUtc);assert.equal(b.ownerPreview.snapshot.observedUtc,b.observedUtc);assert.equal(b.workspace.planningObservedUtc,f.plan.observedUtc);
 const before=JSON.stringify({dashboard:f.dashboard,plan:f.plan,catalog:f.catalog});const retry=await f.producer.produce({revision:2,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog});
 assert.deepEqual(retry.workspace.agents.map(a=>a.observedUtc),b.workspace.agents.map(a=>a.observedUtc));assert.equal(JSON.stringify({dashboard:f.dashboard,plan:f.plan,catalog:f.catalog}),before);
 assert.equal(JSON.stringify(b).includes(projectId),false);assert.equal(b.catalog.worlds[1].connection.target,null);
});

test('same-state bundle carries only explicit canonical QA requirements and still reads older owner5 details',async()=>{
 const f=await siteBundleFixture(),before=JSON.stringify(f.dashboard),task=f.plan.tasks[0];Object.assign(task,{qaRequired:true,qaRequirements:'Check the selected result with the agreed fixture'});
 const next=await f.producer.produce({revision:2,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog}),c=createSiteBundleContract(configuration);await c.assertBundle(next);
 assert.equal(next.workspace.tasks[0].details.qaRequired,true);assert.equal(next.workspace.tasks[0].details.qaRequirements,task.qaRequirements);assert.deepEqual(next.workspace.agents,f.bundle.workspace.agents);assert.equal(next.observedUtc,f.bundle.observedUtc);assert.equal(JSON.stringify(f.dashboard),before);
 const legacy=structuredClone(next);for(const row of legacy.workspace.tasks){delete row.details.qaRequired;delete row.details.qaRequirements;}await c.assertBundle(legacy);assert.equal(c.workspaceResponse(legacy,new Date().toISOString()).snapshot,legacy.workspace);
 const unsafe=structuredClone(next);unsafe.workspace.tasks[0].details.qaRequirements='api_key=private-value';await assert.rejects(c.assertBundle(unsafe));
});
test('same-read supplied owner preview is reused and a mixed-world or mixed-clock component is refused',async()=>{
 const f=await siteBundleFixture();f.dashboard.ownerPreview=f.bundle.ownerPreview;
 const next=await f.producer.produce({revision:2,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog});assert.equal(next.ownerPreview,f.dashboard.ownerPreview);
 const c=createSiteBundleContract(configuration);for(const mutate of [b=>b.project='project-'+'f'.repeat(24),b=>b.worldId='world-foreign',b=>b.workspace.observedUtc=new Date(Date.parse(b.observedUtc)-1).toISOString(),b=>b.ownerPreview.worldId='world-foreign',b=>b.ownerPreview.renderer.artifactSha256='f'.repeat(64),b=>b.workspace.agents.pop()]){const b=structuredClone(f.bundle);mutate(b);await assert.rejects(c.assertBundle(b));}
});
test('an explicit unavailable selected scene cannot fall back to a synthesized default preview',async()=>{
 const f=await siteBundleFixture();
 for(const ownerPreview of [null,undefined])await assert.rejects(f.producer.produce({revision:2,dashboard:{...f.dashboard,ownerPreview},plan:f.plan,catalog:f.catalog}),/no qualified owner preview/);
});

test('bundle closes private fields and rejects unconfigured roles, catalog native IDs and path leaks',async()=>{
 const f=await siteBundleFixture(),c=createSiteBundleContract(configuration);for(const mutate of [b=>b.prompt='private',b=>b.workspace.tasks[0].toolArguments={},b=>b.ownerPreview.names[0].name='C:\\private\\source',b=>b.catalog.worlds[0].name=projectId,b=>b.catalog.worlds[0].connection.target={kind:'owner-private',url:'https://foreign.example/'},b=>b.workspace.agents[0].alias='role-unconfigured']){const b=structuredClone(f.bundle);mutate(b);await assert.rejects(c.assertBundle(b));}
 const roles=Array.from({length:100},(_,i)=>({id:'custom-'+i,title:'Role '+i,role:'worker'}));assert.doesNotThrow(()=>createSiteBundleContract({...configuration,roles}));assert.throws(()=>createSiteBundleContract({...configuration,roles:[...roles,{id:'overflow',title:'Overflow',role:'worker'}]}));
});
test('source producer cannot mix another raw selected project or replace missing real plan/metadata',async()=>{
 const f=await siteBundleFixture();await assert.rejects(f.producer.produce({revision:2,dashboard:{...f.dashboard,project:{id:'foreign'}},plan:f.plan,catalog:f.catalog}));
 await assert.rejects(f.producer.produce({revision:2,dashboard:f.dashboard,catalog:f.catalog}));
 delete f.dashboard.model.nativeMetadata;await assert.rejects(f.producer.produce({revision:2,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog}),/persisted owner metadata required/);
 assert.throws(()=>createSiteBundleProducer({project,projectId:'foreign',worldId,registry:[],renderer,ownerOrigin,oracle:globalThis.AgentOutpost}));
});

test('same-state effective Rules preserve exact human/AI exports and omit history/inactive properties',async()=>{
 const f=await siteBundleFixture(),before=f.bundle;assert(before.ruleLibrary);assert.equal(JSON.stringify(before.ruleLibrary).includes('HISTORICAL_FIXTURE_ONLY'),false);assert.equal(JSON.stringify(before.ruleLibrary).includes('INACTIVE_FIXTURE_ONLY'),false);
 const scope=f.dashboard.ruleCatalog.world;scope.revision++;Object.assign(scope.groups[0].properties[0],{title:'Actual project override',description:'Current human description.',text:'Follow this exact current AI instruction.'});
 const state=JSON.stringify(f.dashboard),next=await f.producer.produce({revision:2,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog}),packet=next.ruleLibrary.scopes.find(row=>row.scope==='world').packet,property=packet.world.groups[0].properties[0];assert.equal(property.title,'Actual project override');assert.equal(property.description,'Current human description.');assert.equal(property.text,'Follow this exact current AI instruction.');assert.deepEqual(parsePortableImport(portableClipboard(packet)),packet);assert.equal(next.observedUtc,before.observedUtc);assert.deepEqual(next.agentMetadata,before.agentMetadata);assert.equal(JSON.stringify(f.dashboard),state);
});

test('absent, unsafe or whole-bundle overbudget Rules become null without blocking valid same-state agents',async()=>{
 const f=await siteBundleFixture(),args={revision:2,plan:f.plan,catalog:f.catalog};
 for(const catalog of [null,undefined,{...f.dashboard.ruleCatalog,world:{...f.dashboard.ruleCatalog.world,scope:'foreign'}}]){const b=await f.producer.produce({...args,dashboard:{...f.dashboard,ruleCatalog:catalog}});assert.equal(b.ruleLibrary,null);assert.deepEqual(b.agentMetadata,f.bundle.agentMetadata);assert.equal(b.observedUtc,f.bundle.observedUtc);}
 const unsafe=structuredClone(f.dashboard.ruleCatalog);unsafe.world.groups[0].properties[0].text='Read C:\\Users\\private\\credential.json';assert.equal((await f.producer.produce({...args,dashboard:{...f.dashboard,ruleCatalog:unsafe}})).ruleLibrary,null);
 const base={...f.bundle,ruleLibrary:null},target=SITE_BUNDLE_LIMIT-Buffer.byteLength(JSON.stringify(base))+8192,large=structuredClone(f.dashboard.ruleCatalog);large.plugin.groups[0].properties=Array.from({length:Math.ceil(target/11000)},(_,i)=>({id:'rule-'+i,title:'Bounded rule '+i,description:'A bounded human label.',text:'x'.repeat(11000),active:true}));const library=createOwnerRuleLibrary(large,{worldId});assert(Buffer.byteLength(JSON.stringify(library))<SITE_BUNDLE_LIMIT);assert(Buffer.byteLength(JSON.stringify({...base,ruleLibrary:library}))>SITE_BUNDLE_LIMIT);const limited=await f.producer.produce({...args,dashboard:{...f.dashboard,ruleCatalog:large}});assert.equal(limited.ruleLibrary,null);assert(Buffer.byteLength(JSON.stringify(limited))<=SITE_BUNDLE_LIMIT);assert.deepEqual(limited.workspace,f.bundle.workspace);
});

test('closed Rules facet rejects foreign/private fields while exact legacy missing-only-Rules remains readable',async()=>{
 const f=await siteBundleFixture(),c=createSiteBundleContract(configuration);for(const mutate of [b=>b.ruleLibrary.worldId='world-foreign',b=>b.ruleLibrary.extra='private',b=>b.ruleLibrary.scopes[0].packet.plugin.groups[0].properties[0].history=[],b=>b.ruleLibrary=undefined,b=>b.extra='unsupported']){const b=structuredClone(f.bundle);mutate(b);await assert.rejects(c.assertBundle(b));}
 const legacy=structuredClone(f.bundle);delete legacy.ruleLibrary;await c.assertBundle(legacy);assert.equal(c.ruleLibraryResponse(legacy,new Date().toISOString()),null);await c.assertBundle({...f.bundle,ruleLibrary:null});
});
