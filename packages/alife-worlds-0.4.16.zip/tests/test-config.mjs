import {writeFile} from 'node:fs/promises';
import path from 'node:path';
export async function writeTestConfig(directory){
 const file=path.join(directory,'test-config.json');
 await writeFile(file,JSON.stringify({projectName:'Isolated test',mode:'demo',port:0,pollMs:5000,stateFile:'state.json',commandsEnabled:false,commandAdapter:null,nativeReadOnly:false}));
 return file;
}
