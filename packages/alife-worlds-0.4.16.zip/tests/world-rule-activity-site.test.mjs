import test from 'node:test';
import assert from 'node:assert/strict';
import {createProjection} from '../lib/projection.mjs';
import {dashboardProgress} from '../web/dashboard-model.mjs';
import {publicWorldSnapshot} from '../lib/public-world.mjs';
import {assertPublicWorldSnapshot} from '../lib/public-world-contract.mjs';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import '../web/agent-outpost/agent-outpost.js';
const api=globalThis.AgentOutpost;
const registry=[{id:'director',title:'Director',role:'director',responsibility:'Coordinate'}];

test('View deletes operational diagnostics without evaluating their builder and restores them only in permitted modes',()=>{
 const canvas={dataset:{state:'PRIVATE OPERATIONAL VALUE'}},host={dataset:{piperAnalyticsState:'current',transitCount:'2',sprint:'private-sprint',fitScale:'1'}};let builds=0;
 const build=()=>{builds++;return{state:{sprint:{percent:75}},piperAnalyticsState:'current',transitCount:2,sprint:'exact-sprint'};};
 api.applySceneDiagnostics(canvas,host,'view',build);assert.equal(builds,0);assert.equal(canvas.dataset.state,undefined);for(const k of ['piperAnalyticsState','transitCount','sprint'])assert.equal(host.dataset[k],undefined);assert.equal(host.dataset.fitScale,'1');
 api.applySceneDiagnostics(canvas,host,'public',build);assert.equal(builds,1);assert.equal(JSON.parse(canvas.dataset.state).sprint.percent,75);assert.equal(host.dataset.transitCount,'2');api.applySceneDiagnostics(canvas,host,'view',build);assert.equal(canvas.dataset.state,undefined);assert.equal(builds,1);
});

test('the actual mode transition clears prior diagnostic, inspector and tooltip data even before a hidden scene draws',async()=>{
 const source=await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8'),start=source.indexOf('setPresentationMode(mode){'),end=source.indexOf(',setWorldVisible(',start);assert(start>=0&&end>start);
 let cleared=0;const image=()=>({width:10,height:20,hidden:false,getContext:()=>({clearRect(){cleared++;}})}),detail={replaceChildren(){this.empty=true;}},traffic={replaceChildren(){this.empty=true;}};
 const x={presentationMode:'public',privateMode:false,host:{dataset:{transitCount:'2',sprint:'Private sprint'}},options:{},canvas:{style:{},dataset:{state:'Private progress'}},applySceneDiagnostics:api.applySceneDiagnostics,roomLens:{hidden:false},roomLensKey:'room',lensInfo:{textContent:'Private model/blocker'},lensTitle:{textContent:'Private role'},lensCanvas:image(),magnifierOn:true,magnifierCanvas:image(),treeTip:{dataset:{label:'Private sprint',progress:'75%'},setAttribute(k,v){this[k]=v;}},detail,traffic,applyPrivacy(){},snapshot:null,operational:()=>x.presentationMode!=='view'};
 const controller=vm.runInNewContext('({'+source.slice(start,end)+'})',x);controller.setPresentationMode('view');assert.equal(x.canvas.dataset.state,undefined);assert.equal(x.host.dataset.sprint,undefined);assert.equal(x.host.dataset.transitCount,undefined);assert.equal(x.lensInfo.textContent,'');assert.equal(x.lensTitle.textContent,'');assert.equal(x.treeTip.dataset.progress,'');assert.equal(x.treeTip['aria-label'],'');assert.equal(x.roomLensKey,'');assert.equal(x.roomLens.hidden,true);assert.equal(x.magnifierOn,false);assert.equal(cleared,2);assert.equal(detail.empty,true);assert.equal(traffic.empty,true);
 x.operational=()=>false;for(const mode of ['public','private']){x.canvas.dataset.state='Old operation';x.host.dataset.sprint='Private sprint';x.lensInfo.textContent='Old blocker';assert.doesNotThrow(()=>controller.setPresentationMode(mode));assert.equal(x.canvas.dataset.state,undefined);assert.equal(x.host.dataset.sprint,undefined);assert.equal(x.lensInfo.textContent,'');}assert.equal(cleared,6);
});

test('actual world status uses fresh canonical accepted progress and never borrows legacy weighted renderer percentages',async()=>{
 const source=await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8'),start=source.indexOf('function applyPrivacy(){'),end=source.indexOf('// Reuse the exact controls',start);assert(start>=0&&end>start);
 const node=()=>({dataset:{},setAttribute(){},getAttribute:()=> 'World artwork'}),status={textContent:''},x={worldInfo:{},privacyBar:{},presentationMode:'public',antKey:null,roster:node(),canvas:node(),document:{documentElement:node(),title:'World'},options:{},privateMode:false,publicDocumentTitle:'World',privacyButton:node(),host:node(),snapshot:{stations:[],sprint:{title:'OLD WEIGHTED SPRINT',percent:99}},canonicalProgress:{sprint:{title:'Exact canonical sprint',percent:40,tasks:5,accepted:2}},feed:{observedUtc:new Date().toISOString()},treeProgressPresentation:api.treeProgressPresentation,renderModelKey(){},status,roomNameButtons:new Map(),qaAccessibility(){}};
 vm.runInNewContext(source.slice(start,end),x);x.applyPrivacy();assert.match(status.textContent,/Exact canonical sprint/);assert.match(status.textContent,/40% accepted work/);assert.doesNotMatch(status.textContent,/OLD WEIGHTED|99%/);
 x.feed.observedUtc=new Date(Date.now()-180000).toISOString();x.applyPrivacy();assert.match(status.textContent,/Progress unavailable/);assert.doesNotMatch(status.textContent,/40%|99%/);
 x.feed.observedUtc=new Date().toISOString();x.canonicalProgress=null;x.applyPrivacy();assert.match(status.textContent,/Current sprint/);assert.match(status.textContent,/Progress unavailable/);assert.doesNotMatch(status.textContent,/OLD WEIGHTED|99%/);
});
function fixture(){
 const observedUtc=new Date().toISOString();
 return {observedUtc,agents:[{roleId:'director',instanceId:'actual-actor',connected:true,activityState:'working',observedUtc}],tasks:[],sprint:{id:'sprint',title:'Selected sprint',taskIds:[]}};
}
const task=()=>({id:'work',title:'Real work',ownerRoleId:'director',sprintId:'sprint',stage:'Done',accepted:false,steps:[{id:'step',title:'Step',complete:true,evidence:'Implementation result'}]});
async function station(input){const state=await createProjection(registry,input);return {state,row:api.project(state.model,state.feed).stations[0]};}

test('Done without canonical acceptance cannot complete a sprint, Epic, public summary or tree',async()=>{
 const input=fixture();input.tasks=[task()];input.sprint.taskIds=['work'];input.roadmap={epic:{id:'epic'},sprints:[{id:'sprint',status:'complete',taskIds:['work']}]};
 for(const acceptance of [{accepted:false,acceptanceEvidence:'An assertion is not acceptance'},{accepted:true,acceptanceEvidence:'  '}]){
  Object.assign(input.tasks[0],acceptance);const before=JSON.stringify(input),{model,feed,...rest}=await createProjection(registry,input),p=dashboardProgress(model);
  assert.equal(p.sprint.percent,0);assert.equal(p.sprint.accepted,0);assert.equal(p.epic.percent,0);assert.equal(model.roadmap.sprints[0].status,'planned');
  const dto=publicWorldSnapshot({model,feed,...rest},registry);assertPublicWorldSnapshot(dto);assert.equal(dto.summary.current.percent,0);assert.equal(dto.summary.epic.percent,0);
  assert.equal(api.treeProgressPresentation(p,feed).percent,0);assert.equal(JSON.stringify(input),before);
 }
 Object.assign(input.tasks[0],{accepted:true,acceptanceEvidence:'Human accepted the actual outcome'});
 const state=await createProjection(registry,input),p=dashboardProgress(state.model);assert.equal(p.sprint.percent,100);assert.equal(p.epic.percent,100);assert.equal(api.treeProgressPresentation(p,state.feed).percent,100);
});

test('required amendment stage is separate from explicit evidenced acceptance and deduplicates by its original ID',async()=>{
 const input=fixture();input.roadmap={epic:{id:'epic'},amendment:{id:'amendment',status:'Done'},sprints:[{id:'sprint',status:'complete',taskIds:[],requiredAmendmentRefs:['roadmap.amendment','roadmap.amendment']}]};
 for(const acceptance of [{},{accepted:false,acceptanceEvidence:'Recorded'},{accepted:true,acceptanceEvidence:''}]){
  Object.assign(input.roadmap.amendment,acceptance);const {model}=await createProjection(registry,input),p=dashboardProgress(model);assert.equal(p.sprint.tasks,1);assert.equal(p.sprint.accepted,0);assert.equal(p.sprint.percent,0);assert.equal(model.roadmap.sprints[0].status,'planned');
 }
 Object.assign(input.roadmap.amendment,{accepted:true,acceptanceEvidence:'Actual amendment accepted'});const {model}=await createProjection(registry,input);assert.equal(dashboardProgress(model).sprint.percent,100);assert.equal(model.roadmap.sprints[0].status,'complete');
});

test('native work needs no task; ordinary idle/waiting with queued work rests and stale evidence never becomes busy or dead',async()=>{
 const input=fixture();assert.equal((await station(input)).row.working,true);
 input.tasks=[{...task(),stage:'Ready'}];input.sprint.taskIds=['work'];input.agents[0].taskIds=['work'];
 for(const activityState of ['idle','waiting']){input.agents[0].activityState=activityState;const {row}=await station(input);assert.equal(row.sleeping,true);assert.equal(row.working,false);assert.equal(row.status,'Sleeping');}
 input.agents[0].activityState='working';input.agents[0].observedUtc=new Date(Date.now()-180000).toISOString();
 const before=JSON.stringify(input),{row}=await station(input);assert.equal(row.working,false);assert.equal(row.sleeping,false);assert.equal(!!row.alert,false);assert.equal(row.status,'Activity unavailable');assert.equal(JSON.stringify(input),before);
});

test('task dependencies remain informational while genuine retirement incidents take precedence over ordinary rest',async()=>{
 const input=fixture();input.agents[0].activityState='idle';input.tasks=[{...task(),stage:'In Progress',blocker:'Unresolved dependency',condition:'blocked'}];input.sprint.taskIds=['work'];input.agents[0].taskIds=['work'];
 const blocked=await station(input);assert.equal(blocked.row.status,'Sleeping');assert.equal(blocked.row.sleeping,true);assert.equal(blocked.row.taskBlocker,'Unresolved dependency');assert.equal(blocked.row.blocker,'');assert.equal(api.recordedFire(blocked.row),false);
 input.agents[0].retirementAlert={state:'retirement-needed',reason:'Recorded lifecycle incident',reportId:'incident',observedUtc:input.observedUtc};const retired=await station(input);assert.equal(retired.row.status,'Retirement Needed');assert.equal(api.recordedFire(retired.row),false);
 input.agents[0].retirementAlert.state='resolved';const restored=await station(input);assert.equal(restored.row.status,'Sleeping');assert.equal(restored.row.taskBlocker,'Unresolved dependency');input.tasks[0].blocker='';input.tasks[0].condition='waiting';const resolved=await station(input);assert.equal(resolved.row.status,'Sleeping');assert.equal(resolved.row.taskBlocker,'');
});

test('public attention carries the generic exact-role flag and original timestamp without request content or native identity',async()=>{
 const input=fixture();Object.assign(input.agents[0],{activityState:'waiting',needsHumanInput:true,requestText:'PRIVATE REQUEST',prompt:'PRIVATE PROMPT'});const state=await createProjection(registry,input),dto=publicWorldSnapshot(state,registry);assertPublicWorldSnapshot(dto);
 assert.equal(dto.feed.agentHealth[0].needsHumanInput,true);assert.equal(dto.feed.agentHealth[0].activityObservedUtc,input.agents[0].observedUtc);assert.equal(api.project(dto.model,dto.feed).stations[0].needsHumanInput,true);
 for(const secret of ['PRIVATE REQUEST','PRIVATE PROMPT','actual-actor'])assert.equal(JSON.stringify(dto).includes(secret),false);
 assert.equal(api.humanInputAttention(dto.feed.agentHealth[0],true),false);assert.equal(api.humanInputAttention({...dto.feed.agentHealth[0],activityState:'working'}),false);assert.equal(api.humanInputAttention({...dto.feed.agentHealth[0],needsHumanInput:false}),false);
 assert.equal(api.humanInputAttention(dto.feed.agentHealth[0],false,Date.now()+180000,dto.feed.observedUtc),false);
 input.agents[0].activityState='working';assert.equal((await station(input)).row.needsHumanInput,false);
});

test('contextual Wake, Unblock and Retire keep exact unavailable reasons and disappear from View access models',()=>{
 const now=Date.now(),model={cfg:{}},feed={observedUtc:new Date(now).toISOString()},access=api.operatorDisplayPermissions('public',false,false);
 for(const row of [{status:'Sleeping',sleeping:true},{status:'Blocked',blocker:'Dependency',task:{id:'work'}},{status:'Retirement Needed'}]){
  row.agent={threadId:'actor'};const unavailable=api.farmCommandPresentation(row,model,feed,access,now);assert.equal(unavailable.unavailable,true);assert.equal(unavailable.reason,'Current command availability has not been verified.');
  for(const cosmetic of [false,true])assert.equal(api.farmCommandPresentation(row,model,feed,api.operatorDisplayPermissions('view',cosmetic,true),now),null);
  const eligibility={wake:true,retire:true,unblockTaskIds:['work'],episodes:{wake:'w',retire:'r',unblock:{work:'u'}}};
  const commands={...feed,farmFacts:{commands:{state:'current',observedUtc:feed.observedUtc,transportEnabled:false,agents:{actor:eligibility}}}};
  assert.equal(api.farmCommandPresentation(row,model,commands,access,now).reason,'The native command connection is unavailable.');
  const ownerReadOnly=api.farmCommandPresentation(row,model,commands,api.operatorDisplayPermissions('public',true,true),now);assert.equal(ownerReadOnly.unavailable,true);assert.match(ownerReadOnly.reason,/read-only/);
 }
});
