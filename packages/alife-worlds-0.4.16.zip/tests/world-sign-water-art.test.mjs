import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const root=new URL('../',import.meta.url),read=p=>readFileSync(new URL(p,root),'utf8');
const renderer=read('web/agent-outpost/agent-outpost.js'),art=read('web/agent-outpost/colony-art.js'),css=read('web/agent-outpost/agent-outpost.css');
const context=vm.createContext({});vm.runInContext(art,context);const a=renderer.indexOf('const groundRefinement='),b=renderer.indexOf('\n})();',a)+6;vm.runInContext(renderer.slice(a,b)+';globalThis.ground=groundRefinement;',context);const ground=context.ground;

test('compact sign keeps independent canonical Epic and Sprint values and View concealment',()=>{
 const value=ground.woodSignModel({badge:'actual',percent:55,epicPercent:42},'private');assert.equal(value.rows[0].value,'42%');assert.equal(value.rows[1].value,'55%');assert.equal(ground.woodSignModel({badge:'actual',percent:100,epicPercent:0},'public').rows[0].value,'0%');
 assert.equal(ground.woodSignModel({badge:'actual',percent:NaN,epicPercent:null},'private').rows[0].value,'Unavailable');assert.equal(ground.woodSignModel({badge:'actual',percent:100,epicPercent:100},'view').visible,false);
 for(const fit of [.2,.5,1]){const g=ground.woodSignGeometry({x:192,y:298,scale:1},1600,fit,0);assert.equal(g.height,48);assert.equal(g.width,68);assert.ok(g.left>=2&&g.left+g.width<=1600*fit-2);}
 const group=css.match(/\.outpost \.ag-progress-sign-group\{([^}]+)\}/)[1];assert.match(group,/flex-direction:row/);assert.match(css,/\.outpost \.ag-progress-sign\{[^}]*flex-direction:column/);
});

function pool(time,environment){const calls=[],state={globalAlpha:1},stack=[];const g=new Proxy(state,{get(o,key){if(key==='save')return()=>stack.push({...o});if(key==='restore')return()=>{const previous=stack.pop();for(const key of Object.keys(o))delete o[key];Object.assign(o,previous);};if(key in o)return o[key];return(...args)=>calls.push([key,...args]);},set(o,key,value){o[key]=value;return true;}});context.AlifeColonyArt.create().paintPool(g,{x:100,y:60,rx:55,ry:25},time,environment);return calls;}
test('real water material animates with visual time, freezes with reduced motion and retains shoreline clip',()=>{
 const env={season:'summer',light:1,day:true,reducedMotion:false};const first=pool(0,env),later=pool(8,env);assert.notDeepEqual(first,later);assert.deepEqual(pool(0,{...env,reducedMotion:true}),pool(8,{...env,reducedMotion:true}));
 assert.deepEqual(pool(0,{...env,season:'winter'}),pool(8,{...env,season:'winter'}));assert.ok(first.some(row=>row[0]==='clip'));assert.equal(first.filter(row=>row[0]==='moveTo').length,later.filter(row=>row[0]==='moveTo').length);
});

test('production renderer, CSS and actual launcher art entry remain exact aliases',()=>{
 assert.equal(renderer,read('web/launcher-world113/renderer.js'));assert.equal(css,read('web/launcher-world113/renderer.css'));assert.equal(art,read('web/launcher-world113/art.js'));
});
