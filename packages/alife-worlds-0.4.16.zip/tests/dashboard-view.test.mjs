import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,mkdir,mkdtemp,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {writeTestConfig} from './test-config.mjs';
import {dashboardProgress,countProgress,recentHandoffs,siteTaskStatus,siteActivityStatus} from '../web/dashboard-model.mjs';
import {createApp} from '../server.mjs';
import {createProjection,loadRegistry} from '../lib/projection.mjs';
import '../web/agent-outpost/agent-outpost.js';
const credits=countProgress;
const task=(id,done)=>({id,title:id,stage:done?'Done':'In Progress',milestone:{delivered:done,steps:[{id:'step',title:'Step',complete:done}]}});
const model=()=>({tasks:[task('current',false),task('later',true)],cfg:{cards:{current:{visualSize:2},later:{visualSize:2}}},presentation:{id:'current',title:'Current sprint',taskIds:['current']},roadmap:{epic:{title:'Epic'},sprints:[{id:'current',title:'Current sprint',taskIds:['current']},{id:'later',title:'Later sprint',taskIds:['later']}]},agents:[{threadId:'one',title:'Director'},{threadId:'two',title:'World Requests'}]});
test('visible sprint/epic meters share whole-task/sprint counts and keep their scope separate',()=>{
 const m=model(),before=JSON.stringify(m),p=dashboardProgress(m,credits);assert.equal(p.sprint.percent,0);assert.equal(p.sprint.tasks,1);assert.equal(p.epic.percent,50);assert.equal(p.epic.tasks,2);assert.equal(p.epic.accepted,1);assert.equal(JSON.stringify(m),before);
 m.tasks[0].stage='Done';m.tasks[0].milestone.delivered=true;m.tasks[0].milestone.steps[0].complete=true;assert.equal(dashboardProgress(m,credits).epic.percent,100);
});
test('empty planning scope stays unknown rather than showing completion',()=>{
 const m=model();m.tasks=[];m.presentation.taskIds=[];const p=dashboardProgress(m,credits);assert.equal(p.sprint.percent,null);assert.equal(p.epic.percent,null);assert.equal(p.epic.complete,false);
});
test('handoff list uses only recorded known-address events with original timestamps and stable IDs',()=>{
 const m=model(),old='2026-11-05T20:00:00.000Z',newer='2026-11-05T21:00:00.000Z',feed={motionEvents:[{id:'a',fromThreadId:'one',toThreadId:'two',observedUtc:old,kind:'message'},{id:'b',fromThreadId:'two',toThreadId:'one',observedUtc:newer,kind:'handoff'},{id:'b',fromThreadId:'two',toThreadId:'one',observedUtc:newer},{id:'foreign',fromThreadId:'foreign',toThreadId:'one',observedUtc:newer},{id:'invalid',fromThreadId:'one',toThreadId:'two',observedUtc:'invalid'}]};
 const p=recentHandoffs(m,feed);assert.deepEqual(p.map(e=>e.id),['b','a']);assert.equal(p[0].from,'World Requests');assert.equal(p[0].kind,'Handoff');assert.equal(p[0].observedUtc,newer);assert.equal(recentHandoffs(m,feed,1).length,1);assert.deepEqual(recentHandoffs(m,{motionEvents:[]}),[]);
});
test('dashboard markup places the world before board, work, responsibilities and folded progress plan',async()=>{
 const html=await readFile(new URL('../web/index.html',import.meta.url),'utf8'),app=await readFile(new URL('../web/app.mjs',import.meta.url),'utf8');
 const ids=['world-anchor','task-board','active-work','role-index','epic-plan'].map(id=>html.indexOf('id="'+id+'"'));assert.ok(ids.every((n,i)=>n>=0&&(i===0||n>ids[i-1])));assert.ok(app.includes("mount($('world-anchor')"));assert.ok(html.includes('<details id="recovery-roadmap">'));assert.ok(html.indexOf('id="sprint-progress"')<html.indexOf('id="roadmap-content"'));assert.ok(html.includes('id="epic-progress"'));assert.ok(html.includes('src="/boot.js"'));assert.ok(html.includes('id="handoff-list"'));
});
test('local server serves the dashboard helper through the fixed public asset allowlist',async()=>{
 const scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));await mkdir(scratch,{recursive:true});const dir=await mkdtemp(path.join(scratch,'view-test-'));const app=await createApp({configFile:await writeTestConfig(dir)});
 try{const url=await app.listen(0),r=await fetch(url+'/dashboard-model.mjs');assert.equal(r.status,200);assert.ok((await r.text()).includes('export function dashboardProgress'));assert.equal((await fetch(url+'/tests/test-config.mjs')).status,404);}finally{await new Promise(resolve=>app.server.close(resolve));assert.ok(path.resolve(dir).startsWith(path.resolve(scratch)+path.sep));await rm(dir,{recursive:true,force:true});}
});

test('recorded handoff type survives safe projection without inventing an event timestamp',async()=>{
 const registry=await loadRegistry(),input={observedUtc:new Date().toISOString(),agents:[],tasks:[],events:[{id:'recorded-handoff',fromRoleId:'director',toRoleId:'world-requests',kind:'handoff',observedUtc:'2026-11-05T20:00:00.000Z',body:'PRIVATE-MESSAGE'}]};
 const s=await createProjection(registry,input),events=recentHandoffs(s.model,s.feed);assert.equal(events.length,1);assert.equal(events[0].kind,'Handoff');assert.equal(events[0].observedUtc,input.events[0].observedUtc);assert.ok(!JSON.stringify(s).includes('PRIVATE-MESSAGE'));delete input.events[0].observedUtc;await assert.rejects(createProjection(registry,input));
});

test('site palette keeps evidence-backed acceptance, blockers and unstarted stages distinct',()=>{
 assert.equal(siteTaskStatus({stage:'Done'}),'unknown');assert.equal(siteTaskStatus({stage:'Done',milestone:{delivered:true}}),'accepted');assert.equal(siteTaskStatus({stage:'Done',milestone:{delivered:true},blocker:'New unresolved issue'}),'blocked');for(const stage of ['Backlog','Shaping','Ready'])assert.equal(siteTaskStatus({stage}),'backlog');for(const stage of ['In Progress','QA','In Review'])assert.equal(siteTaskStatus({stage}),'progress');assert.equal(siteTaskStatus(null),'unknown');
});
test('site idle tint requires fresh or terminal observed idle and never freshens its input',()=>{
 const now=Date.now(),feed={observedUtc:new Date(now).toISOString()},agent={connected:true},h={activityState:'idle',activityObservedUtc:new Date(now).toISOString()},before=JSON.stringify(h);assert.equal(siteActivityStatus(agent,h,feed,now),'idle');assert.equal(JSON.stringify(h),before);assert.equal(siteActivityStatus(agent,{...h,activityState:'working'},feed,now),'progress');assert.equal(siteActivityStatus(agent,{...h,activityObservedUtc:new Date(now-180000).toISOString()},feed,now),'unknown');assert.equal(siteActivityStatus(agent,{...h,activityObservedUtc:new Date(now-180000).toISOString(),terminal:true},feed,now),'idle');assert.equal(siteActivityStatus(agent,h,{...feed,error:'Unavailable'},now),'unknown');assert.equal(siteActivityStatus({connected:false},h,feed,now),'unknown');
});
test('site palette is grouped in plugin scope with separate exports and visible text labels',async()=>{
 const plugin=JSON.parse(await readFile(new URL('../rules/plugin.json',import.meta.url),'utf8')),worldPrompt=await readFile(new URL('../world/WORLD_PROMPT.md',import.meta.url),'utf8'),html=await readFile(new URL('../web/index.html',import.meta.url),'utf8'),css=await readFile(new URL('../web/dashboard.css',import.meta.url),'utf8');const group=plugin.groups.find(g=>g.id==='site-presentation');const ids=group.properties.filter(p=>p.active).map(p=>p.id);for(const expected of ['progress','backlog','blocked','idle','accepted','semantics','sprint-task-cards','four-section-layout','agent-cards','observed-activity','private-toolbar'])assert.ok(ids.includes(expected));assert.equal(new Set(ids).size,ids.length);assert.ok(!worldPrompt.includes('Site Presentation & Status Palette'));for(const [key,value] of Object.entries({progress:'#8dd5ab',backlog:'#a4c8ff',blocked:'#ef6b73',idle:'#d1b9fa',accepted:'#b7e4c7'})){assert.ok(css.includes('--site-'+key+':'+value));assert.ok(html.includes('data-site-status="'+key+'"'));}assert.ok(html.includes('Reference status palette'));
});
