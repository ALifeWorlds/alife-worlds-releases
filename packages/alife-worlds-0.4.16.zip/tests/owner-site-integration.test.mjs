import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,mkdir,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createApp} from '../server.mjs';
import {publicWorldId} from '../lib/public-world.mjs';
import {createOwnerWorkspaceContract} from '../lib/owner-workspace-contract.mjs';
const source=fileURLToPath(new URL('../',import.meta.url));
test('configured local entrypoint serves reusable dashboard and real owner5 data under existing host guards',async()=>{
 const scratch=path.join(source,'runtime/test-fixtures');await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'owner-site-'));
 const configFile=path.join(root,'config.json');await writeFile(configFile,JSON.stringify({mode:'demo',projectId:'OWNER-FIXTURE',projectName:'Fixture world',commandsEnabled:false}));
 const profile=path.join(root,'profile.json');await writeFile(profile,JSON.stringify({schemaVersion:1,worlds:[]}));
 const app=await createApp({configFile,worldProjectsProfilePath:profile,journalPath:path.join(root,'journal.json')}),url=await app.listen(0),worldId=publicWorldId('OWNER-FIXTURE');
 try{
  const page=await fetch(url),html=await page.text();assert.equal(page.status,200);assert.ok(html.includes('id="alife-world-first"'));assert.ok(html.includes('id="wf-world"'));assert.ok(html.includes('id="wf-work"'));assert.ok(html.includes('Created by Itzel Juarez'));assert.ok(!/https?:\/\/[^"'<> ]+\.chatgpt\.site/.test(html));
  const frame=new URL('/operator',url);for(const [k,v]of Object.entries({embed:'1',worldViewport:'1',hostOrigin:url,worldId}))frame.searchParams.set(k,v);
  const child=await fetch(frame);assert.equal(child.status,200);assert.ok(child.headers.get('content-security-policy').includes("frame-ancestors 'self'"));
  assert.equal((await fetch(url+'/operator?project=foreign')).status,404);
  const data=await(await fetch(url+'/api/workspace')).json(),roles=app.registry.map(({id,title,role})=>({id,title,role:role||id}));
  createOwnerWorkspaceContract({worldId,roles}).assertWorkspaceResponse(data,{audience:'owner'});assert.equal(data.snapshot.schemaVersion,5);assert.equal(data.snapshot.sprints.length,0);
  const dashboard=await(await fetch(url+'/api/dashboard')).json();assert.equal(dashboard.ownerPreview,null);assert.equal(dashboard.feed.farmFacts.commands.transportEnabled,false);
  const js=await fetch(url+'/workspace.js'),code=await js.text();assert.equal(js.status,200);assert.match(js.headers.get('content-type'),/javascript/);assert.ok(code.includes('createProjectWorldGallery'));assert.ok(code.includes('layoutProjectWorlds'));
  const viewport=await fetch(url+'/owner-operator-viewport.mjs');assert.equal(viewport.status,200);assert.match(await viewport.text(),/function createOwnerPreviewJoin/);
  const viewportCSS=await fetch(url+'/owner-world-viewport.css');assert.equal(viewportCSS.status,200);assert.match(viewportCSS.headers.get('content-type'),/text\/css/);
  assert.equal((await fetch(url+'/api/workspace?project=world-foreign')).status,404);
  assert.equal((await fetch(url+'/api/workspace',{headers:{Origin:'https://foreign.invalid'}})).status,403);
  assert.equal((await fetch(url+'/api/workspace',{method:'POST'})).status,405);
  assert.equal((await fetch(url+'/api/qa-goals')).status,503);
  for(const denied of ['/antfarm.config.json','/lib/owner-workspace-projection.mjs','/runtime/private.json'])assert.equal((await fetch(url+denied)).status,404);
 }finally{app.server.closeAllConnections();await new Promise(resolve=>app.server.close(resolve));assert.ok(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));await rm(root,{recursive:true,force:true});}
});
