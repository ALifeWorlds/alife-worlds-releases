import {createHash} from 'node:crypto';
import {createProjection} from '../lib/projection.mjs';
import {createDemo} from '../lib/demo.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {publicWorldSnapshot} from '../lib/public-world.mjs';
import {createLocalAppearance} from '../lib/local-world-appearance.mjs';
import '../web/launcher-world113/renderer.js';
export async function candidateFixture({now,revision=1,renderer}){
 const worldId='world-candidate-fixture',state=await createProjection(registry,createDemo(registry,'working'));
 state.feed.observedUtc=new Date(now).toISOString();for(const agent of state.model.agents){agent.model=null;agent.modelSpeed=null;agent.reasoningEffort=null;}
 const snapshot=publicWorldSnapshot(state,registry,{worldId});
 const appearance=createLocalAppearance(state,registry,snapshot,renderer,{oracle:globalThis.AgentOutpost,digestJSON:text=>createHash('sha256').update(text).digest('hex'),now});
 const names=snapshot.model.agents.map(agent=>({id:agent.threadId,name:'Fixture agent',source:'registry-fallback',observedUtc:null,state:'unknown'}));
 const agents=names.map(agent=>({id:agent.id,modelState:'unknown',modelSource:null,modelObservedUtc:null,selectedState:'unknown',selectedSource:null,selectedObservedUtc:null,presentationSource:'unknown',appliedToken:null}));
 return{schemaVersion:3,kind:'owner-world-preview',worldId,renderer,snapshot,appearance,names,metadata:{revision,contentHash:'b'.repeat(64),agents}};
}
