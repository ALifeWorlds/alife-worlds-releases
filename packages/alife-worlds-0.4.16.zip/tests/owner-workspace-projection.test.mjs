import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createProjection} from '../lib/projection.mjs';
import {createDemo} from '../lib/demo.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {createWorkspaceProjector} from '../lib/owner-workspace-projection.mjs';
import {createOwnerWorkspaceContract} from '../lib/owner-workspace-contract.mjs';
import {dashboardProgress} from '../web/dashboard-model.mjs';
import {publicWorldSnapshot} from '../lib/public-world.mjs';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const projectId='fixture-project',worldId='world-'+createHash('sha256').update(projectId).digest('hex').slice(0,14),roles=registry.map(({id,title,role})=>({id,title,role}));
test('owner5 projection and response preserve actual scope, safe details and original planning/work times',async()=>{
 const plan=createDemo(registry,'working'),planningTime=new Date(Date.now()-60000).toISOString();plan.observedUtc=planningTime;
 plan.roadmap={epic:{id:'fixture-epic',title:'Fixture epic',goal:'Exercise the portable contract'},sprints:[{id:plan.sprint.id,title:plan.sprint.title,taskIds:plan.tasks.map(t=>t.id)}]};
 plan.tasks[0].current='Recorded fixture task';plan.tasks[0].next='Retain the original time';plan.tasks[0].updatedUtc=planningTime;plan.tasks[0].qaRequired=true;plan.tasks[0].qaRequirements='Verify the actual output with a fresh fixture.';
 const state=await createProjection(registry,plan);state.project.id=projectId;state.feed.observedUtc=new Date().toISOString();
 const workTime=new Date(Date.now()-2000).toISOString();state.model.agents[0].progressUpdate={id:'activity-'+'a'.repeat(14),headline:'Checking a fixture',detail:null,source:'agent-progress',recordedUtc:workTime};
 const contract=createOwnerWorkspaceContract({worldId,roles}),projector=createWorkspaceProjector({worldId,projectId,roles,contract}),before=JSON.stringify({plan,state});
 const pair=projector.projectWorkspace({dashboard:state,plan});const response=contract.workspaceEnvelope(pair.owner,new Date().toISOString());
 assert.equal(contract.assertWorkspaceResponse(response,{audience:'owner'}),response);assert.equal(pair.owner.schemaVersion,5);
 assert.equal(pair.owner.worldId,worldId);assert.equal(pair.owner.planningObservedUtc,planningTime);assert.equal(pair.owner.tasks[0].details.sourceUpdatedUtc,planningTime);assert.equal(pair.owner.agents[0].progressUpdate.recordedUtc,workTime);
 assert.equal(pair.owner.tasks[0].details.qaRequired,true);assert.equal(pair.owner.tasks[0].details.qaRequirements,plan.tasks[0].qaRequirements);assert.equal(pair.owner.tasks[1].details.qaRequired,null);assert.equal(pair.owner.tasks[1].details.qaRequirements,null);
 assert.equal(JSON.stringify({plan,state}),before);assert.equal(pair.public.agents[0].progressUpdate,undefined);assert.equal(pair.public.tasks[0].details,undefined);
 assert.throws(()=>contract.assertWorkspaceSnapshot(pair.owner,{audience:'public'}));
 assert.throws(()=>projector.projectWorkspace({dashboard:{...state,project:{...state.project,id:'foreign'}},plan}));
 const withoutRoadmap={...plan};delete withoutRoadmap.roadmap;const emptyRoadmap=projector.projectWorkspace({dashboard:state,plan:withoutRoadmap}).owner;
 assert.equal(emptyRoadmap.sprints.length,0);assert.equal(emptyRoadmap.currentSprintId,null);assert.equal(emptyRoadmap.epic.progress.complete,false);
 const customRoles=[...roles,{id:'curator',title:'Confidential registry label',role:'worker'}],customState=structuredClone(state);
 customState.model.agents.push({...customState.model.agents[0],roleId:'curator',threadId:'fixture-extra',title:'Private fixture name',progressUpdate:null});
 const customContract=createOwnerWorkspaceContract({worldId,roles:customRoles}),custom=createWorkspaceProjector({worldId,projectId,roles:customRoles,contract:customContract}).projectWorkspace({dashboard:customState,plan});
 assert.equal(custom.owner.agents.at(-1).name,'Private fixture name');assert.equal(custom.public.agents.at(-1).name,'ALife Agent');assert.equal(custom.public.agents.at(-1).alias,'role-curator');
 assert.ok(!JSON.stringify(custom.public).includes('Confidential registry label'));assert.ok(!JSON.stringify(custom.public).includes('Private fixture name'));
});

test('workspace, dashboard, sanitized summary and tree require the same evidenced whole-member acceptance',async()=>{
 const contract=createOwnerWorkspaceContract({worldId,roles}),projector=createWorkspaceProjector({worldId,projectId,roles,contract});
 for(const accepted of [false,true]){
  const plan={observedUtc:new Date().toISOString(),agents:[],tasks:[{id:'real-task',title:'Private goal',ownerRoleId:'director',sprintId:'selected',stage:'Done',accepted,acceptanceEvidence:accepted?'Actual accepted outcome':null,progressPercent:100,steps:[{id:'step',title:'Implementation',complete:true,evidence:'Technical evidence'}]}],sprint:{id:'selected',title:'Selected',taskIds:['real-task']},roadmap:{epic:{id:'epic',title:'Private epic'},amendment:{id:'amendment',status:'Done',accepted,acceptanceEvidence:accepted?'Actual amendment acceptance':null},sprints:[{id:'selected',title:'Selected',status:'complete',taskIds:['real-task'],requiredAmendmentRefs:['roadmap.amendment']}]}};
  const before=JSON.stringify(plan),dashboard=await createProjection(registry,plan);dashboard.project.id=projectId;
  const canonical=dashboardProgress(dashboard.model),dto=publicWorldSnapshot(dashboard,registry,{worldId}),pair=projector.projectWorkspace({dashboard,plan});
  for(const surface of [pair.owner,pair.public]){
   contract.assertWorkspaceSnapshot(surface,{audience:surface===pair.owner?'owner':'public'});
   assert.equal(surface.tasks.length,2);assert(surface.tasks.every(t=>t.stage==='Done'));assert(surface.tasks.every(t=>t.done===accepted));assert(surface.tasks.every(t=>accepted?t.progress.percent===100:t.progress.percent<100));
   assert.equal(surface.sprints[0].progress.total,2);assert.equal(surface.sprints[0].progress.completed,accepted?2:0);assert.equal(surface.sprints[0].progress.percent,canonical.sprint.percent);assert.equal(surface.epic.progress.percent,canonical.epic.percent);
  }
  assert.equal(dto.summary.current.percent,canonical.sprint.percent);assert.equal(dto.summary.epic.percent,canonical.epic.percent);assert.equal(globalThis.AgentOutpost.treeProgressPresentation(canonical,dashboard.feed).percent,canonical.sprint.percent);assert.equal(canonical.sprint.percent,accepted?100:0);assert.equal(JSON.stringify(plan),before);assert(!JSON.stringify(pair.public).includes('Private goal'));
 }
});

test('workspace rejects empty acceptance and withholds100percent from completed subtasks until actual acceptance',async()=>{
 const plan=createDemo(registry,'working');plan.tasks=[{id:'pending-acceptance',title:'Pending acceptance',ownerRoleId:'director',sprintId:'selected',stage:'Done',accepted:true,acceptanceEvidence:'  ',steps:[{id:'step',title:'Step',complete:true,evidence:'Technical evidence'}]}];plan.sprint={id:'selected',taskIds:['pending-acceptance']};plan.roadmap={sprints:[{id:'selected',taskIds:['pending-acceptance']}]};
 const dashboard=await createProjection(registry,plan);dashboard.project.id=projectId;const contract=createOwnerWorkspaceContract({worldId,roles}),pair=createWorkspaceProjector({worldId,projectId,roles,contract}).projectWorkspace({dashboard,plan});
 assert.equal(pair.owner.tasks[0].stage,'Done');assert.equal(pair.owner.tasks[0].done,false);assert.equal(pair.owner.tasks[0].progress.basis,'subtasks');assert.equal(pair.owner.tasks[0].progress.completedSteps,1);assert.equal(pair.owner.tasks[0].progress.percent,99);assert.equal(pair.owner.sprints[0].progress.percent,0);
});

test('task cards show the requested task fields while underlying acceptance remains unchanged',async()=>{
 const source=await readFile(new URL('../web/owner-site/workspace-client.js',import.meta.url),'utf8'),anchor='function renderProgress(){';assert(source.includes(anchor));
 const elements=[],node=tag=>{const n={tag,dataset:{},attributes:{},children:[],style:{setProperty(){},removeProperty(){}},append(...items){this.children.push(...items);},setAttribute(k,v){this.attributes[k]=v;},addEventListener(){}};elements.push(n);return n;},root=node('main'),nodes=new Map();root.dataset.workspaceAudience='owner';root.querySelector=id=>{if(!nodes.has(id))nodes.set(id,node('select'));return nodes.get(id);};
 const context={OWNER_SITE_CONTEXT:{publicOrigin:'https://public.invalid'},createOwnerWorkspaceContract:()=>({WORKSPACE_WORLD_ID:'world-fixture',WORKSPACE_ROLES:[]}),document:{getElementById:()=>root,createElement:node},localStorage:{getItem:()=>null,setItem(){}}};
 vm.runInNewContext(source.replace(anchor,'globalThis.renderActualTaskCard=taskCard;return;\n'+anchor),context);
 for(const done of [false,true]){
  const task={id:'task-fixture',title:'Actual outcome',stage:'Done',done,known:true,assignedOwners:[],actingOwner:null,condition:null,reference:'task-fixture',progress:{percent:done?100:99,basis:'subtasks',completedSteps:1,totalSteps:1},steps:[],description:null,goal:null};
  const before=JSON.stringify(task);
  const card=context.renderActualTaskCard(task),all=[];const visit=n=>{all.push(n);for(const child of n.children||[])visit(child);};visit(card);
  assert.deepEqual(all.filter(n=>n.className==='wf-field-label').map(n=>n.textContent),['Goal','QA needed','What QA entails','Blockers','Next']);assert.equal(all.find(n=>n.className==='wf-task-summary-title').textContent,'Actual outcome');assert.equal(all.some(n=>['wf-badge','wf-completion','wf-task-percent','wf-task-owners','wf-task-subtasks'].includes(n.className)),false);assert.equal(JSON.stringify(task),before);
 }
});

test('owner QA details accept exact legacy records, preserve explicit false, redact public data and refuse malformed extensions',async()=>{
 const plan=createDemo(registry,'working');Object.assign(plan.tasks[0],{qaRequired:false,qaRequirements:'Recorded exemption rationale'});Object.assign(plan.tasks[1],{qaRequired:'yes',qaRequirements:'api_key=private-value'});
 const dashboard=await createProjection(registry,plan);dashboard.project.id=projectId;const contract=createOwnerWorkspaceContract({worldId,roles}),pair=createWorkspaceProjector({worldId,projectId,roles,contract}).projectWorkspace({dashboard,plan});
 assert.equal(pair.owner.tasks[0].details.qaRequired,false);assert.equal(pair.owner.tasks[1].details.qaRequired,null);assert.match(pair.owner.tasks[1].details.qaRequirements,/withheld/);assert.equal(JSON.stringify(pair.public).includes('Recorded exemption rationale'),false);assert.equal(JSON.stringify(pair.public).includes('qaRequired'),false);
 const legacy=structuredClone(pair.owner);for(const task of legacy.tasks){delete task.details.qaRequired;delete task.details.qaRequirements;}assert.equal(contract.assertWorkspaceSnapshot(legacy,{audience:'owner'}),legacy);
 for(const change of [d=>delete d.qaRequired,d=>d.qaRequired='yes',d=>d.qaRequirements={},d=>d.qaRequirements='x'.repeat(1201),d=>d.extra='unrecognized',d=>d.qaRequirements='https://private.invalid/check']){const bad=structuredClone(pair.owner);change(bad.tasks[0].details);assert.throws(()=>contract.assertWorkspaceSnapshot(bad,{audience:'owner'}));}
});
