// Fictional custom-project test roster, not product defaults, staffing instructions or native bindings.
export const customProjectRegistry=[
  {
    "id": "director",
    "title": "Director",
    "role": "director",
    "responsibility": "Priorities,scope,staffing,concrete decisions and delivery follow-through.",
    "tree": false,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "intake",
    "title": "Request Intake",
    "role": "intake",
    "responsibility": "Preserve user requests,merge intent and route current work without duplicates.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "dispatch",
    "title": "Delivery Lead",
    "role": "dispatch",
    "responsibility": "One authoritative queue,serialized claims,capacity,starts,result consumption and stages.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "release",
    "title": "Release & Closeout",
    "role": "release",
    "responsibility": "Stable candidate/publication windows and ordinary closeout after first goal PASS.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "worker1",
    "title": "Agent Worker #1",
    "role": "worker",
    "responsibility": "Implementation,affected checks and same-owner corrections.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "worker2",
    "title": "Agent Worker #2",
    "role": "worker",
    "responsibility": "Implementation,affected checks and same-owner corrections.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "worker3",
    "title": "Agent Worker #3",
    "role": "worker",
    "responsibility": "Implementation,affected checks and same-owner corrections.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "worker4",
    "title": "Agent Worker #4",
    "role": "worker",
    "responsibility": "Implementation,affected checks and same-owner corrections.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "native-coordinator",
    "title": "QA Coordinator",
    "role": "native-coordinator",
    "responsibility": "Compatible run preparation,exact candidate/environment and authorized scheduling.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "native-operator",
    "title": "QA Operator",
    "role": "native-operator",
    "responsibility": "Actual target-product integration/testing and independent original-goal results.",
    "tree": false,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "cleanup",
    "title": "Memory Clean",
    "role": "cleanup",
    "responsibility": "Measured resources and verified-unused cleanup preserving active tools and recovery.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "support",
    "title": "Agent Support",
    "role": "support",
    "responsibility": "Genuine agent failures,first-response triage and safe recovery/retirement continuity.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "technical-support",
    "title": "Technical Support",
    "role": "technical-support",
    "responsibility": "Precise tooling/environment/integration unblocks under existing ownership.",
    "tree": false,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "shaping",
    "title": "Product Design & Shaping",
    "role": "shaping",
    "responsibility": "Small coherent product outcomes,exclusions and executable acceptance.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "followthrough",
    "title": "Spinner Whip",
    "role": "followthrough",
    "responsibility": "Verify eligible work actually resumes,settle claims/results and route one concrete nudge.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "git-merger",
    "title": "Git Merger",
    "role": "git-merger",
    "responsibility": "Safe synchronization,conflict resolution,scoped publication and remote proof.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "special-forces",
    "title": "Special Forces",
    "role": "special-forces",
    "responsibility": "One bounded complex implementation or critical bottleneck correction.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "optimizer",
    "title": "Optimizer",
    "role": "optimizer",
    "responsibility": "Measured performance diagnosis and justified implementation against this project metric.",
    "tree": false,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "piper",
    "title": "Piper",
    "role": "piper",
    "responsibility": "Evidence-backed productivity/token/flow analytics and authorized process improvements.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  },
  {
    "id": "world-requests",
    "title": "World Requests",
    "role": "world-requests",
    "responsibility": "Sole implementer of this world,website,rooms,visual logic,data projection and fixes.",
    "tree": true,
    "instanceId": null,
    "serviceTier": "default"
  }
];
