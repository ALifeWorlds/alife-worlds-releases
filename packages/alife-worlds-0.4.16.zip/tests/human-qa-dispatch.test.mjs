import test from 'node:test';import assert from 'node:assert/strict';import {randomUUID} from 'node:crypto';
import {qaDigest} from '../lib/human-qa-contract.mjs';import {createQaDispatcher} from '../lib/human-qa-dispatch.mjs';
async function fixture(){
 const worldId='fixture-world',targetThreadId=randomUUID(),goal={entryId:'entry',goalId:'goal',taskIds:['task'],candidateId:'candidate',title:'Finished goal',
 goal:'Actual immutable test goal',candidate:{websiteVersion:'1.0.0',pluginVersion:null,worldVersion:null},surface:{id:'owner',label:'Owner site',url:'https://example.com/'},
 optional:false,reviewState:'current',prior:{state:'unconfirmed',reportedUtc:null,proofId:null}};
 const event={schemaVersion:1,kind:'owner-human-qa-verification',worldId,eventId:await qaDigest([worldId,goal.entryId,goal.candidateId,goal.surface.id]),
 requestId:randomUUID(),manifestId:'a'.repeat(64),entryId:goal.entryId,goalId:goal.goalId,taskIds:goal.taskIds,candidateId:goal.candidateId,surface:goal.surface,
 result:'pass',source:'authenticated-owner-checkbox',reportedUtc:'2026-11-09T06:00:00.000Z',testedUtc:null,reporterHash:'b'.repeat(64)};
 const proof={event,goal,proofSha256:await qaDigest(event)},rows=new Map(),messages=[],receipts=[];
 const options={worldId,targetThreadId,randomId:randomUUID,store:{read:async id=>rows.get(id),reserve:async(id,row)=>{if(rows.has(id))return false;rows.set(id,row);return true;},
 replace:async(id,row)=>rows.set(id,row)},claim:async r=>({ok:true,applied:true,attemptId:r.attemptId}),
 putReceipt:async r=>receipts.push(r),queue:async data=>{messages.push(data);return{exitCode:0,queueReceiptId:randomUUID()};}};
 return{options,proof,rows,messages,receipts};
}
test('one durable reservation invokes exact bound target once; queue receipt is never delivered',async()=>{
 const f=await fixture(),d=createQaDispatcher(f.options);assert.equal((await d.dispatch(f.proof)).state,'queued');
 assert.equal((await d.dispatch(f.proof)).attempted,false);assert.equal(f.messages.length,1);assert.equal(f.messages[0].targetThreadId,f.options.targetThreadId);
 assert.equal(f.receipts[0].state,'queued');assert.equal(f.receipts[0].receiptSha256,null);
});
test('unknown claim result is retained without sending or automatic replay',async()=>{
 const f=await fixture();f.options.claim=async()=>{throw Error('unknown claim');};const d=createQaDispatcher(f.options);
 await d.dispatch(f.proof);await d.dispatch(f.proof);assert.equal(f.messages.length,0);assert.equal(f.rows.get(f.proof.event.eventId).state,'unknown');
});
test('lost queue result never sends again, including a replacement dispatcher',async()=>{
 const f=await fixture();f.options.queue=async()=>{f.messages.push('sent');throw Error('lost result');};
 await createQaDispatcher(f.options).dispatch(f.proof);await createQaDispatcher(f.options).dispatch(f.proof);
 assert.equal(f.messages.length,1);assert.equal(f.receipts[0].state,'unknown');
});
test('receipt upload failure may retry immutable receipt without another native message',async()=>{
 const f=await fixture(),normal=f.options.putReceipt;let fail=true;f.options.putReceipt=async r=>{if(fail)throw Error('network');return normal(r);};
 await assert.rejects(createQaDispatcher(f.options).dispatch(f.proof));fail=false;
 await createQaDispatcher(f.options).dispatch(f.proof);assert.equal(f.messages.length,1);assert.equal(f.receipts.length,1);
});
test('tampered proof fails before any local/cloud reservation or message',async()=>{
 const f=await fixture();await assert.rejects(createQaDispatcher(f.options).dispatch({...f.proof,goal:{...f.proof.goal,candidateId:'other'}}));
 assert.equal(f.rows.size,0);assert.equal(f.messages.length,0);
});
