import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,realpath,rm,lstat,mkdir,writeFile,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';import path from 'node:path';
import {createHash} from 'node:crypto';import {fileURLToPath} from 'node:url';
import {createOwnerDirectorAuthenticator,createDirectorIssueAuthority} from '../lib/owner-director-authority.mjs';
import {createOwnerDirectorCloudClient,createOwnerDirectorPublisher} from '../lib/owner-director-publisher.mjs';
import {createOwnerDirectorService} from '../lib/owner-director-service.mjs';
import {createDirectorDirectoryStore,createOwnerDirectorDispatcher,createDirectorOwnIntakeVerifier,createOwnerDirectorNodeBackend} from '../lib/owner-director-node.mjs';
import {applyNativeActivity,nativeActivityProjection} from '../lib/native-activity.mjs';

const at=Date.parse('2026-11-10T21:00:00.000Z'),Q='a'.repeat(64),O='b'.repeat(64),P='c'.repeat(64);
const thread='11111111-1111-4111-8111-111111111111',requestId='22222222-2222-4222-8222-222222222222',
 attemptId='33333333-3333-4333-8333-333333333333',queueId='44444444-4444-4444-8444-444444444444';
const directorThread='88888888-8888-4888-8888-888888888888';
const c={projectId:'fixture-project',worldId:'fixture-world',qualificationSha256:Q,ownerOrigin:'https://fixture.invalid',
 ownerSubjectHash:O,publisherSubjectHash:P};
function observation() {
 const n={};applyNativeActivity(n,{type:'event_msg',timestamp:new Date(at).toISOString(),
  payload:{type:'task_complete',turn_id:attemptId}},{threadId:thread});
 return{dashboard:{project:{id:c.projectId},model:{nativeMetadata:{persistence:'available'},cfg:{paused:false},
  agents:[{roleId:'worker',threadId:thread,connected:true,onboarded:true},{roleId:'director',threadId:directorThread,connected:true,onboarded:true}],tasks:[{id:'existing-task',done:false}]},
  feed:{observedUtc:new Date(at).toISOString(),error:null,agentHealth:[{threadId:thread,activityState:'idle',
   terminal:true,activityObservedUtc:n.observedUtc,...nativeActivityProjection(n)},{threadId:directorThread,activityState:'working',terminal:false}]}},
  plan:{projectId:c.projectId,paused:false,tasks:[{id:'existing-task',sprintId:'current-sprint',stage:'Ready'}],
   roadmap:{sprints:[{id:'current-sprint',status:'current',taskIds:['existing-task']}]}}};
}
function authorityFor(input,clock=()=>at,verify=async()=>true){return createDirectorIssueAuthority({
 configuration:c,directorTarget:{threadId:directorThread,executionCwd:'fixture-cwd'},readCurrent:async()=>input,verifyContext:verify,now:clock});}
function bucket(){const map=new Map();return{async get(key){if(!map.has(key))return null;const text=map.get(key);
 return{size:Buffer.byteLength(text),text:async()=>text};},async put(key,text,opt){if(opt?.onlyIf?.get('If-None-Match')==='*'&&map.has(key))return null;map.set(key,text);return{etag:'fixture'};},
 async list({prefix,limit,cursor}){const keys=[...map.keys()].filter(k=>k.startsWith(prefix)).sort(),start=Number(cursor||0);
 return{objects:keys.slice(start,start+limit).map(key=>({key})),truncated:start+limit<keys.length,cursor:String(start+limit)};}};}
async function temporary(t){const parent=await realpath(tmpdir()),dir=await mkdtemp(path.join(parent,'alife-director-0410-'));
 t.after(async()=>{const actual=await realpath(dir),s=await lstat(dir);assert.equal(path.dirname(actual),parent);
  assert(path.basename(actual).startsWith('alife-director-0410-'));assert(!s.isSymbolicLink());await rm(actual,{recursive:true,force:true});});return dir;}
async function integrated(t,{loseReceipt=false}={}) {
 const input=observation(),authority=authorityFor(input),principals=new WeakMap(),storage=bucket(),store=await createDirectorDirectoryStore(await temporary(t));
 const auth=createOwnerDirectorAuthenticator({configuration:c,readOwnerIdentity:async r=>principals.get(r)?.owner,
  readPublisherIdentity:async r=>principals.get(r)?.publisher});
 const service=createOwnerDirectorService({configuration:c,authenticate:auth,now:()=>at});
 const ownerRequest=async(method,route,body)=>{const r=new Request(c.ownerOrigin+route,{method,headers:{
  ...(body?{'Content-Type':'application/json',origin:c.ownerOrigin,'sec-fetch-site':'same-origin'}:{})},
  ...(body?{body:JSON.stringify(body)}:{})});principals.set(r,{owner:{subjectHash:O,projectId:c.projectId,worldId:c.worldId}});
  const response=await service.handle(r,{BUCKET:storage});return{status:response.status,body:await response.json()};};
 let lost=loseReceipt,queues=0;
 const cloud=createOwnerDirectorCloudClient({configuration:c,publisherCredential:'fixture-server-credential-123456789',now:()=>at,
  request:async(url,init)=>{const r=new Request(url,init);assert.equal(new URL(url).origin,c.ownerOrigin);
   assert.equal(r.headers.get('origin'),null);assert.equal(r.headers.get('oai-authenticated-user-id'),null);
   principals.set(r,{publisher:{subjectHash:P,projectId:c.projectId,worldId:c.worldId}});
   const data=init.body?JSON.parse(init.body):null,response=await service.handle(r,{BUCKET:storage});
   if(lost&&data?.state==='queued'){lost=false;throw Error('Fixture receipt response lost after write');}return response;}});
 const cli={target:{threadId:directorThread,executionCwd:'fixture-cwd'},verify:async()=>true,queue:async()=>{
  queues++;return{exitCode:0,queueReceiptId:queueId};}};
 const dispatcher=createOwnerDirectorDispatcher({configuration:c,cli,store,cloud,
  verifyCurrentIssue:authority.verifyCurrentIssue,verifyOwnIntake:async()=>false,now:()=>at,newId:()=>attemptId});
 const publisher=()=>createOwnerDirectorPublisher({configuration:c,cloud,authority,dispatcher,store,now:()=>at});
 return{input,authority,store,cloud,dispatcher,publisher,ownerRequest,queues:()=>queues};
}

test('current sprint and real terminal native event define stable eligibility; polling cannot invent an issue',async()=>{
 let time=at;const input=observation(),a=authorityFor(input,()=>time),first=await a.readCapability();
 assert.equal(first.aliases.length,1);time+=1000;input.dashboard.feed.observedUtc=new Date(time).toISOString();
 assert.equal((await a.readCapability()).aliases[0].issueEpisodeId,first.aliases[0].issueEpisodeId);
 input.plan.paused=true;assert.equal((await a.readCapability()).aliases.length,0);input.plan.paused=false;
 input.dashboard.feed.agentHealth[0].activityState='working';assert.equal((await a.readCapability()).aliases.length,0);
 input.dashboard.feed.agentHealth[0].activityState='idle';input.dashboard.feed.agentHealth[0].nativeActivity=null;
 assert.equal((await a.readCapability()).aliases.length,0);
 const blocked=observation();blocked.plan.tasks[0].ownerRoleId='worker';blocked.plan.tasks[0].blocker='Requires an actual owner decision';assert.equal((await authorityFor(blocked).readCapability()).aliases.length,0);
 const retiring=observation();retiring.plan.agents=[{roleId:'worker',retirementNeeded:true}];assert.equal((await authorityFor(retiring).readCapability()).aliases.length,0);
 const done=observation();done.plan.tasks[0].completed=true;assert.equal((await authorityFor(done).readCapability()).aliases.length,0);
 const duplicate=observation();duplicate.plan.tasks.push({...duplicate.plan.tasks[0]});
 await assert.rejects(authorityFor(duplicate).readCapability(),/tasks differ/);
 await assert.rejects(authorityFor(observation(),()=>at,async()=>false).readCapability(),/context unavailable/);
 const lost=observation();lost.dashboard.model.agents.find(a=>a.roleId==='director').connected=false;await assert.rejects(authorityFor(lost).readCapability(),/Director source/);
 const moved=observation();moved.dashboard.model.agents.find(a=>a.roleId==='director').threadId=queueId;await assert.rejects(authorityFor(moved).readCapability(),/Director source/);
});
test('verified host identities stay separate from spoofed browser headers and service credential presence',async()=>{
 const identities=new WeakMap(),auth=createOwnerDirectorAuthenticator({configuration:c,
  readOwnerIdentity:async r=>identities.get(r)?.owner,readPublisherIdentity:async r=>identities.get(r)?.publisher});
 const r=new Request(c.ownerOrigin+'/api/director-requests',{method:'POST',headers:{
  'oai-authenticated-user-id':'spoofed','OAI-Sites-Authorization':'Bearer fixture-service-key'}});
 assert.equal(await auth(r),null);identities.set(r,{publisher:{subjectHash:P,projectId:c.projectId,worldId:c.worldId}});
 assert.equal(await auth(r),null);identities.set(r,{owner:{subjectHash:O,projectId:'other-project',worldId:c.worldId}});
 assert.equal(await auth(r),null);identities.set(r,{owner:{subjectHash:O,projectId:c.projectId,worldId:c.worldId}});
 assert.equal((await auth(r)).kind,'owner');
});
test('one authenticated owner click reaches only the fixed Director; saved/queued is not received or task work',async t=>{
 const f=await integrated(t),run=f.publisher();await run.tick();assert.equal(f.queues(),0);
 const cap=await f.authority.readCapability(),s={schemaVersion:1,requestId,worldId:c.worldId,
  action:'request-existing-task',...cap.aliases[0]};
 const saved=await f.ownerRequest('POST','/api/director-requests',s);assert.equal(saved.status,201);
 const result=await run.tick();assert.equal(result.results[0].state,'queued');assert.equal(f.queues(),1);
 assert.equal(result.nativeQueueConsumption,'unavailable');assert.equal(result.taskProgressChanged,false);
 const state=await f.ownerRequest('GET','/api/director-requests?requestId='+requestId);
 assert.equal(state.body.delivery.state,'queued');assert.equal(state.body.taskProgressChanged,false);
 assert.equal(f.input.plan.tasks[0].stage,'Ready');
 const duplicate=await f.ownerRequest('POST','/api/director-requests',s);assert.equal(duplicate.body.delivery.state,'queued');
 await run.tick();assert.equal(f.queues(),1);
});
test('a lost receipt upload recovers through the private pending journal after publisher restart without another native send',async t=>{
 const f=await integrated(t,{loseReceipt:true}),run=f.publisher();await run.tick();
 const cap=await f.authority.readCapability(),s={schemaVersion:1,requestId,worldId:c.worldId,action:'request-existing-task',...cap.aliases[0]};
 const saved=await f.ownerRequest('POST','/api/director-requests',s),first=await run.tick();
 assert.equal(first.results[0].state,'unknown');assert.equal(first.results[0].attempted,null);assert.equal(f.queues(),1);
 assert.equal((await f.store.pendingReceipts()).eventIds.length,1);
 const restarted=f.publisher();await restarted.tick();
 assert.equal((await f.store.pendingReceipts()).eventIds.length,0);assert.equal(f.queues(),1);
 const p=await f.cloud.readEvent(saved.body.eventId),before=f.queues();
 const empty=await createDirectorDirectoryStore(await temporary(t));
 const isolated=createOwnerDirectorDispatcher({configuration:c,cli:{target:{threadId:directorThread,executionCwd:'fixture-cwd'},
  verify:async()=>true,queue:async()=>{throw Error('Reconciliation must never queue');}},store:empty,cloud:f.cloud,
  verifyCurrentIssue:async()=>true,verifyOwnIntake:async()=>false,now:()=>at});
 await assert.rejects(isolated.reconcile(p),/reservation required/);assert.equal(f.queues(),before);
});
test('a revoked current project between cloud claim and send is known not-sent through actual eligibility logic',async t=>{
 const f=await integrated(t),run=f.publisher();await run.tick();const cap=await f.authority.readCapability();
 const saved=await f.ownerRequest('POST','/api/director-requests',{schemaVersion:1,requestId,worldId:c.worldId,
  action:'request-existing-task',...cap.aliases[0]}),p=await f.cloud.readEvent(saved.body.eventId);
 const cloud={claim:async v=>{const r=await f.cloud.claim(v);f.input.plan.paused=true;return r;},putReceipt:f.cloud.putReceipt};
 const d=createOwnerDirectorDispatcher({configuration:c,cli:{target:{threadId:directorThread,executionCwd:'fixture-cwd'},
  verify:async()=>true,queue:async()=>{throw Error('Revoked request cannot send');}},store:f.store,cloud,
  verifyCurrentIssue:f.authority.verifyCurrentIssue,verifyOwnIntake:async()=>false,now:()=>at,newId:()=>attemptId});
 assert.equal((await d.dispatch(p)).state,'not-sent');assert.equal(f.queues(),0);
});

test('received needs the fixed Director-owned file and independent actual native provenance',async t=>{
 const home=await temporary(t),root=path.join(home,'runtime','director-intake');await mkdir(root,{recursive:true});
 const target={threadId:directorThread,executionCwd:'fixture-cwd',homePath:home};let trusted=false,current=true;
 const check=createDirectorOwnIntakeVerifier({configuration:c,target,root,
  verifyCurrentContext:async()=>current,verifyNativeProvenance:async()=>trusted});
 const value={schemaVersion:1,kind:'actual-owner-director-intake',projectId:c.projectId,worldId:c.worldId,
  eventId:'e'.repeat(64),proofSha256:'f'.repeat(64),attemptId,directorThreadId:directorThread,executionCwd:'fixture-cwd',
  sourceTurnId:'55555555-5555-4555-8555-555555555555',sourceMessageId:'66666666-6666-4666-8666-666666666666',
  recordedUtc:new Date(at).toISOString(),receivedUtc:null};
 await writeFile(path.join(root,value.eventId+'.'+attemptId+'.json'),JSON.stringify(value));
 assert.equal(await check(value),false);trusted=true;assert.equal(await check(value),true);
 assert.equal(await check({...value,sourceMessageId:queueId}),false);
 current=false;assert.equal(await check(value),false);
 assert.throws(()=>createDirectorOwnIntakeVerifier({configuration:c,target,root:path.dirname(home),
  verifyCurrentContext:async()=>true,verifyNativeProvenance:async()=>true}),/Director-owned/);
});

test('complete private backend construction pins its real dependency closure and starts no source/network/native loop',async t=>{
 const home=await temporary(t),files={};for(const name of ['node','cli','vendor','binding','membership','guard','host'])files[name]=path.join(home,name+'.fixture');
 await Promise.all(['node','cli','vendor','host'].map(name=>writeFile(files[name],'inert-'+name)));
 await writeFile(files.binding,JSON.stringify({threadId:directorThread,roleId:'director',workspacePath:home}));
 await writeFile(files.membership,JSON.stringify({logicalProjectId:c.projectId,members:[{roleId:'director',
  threadId:directorThread,hostId:'local',lifecycle:'active',executionCwd:home}]}));
 const source=name=>fileURLToPath(new URL('../lib/'+name,import.meta.url)),paths=[files.node,files.cli,files.vendor,files.binding,files.host,
  ...['owner-director-node.mjs','owner-director-contract.mjs','owner-director-authority.mjs','owner-director-publisher.mjs','native-activity.mjs'].map(source)];
 const pins=[];for(const file of paths)pins.push({path:file,sha256:createHash('sha256').update(await readFile(file)).digest('hex'),maxBytes:262144});
 const g={schemaVersion:1,kind:'owner-director-cli-guard',projectId:c.projectId,worldId:c.worldId,
  projectRoot:home,executionCwd:home,directorThreadId:directorThread,directorBindingPath:files.binding,membershipPath:files.membership,
  nodePath:files.node,cliPath:files.cli,cliExecutablePath:files.vendor,pins};
 const raw=JSON.stringify(g);await writeFile(files.guard,raw);let reads=0,sends=0,requests=0;
 const backend=await createOwnerDirectorNodeBackend({configuration:{...c,qualificationSha256:createHash('sha256').update(raw).digest('hex')},
  guardPath:files.guard,guardSha256:createHash('sha256').update(raw).digest('hex'),journalRoot:path.join(home,'outbox'),
  hostAdapterPath:files.host,publisherCredential:'fixture-server-credential-123456789',
  readCurrent:async()=>{reads++;throw Error('Construction must not read source');},
  request:async()=>{requests++;throw Error('Construction must not request');},
  spawnImpl:()=>{sends++;throw Error('Construction must not queue');}});
 assert.equal(backend.status.intakeVerification,'unavailable');assert.equal(backend.status.nativeQueueConsumption,'unavailable');
 assert.equal(backend.status.newObserver,false);assert.equal(reads+requests+sends,0);
 const missing={...g,pins:g.pins.filter(p=>p.path!==files.host)},bad=JSON.stringify(missing);await writeFile(files.guard,bad);
 await assert.rejects(createOwnerDirectorNodeBackend({configuration:{...c,qualificationSha256:createHash('sha256').update(bad).digest('hex')},
  guardPath:files.guard,guardSha256:createHash('sha256').update(bad).digest('hex'),journalRoot:path.join(home,'other-outbox'),
  hostAdapterPath:files.host,publisherCredential:'fixture-server-credential-123456789',readCurrent:async()=>observation()}),/dependency closure/);
});
