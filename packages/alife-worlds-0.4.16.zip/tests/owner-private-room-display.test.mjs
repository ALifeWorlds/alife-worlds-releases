import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const renderer=await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8');
const viewer=(await readFile(new URL('../web/world-view.mjs',import.meta.url),'utf8')).replace(/^import .*;\r?$/gm,'').replace(/^await import.*;\r?$/gm,'');
const module={exports:{}};vm.runInNewContext(renderer,{module,URL,require:()=>({})});const api=module.exports;
const reason='This viewer is read-only; native agent commands are unavailable here.';

async function receiver({operator=false,embedded=false,queryOperator=false}={}){
 const listeners=new Map(),calls={mount:[],modes:[],fetch:[],render:[]};
 const pause={getAttribute:()=> 'false'},range={value:'100',disabled:false};
 const controls={querySelector:q=>q==='input[type=range]'?range:pause,addEventListener(){}};
 const main={dataset:{source:'/api/world-view',world:'world-fixture',operatorPresentation:String(operator)},querySelectorAll:()=>[]};
 const anchor={},document={baseURI:'https://world.test/world/view',referrer:'https://owner.test/',hidden:false,getElementById:id=>id==='world-showcase'?main:anchor,addEventListener(){}};
 const parent={postMessage(){}},window={addEventListener:(type,fn)=>listeners.set(type,fn)};
 const farm={host:{dataset:{mode:'view',renderBuild:'fixture'},querySelector:()=>controls,addEventListener(){}},audio:{state:()=>({enabled:false})},setAudioPreferenceKey(){},render:(...a)=>calls.render.push(a),setPresentationMode:mode=>calls.modes.push(mode)};
 const snapshot={kind:'read-only-world',world:{id:'world-fixture'},model:{agents:[]},feed:{}};
 const context={document,parent,window,URL,URLSearchParams,location:{origin:'https://world.test',search:'?project=world-fixture'+(embedded?'&embedded=planet':'')+(queryOperator?'&operatorPresentation=true':'')},AgentOutpost:{mount:(node,opts)=>{assert.equal(node,anchor);calls.mount.push(opts);return farm;}},fetch:async(url,opts)=>{calls.fetch.push({url:String(url),opts});return{ok:true,json:async()=>snapshot};},setInterval(){},innerHeight:720,queueMicrotask};
 vm.runInNewContext(viewer,context);await new Promise(setImmediate);
 const mode=value=>listeners.get('message')({source:parent,origin:'https://owner.test',data:{type:'alife-world-mode',worldId:'world-fixture',mode:value}});
 return{calls,mode};
}

test('actual viewer receiver forwards only explicit non-planet owner presentation; no native host is mounted',async()=>{
 for(const [params,expected]of [[{operator:true},true],[{},false],[{operator:true,embedded:true},false],[{queryOperator:true},false]]){
  const h=await receiver(params),opts=h.calls.mount[0];assert.equal(opts.operatorPresentation,expected);assert.equal(opts.cosmeticOnly,true);assert.equal(opts.presentationMode,'view');assert.equal(opts.farmCommandHost,undefined);
  assert.equal(h.calls.fetch[0].opts.credentials,'omit');assert.equal(h.calls.fetch[0].opts.method,undefined);
  h.mode('private');assert.deepEqual(h.calls.modes,params.embedded?[]:[expected?'private':'view']);
 }
});

test('read-only owner room inspection and command display never acquire native permission or alter View',()=>{
 for(const mode of ['public','private','view']){
  const before=api.presentationPermissions(mode,true),ordinary=api.operatorDisplayPermissions(mode,true),owner=api.operatorDisplayPermissions(mode,true,true);
  assert.equal(before.native,false);assert.equal(ordinary.inspect,false);assert.equal(ordinary.displayCommands,false);assert.equal(owner.native,false);
  assert.equal(owner.inspect,mode!=='view');assert.equal(owner.displayCommands,mode!=='view');assert.equal(owner.readOnlyOperator,mode!=='view');
  assert.equal(api.operatorDisplayPermissions(mode,false,true).native,api.presentationPermissions(mode,false).native);
 }
});

const stamp=new Date().toISOString(),id='fixture-ant',agent={threadId:id,title:'Fixture ant',role:'worker'},task={id:'fixture-task',ownerIds:[id],stage:'In Progress',done:false},model={agents:[agent],tasks:[task],cfg:{cards:{}}};
const feed={observedUtc:stamp,farmFacts:{commands:{state:'current',observedUtc:stamp,transportEnabled:true,agents:{[id]:{wake:true,retire:true,unblockTaskIds:[task.id],episodes:{wake:'w',retire:'r',unblock:{[task.id]:'b'}}}}}}};
const stations=[{key:'sleep',agent,status:'Sleeping',sleeping:true},{key:'block',agent,status:'Blocked',task,blocker:'Needs help'},{key:'retire',agent,status:'Retirement Needed'}];

test('eligible received command facts remain visibly unavailable in the owner display for all contextual actions',()=>{
 const access=api.operatorDisplayPermissions('private',true,true);
 for(const [s,action]of stations.map((s,i)=>[s,['wake','unblock','retire'][i]])){
  const spec=api.farmCommandPresentation(s,model,feed,access);assert.equal(spec.action,action);assert.equal(spec.unavailable,true);assert.equal(spec.reason,reason);
  assert.equal(api.farmCommandPresentation(s,model,feed,api.operatorDisplayPermissions('view',true,true)),null);
  assert.equal(api.farmCommandPresentation(s,model,feed,api.operatorDisplayPermissions('private',true,false)),null);
 }
 const native=api.operatorDisplayPermissions('private',false);assert.equal(api.farmCommandPresentation(stations[0],model,feed,native).unavailable,undefined);
});

test('custom and legacy scene preserves removal of room-side controls without invoking native actions',()=>{
 const start=renderer.indexOf('function sceneRenderCommands(){'),end=renderer.indexOf('function sceneAnalyticsDetails()',start);assert(start>=0&&end>start);
 for(const mode of ['private','public','view'])for(const [woodland,roomLabelPlacement] of [[false,undefined],[true,'below-room']]){
  let sends=0,placed=0,notes=0;const layer={children:[{tag:'button',disabled:true,icon:true}],replaceChildren(...nodes){this.children=nodes;}},context={snapshot:{stations},layout:{},sceneCommandLayer:layer,placeRoster(){placed++;},renderRetirementNotes(){notes++;},woodlandActive:()=>woodland,permissions:()=>api.operatorDisplayPermissions(mode,true,true),options:{roomLabelPlacement,farmCommandHost:{sendAction(){sends++;}}},el(){throw Error('No control may be created');}};
  vm.runInNewContext(renderer.slice(start,end),context);context.sceneRenderCommands();assert.equal(layer.children.length,0);assert.equal(sends,0);assert.equal(placed,1);assert.equal(notes,mode==='view'?0:1);
 }
});

test('passive inspection preserves public concealment and displays received owner summary/blocker without enabling commands',()=>{
 const start=renderer.indexOf('function drawRoomLens()'),end=renderer.indexOf('function detailRender()',start),body=renderer.slice(start,end);
 assert(body.includes('if(!operational()||!roomLensKey'));assert(body.includes("privateMode&&!permissions().readOnlyOperator?''"));

 assert(renderer.includes("host.dataset.roomNames=belowRoom?'below-room':quiet?'in-room':'legacy'"));
});
