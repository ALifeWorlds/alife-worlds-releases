// Isolated writer fixtures only; no actual private home, Site or native process.
import test from 'node:test';
import assert from 'node:assert/strict';
import {open,mkdir,mkdtemp,writeFile,readFile,readdir,unlink,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {createOwnerSitePublisher,ownerSiteRetryDelay} from '../lib/site-sync-publisher.mjs';
import {createSiteBundleService} from '../lib/site-sync-receiver.mjs';
import {siteBundleFixture,r2Fixture,configuration,projectId,ownerOrigin} from './site-sync-fixture.mjs';
const scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url)),secret='fixture-bundle-key-'.repeat(3),serviceToken='fixture-service-token-'.repeat(2),hash=text=>createHash('sha256').update(text).digest('hex');
async function fixture(run){
 await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'owner-publisher-')),privateRoot=path.join(root,'.alife-worlds'),runtime=path.join(privateRoot,'runtime');await mkdir(runtime,{recursive:true});
 await writeFile(path.join(runtime,'antfarm.config.json'),JSON.stringify({nativeReadOnly:true,nativeWorkspaceRoot:root,projectId,stateFile:'data/project-state.json'}));
 const f=await siteBundleFixture(),stateFile=path.join(privateRoot,'site-bundle-sync-state.json'),recoveryFile=path.join(privateRoot,'site-bundle-sync-recovery.json'),logs=[],publishers=[];let observations=0,body=f.bundle;
 const pairing={mode:'owner-bundle',siteUrl:ownerOrigin+'/',dashboardOrigin:'http://127.0.0.1:12345',syncKey:secret,serviceToken};
 function source(renderer=configuration.renderer){return{projectRoot:root,project:configuration.project,worldId:configuration.worldId,ownerOrigin,renderer,roles:configuration.roles,async observe(revision){observations++;const value=structuredClone(body);value.revision=revision;value.ownerPreview.renderer={...renderer};value.ownerPreview.appearance.renderer={...renderer};return value;}};}
 async function create(options={}){const publisher=await createOwnerSitePublisher({projectRoot:root,source:source(),pairing,log:value=>logs.push(value),...options});publishers.push(publisher);return publisher;}
 const state=async()=>JSON.parse(await readFile(stateFile,'utf8'));
 try{await run({root,privateRoot,stateFile,recoveryFile,pairing,logs,create,source,state,get observations(){return observations;},change:mutate=>mutate(body)});}finally{for(const publisher of publishers)try{await publisher.close();}catch{}assert.ok(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));await rm(root,{recursive:true,force:true});}
}
test('one shared writer reserves exact body before PUT, keeps work clocks, skips identical observations and persists no credentials',async()=>fixture(async f=>{
 let writes=0;const publisher=await f.create({fetcher:async(url,options)=>{writes++;assert.equal(url.pathname,'/api/owner-bundle');const saved=await f.state();assert.equal(saved.pending.outcome,'sending');assert.equal(saved.pending.bodySha256,hash(options.body));assert.equal(saved.pending.revision,JSON.parse(options.body).revision);assert.equal(options.headers['X-ALife-Sync-Key'],secret);assert.equal(options.headers['OAI-Sites-Authorization'],'Bearer '+serviceToken);return Response.json({state:'accepted',revision:saved.revision,receivedUtc:new Date().toISOString(),duplicate:false});}});
 assert.equal((await publisher.step()).state,'connected');assert.equal((await publisher.step()).state,'connected-unchanged');assert.equal(writes,1);assert.equal(f.observations,2);
 const saved=await f.state();assert.equal(saved.revision,1);assert.equal(saved.pending,null);assert.ok(saved.lastReceipt.bodySha256);const text=await readFile(f.stateFile,'utf8');assert.equal(text.includes(secret),false);assert.equal(text.includes(serviceToken),false);assert.equal(JSON.stringify(f.logs).includes('Fixture World'),false);
}));
test('lost accepted reply and process restart reconcile the same original body after expiry without a new source read',async()=>fixture(async f=>{
 let now=Date.now(),lost=false;const store=r2Fixture(),receiver=createSiteBundleService({...configuration,clock:()=>now}),bodies=[];
 const publisher=await f.create({clock:()=>now,fetcher:async(url,options)=>{bodies.push(options.body);const response=await receiver.publish(store,JSON.parse(options.body));if(!lost){lost=true;throw Error('Lost fixture reply');}return response;}});
 assert.equal((await publisher.step()).state,'delivery-unconfirmed');const pending=await f.state(),id=pending.pending.requestId;assert.equal(pending.pending.hadUnknown,true);assert.equal(f.observations,1);await publisher.close();now+=60000;
 const resumed=await f.create({clock:()=>now,fetcher:async(url,options)=>{bodies.push(options.body);return receiver.publish(store,JSON.parse(options.body));}});const result=await resumed.step();assert.equal(result.state,'connected');assert.equal(result.receiptId,id);assert.equal(f.observations,1);assert.equal(bodies[0],bodies[1]);assert.equal(store.puts.filter(put=>put.applied).length,1);assert.equal((await f.state()).lastReceipt.duplicate,true);
}));
test('known nonapplied expiry clears only that reservation, while expiry after unknown effect retains original recovery and halts',async()=>fixture(async f=>{
 let expired=true;const publisher=await f.create({fetcher:async()=>{if(expired)return Response.json({error:'Expired source observation'},{status:400});throw Error('Unknown fixture write');}});
 assert.equal((await publisher.step()).state,'expired-not-applied');assert.equal((await f.state()).pending,null);expired=false;assert.equal((await publisher.step()).state,'delivery-unconfirmed');const original=await f.state();await publisher.close();
 const resumed=await f.create({fetcher:async()=>Response.json({error:'Expired source observation'},{status:400})});const result=await resumed.step();assert.equal(result.halt,true);const final=await f.state();assert.equal(final.pending.requestId,original.pending.requestId);assert.equal(final.pending.bodySha256,original.pending.bodySha256);assert.equal(final.pending.outcome,'conflict');const reads=f.observations;await resumed.step();assert.equal(f.observations,reads);
}));
test('common original v1/v2 lock prevents duplicate writers and foreign journal bytes are never overwritten',async()=>fixture(async f=>{
 const first=await f.create({fetcher:async()=>{throw Error('No write expected');}}),original=await readFile(f.stateFile,'utf8');await assert.rejects(f.create(),{code:'RELAY_ALREADY_EXISTS'});assert.equal(await readFile(f.stateFile,'utf8'),original);await first.close();
 const foreign={...JSON.parse(original),project:'project-'+'f'.repeat(24)};await writeFile(f.stateFile,JSON.stringify(foreign));await assert.rejects(f.create(),{code:'RELAY_FOREIGN_STATE'});assert.deepEqual(await f.state(),foreign);assert.equal((await readdir(f.privateRoot)).includes('site-sync.lock'),false);
}));
test('settled artifact migration preserves exact previous bytes and pending old artifacts cannot migrate',async()=>fixture(async f=>{
 const accepted=await f.create({fetcher:async(url,options)=>Response.json({state:'accepted',revision:JSON.parse(options.body).revision,receivedUtc:new Date().toISOString(),duplicate:false})});await accepted.step();await accepted.close();const prior=await readFile(f.stateFile,'utf8'),nextRenderer={...configuration.renderer,artifactSha256:'d'.repeat(64)};
 const migrated=await f.create({source:f.source(nextRenderer),fetcher:async()=>{throw Error('No send during migration');}}),state=await f.state();assert.equal(state.rendererSha256,nextRenderer.artifactSha256);assert.equal(state.revision,1);assert.equal(await readFile(path.join(f.privateRoot,state.previousState.file),'utf8'),prior);assert.equal(state.previousState.sha256,hash(prior));await migrated.step();await migrated.close();
 const pending=await readFile(f.stateFile,'utf8');await assert.rejects(f.create({source:f.source({...nextRenderer,artifactSha256:'e'.repeat(64)})}),{code:'RELAY_ARTIFACT_PENDING'});assert.equal(await readFile(f.stateFile,'utf8'),pending);
}));
test('receipt mismatches and bounded read failures keep exact pending body; backoff is bounded and one attempt occurs per step',async()=>fixture(async f=>{
 let calls=0;const publisher=await f.create({fetcher:async(url,options)=>{calls++;return calls===1?Response.json({state:'accepted',revision:JSON.parse(options.body).revision+1,receivedUtc:new Date().toISOString(),duplicate:false}):new Response('x'.repeat(16385));}});
 assert.equal((await publisher.step()).state,'delivery-unconfirmed');const original=await f.state();assert.equal((await publisher.step()).state,'delivery-unconfirmed');const after=await f.state();assert.equal(calls,2);assert.equal(after.pending.bodySha256,original.pending.bodySha256);assert.equal(after.pending.requestId,original.pending.requestId);assert.equal(f.observations,1);assert.equal(after.pending.attempts,2);
 assert.deepEqual([0,1,2,3,4,100].map(ownerSiteRetryDelay),[5000,5000,10000,20000,30000,30000]);assert.throws(()=>ownerSiteRetryDelay(-1));
}));
test('the run loop has one source observation at a time, waits normally and stops on abort without spawning a process',async()=>fixture(async f=>{
 const controller=new AbortController(),waits=[];let writes=0;const publisher=await f.create({fetcher:async(url,options)=>{writes++;return Response.json({state:'accepted',revision:JSON.parse(options.body).revision,receivedUtc:new Date().toISOString(),duplicate:false});}});
 await publisher.run({signal:controller.signal,wait:async ms=>{waits.push(ms);if(waits.length===2)controller.abort();}});assert.equal(writes,1);assert.equal(f.observations,2);assert.deepEqual(waits,[5000,5000]);
 const module=await readFile(new URL('../lib/site-sync-source.mjs',import.meta.url),'utf8'),relay=await readFile(new URL('../scripts/relay-owner-site.mjs',import.meta.url),'utf8');assert.equal(module.includes('child_process'),false);assert.equal(relay.includes('child_process'),false);
}));

test('an outstanding question is checked after 1.5 seconds and its clearance bypasses ordinary coalescing',async()=>fixture(async f=>{
 let now=Date.now(),observations=0;const delays=[],uploads=[],controller=new AbortController();
 f.change(body=>{body.workspace.agents[0].state='needs-input';});
 const publisher=await f.create({clock:()=>now,fetcher:async(url,options)=>{
  const body=JSON.parse(options.body);uploads.push(body.workspace.agents[0].state);
  return Response.json({state:'accepted',revision:body.revision,receivedUtc:new Date(now).toISOString(),duplicate:false});
 }});
 await publisher.run({signal:controller.signal,wait:async ms=>{
  delays.push(ms);now+=ms;observations++;
  if(observations===2)f.change(body=>{body.workspace.agents[0].state='working';});
  if(observations===3)controller.abort();
 }});
 assert.deepEqual(uploads,['needs-input','working']);assert.deepEqual(delays,[1500,1500,5000]);
 assert.equal((await f.state()).pending,null);
}));
test('a concurrently replaced private journal is preserved and prevents the next network effect',async()=>fixture(async f=>{
 let writes=0;const publisher=await f.create({fetcher:async()=>{writes++;throw Error('No network effect expected');}}),changed={...await f.state(),revision:4};await writeFile(f.stateFile,JSON.stringify(changed));
 await assert.rejects(publisher.step(),{code:'RELAY_STATE_CHANGED'});assert.equal(writes,0);assert.deepEqual(await f.state(),changed);
}));

test('the single bounded recovery record holds exact flushed sending bytes before every network effect',async()=>fixture(async f=>{
 const publisher=await f.create({fetcher:async(url,options)=>{
  const text=await readFile(f.stateFile,'utf8'),backup=JSON.parse(await readFile(f.recoveryFile,'utf8'));assert.equal(backup.kind,'owner-site-publisher-recovery');assert.equal(backup.stateText,text);assert.equal(backup.stateSha256,hash(text));const saved=JSON.parse(text);assert.equal(saved.pending.outcome,'sending');assert.equal(JSON.stringify(saved.pending.body),options.body);assert.equal(saved.pending.bodySha256,hash(options.body));assert.equal(backup.project,saved.project);assert.equal(backup.worldId,saved.worldId);assert.equal(backup.siteOrigin,saved.siteOrigin);assert.equal(backup.rendererSha256,saved.rendererSha256);throw Error('Unknown original fixture effect');
 }});await publisher.step();const text=await readFile(f.stateFile,'utf8'),backup=JSON.parse(await readFile(f.recoveryFile,'utf8'));assert.equal(backup.stateText,text);assert.equal(backup.stateSha256,hash(text));assert.equal(JSON.parse(backup.stateText).pending.hadUnknown,true);assert.equal((await readdir(f.privateRoot)).filter(name=>name==='site-bundle-sync-recovery.json').length,1);assert.equal((await readdir(f.privateRoot)).some(name=>name.endsWith('.tmp')),false);
 const encoded=JSON.stringify(backup);assert.equal(encoded.includes(secret),false);assert.equal(encoded.includes(serviceToken),false);
}));

test('cold unreadable or missing primary preserves the validated exact pending backup and never rolls it back automatically',async()=>fixture(async f=>{
 let writes=0;const publisher=await f.create({fetcher:async()=>{writes++;throw Error('Unknown fixture effect');}});await publisher.step();await publisher.close();const original=await f.state(),backup=await readFile(f.recoveryFile,'utf8');
 for(const mode of ['nul','missing']){
  const corrupt=Buffer.alloc(663);if(mode==='nul')await writeFile(f.stateFile,corrupt);else await unlink(f.stateFile);
  await assert.rejects(f.create({fetcher:async()=>{writes++;throw Error('No recovery send allowed');}}),error=>{assert.equal(error.code,'RELAY_RECOVERY_REQUIRED');assert.equal(error.recovery.reason,mode==='nul'?'primary-unreadable':'primary-missing');assert.equal(error.recovery.requestId,original.pending.requestId);assert.equal(error.recovery.revision,original.pending.revision);assert.equal(error.recovery.sha256,JSON.parse(backup).stateSha256);assert.equal(Object.hasOwn(error.recovery,'body'),false);return true;});
  assert.equal(await readFile(f.recoveryFile,'utf8'),backup);if(mode==='nul')assert.deepEqual(await readFile(f.stateFile),corrupt);else await assert.rejects(readFile(f.stateFile),{code:'ENOENT'});
 }
 assert.equal(writes,1);assert.equal(f.observations,1);assert.equal((await readdir(f.privateRoot)).includes('site-sync.lock'),false);
}));

test('an older verified backup cannot hide a newer unknown live delivery',async()=>fixture(async f=>{
 let writes=0;const publisher=await f.create({fetcher:async(url,options)=>{writes++;if(writes>1)throw Error('Newer unknown write');return Response.json({state:'accepted',revision:JSON.parse(options.body).revision,receivedUtc:new Date().toISOString(),duplicate:false});}});await publisher.step();const oldBackup=await readFile(f.recoveryFile,'utf8');f.change(body=>body.workspace.project.name='A new source label');await publisher.step();await publisher.close();const newer=await readFile(f.stateFile,'utf8'),pending=JSON.parse(newer).pending;assert.equal(pending.revision,2);await writeFile(f.recoveryFile,oldBackup);
 await assert.rejects(f.create({fetcher:async()=>{writes++;throw Error('Cannot replay old revision');}}),error=>error.code==='RELAY_RECOVERY_REQUIRED'&&error.recovery.reason==='primary-backup-mismatch');assert.equal(await readFile(f.stateFile,'utf8'),newer);assert.equal(await readFile(f.recoveryFile,'utf8'),oldBackup);assert.equal(writes,2);assert.equal((await f.state()).pending.requestId,pending.requestId);
}));

test('foreign, corrupt, hash-mismatched and partially specified recovery records fail closed without replacement',async()=>fixture(async f=>{
 const publisher=await f.create();await publisher.close();const head=await readFile(f.stateFile,'utf8'),original=JSON.parse(await readFile(f.recoveryFile,'utf8'));
 for(const mutate of [b=>b.project='project-'+'f'.repeat(24),b=>b.worldId='world-foreign',b=>b.siteOrigin='https://foreign.invalid',b=>b.rendererSha256='f'.repeat(64),b=>b.stateSha256='0'.repeat(64),b=>delete b.stateText,b=>b.extra='unrecognized',b=>{const state=JSON.parse(b.stateText);state.project='project-'+'f'.repeat(24);b.stateText=JSON.stringify(state);b.stateSha256=hash(b.stateText);}]){
  const value=structuredClone(original);mutate(value);const bytes=JSON.stringify(value);await writeFile(f.recoveryFile,bytes);await assert.rejects(f.create(),{code:'RELAY_FOREIGN_STATE'});assert.equal(await readFile(f.recoveryFile,'utf8'),bytes);assert.equal(await readFile(f.stateFile,'utf8'),head);
 }
 await writeFile(f.recoveryFile,Buffer.alloc(200));await assert.rejects(f.create(),{code:'RELAY_STATE_CORRUPT'});assert.deepEqual(await readFile(f.recoveryFile),Buffer.alloc(200));assert.equal(await readFile(f.stateFile,'utf8'),head);
}));

test('a valid legacy head seeds exact recovery once; a missing head without recovery is never inferred from corrupt bytes',async()=>fixture(async f=>{
 const publisher=await f.create({fetcher:async()=>{throw Error('Preserve original pending');}});await publisher.step();await publisher.close();const original=await readFile(f.stateFile,'utf8');await unlink(f.recoveryFile);
 const resumed=await f.create();const backup=JSON.parse(await readFile(f.recoveryFile,'utf8'));assert.equal(backup.stateText,original);assert.equal(backup.stateSha256,hash(original));assert.equal(backup.previousSha256,hash(original));assert.equal(await readFile(f.stateFile,'utf8'),original);await resumed.close();
 await unlink(f.recoveryFile);await writeFile(f.stateFile,Buffer.alloc(663));await assert.rejects(f.create(),{code:'RELAY_STATE_CORRUPT'});assert.deepEqual(await readFile(f.stateFile),Buffer.alloc(663));await assert.rejects(readFile(f.recoveryFile),{code:'ENOENT'});
}));

for(const failedKind of ['owner-site-publisher-recovery','owner-site-publisher'])test('failed '+failedKind+' fsync prevents PUT and preserves the original reservation',async t=>fixture(async f=>{
 const sample=await open(path.join(f.privateRoot,'prototype-fixture'),'wx');const prototype=Object.getPrototypeOf(sample),realSync=prototype.sync;await sample.close();await unlink(path.join(f.privateRoot,'prototype-fixture'));
 let injected=false,writes=0;
 t.mock.method(prototype,'sync',async function(){
  const temporary=(await readdir(f.privateRoot)).find(name=>name.endsWith('.tmp'));if(temporary){const value=JSON.parse(await readFile(path.join(f.privateRoot,temporary),'utf8')),state=value.kind==='owner-site-publisher-recovery'?JSON.parse(value.stateText):value;
   if(!injected&&value.kind===failedKind&&state.pending?.outcome==='sending'){injected=true;throw Object.assign(Error('Fixture durability failure'),{code:'EIO'});}
  }return realSync.call(this);
 });
 const publisher=await f.create({fetcher:async()=>{writes++;throw Error('No PUT before durable sending');}});await assert.rejects(publisher.step(),{code:'RELAY_SAVE_UNCONFIRMED'});const original=await f.state(),body=original.pending.bodySha256;assert.equal(injected,true);assert.equal(original.pending.outcome,'reserved');assert.equal(original.pending.attempts,0);assert.equal(writes,0);assert.equal((await readdir(f.privateRoot)).some(name=>name.endsWith('.tmp')),false);await publisher.close();
 const backup=JSON.parse(await readFile(f.recoveryFile,'utf8')),pending=JSON.parse(backup.stateText).pending;assert.equal(pending.requestId,original.pending.requestId);assert.equal(pending.bodySha256,body);
 if(failedKind==='owner-site-publisher'){
  assert.equal(pending.outcome,'sending');await assert.rejects(f.create(),{code:'RELAY_RECOVERY_REQUIRED'});
 }else{
  assert.equal(pending.outcome,'reserved');const resumed=await f.create({fetcher:async()=>{writes++;throw Error('First original effect remains unknown');}});assert.equal((await resumed.step()).state,'delivery-unconfirmed');assert.equal((await f.state()).pending.requestId,original.pending.requestId);assert.equal(writes,1);
 }
}));

test('HTTP401/403 halt credential retries with the same pending body, including HTML or missing bodies',async()=>{
 for(const status of [401,403])for(const shape of ['json','html','empty'])await fixture(async f=>{
  let writes=0,waits=0;const publisher=await f.create({fetcher:async()=>{writes++;return shape==='json'?Response.json({error:'Authentication required'},{status}):new Response(shape==='html'?'<html>Sign in</html>':null,{status});}});
  const result=await publisher.step(),saved=await f.state();assert.equal(result.state,'authentication-required');assert.equal(result.halt,true);assert.equal(saved.pending.requestId,result.receiptId);assert.equal(saved.pending.revision,1);assert.equal(saved.pending.outcome,shape==='json'?'not-applied':'unknown');assert.equal(saved.pending.hadUnknown,shape!=='json');assert.equal(saved.lastReceipt,null);
  const bytes=await readFile(f.stateFile,'utf8');assert.equal((await publisher.step()).halt,true);await publisher.run({wait:async()=>{waits++;}});assert.equal(writes,1);assert.equal(waits,0);assert.equal(f.observations,1);assert.equal(await readFile(f.stateFile,'utf8'),bytes);
 });
});

test('authentication refusal after an unknown original effect never changes it to a known nonwrite',async()=>fixture(async f=>{
 let writes=0;const publisher=await f.create({fetcher:async()=>{if(++writes===1)throw Error('Original effect unavailable');return Response.json({error:'Authentication required'},{status:403});}});await publisher.step();const original=await f.state(),beforeBody=JSON.stringify(original.pending.body);const result=await publisher.step(),saved=await f.state();assert.equal(result.state,'authentication-required');assert.equal(result.halt,true);assert.equal(saved.pending.outcome,'unknown');assert.equal(saved.pending.hadUnknown,true);assert.equal(saved.pending.requestId,original.pending.requestId);assert.equal(saved.pending.revision,original.pending.revision);assert.equal(saved.pending.reservedUtc,original.pending.reservedUtc);assert.equal(JSON.stringify(saved.pending.body),beforeBody);assert.equal(saved.lastReceipt,null);
}));
