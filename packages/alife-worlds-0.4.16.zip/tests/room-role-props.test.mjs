import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const art=readFileSync(new URL('../web/agent-outpost/colony-art.js',import.meta.url),'utf8'),renderer=readFileSync(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8');
const sandbox=vm.createContext({});vm.runInContext(art,sandbox);const painter=sandbox.AlifeColonyArt.create();
function canvas(){const ops=[],state={globalAlpha:1},stack=[];return{ops,ctx:new Proxy(state,{get(o,k){if(k==='save')return()=>stack.push({...o});if(k==='restore')return()=>{const old=stack.pop();for(const key of Object.keys(o))delete o[key];Object.assign(o,old);};if(k in o)return o[k];return(...args)=>ops.push([k,...args,o.fillStyle,o.strokeStyle]);},set(o,k,v){o[k]=v;return true;}})};}

test('real role prop painter supplies distinct workstations and stable agent variation without mutating room geometry/state',()=>{
 const roles=['director','support','world-requests','cleanup','special-forces','technical-support','optimizer','piper','intake','release','git-merger','research','docs','planner','test-engineer','worker','web-developer','native-coordinator','dispatch','followthrough','shaping'];const traces=[];
 for(const role of roles){const input={x:10,y:20,w:190,h:90,artScale:1,role,id:47,state:'Sleeping'},before=JSON.stringify(input),a=canvas(),b=canvas();painter.paintRoom(a.ctx,input,10);painter.paintRoom(b.ctx,input,10);assert.equal(JSON.stringify(input),before);assert.deepEqual(a.ops,b.ops);assert.ok(a.ops.length>20);traces.push(JSON.stringify(a.ops));}
 assert.equal(new Set(traces).size,roles.length);
 const one=canvas(),two=canvas();painter.paintRoom(one.ctx,{x:0,y:0,w:180,h:80,role:'worker',id:1},0);painter.paintRoom(two.ctx,{x:0,y:0,w:180,h:80,role:'worker',id:2},0);assert.notDeepEqual(one.ops,two.ops);
});

test('selection changes detail/contrast while the actual room input and retirement state remain intact',()=>{
 const room={x:0,y:0,w:180,h:80,role:'research',id:3,state:'Sleeping'},plain=canvas(),focus=canvas(),retired=canvas();painter.paintRoom(plain.ctx,room,1);painter.paintRoom(focus.ctx,{...room,focused:true},1);assert.notDeepEqual(plain.ops,focus.ops);painter.paintRoom(retired.ctx,{...room,state:'retirement',focused:true},1);assert.ok(retired.ops.length>0);assert.equal(room.state,'Sleeping');
});

function chunk(source,name){const start=source.indexOf('function '+name+'(');let depth=0,quote=null,escape=false;for(let i=source.indexOf('{',start);i<source.length;i++){const c=source[i];if(quote){if(escape)escape=false;else if(c==='\\')escape=true;else if(c===quote)quote=null;continue;}if(c==='"'||c==="'"||c==='`'){quote=c;continue;}if(c==='{')depth++;else if(c==='}'&&--depth===0)return source.slice(start,i+1);}throw Error('Missing function');}
test('actual renderer passes focus only for a selected inspectable room and preserves its real role/state',()=>{
 const room={x:30,y:40,w:180,h:80},station={key:'worker',agent:{role:'worker'},status:'Sleeping'},paint=[];let inspect=false;const context={woodlandActive:()=>true,layout:{places:new Map([['worker',{room,uiRoomPlaqueOffsets:{propsDy:8}}]])},roomKind:()=> 'worker',ctx:{save(){},restore(){},translate(){}},woodland:{paintRoom:(ctx,r,time)=>paint.push({r,time})},sceneHill:()=>({artScale:1}),sceneHash:()=>19,operational:()=>inspect,selected:'worker',roomLensKey:'',clock:7};vm.runInNewContext(chunk(renderer,'sceneDrawRoom'),context);context.sceneDrawRoom(station);assert.equal(paint.at(-1).r.focused,false);inspect=true;context.sceneDrawRoom(station);assert.equal(paint.at(-1).r.focused,true);context.selected='other';context.sceneDrawRoom(station);assert.equal(paint.at(-1).r.focused,false);assert.equal(paint.at(-1).r.role,'worker');assert.equal(paint.at(-1).r.state,'Sleeping');assert.deepEqual(room,{x:30,y:40,w:180,h:80});
});

test('shared and actual launcher art/renderer entries remain exact aliases',()=>{
 assert.equal(art,readFileSync(new URL('../web/launcher-world113/art.js',import.meta.url),'utf8'));assert.equal(renderer,readFileSync(new URL('../web/launcher-world113/renderer.js',import.meta.url),'utf8'));
});
