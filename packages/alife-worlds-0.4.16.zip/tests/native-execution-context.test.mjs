import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm,symlink} from 'node:fs/promises';
import path from 'node:path';import os from 'node:os';import {DatabaseSync} from 'node:sqlite';
import {readBoundNativeExecutionContext} from '../lib/native-archive-index.mjs';
import {nativeSessionMetadata} from '../lib/world-bootstrap.mjs';
const id='10000000-0000-0000-0000-000000000001';
async function fixture(){
 const base=await mkdtemp(path.join(os.tmpdir(),'alife-context-')),root=path.join(base,'project'),home=path.join(base,'codex'),executionCwd=path.join(root,'.git'),sessionPath=path.join(base,'session.jsonl');
 await mkdir(executionCwd,{recursive:true});await mkdir(home);
 await writeFile(sessionPath,JSON.stringify({type:'session_meta',payload:{id,cwd:root}})+'\n');
 const dbFile=path.join(home,'state_5.sqlite'),db=new DatabaseSync(dbFile);db.exec('CREATE TABLE threads(id TEXT PRIMARY KEY,rollout_path TEXT,cwd TEXT,archived INTEGER,model TEXT,title TEXT)');
 const set=(values={})=>{const r={id,rollout_path:sessionPath,cwd:executionCwd,archived:0,...values};db.prepare('DELETE FROM threads').run();db.prepare('INSERT INTO threads VALUES(?,?,?,?,?,?)').run(r.id,r.rollout_path,r.cwd,r.archived,'not-applied','PRIVATE_FIXTURE_CONTENT');};set();
 const options={threadId:id,sessionPath,executionCwd,codexHome:home};
 return {base,root,home,executionCwd,sessionPath,dbFile,db,set,options,async close(){db.close();assert(path.resolve(base).startsWith(path.resolve(os.tmpdir())+path.sep));await rm(base,{recursive:true,force:true});}};
}
test('exact active thread/session/cwd index proof is read-only and contains no settings/content',async()=>{
 const f=await fixture();try{const before=await readFile(f.dbFile);const v=await readBoundNativeExecutionContext(f.options);assert.deepEqual(v,{threadId:id,sessionPath:f.sessionPath,cwd:f.executionCwd,source:'native-index'});assert(!JSON.stringify(v).includes('PRIVATE_FIXTURE_CONTENT'));assert(!Object.hasOwn(v,'model'));assert.deepEqual(await readFile(f.dbFile),before);
 if(process.platform==='win32'){f.set({cwd:'\\\\?\\'+f.executionCwd});assert.equal((await readBoundNativeExecutionContext(f.options)).cwd,f.executionCwd);}
 }finally{await f.close();}
});
test('foreign or missing identity/session/cwd/archive index evidence never authorizes context',async()=>{
 const f=await fixture();try{for(const change of [{id:'20000000-0000-0000-0000-000000000002'},{rollout_path:path.join(f.base,'other.jsonl')},{cwd:f.root},{cwd:null},{archived:1},{archived:null}]){f.set(change);assert.equal(await readBoundNativeExecutionContext(f.options),null);}
 f.set();assert.equal(await readBoundNativeExecutionContext({...f.options,codexHome:path.join(f.base,'absent')}),null);
 assert.equal(await readBoundNativeExecutionContext({...f.options,threadId:'invalid'}),null);
 }finally{await f.close();}
});
test('redirected native session evidence is rejected',async t=>{
 const f=await fixture();try{const alias=path.join(f.base,'alias.jsonl');try{await symlink(f.sessionPath,alias,'file');}catch(e){if(['EPERM','EACCES'].includes(e.code)){t.skip('Host cannot create an isolated symlink fixture');return;}throw e;}f.set({rollout_path:alias});assert.equal(await readBoundNativeExecutionContext({...f.options,sessionPath:alias}),null);}finally{await f.close();}
});
test('header and explicit mapped context checks retain their fail-closed behavior',async()=>{
 const f=await fixture();try{const header=JSON.stringify({type:'session_meta',payload:{id,cwd:f.root}})+'\n';const opts={threadId:id,projectRoot:f.root,executionCwd:f.executionCwd};
 await writeFile(f.sessionPath,header+JSON.stringify({type:'turn_context',payload:{cwd:f.executionCwd,model:'fixture-model',reasoning_effort:'low'}})+'\n');const valid=await nativeSessionMetadata(f.sessionPath,opts);assert.equal(valid.cwd,f.executionCwd);assert.equal(valid.applied.model,'fixture-model');
 for(const cwd of [f.root,path.join(f.base,'foreign'),null]){await writeFile(f.sessionPath,header+JSON.stringify({type:'turn_context',payload:{cwd}})+'\n');await assert.rejects(nativeSessionMetadata(f.sessionPath,opts),/Mapped current execution|moved to another project/);}
 await writeFile(f.sessionPath,header+JSON.stringify({type:'turn_context',payload:{cwd:f.executionCwd,thread_id:'20000000-0000-0000-0000-000000000002'}})+'\n');await assert.rejects(nativeSessionMetadata(f.sessionPath,opts),/identity changed/);
 await writeFile(f.sessionPath,JSON.stringify({type:'session_meta',payload:{id:'20000000-0000-0000-0000-000000000002',cwd:f.root}})+'\n');await assert.rejects(nativeSessionMetadata(f.sessionPath,opts),/selected project\/chat/);
 await writeFile(f.sessionPath,JSON.stringify({type:'session_meta',payload:{id,cwd:path.join(f.base,'foreign')}})+'\n');await assert.rejects(nativeSessionMetadata(f.sessionPath,opts),/selected project\/chat/);
 }finally{await f.close();}
});
test('a long no-cwd tail and absent exact native index proof remain unknown',async()=>{
 const f=await fixture();try{const header=JSON.stringify({type:'session_meta',payload:{id,cwd:f.root}})+'\n';const old=JSON.stringify({type:'turn_context',payload:{cwd:f.executionCwd}})+'\n';const padding=(JSON.stringify({type:'fixture_padding',payload:'x'.repeat(1024)})+'\n').repeat(2300);await writeFile(f.sessionPath,header+old+padding);await assert.rejects(nativeSessionMetadata(f.sessionPath,{threadId:id,projectRoot:f.root,executionCwd:f.executionCwd}),/Mapped current execution context is not verified/);const ordinary=await nativeSessionMetadata(f.sessionPath,{threadId:id,projectRoot:f.root});assert.equal(ordinary.cwd,f.root);assert.deepEqual(ordinary.applied,{model:null,reasoningEffort:null,serviceTier:null});}finally{await f.close();}
});
