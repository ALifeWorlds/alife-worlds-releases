import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const root=new URL('../',import.meta.url);
const renderer=readFileSync(new URL('web/agent-outpost/agent-outpost.js',root),'utf8');
const art=readFileSync(new URL('web/agent-outpost/colony-art.js',root),'utf8');
const manifest=JSON.parse(readFileSync(new URL('web/agent-outpost/assets/midnight-colony-reference-20261107/sprites.json',root),'utf8'));
const start=renderer.indexOf(' // Resource readiness comes from settled loaders, never writable DOM flags.');
const end=renderer.indexOf(' const antKey=',start);
assert.ok(start>0&&end>start);
const productionReadiness=renderer.slice(start,end);
const turn=()=>new Promise(resolve=>setImmediate(resolve));

function fixture({font='ready',decodeFailure=false,injected=false,noStylesheet=false}={}){
 const decodes=[];let fontLoads=0,fetches=0;
 class ImageFixture{
  constructor(){this.complete=true;this.naturalWidth=1536;this.naturalHeight=1024;}
  set src(value){this.url=value;queueMicrotask(()=>this.onload());}
  decode(){return new Promise((resolve,reject)=>decodes.push(()=>decodeFailure?reject(Error('decode failed')):resolve()));}
 }
 const document={baseURI:'https://world.invalid/',querySelectorAll:()=>noStylesheet?[]:[{href:'https://world.invalid/agent-outpost/agent-outpost.css'}]};
 if(font!=='missing')document.fonts={load(){fontLoads++;return font==='fail'?Promise.reject(Error('font failed')):Promise.resolve([{status:'loaded'}]);}};
 const context=vm.createContext({module:{exports:{}},URL,Image:ImageFixture,document,location:{origin:'https://world.invalid'},fetch:async()=>{fetches++;return{ok:true,text:async()=>JSON.stringify(manifest)};}});
 vm.runInContext(art,context);
 const api=context.module.exports;
 if(injected)assert.equal(api.provideReferenceAssets({manifest,images:Object.fromEntries(Object.keys(manifest.atlases).map(key=>[key,new ImageFixture()])),fontReady:true}).state,'ready');
 context.woodland=api.create();context.host={dataset:{}};
 vm.runInContext('let disposed=false,snapshot={},layout={},paints=0;function paintTerrain(){paints++;}function placeRoster(){}function draw(){}',context);
 vm.runInContext(productionReadiness,context);
 return{context,decodes,status:()=>JSON.parse(vm.runInContext('JSON.stringify(getResourceStatus())',context)),dispose:()=>vm.runInContext('disposed=true',context),paints:()=>vm.runInContext('paints',context),fontLoads:()=>fontLoads,fetches:()=>fetches};
}

test('resource status waits for every real atlas decode and font settlement, independent of DOM hints',async()=>{
 const f=fixture();assert.equal(f.status().ready,false);
 f.context.host.dataset.artReadiness='ready';f.context.host.dataset.roomFontReadiness='ready';
 await turn();assert.equal(f.decodes.length,4);assert.equal(f.status().font,'ready');assert.equal(f.status().art,'loading');assert.equal(f.status().ready,false);
 for(const decode of f.decodes.slice(0,3))decode();await turn();assert.equal(f.status().ready,false);
 f.decodes[3]();await turn();assert.deepEqual(f.status(),{ready:true,art:'ready',font:'ready',disposed:false});assert.equal(f.paints(),1);
});

test('decode rejection keeps fallback painter and refuses strict resources',async()=>{
 const f=fixture({decodeFailure:true});await turn();for(const decode of f.decodes)decode();await turn();
 assert.deepEqual(f.status(),{ready:false,art:'fallback',font:'ready',disposed:false});
});

for(const font of ['fail','missing'])test(`a ${font} font cannot qualify a decoded world`,async()=>{
 const f=fixture({font});await turn();for(const decode of f.decodes)decode();await turn();
 assert.deepEqual(f.status(),{ready:false,art:'ready',font:'fallback',disposed:false});
});

test('disposal remains false after late load success and does not repaint removed content',async()=>{
 const f=fixture();f.dispose();await turn();for(const decode of f.decodes)decode();await turn();
 assert.deepEqual(f.status(),{ready:false,art:'ready',font:'ready',disposed:true});assert.equal(f.paints(),0);
});

test('verified injected family uses its existing font readiness with no second load or fetch',async()=>{
 const f=fixture({injected:true});await turn();assert.equal(f.status().ready,true);assert.equal(f.fontLoads(),0);assert.equal(f.fetches(),0);
 f.dispose();assert.equal(f.status().ready,false);
});

test('missing real stylesheet base is fallback despite a successful font',async()=>{
 const f=fixture({noStylesheet:true});await turn();assert.equal(f.status().art,'fallback');assert.equal(f.status().ready,false);assert.equal(f.fetches(),0);
});

test('both distributed renderer entry points expose the same mount getter',()=>{
 assert.equal(renderer,readFileSync(new URL('web/launcher-world113/renderer.js',root),'utf8'));
 assert.ok(renderer.includes('return{host,render,destroy,toggleFullscreen,captureVisualState,restoreVisualState,getResourceStatus,'));
});
