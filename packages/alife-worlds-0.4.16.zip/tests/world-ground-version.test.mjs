import test from 'node:test';
import assert from 'node:assert/strict';
import {assertOwnerSiteContext} from '../lib/owner-site.mjs';
import '../web/agent-outpost/agent-outpost.js';
const {groundVersionMark,paintGroundVersion}=globalThis.AgentOutpost;

test('world ground identity stays absent for unknown or malformed releases',()=>{
 for(const value of [null,undefined,'','1.2','01.2.3','1.2.3-beta','World 1.2.3',42,'<script>'])assert.equal(groundVersionMark(value,1200,900,840),null);
 const actual=groundVersionMark('1.7.9',1200,900,840);
 assert.equal(actual.text,'World 1.7.9');assert.equal(actual.x,600);
 assert.equal(groundVersionMark(null,1200,900,840),null);
});

test('ground text keeps a bounded screen size and paints as noninteractive terrain',()=>{
 for(const fit of [.25,.5,1,2]){
  const mark=groundVersionMark('2.0.1',1600,1000,960,fit);
  assert.ok(mark.font*fit>=9&&mark.font*fit<=11);
  assert.ok(mark.y<960&&mark.y<1000);
  const text=[],ctx={save(){},restore(){},fillText(...args){text.push(args);}};
  paintGroundVersion(ctx,mark);assert.equal(text.length,2);assert.ok(text.every(row=>row[0]==='World 2.0.1'&&row[1]===800));
 }
 let calls=0;paintGroundVersion({save(){calls++;}},null);assert.equal(calls,0);
 for(const dimensions of [[0,900,840,1],[1200,0,840,1],[1200,900,840,0],[1200,900,Infinity,1]])assert.equal(groundVersionMark('1.0.0',...dimensions),null);
});

test('owner context keeps actual world release separate from website and renderer versions',()=>{
 const descriptor={schemaVersion:1,bundleId:'test-renderer',worldVersion:'8.0.0',artifactSha256:'a'.repeat(64)};
 const context={schemaVersion:1,access:'local-owner',worldId:'world-ground-fixture',roles:[{id:'director',title:'Director',role:'director'}],websiteVersion:'9.0.0',worldVersion:null,ownerOrigin:'http://127.0.0.1:12345',publicOrigin:null,framePath:'/operator',projectName:'Fixture',creatorLabel:'Fixture creator',renderer:descriptor,qualifiedGalleryRenderer:descriptor};
 assert.equal(assertOwnerSiteContext(context).worldVersion,null);
 assert.equal(assertOwnerSiteContext({...context,worldVersion:'1.7.9'}).worldVersion,'1.7.9');
 for(const value of ['01.2.3','1.2','next',undefined])assert.throws(()=>assertOwnerSiteContext({...context,worldVersion:value}));
 assert.equal(context.worldVersion,null);assert.equal(descriptor.worldVersion,'8.0.0');
});
