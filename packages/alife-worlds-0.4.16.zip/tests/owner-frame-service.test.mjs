import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createOwnerFrameService} from '../lib/owner-frame-service.mjs';
import {createProjection} from '../lib/projection.mjs';
import {createDemo} from '../lib/demo.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {publicWorldSnapshot} from '../lib/public-world.mjs';
import {createLocalAppearance,canonicalWorldJSON} from '../lib/local-world-appearance.mjs';
import '../web/launcher-world113/renderer.js';

const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const worldId='world-fixture';
const descriptor=(n,version)=>({schemaVersion:1,bundleId:'fixture-scene',worldVersion:version,artifactSha256:n.repeat(64)});
const a=descriptor('a','1.3.4'),b=descriptor('b','1.3.3');
const js=new TextEncoder().encode('/* qualified fixture renderer */'),png=new Uint8Array([137,80,78,71]);
const files=[{path:'web/agent-outpost/agent-outpost.js',sha256:hash(js),bytes:js.length},{path:'web/assets/worker-atlas.png',sha256:hash(png),bytes:png.length}];
const release=renderer=>({renderer,resourceIdentity:'f'.repeat(64),files:structuredClone(files)});
async function envelope(renderer,revision=1){
 const state=await createProjection(registry,createDemo(registry,'working'));state.feed.observedUtc=new Date().toISOString();
 for(const agent of state.model.agents){agent.model=null;agent.modelSpeed=null;agent.reasoningEffort=null;}
 const snapshot=publicWorldSnapshot(state,registry,{worldId});snapshot.model.visualWorldKey='scene-1234567890abcd';
 const appearance=createLocalAppearance(state,registry,snapshot,renderer,{oracle:globalThis.AgentOutpost,digestJSON:hash});
 const names=snapshot.model.agents.map(agent=>({id:agent.threadId,name:'Fixture agent',source:'registry-fallback',observedUtc:null,state:'unknown'}));
 const agents=names.map(agent=>({id:agent.id,modelState:'unknown',modelSource:null,modelObservedUtc:null,selectedState:'unknown',selectedSource:null,selectedObservedUtc:null,presentationSource:'unknown',appliedToken:null}));
 return {schemaVersion:3,kind:'owner-world-preview',worldId,renderer,snapshot,appearance,names,metadata:{revision,contentHash:'c'.repeat(64),agents}};
}
function fixture(overrides={}){
 const config={worldId,access:'owner-private',ownerOrigin:'https://fixture.invalid',websiteVersion:'1.1.5',readReleases:async()=>({current:release(a),previous:release(b)}),readSnapshot:envelope,readAsset:async(_,row)=>row.path.endsWith('.png')?png:js,readClientModule:async()=>js,renderFrame:context=>'<meta name="alife-owner-context" content="'+context.framePath+'context"><script type="module" src="/owner-frame-client.mjs"></script>',...overrides};
 const service=createOwnerFrameService(config);
 return {config,call:(route,options={})=>{const {ownerAuthorized=true,...init}=options;return service.ownerFrameResponse(new Request(config.ownerOrigin+route,init),{ownerAuthorized});}};
}
const frame=d=>'/world-frame/'+d.artifactSha256+'/';

test('owner gate, exact world query, allowed methods and immutable path fence run before providers',async()=>{
 let reads=0;const {call}=fixture({readReleases:async()=>{reads++;throw Error();}});
 assert.equal((await call('/api/owner-world-release?project='+worldId,{ownerAuthorized:false})).status,403);
 assert.equal((await call('/api/owner-world-release?project=world-other')).status,404);
 assert.equal((await call('/api/owner-world-release?project='+worldId+'&project='+worldId)).status,404);
 assert.equal((await call('/api/owner-world-release?project='+worldId,{method:'POST'})).status,405);
 assert.equal((await call(frame(a)+'context?unapproved=1')).status,404);
 assert.equal((await call(frame(a)+'assets/agent-outpost/%5csecret.js')).status,404);
 assert.equal(await call('/unrelated'),null);assert.equal(reads,0);
});

test('closed release/context contract binds current and qualified previous to actual live envelopes',async()=>{
 let revision=1;const {call}=fixture({readSnapshot:renderer=>envelope(renderer,revision)});
 const result=await(await call('/api/owner-world-release?project='+worldId)).json();
 assert.deepEqual(Object.keys(result),['schemaVersion','kind','worldId','access','ownerOrigin','websiteVersion','current','previous']);
 assert.equal(Object.keys(result.current).length,11);assert.deepEqual(result.current.renderer,a);assert.deepEqual(result.previous.renderer,b);
 assert.deepEqual(result.current.visualStateScope,result.previous.visualStateScope);
 revision=2;
 for(const renderer of [a,b]){const response=await call(frame(renderer)+'snapshot');assert.equal(response.status,200);const value=await response.json();assert.equal(value.metadata.revision,2);assert.deepEqual(value.renderer,renderer);}
 const document=await call(frame(a));assert.equal(document.status,200);assert.match(document.headers.get('content-security-policy'),/frame-ancestors 'self'/);assert.match(await document.text(),new RegExp(a.artifactSha256));
});

test('exact asset bytes are checked; absent, changed and third releases cannot borrow current files',async()=>{
 const {call}=fixture();const asset=frame(a)+'assets/agent-outpost/agent-outpost.js';
 const response=await call(asset);assert.equal(response.status,200);assert.equal(response.headers.get('cache-control'),'no-store');assert.deepEqual(new Uint8Array(await response.arrayBuffer()),js);
 assert.equal((await call(frame(a)+'assets/agent-outpost/private.json')).status,404);
 assert.equal((await call('/world-frame/'+'d'.repeat(64)+'/context')).status,404);
 const changed=fixture({readAsset:async()=>new Uint8Array(js.length)});assert.equal((await changed.call(asset)).status,503);
 const head=await call(asset,{method:'HEAD'});assert.equal(head.status,200);assert.equal(await head.text(),'');
});

test('cosmetic scope follows real art/resource identity/audience and never substitutes missing world key',async()=>{
 const context=async overrides=>await(await fixture(overrides).call(frame(a)+'context')).json();
 const initial=await context({});
 const changedArt=await context({readReleases:async()=>{const current=release(a);current.files[1].sha256='e'.repeat(64);return {current,previous:null};}});
 assert.notEqual(initial.visualStateScope.artKey,changedArt.visualStateScope.artKey);
 const changedIdentity=await context({readReleases:async()=>({current:{...release(a),resourceIdentity:'e'.repeat(64)},previous:null})});
 assert.notEqual(initial.visualStateScope.artKey,changedIdentity.visualStateScope.artKey);
 const local=await context({access:'local-owner',ownerOrigin:'http://127.0.0.1:12345'});assert.notEqual(initial.visualStateScope.audienceKey,local.visualStateScope.audienceKey);
 const missing=await context({readSnapshot:async renderer=>{const value=await envelope(renderer);delete value.snapshot.model.visualWorldKey;value.appearance.snapshotSha256=hash(canonicalWorldJSON(value.snapshot));return value;}});
 assert.equal(missing.visualStateScope,null);
});

test('stale or cross-renderer snapshots fail without freshening observations or blocking the valid current offer',async()=>{
 const stale=await envelope(b);stale.snapshot.observedUtc=new Date(Date.now()-46000).toISOString();stale.appearance.observedUtc=stale.snapshot.observedUtc;stale.appearance.snapshotSha256=hash(canonicalWorldJSON(stale.snapshot));const originalObserved=stale.snapshot.observedUtc;
 const {call}=fixture({readSnapshot:renderer=>renderer.artifactSha256===b.artifactSha256?structuredClone(stale):envelope(renderer)});
 assert.equal((await call(frame(b)+'snapshot')).status,503);
 const offer=await(await call('/api/owner-world-release?project='+worldId)).json();assert.deepEqual(offer.current.renderer,a);assert.equal(offer.previous,null);
 const wrong=fixture({readSnapshot:()=>envelope(b)});assert.equal((await wrong.call(frame(a)+'snapshot')).status,503);
 assert.equal(stale.snapshot.observedUtc,originalObserved);
});

test('per-artifact publisher adapter remains service-only and receives the exact qualified descriptor',async()=>{
 let seen=null;const {call}=fixture({writeSnapshot:async(renderer,request)=>{seen=renderer;assert.equal(await request.text(),'fixture');return new Response('{"ok":true}',{headers:{'content-type':'application/json'}});}});
 const route=frame(b)+'snapshot';
 assert.equal((await call(route,{method:'PUT',body:'fixture',headers:{Origin:'https://fixture.invalid'}})).status,403);assert.equal(seen,null);
 assert.equal((await call(route,{method:'PUT',body:'fixture'})).status,200);assert.deepEqual(seen,b);
});

test('frame bootstrap preserves nullable actual world release independently of compatibility descriptor',async()=>{
 let actual='unobserved';
 const build=(context,{worldVersion})=>{actual=worldVersion;return '<meta name="alife-owner-context" content="'+context.framePath+'context"><meta name="alife-world-version" content="'+String(worldVersion)+'"><script type="module" src="/owner-frame-client.mjs"></script>';};
 assert.equal((await fixture({renderFrame:build}).call(frame(a))).status,200);assert.equal(actual,null);
 assert.equal((await fixture({renderFrame:build,readWorldVersion:()=>a.worldVersion}).call(frame(a))).status,200);assert.equal(actual,a.worldVersion);
 assert.equal((await fixture({renderFrame:build,readWorldVersion:()=>b.worldVersion}).call(frame(a))).status,200);assert.equal(actual,b.worldVersion);
 actual='unobserved';assert.equal((await fixture({renderFrame:build,readWorldVersion:()=>'unconfirmed'}).call(frame(a))).status,503);assert.equal(actual,'unobserved');
});
