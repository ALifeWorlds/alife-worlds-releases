import {customProjectRegistry} from './custom-project-registry.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,mkdir,mkdtemp,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {createProjection,loadRegistry} from '../lib/projection.mjs';
import {createDemo} from '../lib/demo.mjs';
import {createQualifiedFixtureApp} from './qualified-fixture-app.mjs';
import {writeTestConfig} from './test-config.mjs';
import '../web/agent-outpost/agent-outpost.js';
const F=globalThis.AgentOutpost,registry=customProjectRegistry;

test('confirmed native idle rests even with eligible work while eligibility stays separate',async()=>{
 const d=createDemo(registry,'sleeping'),s=await createProjection(registry,d),p=F.project(s.model,s.feed);assert.ok(p.stations.every(a=>a.status==='Sleeping'&&a.sleeping&&!a.working));
 d.tasks.forEach(t=>{t.accepted=true;t.acceptanceEvidence='Synthetic acceptance';t.stage='Done';});const done=await createProjection(registry,d);assert.ok(F.project(done.model,done.feed).stations.every(a=>a.sleeping));
 assert.equal(F.eligibleWorldTask({stage:'Ready'}),true);for(const condition of ['waiting','paused','blocked'])assert.equal(F.eligibleWorldTask({stage:'Ready',condition}),false);assert.equal(F.eligibleWorldTask({stage:'Backlog'}),false);
});

test('resolved retirement never remains a ghost or an unresolved Support incident',async()=>{
 const d=createDemo(registry,'retirement');const before=await createProjection(registry,d),active=F.project(before.model,before.feed);assert.equal(active.supportAlarm.state,'Responding');assert.equal(active.stations.find(a=>a.agent.role==='support').responseActive,true);const a=d.agents.find(a=>a.roleId==='worker1');a.retirementAlert.state='resolved';delete a.failure;a.activityState='idle';const t=d.tasks.find(t=>t.ownerRoleId==='worker1');t.blocker='';t.condition='working';const s=await createProjection(registry,d),p=F.project(s.model,s.feed);assert.equal(p.stations.find(a=>a.agent.roleId==='worker1').status,'Sleeping');assert.equal(p.supportAlarm.active,false);
});

test('a task helper assignment cannot manufacture a native Support incident',async()=>{
 const d=createDemo(registry,'blocked');d.tasks.find(t=>t.ownerRoleId==='worker2').helperRoleId='support';const state=await createProjection(registry,d),p=F.project(state.model,state.feed);assert.equal(p.supportAlarm.active,false);assert.equal(p.supportAlarm.state,'clear');assert.equal(p.stations.find(s=>s.agent.role==='support').responseActive,false);
});

test('gems get one bounded click count, chip to walkable debris and stay broken',()=>{
 const requirements=new Set();for(let i=0;i<80;i++){let calls=0;let g=F.gemRecord('gem-'+i,100,200,()=>calls++===0?.5:i/80);requirements.add(g.required);const required=g.required;for(let hit=1;hit<=required;hit++){g=F.chipGem(g);assert.equal(g.hits,hit);assert.equal(g.broken,hit===required);assert.equal(g.required,required);}assert.equal(F.chipGem(g),g);}assert.deepEqual([...requirements].sort((a,b)=>a-b),[2,3,4,5,6,7,8]);
});

test('dragged delivery duration follows distance with a bounded catch-up speed',()=>{
 const p=d=>[{x:0,y:0},{x:d,y:0}];assert.equal(F.routeDistance(p(950)),950);assert.equal(F.deliveryTravelSeconds(p(950)),10);assert.ok(F.deliveryTravelSeconds(p(950),1.5)<10);const short=F.deliveryTravelSeconds(p(1900),1,.5),far=F.deliveryTravelSeconds(p(3800),1,.5);assert.equal(short,2.5);assert.equal(far,5);assert.ok(1900/short<=95*8);assert.equal(F.deliveryTravelSeconds(p(95),1,10),1);
});

test('ghost motion stays inside its own room, dangling has six moving legs and rescue waits at CPR',()=>{
 const room={x:40,y:200,w:100,h:72};for(let n=0;n<100;n++){const p=F.ghostRoomPosition('support',room,n*.7);assert.ok(p.x>=52&&p.x<=128&&p.y>=212&&p.y<=260);assert.deepEqual(F.ghostRoomPosition('support',room,n*.7),p);}assert.notDeepEqual(F.ghostRoomPosition('support',room,0),F.ghostRoomPosition('support',room,9));assert.equal(F.danglingLegs(0).length,6);assert.notDeepEqual(F.danglingLegs(0),F.danglingLegs(.2));assert.equal(F.rescueVisualPhase({arriving:false}),'travelling');assert.equal(F.rescueVisualPhase({arriving:true,vehicle:'ambulance',elapsed:11,seconds:10}),'lifting');assert.equal(F.rescueVisualPhase({arriving:true,vehicle:'ambulance',elapsed:1000,seconds:10}),'cpr');assert.equal(F.rescueVisualPhase({arriving:true,vehicle:'fire-engine'}),'hose');assert.equal(F.pointSegmentDistance({x:2,y:3},{x:0,y:0},{x:10,y:0}),3);
});

test('bundled Freesound audio matches provenance and only allowlisted sound files are served',async()=>{
 const assets=JSON.parse(await readFile(new URL('../web/assets/audio/LICENSES.json',import.meta.url),'utf8'));for(const a of assets.assets){const bytes=await readFile(new URL('../web/assets/audio/'+a.file,import.meta.url));assert.equal(createHash('sha256').update(bytes).digest('hex'),a.sha256);assert.equal(a.license,'CC0 1.0');assert.ok(a.source.startsWith('https://freesound.org/'));}
 const scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'restoration-test-')),createApp=await createQualifiedFixtureApp(root),app=await createApp({configFile:await writeTestConfig(root)});try{const url=await app.listen(0);for(const a of assets.assets){const r=await fetch(url+'/assets/audio/'+a.file);assert.equal(r.status,200);assert.equal(r.headers.get('content-type'),'audio/mpeg');assert.equal((await r.arrayBuffer()).byteLength,a.bytes);}assert.equal((await fetch(url+'/assets/audio/LICENSES.json')).status,200);assert.equal((await fetch(url+'/api/ant-farm-command',{method:'POST'})).status,503);}finally{await new Promise(resolve=>app.server.close(resolve));assert.ok(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));await rm(root,{recursive:true,force:true});}
});

test('an explicit unresolved retirement alert survives unavailable verification without dispatch',async()=>{
 const d=createDemo(registry,'retirement'),state=await createProjection(registry,d);state.feed.error='Synthetic feed loss';const p=F.project(state.model,state.feed),worker=p.stations.find(s=>s.agent.roleId==='worker1');assert.equal(worker.status,'Retirement Needed');assert.equal(p.supportAlarm.active,true);assert.ok(p.supportAlarm.issues.some(i=>i.key===worker.key&&i.kind==='agent-recovery'));assert.equal(p.stations.find(s=>s.agent.role==='support').responseActive,false);assert.equal(F.recordedFire(worker),false);
});

test('three-hit rocks progressively shrink before the final breakdown',()=>{let g={id:'rock-test',kind:'rock',radius:12,required:3,hits:0,broken:false};g=F.chipGem(g);assert.ok(F.materialRadius(g)<12);g=F.chipGem(g);assert.equal(F.materialRadius(g),6);assert.equal(g.broken,false);g=F.chipGem(g);assert.equal(g.broken,true);});

test('every supported gem hit target retains full size until its own final hit and preserves mineral identity',()=>{
 for(let required=2;required<=8;required++){let g={id:'gem-'+required,kind:'gem',radius:12,required,hits:0,broken:false,reservedBy:'agent-a'};const original={...g};for(let hit=1;hit<=required;hit++){const prior=g;g=F.chipGem(g);assert.notEqual(g,prior);assert.equal(prior.hits,hit-1);assert.equal(g.id,original.id);assert.equal(g.required,required);assert.equal(g.hits,hit);assert.equal(g.broken,hit===required);assert.equal(g.reservedBy,null);assert.equal(F.materialRadius(g),hit===required?original.radius*.3:original.radius);}assert.equal(F.chipGem(g),g);assert.equal(g.hits,required);}
});

test('Support rescue transit keeps a full visible ant silhouette with its vehicle in both art branches',async()=>{const vm=await import('node:vm'),s=await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8'),code=s.slice(s.indexOf(' function sceneDrawWork('),s.indexOf(' function sceneScreenBox('));for(const selected of [false,true]){let ants=0,vehicles=0;const ctx=new Proxy({},{get:(o,k)=>o[k]??(()=>{}),set:(o,k,v)=>(o[k]=v,true)}),x={ctx,clock:0,layout:{roomScale:1},snapshot:{stations:[]},agentMotion:new Map(),roomKind:F.roomKind,wallpaperTarget(){},woodlandActive:()=>selected,woodland:{paintAmbulance(){vehicles++;}},drawAnt(){ants++;},line(){},oval(){},emergencyLights(){}};vm.runInNewContext(code,x);x.sceneDrawWork({key:'support',agent:{role:'support'},color:'#bed0aa'},{x:100,y:200,a:0},{mode:'rescue',vehicle:'ambulance',target:'target',arriving:false});assert.equal(ants,1,'transit may not leave only a name or tiny driver dot');if(selected)assert.equal(vehicles,1);}});


const paritySource=await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8');
function parityFunction(name){const a=paritySource.indexOf(' function '+name+'(');assert.ok(a>=0,name);return paritySource.slice(a,paritySource.indexOf('\n function ',a+2));}
async function placementContext(seed=1,visualWorldKey='scene-0123456789abcd'){
 const vm=await import('node:vm'),math=Object.create(Math);math.random=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);const x={Math:math,model:{visualWorldKey},W:1600,H:1100,HILL_HALF:380,SURFACE_Y:300,scope:'same-canonical-sprint',layout:{width:1600,H:1100,walkBottom:1000,bodyRadius:29,places:new Map(),travelCorridors:[]},fieldSerial:seed*11,fieldLayoutKey:'',fieldSupplies:[],gemSerial:seed*13,gemLayout:'',miningGems:[],parkedGems:[],placingLayoutMaterials:false,supplies:[],agentMotion:new Map(),carriers:[],navCache:new Map(),woodlandActive:()=>true,sceneHill:()=>({artScale:1}),fixedObstacles:()=>[],clearSegment:p=>p.x>=130,pointSegmentDistance:F.pointSegmentDistance,miningLayoutKey:F.miningLayoutKey,gemRecord:F.gemRecord,placementRandom:F.placementRandom,placementSeed:F.placementSeed,clamp:(n,a,b)=>Math.max(a,Math.min(b,n))};vm.runInNewContext(['placementScope','placementStream','spawnFieldGrass','rebuildFieldGrass','spawnMiningGem','rebuildMiningGems'].map(parityFunction).join('\n'),x);return x;
}
test('actual initial grass and mineral rebuilds ignore ambient RNG and prior page serials, but isolate worlds and preserve broken reflow state',async()=>{
 const a=await placementContext(1),b=await placementContext(99);a.rebuildFieldGrass();b.rebuildFieldGrass();a.rebuildMiningGems();b.rebuildMiningGems();const clean=v=>JSON.parse(JSON.stringify(v));assert.deepEqual(clean(a.fieldSupplies),clean(b.fieldSupplies));assert.deepEqual(clean(a.miningGems),clean(b.miningGems));assert.equal(a.fieldSupplies.length,5);assert.equal(a.miningGems.length,28);assert.equal(new Set(a.miningGems.map(g=>g.id)).size,28);
 for(let i=0;i<200;i++)a.Math.random();a.rebuildFieldGrass();a.rebuildMiningGems();assert.deepEqual(clean(a.fieldSupplies),clean(b.fieldSupplies));assert.deepEqual(clean(a.miningGems),clean(b.miningGems));const other=await placementContext(1,'scene-fedcba98765432');other.rebuildFieldGrass();assert.notDeepEqual(clean(a.fieldSupplies),clean(other.fieldSupplies));
 const broken=a.miningGems[0];Object.assign(broken,{broken:true,hits:broken.required});const saved=clean(broken);a.W=1900;a.H=1300;Object.assign(a.layout,{width:1900,H:1300,walkBottom:1200});a.rebuildMiningGems();const retained=a.miningGems.find(g=>g.id===saved.id);assert.equal(retained.broken,true);assert.equal(retained.hits,saved.hits);assert.equal(retained.required,saved.required);assert.equal(retained.kind,saved.kind);assert.equal(new Set(a.miningGems.map(g=>g.id)).size,a.miningGems.length);
});
test('keyed placement streams are independent by feature/entity/attempt and dynamic interactions retain their own random choice',async()=>{
 const sample=(feature,entity,attempt=0)=>{const r=F.placementRandom('scene-0123456789abcd',feature,entity,attempt);return Array.from({length:6},()=>r());},expected=sample('grass',2);for(let i=0;i<100;i++)sample('dust',i);assert.deepEqual(sample('grass',2),expected);assert.notDeepEqual(sample('grass',3),expected);assert.notDeepEqual(sample('grass',2,1),expected);assert.notDeepEqual(sample('gem',2),expected);assert.ok(expected.every(v=>v>=0&&v<1));const a=await placementContext(1),b=await placementContext(99);assert.notEqual(a.spawnFieldGrass().x,b.spawnFieldGrass().x);
});
test('production blocked rock anchors match across canonical/public IDs and reordered equivalent tasks',async()=>{
 const vm=await import('node:vm'),run=(ids,reverse=false)=>{let rows=ids.map((id,i)=>({id,visualKey:'visual-'+String(i+1).padStart(14,'0')}));if(reverse)rows.reverse();const x={model:{visualWorldKey:'scene-0123456789abcd'},W:1600,SURFACE_Y:300,clock:0,layout:{walkBottom:1000,bodyRadius:29,places:new Map()},snapshot:{blockedPackages:rows,tasks:rows},sceneRockCacheKey:'',sceneRockCache:[],sceneRockArrivals:new Map(),navCache:new Map(),fixedObstacles:()=>[],clearSegment:()=>true,progressForRock:()=>0,clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),placementSeed:F.placementSeed};vm.runInNewContext(parityFunction('sceneHash')+parityFunction('sceneRocks'),x);return JSON.parse(JSON.stringify(x.sceneRocks().map(p=>({x:p.x,y:p.y,radius:p.radius}))));};assert.deepEqual(run(['canonical-a','canonical-b']),run(['work-aaaaaaaaaaaaaa','work-bbbbbbbbbbbbbb'],true));
});
test('production fallback pond placement is independent of ambient RNG while honoring its existing geometry guards',async()=>{
 const vm=await import('node:vm'),run=seed=>{const math=Object.create(Math);math.random=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);const rooms=[{x:0,y:680,w:170,h:120},{x:830,y:680,w:170,h:120}],x={Math:math,model:{visualWorldKey:'scene-0123456789abcd'},W:1000,H:900,SURFACE_Y:170,scope:'pond',layout:{wide:false,referenceArt:false,walkBottom:800,bodyRadius:12,roomScale:1,bank:{x:500,y:190,label:{x:480,y:200,w:40,h:14}},places:new Map(rooms.map((room,i)=>[i,{room}]))},snapshot:{stations:[],qaPackages:[],blockedPackages:[]},host:{dataset:{fitScale:1}},qaStackGeometry:()=>({}),parcelGeometry:()=>({}),woodlandActive:()=>false,placementRandom:F.placementRandom,waterGeometry:F.waterGeometry,sceneHill:()=>({shaft:{x:500,y:190}}),routePath:(a,b)=>[a,b],routePathRaw:(a,b)=>[a,b],supplies:[]};vm.runInNewContext(parityFunction('placementStream')+parityFunction('makeSupplyPiles'),x);return JSON.parse(JSON.stringify(x.makeSupplyPiles()));};const a=run(1),b=run(99);assert.equal(a.length,2);assert.deepEqual(a,b);assert.ok(a.some(p=>Math.abs(p.y-767)>10),'blocked edge anchors must use fallback placement');assert.ok(a.every(p=>p.x>=43.5&&p.x<=956.5));
});
