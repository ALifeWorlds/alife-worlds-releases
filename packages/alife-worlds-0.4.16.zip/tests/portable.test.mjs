import {customProjectRegistry} from './custom-project-registry.mjs';
import {writeTestConfig} from './test-config.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,rm,readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createRequire} from 'node:module';
import {runInNewContext} from 'node:vm';
import {loadRegistry,createProjection} from '../lib/projection.mjs';
import {createDemo} from '../lib/demo.mjs';
import {createApp} from '../server.mjs';
import {createQualifiedFixtureApp} from './qualified-fixture-app.mjs';
import '../web/agent-outpost/agent-outpost.js';
const F=globalThis.AgentOutpost,registry=customProjectRegistry,coreRegistry=await loadRegistry(),require=createRequire(import.meta.url),{createFarmCommandGateway,marker}=require('../lib/farm-command-gateway.cjs');
async function scenario(name){const d=createDemo(registry,name),s=await createProjection(registry,d);return {d,s,p:F.project(s.model,s.feed)};}
const station=(p,id)=>p.stations.find(s=>s.agent.role===id||s.agent.threadId==='demo-'+id);
const emptySnapshot=()=>({observedUtc:new Date().toISOString(),agents:[],tasks:[],events:[]});
const testHome=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));

test('actual renderer projects all 20 roles with required names and four tree exceptions',async()=>{
 const {p}=await scenario('working');assert.equal(F.version,'3.22.0');assert.equal(p.stations.length,20);assert.equal(new Set(p.stations.map(s=>s.agent.threadId)).size,20);
 assert.equal(station(p,'director').agent.title,'Director');assert.equal(station(p,'world-requests').agent.title,'World Requests');assert.equal(p.stations.filter(F.stationHasTree).length,16);
 assert.deepEqual(p.stations.filter(s=>!F.stationHasTree(s)).map(s=>s.agent.role).sort(),['director','native-operator','optimizer','technical-support']);
});
test('empty live data stays disconnected with unknown activity and no metrics or acceptance',async()=>{
 const d=emptySnapshot(),s=await createProjection(registry,d),p=F.project(s.model,s.feed);
 assert.equal(s.roster.filter(a=>a.connected).length,0);assert.ok(p.stations.every(s=>!s.working&&!s.sleeping));assert.equal(p.tasks.length,0);assert.equal(p.telemetry.fps.value,null);assert.equal(p.sprint.accepted,0);
});
test('confirmed idle rests despite task dependencies,empty idle sleeps,and activity updates without reload',async()=>{
 const {d,p}=await scenario('blocked');assert.equal(station(p,'worker2').status,'Sleeping');assert.equal(station(p,'worker2').sleeping,true);assert.equal(p.supportAlarm.active,false);assert.equal(p.blockedPackages.length,1);assert.equal(station(p,'technical-support').repairActive,true);
 d.tasks.find(t=>t.ownerRoleId==='worker2').blocker='';d.tasks.find(t=>t.ownerRoleId==='worker2').condition='working';d.agents.find(a=>a.roleId==='worker2').activityState='working';const next=await createProjection(registry,d),q=F.project(next.model,next.feed);assert.equal(station(q,'worker2').status,'Working');assert.equal(q.blockedPackages.length,0);
 const idle=await scenario('sleeping');assert.ok(idle.p.stations.every(a=>a.status==='Sleeping'&&a.sleeping&&!a.working));assert.ok(idle.d.tasks.length>0);idle.d.tasks=[];for(const a of idle.d.agents)a.taskIds=[];const empty=await createProjection(registry,idle.d);assert.ok(F.project(empty.model,empty.feed).stations.every(a=>a.sleeping));
});
test('stale activity suppresses work rather than awarding movement',async()=>{
 const {p}=await scenario('stale');assert.ok(p.stations.every(s=>!s.working&&!s.sleeping));assert.ok(p.stations.every(s=>s.status==='Activity unavailable'));
});
test('fresh current report outranks retained task blocker and exact repair target is required',async()=>{
 const {d}=await scenario('blocked');const a=d.agents.find(a=>a.roleId==='technical-support');a.taskIds=['example-technical-support'];const s=await createProjection(registry,d),p=F.project(s.model,s.feed);assert.equal(station(p,'technical-support').repairActive,false);
 const v=s.feed.items.find(a=>a.id==='demo-worker2');v.taskIds=['not-in-model'];const q=F.project(s.model,s.feed);assert.equal(station(q,'worker2').task,null);assert.equal(station(q,'worker2').blocker,'');
});
test('evidence is required for completed steps and explicit original outcome acceptance',async()=>{
 const {d}=await scenario('working');d.tasks[0].steps[0].evidence='';d.tasks[0].accepted=true;d.tasks[0].acceptanceEvidence='';d.tasks[0].stage='Done';const s=await createProjection(registry,d);assert.equal(s.model.tasks[0].milestone.steps[0].complete,false);assert.equal(s.model.tasks[0].done,false);
 const a=await scenario('accepted');assert.equal(a.p.sprint.accepted,20);assert.equal(a.p.sprint.percent,100);assert.equal(a.p.deliveries.length,20);
});
test('credits use stable step identities and one QA parcel/publication per unique task/commit',async()=>{
 const {s,p}=await scenario('working');assert.equal(p.qaPackages.length,2);assert.equal(p.originPublications.length,1);const c=s.model.cfg.cards;const first=c['example-git-merger'];c['example-release']={...c['example-release'],publishedCommit:first.publishedCommit,sourcePublication:first.sourcePublication,publicationRemote:'origin',sourcePublicationState:'PUBLISHED_TO_ORIGIN'};
 assert.equal(F.originPublications(s.model).length,1);const again=F.project(s.model,s.feed);assert.equal(again.sprint.units,p.sprint.units);assert.equal(F.changes(p,again).length,0);
});
test('task dependencies cannot sound native Support alarms;actual assigned retirement recovery responds',async()=>{
 for(const name of ['blocked','support']){const {p}=await scenario(name);assert.equal(p.blockedPackages.length,1);assert.equal(p.supportAlarm.active,false);assert.equal(p.supportAlarm.state,'clear');assert.equal(station(p,'support').responseActive,false);}
 const retirement=await scenario('retirement');assert.equal(station(retirement.p,'worker1').status,'Retirement Needed');assert.equal(retirement.p.supportAlarm.active,true);assert.equal(retirement.p.supportAlarm.state,'Responding');assert.equal(station(retirement.p,'support').responseActive,true);assert.ok(retirement.p.supportAlarm.issues.some(i=>i.threadId==='demo-worker1'&&i.kind==='agent-recovery'));
 retirement.d.tasks.find(t=>t.ownerRoleId==='worker1').helperRoleId=null;const state=await createProjection(registry,retirement.d),unassigned=F.project(state.model,state.feed);assert.equal(unassigned.supportAlarm.active,true);assert.equal(station(unassigned,'support').responseActive,false);assert.ok(unassigned.supportAlarm.issues.some(i=>i.threadId==='demo-worker1'&&!i.assigned));
});
test('telemetry and analytics expire without changing old evidence timestamps',async()=>{
 const {s}=await scenario('working');const now=Date.now()+180001;assert.equal(F.telemetryView(s.feed.farmFacts.visualTelemetry,now).fps.value,null);assert.equal(F.telemetryView(s.feed.farmFacts.visualTelemetry,now).resources.clutter,null);assert.equal(F.currentPiperAnalytics(s.feed.farmFacts,now),null);
});
test('original walking and outdoor physics retain six legs and grounded surface route',()=>{
 for(const n of [0,1,8]){assert.equal(F.walkingLegs(n).length,6);assert.equal(F.sideWalkingLegs(n).length,6);}
 const r=F.outdoorGroundRoute(1000,{x:100,y:0},{x:900,y:0});assert.ok(r.length>60);assert.ok(r.every(p=>Math.abs(p.y-(F.outdoorSurface(1000,p.x).y-11))<0.001));assert.equal(F.antPerspective({outside:true}),'side-platform');
});
test('all role geometry fits source layouts without missing rooms',async()=>{
 const {p}=await scenario('working');for(const width of [320,390,1440]){const q=F.fittedGardenLayout(width,900,p.stations);assert.equal(q.layout.places.size,20);assert.ok(Number.isFinite(q.layout.H));assert.ok(q.fit>0);}
});
test('projection refuses duplicated identities,duplicate tasks and unknown handoff roles',async()=>{
 for(const kind of ['identity','task','event']){const {d}=await scenario('working');if(kind==='identity')d.agents[1].instanceId=d.agents[0].instanceId;if(kind==='task')d.tasks.push(d.tasks[0]);if(kind==='event')d.events[0].toRoleId='foreign-role';await assert.rejects(createProjection(registry,d));}
});
test('projection excludes arbitrary source/private fields from public endpoints',async()=>{
 const {d}=await scenario('working');d.secret='private-source-field';d.agents[0].transcript='private-transcript-field';d.analytics.secret='private-analytics-field';d.metrics.game.sourcePath='private-machine-field';const s=await createProjection(registry,d),json=JSON.stringify(s);assert.ok(!json.includes('private-source-field'));assert.ok(!json.includes('private-transcript-field'));assert.ok(!json.includes('private-analytics-field'));assert.ok(!json.includes('private-machine-field'));
});
test('gateway revalidates idle,paused,disconnected and current blocked identities',async()=>{
 const {s}=await scenario('blocked'),g=createFarmCommandGateway();assert.equal(g.resolve({action:'unblock',agentId:'demo-worker2',taskId:'example-worker2'},s).target,'demo-support');
 assert.throws(()=>g.resolve({action:'wake',agentId:'demo-director'},s));s.roster.find(a=>a.role==='support').connected=false;assert.throws(()=>g.resolve({action:'unblock',agentId:'demo-worker2',taskId:'example-worker2'},s));s.clarity.productionCoordination.deliveryPipeline.paused=true;assert.throws(()=>g.resolve({action:'wake',agentId:'demo-worker1'},s));
});
async function withApp({qualifiedFixture=false,...options},fn){await mkdir(testHome,{recursive:true});const dir=await mkdtemp(path.join(testHome,'ant-farm-test-'));try{const factory=qualifiedFixture?await createQualifiedFixtureApp(dir):createApp,app=await factory({configFile:await writeTestConfig(dir),mode:'demo',nativeReadOnly:false,...options,journalPath:path.join(dir,'journal.json')});try{const url=await app.listen(0);await fn(app,url,dir);}finally{await new Promise(resolve=>app.server.close(resolve));}}finally{assert.ok(path.resolve(dir).startsWith(path.resolve(testHome)+path.sep));await rm(dir,{recursive:true,force:true});}}
async function context(url){const html=await(await fetch(url+'/operator')).text();const value=html.match(/window\.FARM_COMMAND_CONTEXT=JSON\.parse\('([^']+)'\)/);assert.ok(value);return JSON.parse(value[1]);}
function action(url,c,sequence,body,extra={}){return fetch(url+'/api/ant-farm-command',{method:'POST',headers:{Origin:url,'Content-Type':'application/json','Sec-Fetch-Site':'same-origin','Sec-Fetch-Dest':'empty','X-Farm-Session':c.session,'X-Farm-CSRF':c.csrf,'X-Farm-Sequence':String(sequence),...extra},body:JSON.stringify(body)});}
test('qualified local server serves exact selected source,blocks config/runtime paths and disables demo commands',async()=>withApp({qualifiedFixture:true},async(app,url)=>{
 const res=await fetch(url);assert.equal(res.status,200);assert.ok(res.headers.get('content-security-policy').includes("frame-ancestors 'none'"));const asset=await fetch(url+'/agent-outpost/agent-outpost.js');assert.equal(asset.status,200);assert.match(asset.headers.get('content-type'),/javascript/);assert.equal(await asset.text(),await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8'));for(const rel of ['antfarm.config.json','runtime/Commands/Journal.json','data/project-state.json','api/state'])assert.equal((await fetch(url+'/'+rel)).status,404);
 const data=await(await fetch(url+'/api/dashboard')).json();assert.equal(data.model.agents.length,coreRegistry.length);assert.equal(data.feed.farmFacts.commands.transportEnabled,false);assert.ok(Object.values(data.feed.farmFacts.commands.agents).every(a=>!a.wake&&!a.retire&&!a.unblockTaskIds.length));
}));
test('unsealed source cannot serve default world assets',async()=>withApp({},async(app,url)=>{
 const response=await fetch(url+'/agent-outpost/agent-outpost.js');assert.equal(response.status,503);assert.deepEqual(await response.json(),{error:'Compatible world resource unavailable'});
}));
test('live empty feed has zero real connected agents',async()=>withApp({mode:'live',adapter:{readSnapshot:async()=>emptySnapshot()}},async(app,url)=>{const d=await(await fetch(url+'/api/dashboard')).json();assert.equal(d.mode,'live');assert.ok(d.model.agents.every(a=>!a.connected));assert.equal(d.model.tasks.length,0);}));
test('command security,repeated intent dedup and queue evidence work without real sends',async()=>{
 let calls=0;const snapshot=createDemo(coreRegistry,'sleeping');await withApp({mode:'live',adapter:{readSnapshot:async()=>snapshot},commandsEnabled:true,commandAdapter:{dispatch:async()=>{calls++;return {state:'queued',nativeQueueId:'example-queue-id',queueAccepted:true,message:'Mock queue'};}}},async(app,url)=>{
 const c=await context(url),body={action:'wake',agentId:'demo-support',requestId:'test-one'};
 assert.equal((await action(url,c,1,body,{'X-Farm-CSRF':'0'.repeat(64)})).status,403);assert.equal(calls,0);
 const a=await(await action(url,c,1,body)).json();assert.equal(a.state,'queued');assert.equal(a.queueAccepted,true);assert.equal(calls,1);
 assert.equal((await action(url,c,1,body)).status,409);await action(url,c,2,body);assert.equal(calls,1);
 const b=await(await action(url,c,3,{...body,requestId:'test-two'})).json();assert.equal(b.coalescedWithRequestId,'test-one');assert.equal(calls,1);
 });
});
test('unknown transport effect is retained and later intent is not replayed',async()=>{
 let calls=0;const snapshot=createDemo(coreRegistry,'sleeping');await withApp({mode:'live',adapter:{readSnapshot:async()=>snapshot},commandsEnabled:true,commandAdapter:{dispatch:async()=>{calls++;throw Error('Mock lost return');}}},async(app,url)=>{
 const c=await context(url),body={action:'wake',agentId:'demo-support',requestId:'unknown-one'};const a=await(await action(url,c,1,body)).json();assert.equal(a.state,'unknown');const b=await(await action(url,c,2,{...body,requestId:'unknown-two'})).json();assert.equal(b.state,'queued');assert.equal(calls,1);
 const browser={AbortSignal},requests=[];runInNewContext(await readFile(new URL('../web/command-exchange.js',import.meta.url),'utf8'),browser);
 const exchange=browser.FarmCommandBrowserExchange.create(null,{origin:url,fetch:async(route,options)=>{requests.push(route);return fetch(new URL(route,url),{...options,headers:{Origin:url,'Sec-Fetch-Site':'same-origin','Sec-Fetch-Dest':'empty',...options.headers}});}});
 const reconnected=await exchange.sendAction({...body,requestId:'unknown-client'});assert.equal(reconnected.state,'queued');assert.equal(requests[0],'/operator');assert.equal(requests.filter(r=>r==='/api/ant-farm-command').length,1);assert.equal(calls,1);
 });
});
