import {writeTestConfig} from './test-config.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,appendFile,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createAdapter} from '../adapters/native-session-adapter.mjs';
import {createProjection,loadRegistry} from '../lib/projection.mjs';
import {createApp} from '../server.mjs';
import '../web/agent-outpost/agent-outpost.js';
const registry=await loadRegistry(),home=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));
const projectId='10000000-0000-0000-0000-000000000000',threadId='20000000-0000-0000-0000-000000000000';
const stamp='2026-11-05T20:00:00.000Z',t0=Date.parse(stamp),row=(type,payload,t=stamp)=>JSON.stringify({type,payload,timestamp:t})+'\n';
async function fixture(fn){
 await mkdir(home,{recursive:true});
 const root=await mkdtemp(path.join(home,'native-test-'));let time=t0;
 const config={projectId,bindingsFile:'bindings.json',stateFile:'state.json'},session=path.join(root,'native.jsonl');
 const bindings={schemaVersion:1,projectId,projectRoot:root,agents:[{id:'world-requests',title:'World Requests',home:'Agent',threadId,hostId:'local',sessionPath:session}]};
 const snapshot={schemaVersion:1,projectId,projectName:'Test project',observedUtc:stamp,agents:[],tasks:[],events:[]};
 const write=async(name,value)=>writeFile(path.join(root,name),JSON.stringify(value));
 await mkdir(path.join(root,'Agent'));
 await write('bindings.json',bindings);await write('state.json',snapshot);
 await writeFile(session,row('session_meta',{id:threadId,cwd:root})+row('turn_context',{cwd:root,model:'gpt-6-astra',effort:'xhigh'})+row('event_msg',{type:'thread_settings_applied',thread_id:threadId,thread_settings:{cwd:root,service_tier:'default'}}));
 const adapter=createAdapter({root,config,registry,now:()=>time});
 const agent=async()=>((await adapter.readSnapshot()).agents.find(a=>a.roleId==='world-requests'));
 try{await fn({root,config,session,bindings,snapshot,write,adapter,agent,setTime:t=>time=t,append:async(p,t=stamp)=>appendFile(session,row('event_msg',p,t))});}
 finally{assert.ok(path.resolve(root).startsWith(path.resolve(home)+path.sep));await rm(root,{recursive:true,force:true});}
}

test('only verified exact session ID and cwd can connect; foreign records refused',async()=>{
 for(const kind of ['id','cwd'])await fixture(async f=>{
  await writeFile(f.session,row('session_meta',{id:kind==='id'?'30000000-0000-0000-0000-000000000000':threadId,cwd:kind==='cwd'?path.dirname(f.root):f.root})+row('event_msg',{type:'task_started'}));
  const a=await f.agent();assert.equal(a.connected,false);assert.equal(a.instanceId,null);assert.equal(a.connectionState,'refused');
 });
});
test('foreign binding root, project ID and duplicate role/thread/session/home fail closed',async()=>{
 for(const kind of ['root','project','role','thread','session','home'])await fixture(async f=>{
  if(kind==='root')f.bindings.projectRoot=path.dirname(f.root);
  else if(kind==='project')f.bindings.projectId='foreign';
  else {const b={...f.bindings.agents[0],id:'worker1',home:'Other',threadId:'30000000-0000-0000-0000-000000000000',sessionPath:path.join(f.root,'other.jsonl')};b[{role:'id',thread:'threadId',session:'sessionPath',home:'home'}[kind]]=f.bindings.agents[0][{role:'id',thread:'threadId',session:'sessionPath',home:'home'}[kind]];f.bindings.agents.push(b);}
  await f.write('bindings.json',f.bindings);await assert.rejects(f.adapter.readSnapshot());
 });
});
test('missing session is unconfirmed; missing file unavailable; unknown native activity never works',async()=>fixture(async f=>{
 let a=await f.agent();assert.equal(a.connected,true);assert.equal(a.activityState,'unknown');
 f.bindings.agents[0].sessionPath=null;await f.write('bindings.json',f.bindings);a=await f.agent();assert.equal(a.connectionState,'unconfirmed');
 f.bindings.agents[0].sessionPath=path.join(f.root,'missing.jsonl');await f.write('bindings.json',f.bindings);a=await f.agent();assert.equal(a.connectionState,'unavailable');assert.equal(a.connected,false);
}));
test('actual lifecycle timestamps persist through polls; stale work expires; terminal idle is durable',async()=>fixture(async f=>{
 await f.append({type:'task_started',turn_id:'turn-1'});let a=await f.agent();assert.equal(a.activityState,'working');assert.equal(a.observedUtc,stamp);
 f.setTime(t0+60000);assert.equal((await f.agent()).observedUtc,stamp);
 f.setTime(t0+120001);a=await f.agent();assert.equal(a.activityState,'unknown');assert.equal(a.connectionState,'unavailable');assert.equal(a.observedUtc,stamp);
 const end=new Date(t0+130000).toISOString();await f.append({type:'task_complete',turn_id:'turn-1',last_agent_message:'SECRET'},end);f.setTime(t0+3600000);a=await f.agent();assert.equal(a.activityState,'idle');assert.equal(a.terminal,true);assert.equal(a.observedUtc,end);
 await f.append({type:'item_completed',turn_id:'turn-1',item:{type:'AgentMessage',content:'SECRET'}},end);assert.equal((await f.agent()).activityState,'idle');
 await f.append({type:'task_started',turn_id:'turn-2'},new Date(t0+3600000).toISOString());a=await f.agent();assert.equal(a.activityState,'working');assert.equal(a.terminal,false);
}));
test('waiting, intentional stop, resumed activity and future timestamps are distinct',async()=>fixture(async f=>{
 await f.append({type:'approval_requested',turn_id:'turn-1'});assert.equal((await f.agent()).activityState,'waiting');
 await f.append({type:'turn_aborted',turn_id:'turn-1'});assert.equal((await f.agent()).activityState,'idle');
 await f.append({type:'task_resumed',turn_id:'turn-2'});assert.equal((await f.agent()).activityState,'working');
 await f.append({type:'task_started',turn_id:'turn-3'},new Date(t0+100000).toISOString());assert.equal((await f.agent()).activityState,'unknown');
}));
test('safe receipt/checkpoint allowlists and native model settings exclude private content',async()=>fixture(async f=>{
 const identity={schemaVersion:1,projectId,roleId:'world-requests',threadId,workspacePath:f.root,homePath:path.join(f.root,'Agent')};
 await f.write('Agent/receipt.json',{...identity,accessVerified:true,contractsFullRead:true,retirementVersion:1,prompt:'SECRET-RECEIPT'});
 await f.write('Agent/checkpoint.json',{...identity,status:'ready',taskIds:[],fullInstructions:'SECRET-CONTRACT'});
 await f.append({type:'thread_settings_applied',thread_id:threadId,thread_settings:{model:'gpt-6-astra',service_tier:'priority',reasoning_effort:'xhigh',credentials:'SECRET-SETTINGS'}});
 await f.append({type:'item_completed',turn_id:'turn-1',item:{type:'CommandExecution',command:'SECRET-COMMAND',aggregated_output:'SECRET-OUTPUT'}});
 await appendFile(f.session,row('response_item',{type:'reasoning',content:'SECRET-REASONING'}));
 const a=await f.agent();assert.equal(a.onboarded,true);assert.equal(a.checkpointStatus,'ready');assert.equal(a.model,'gpt-6-astra');assert.equal(a.reasoningEffort,'xhigh');assert.equal(a.serviceTier,'priority');
 const s=await createProjection(registry,await f.adapter.readSnapshot(),t0);assert.equal(s.model.agents.find(a=>a.role==='world-requests').modelSpeed.serviceTier,'priority');assert.ok(!JSON.stringify(s).includes('SECRET'));assert.ok(!JSON.stringify(s).includes(f.root.replaceAll('\\','\\\\')));
}));
test('full applied settings clear an omitted tier without inferring Standard or retaining fast',async()=>fixture(async f=>{
 await f.append({type:'task_started',turn_id:'turn-1'});
 let settingsAt=t0;const settingsTime=()=>new Date(++settingsAt).toISOString();
 for(const replacement of [{},{service_tier:null},{service_tier:'unsupported'}]){
  await f.append({type:'thread_settings_applied',thread_id:threadId,thread_settings:{model:'gpt-6-astra',service_tier:'priority'}},settingsTime());
  assert.equal((await f.agent()).serviceTier,'priority');
  await f.append({type:'thread_settings_applied',thread_id:threadId,thread_settings:{model:'gpt-6.1-sol',reasoning_effort:'xhigh',...replacement}},settingsTime());
  const a=await f.agent();assert.equal(a.serviceTier,null);assert.equal(a.model,'gpt-6.1-sol');assert.equal(a.observedUtc,stamp);
  const s=await createProjection(registry,await f.adapter.readSnapshot(),t0),speed=s.model.agents.find(a=>a.roleId==='world-requests').modelSpeed;
  assert.equal(speed.known,false);assert.equal(speed.serviceTier,null);assert.equal(speed.fast,false);
  const cold=createAdapter({root:f.root,config:f.config,registry,now:()=>t0});assert.equal((await cold.readSnapshot()).agents.find(a=>a.roleId==='world-requests').serviceTier,null);
 }
 await f.append({type:'thread_settings_applied',thread_id:threadId,thread_settings:{service_tier:'default'}},settingsTime());assert.equal((await f.agent()).serviceTier,'default');
 await appendFile(f.session,row('turn_context',{cwd:f.root,model:'gpt-6.1-sol',effort:'xhigh'},settingsTime()));assert.equal((await f.agent()).serviceTier,'default');
 const s=await createProjection(registry,await f.adapter.readSnapshot(),t0),speed=s.model.agents.find(a=>a.roleId==='world-requests').modelSpeed;
 assert.equal(speed.known,true);assert.equal(speed.serviceTier,'default');assert.equal(speed.fast,false);
}));
test('binding edits and canonical task edits load without restarting the adapter',async()=>fixture(async f=>{
 assert.equal((await f.adapter.readSnapshot()).tasks.length,0);
 f.snapshot.tasks.push({id:'real-task',ownerRoleId:'world-requests',title:'Actual assignment',stage:'In Progress',steps:[]});await f.write('state.json',f.snapshot);
 assert.equal((await f.adapter.readSnapshot()).tasks.length,1);
 f.bindings.agents[0].threadId='30000000-0000-0000-0000-000000000000';await f.write('bindings.json',f.bindings);assert.equal((await f.agent()).connected,false);
 await writeFile(f.session,row('session_meta',{id:f.bindings.agents[0].threadId,cwd:f.root})+row('event_msg',{type:'task_complete'}));assert.equal((await f.agent()).instanceId,f.bindings.agents[0].threadId);
}));
test('cwd drift, malformed completed rows and oversized read gaps fail safely',async()=>fixture(async f=>{
 await appendFile(f.session,row('turn_context',{cwd:path.dirname(f.root),model:'foreign'}));assert.equal((await f.agent()).connected,false);
 await writeFile(f.session,row('session_meta',{id:threadId,cwd:f.root})+row('event_msg',{type:'task_complete'}));assert.equal((await f.agent()).activityState,'idle');
 await appendFile(f.session,row('response_item',{type:'message',content:'x'.repeat(2*1024*1024+100)}));assert.equal((await f.agent()).activityState,'unknown');
 await f.append({type:'task_started',turn_id:'new'});assert.equal((await f.agent()).activityState,'working');
 await appendFile(f.session,'{invalid}\n');assert.equal((await f.agent()).connected,false);
}));
test('partial native lines do not fabricate work and complete on the next read',async()=>fixture(async f=>{
 const event=row('event_msg',{type:'task_started',turn_id:'new'});await appendFile(f.session,event.slice(0,20));assert.equal((await f.agent()).activityState,'unknown');await appendFile(f.session,event.slice(20));assert.equal((await f.agent()).activityState,'working');
}));
test('renderer expires per-agent work while retaining terminal idle under a fresh feed',async()=>{
 const now=Date.now(),old=new Date(now-240000).toISOString(),d={observedUtc:new Date(now).toISOString(),agents:[{roleId:'world-requests',instanceId:threadId,connected:true,observedUtc:old,activityState:'working'}],tasks:[],events:[]};
 let s=await createProjection(registry,d),p=globalThis.AgentOutpost.project(s.model,s.feed);let a=p.stations.find(s=>s.agent.role==='world-requests');assert.equal(a.status,'Activity unavailable');assert.equal(a.working,false);
 d.agents[0].activityState='idle';d.agents[0].terminal=true;s=await createProjection(registry,d);p=globalThis.AgentOutpost.project(s.model,s.feed);a=p.stations.find(s=>s.agent.role==='world-requests');assert.equal(a.sleeping,true);
 s.feed.observedUtc=old;p=globalThis.AgentOutpost.project(s.model,s.feed);assert.equal(p.stations.find(s=>s.agent.role==='world-requests').sleeping,false);
});
test('native read-only server rejects command transport and protects private endpoint paths',async()=>fixture(async f=>{
 let calls=0;const app=await createApp({configFile:await writeTestConfig(f.root),mode:'live',nativeReadOnly:true,commandsEnabled:true,commandAdapter:{dispatch:async()=>{calls++;}},adapter:f.adapter,journalPath:path.join(f.root,'journal.json')});
 try{const url=await app.listen(0);const r=await fetch(url+'/api/ant-farm-command',{method:'POST',headers:{'Content-Type':'application/json',Origin:url},body:JSON.stringify({action:'wake',agentId:'foreign-thread',requestId:'attempt'})});assert.equal(r.status,503);assert.equal(calls,0);
  for(const p of ['data/agent-bindings.json','World%20Requests/checkpoint.json','runtime/Commands/Journal.json','adapters/native-session-adapter.mjs','antfarm.config.json','api/config','api/raw','%2e%2e/server.mjs'])assert.equal((await fetch(url+'/'+p)).status,404,p);
  const data=await(await fetch(url+'/api/dashboard')).json();assert.equal(data.mode,'live');assert.equal(data.model.agents.length,registry.length);assert.equal(data.feed.motionEvents.length,0);assert.equal(data.feed.farmFacts.commands.transportEnabled,false);assert.ok(data.model.agents.every(a=>!a.threadId.startsWith('demo-')));
 }finally{await new Promise(resolve=>app.server.close(resolve));}
}));

test('only explicit input requests set attention; verified unresolved waits survive work freshness and resume clears them',async()=>fixture(async f=>{await f.append({type:'task_paused',turn_id:'t'});assert.equal((await f.agent()).needsHumanInput,false);await f.append({type:'user_input_requested',turn_id:'t',prompt:'PRIVATE-REQUEST-CONTENT'});let a=await f.agent();assert.equal(a.needsHumanInput,true);assert.equal(a.activityState,'waiting');assert.ok(!JSON.stringify(a).includes('PRIVATE-REQUEST-CONTENT'));await f.append({type:'item_completed',turn_id:'t',item:{type:'FunctionCallOutput',content:'PRIVATE-REQUEST-CONTENT'}});assert.equal((await f.agent()).activityState,'waiting');f.setTime(t0+120001);const pending=await f.agent();assert.equal(pending.needsHumanInput,true);assert.equal(pending.activityState,'waiting');assert.equal(pending.observedUtc,stamp);f.setTime(t0+1000);await f.append({type:'turn_resumed',turn_id:'t'});a=await f.agent();assert.equal(a.needsHumanInput,false);assert.equal(a.activityState,'working');}));

test('actual native request tool metadata sets attention without reading arguments, and a human reply/resume clears it',async()=>fixture(async f=>{await appendFile(f.session,row('response_item',{type:'function_call',name:'request_user_input_async',call_id:'actual-request-shape',arguments:'PRIVATE-QUESTION-CONTENT'}));let a=await f.agent();assert.equal(a.needsHumanInput,true);assert.equal(a.activityState,'waiting');assert.ok(!JSON.stringify(a).includes('PRIVATE-QUESTION-CONTENT'));await f.append({type:'item_completed',item:{type:'FunctionCallOutput'}});assert.equal((await f.agent()).needsHumanInput,true);await f.append({type:'user_message',message:'PRIVATE-REPLY'});await f.append({type:'turn_resumed',turn_id:'next'});a=await f.agent();assert.equal(a.needsHumanInput,false);assert.equal(a.activityState,'working');}));

test('speed evidence keeps its own observation time and updates normal/unknown without chat selection',async()=>fixture(async f=>{await f.append({type:'thread_settings_applied',thread_settings:{service_tier:'priority'}});let a=await f.agent();assert.equal(a.serviceTier,'priority');assert.equal(a.serviceTierObservedUtc,stamp);assert.equal(a.serviceTierSource,'thread_settings_applied');let p=await createProjection(registry,await f.adapter.readSnapshot(),t0);assert.equal(p.model.agents.find(a=>a.roleId==='world-requests').modelSpeed.fast,true);const later=t0+121000;f.setTime(later);await f.append({type:'task_started',turn_id:'fresh-activity'},new Date(later).toISOString());a=await f.agent();assert.equal(a.activityState,'working');assert.equal(a.serviceTierObservedUtc,stamp);p=await createProjection(registry,await f.adapter.readSnapshot(),later);assert.equal(p.model.agents.find(a=>a.roleId==='world-requests').modelSpeed.known,false);await f.append({type:'thread_settings_applied',thread_settings:{service_tier:'default'}},new Date(later).toISOString());p=await createProjection(registry,await f.adapter.readSnapshot(),later);let speed=p.model.agents.find(a=>a.roleId==='world-requests').modelSpeed;assert.equal(speed.known,true);assert.equal(speed.fast,false);assert.equal(speed.serviceTier,'default');for(const settings of [{},{service_tier:null},{service_tier:'unsupported'}]){await f.append({type:'thread_settings_applied',thread_settings:settings},new Date(later).toISOString());a=await f.agent();assert.equal(a.serviceTier,null);p=await createProjection(registry,await f.adapter.readSnapshot(),later);assert.equal(p.model.agents.find(a=>a.roleId==='world-requests').modelSpeed.known,false);}}));


test('long turns resume after actual user-role reply metadata without reading content or refreshing time on the reply/poll',async()=>{
 for(const kind of ['response-user','completed-user'])await fixture(async f=>{
  await f.append({type:'task_started',turn_id:'long-turn'});await appendFile(f.session,row('response_item',{type:'function_call',name:'request_user_input_async',arguments:'PRIVATE-QUESTION'}));assert.equal((await f.agent()).needsHumanInput,true);
  const later=t0+30*60*1000,at=new Date(later).toISOString();f.setTime(later);
  await appendFile(f.session,row('response_item',{type:'message',role:'assistant',content:'PRIVATE-ASSISTANT-ACK'},at));await appendFile(f.session,row('response_item',{type:'function_call_output',output:'PRIVATE-TOOL-ACK'},at));await f.append({type:'item_completed',turn_id:'long-turn',item:{type:'McpToolCall',arguments:'PRIVATE-ARGUMENT',result:'PRIVATE-RESULT'}},at);
  let a=await f.agent();assert.equal(a.activityState,'waiting');assert.equal(a.needsHumanInput,true);assert.equal(a.observedUtc,stamp);
  if(kind==='response-user')await appendFile(f.session,row('response_item',{type:'message',role:'user',content:'PRIVATE-REPLY'},at));else await f.append({type:'item_completed',turn_id:'long-turn',item:{type:'UserMessage',content:'PRIVATE-REPLY'}},at);
  a=await f.agent();assert.equal(a.activityState,'unknown');assert.equal(a.observedUtc,stamp);
  await f.append({type:'item_completed',turn_id:'long-turn',item:{type:'CommandExecution',command:'PRIVATE-COMMAND',output:'PRIVATE-OUTPUT'}},at);a=await f.agent();assert.equal(a.activityState,'working');assert.equal(a.needsHumanInput,false);assert.equal(a.observedUtc,at);assert.ok(!JSON.stringify(a).includes('PRIVATE-'));
  f.setTime(later+60000);assert.equal((await f.agent()).observedUtc,at);f.setTime(later+120001);assert.equal((await f.agent()).activityState,'unknown');
 });
});
test('assistant and tool acknowledgements preserve a fresh real input wait, and terminal turns never wake from a trailing reply',async()=>fixture(async f=>{
 await f.append({type:'user_input_requested',turn_id:'wait',prompt:'PRIVATE-PROMPT'});await appendFile(f.session,row('response_item',{type:'message',role:'assistant',content:'PRIVATE-ACK'}));await appendFile(f.session,row('response_item',{type:'function_call_output',output:'PRIVATE-ACK'}));await f.append({type:'item_completed',turn_id:'wait',item:{type:'Reasoning',text:'PRIVATE-REASONING'}});let a=await f.agent();assert.equal(a.activityState,'waiting');assert.equal(a.needsHumanInput,true);
 await f.append({type:'task_complete',turn_id:'wait'});await appendFile(f.session,row('response_item',{type:'message',role:'user',content:'PRIVATE-TRAILING'}));await f.append({type:'item_completed',turn_id:'wait',item:{type:'AgentMessage'}});a=await f.agent();assert.equal(a.activityState,'idle');assert.equal(a.terminal,true);assert.equal(a.needsHumanInput,false);assert.ok(!JSON.stringify(a).includes('PRIVATE-'));
}));
test('read-only HTTP activity is equivalent to the qualified observer after a long-turn user reply',async()=>fixture(async f=>{
 const now=Date.now(),at=new Date(now).toISOString();f.setTime(now);await f.append({type:'task_started',turn_id:'live'});await f.append({type:'approval_requested',turn_id:'live'});await f.agent();await appendFile(f.session,row('response_item',{type:'message',role:'user',content:'PRIVATE-REPLY'},at));await f.append({type:'item_completed',turn_id:'live',item:{type:'McpToolCall',arguments:'PRIVATE-ARGS'}},at);const actual=await f.agent();
 const app=await createApp({configFile:await writeTestConfig(f.root),mode:'live',nativeReadOnly:true,adapter:f.adapter});try{const origin=await app.listen(0),data=await(await fetch(origin+'/api/dashboard')).json(),health=data.feed.agentHealth.find(h=>h.threadId===threadId);assert.equal(health.activityState,actual.activityState);assert.equal(health.activityObservedUtc,actual.observedUtc);assert.equal(health.needsHumanInput===true,false);assert.equal(data.feed.farmFacts.commands.transportEnabled,false);assert.ok(!JSON.stringify(data).includes('PRIVATE-'));}finally{await new Promise(resolve=>app.server.close(resolve));}
}));
