import test from 'node:test';
import assert from 'node:assert/strict';
import {createProjection} from '../lib/projection.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {createSiteAgentMetadataContract,createSiteAgentMetadataProjector} from '../lib/site-agent-metadata.mjs';
import {createSiteBundleContract} from '../lib/site-sync-bundle.mjs';
import {configuration,siteBundleFixture,refreshSiteOwnerPreview,worldId,roles} from './site-sync-fixture.mjs';

async function knownFixture(){
 const f=await siteBundleFixture(),now=Date.parse(f.bundle.observedUtc),input=structuredClone(f.plan),raw=input.agents[0];
 const stamps={model:new Date(now-60000).toISOString(),selection:new Date(now-2000).toISOString(),reasoning:new Date(now-25000).toISOString(),speed:new Date(now-15000).toISOString(),work:new Date(now-20000).toISOString()};
 Object.assign(raw,{model:'gpt-6-astra',modelSource:'turn_context',modelObservedUtc:stamps.model,modelState:'current',selectedModel:'gpt-6.1-sol',selectedModelSource:'native-index-selection',selectedModelObservedUtc:stamps.selection,selectedModelState:'current',reasoningEffort:'high',reasoningEffortSource:'turn_context',reasoningEffortObservedUtc:stamps.reasoning,serviceTier:'default',serviceTierSource:'thread_settings_applied',serviceTierObservedUtc:stamps.speed,observedUtc:stamps.work});
 const projected=await createProjection(registry,input),source=projected.model.agents.find(agent=>agent.roleId===raw.roleId),index=f.dashboard.model.agents.findIndex(agent=>agent.roleId===raw.roleId);
 f.dashboard.model.agents[index]=source;f.dashboard.feed.agentHealth=f.dashboard.feed.agentHealth.map(row=>row.threadId===source.threadId?projected.feed.agentHealth.find(h=>h.threadId===source.threadId):row);
 f.dashboard.model.nativeMetadata={persistence:'available',revision:2,contentHash:'c'.repeat(64)};
 refreshSiteOwnerPreview(f.dashboard);
 return{...f,source,stamps,index,bundle:await f.producer.produce({revision:2,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog})};
}
test('same-read literal selection stays separate from actual applied model and every original effort/speed/work clock',async()=>{
 const f=await knownFixture(),row=f.bundle.agentMetadata.agents.find(row=>row.role===f.source.roleId);
 assert.equal(row.selection.model,'gpt-6.1-sol');assert.equal(row.applied.model,'gpt-6-astra');assert.equal(row.selection.source,'native-index-selection');assert.equal(row.applied.source,'turn_context');
 assert.equal(row.selection.observedUtc,f.stamps.selection);assert.equal(row.applied.observedUtc,f.stamps.model);assert.equal(row.applied.reasoningObservedUtc,f.stamps.reasoning);assert.equal(row.applied.speedObservedUtc,f.stamps.speed);assert.equal(row.activity.observedUtc,f.stamps.work);
 assert.equal(row.applied.reasoning,'high');assert.equal(row.applied.speed,'default');assert.equal(f.source.reasoningEffortObservedUtc,f.stamps.reasoning);assert.equal(f.source.serviceTierObservedUtc,f.stamps.speed);
 const again=await f.producer.produce({revision:3,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog});assert.deepEqual(again.agentMetadata,f.bundle.agentMetadata);
});
test('an unsupported future native model stays literal while its selected visual appearance remains neutral',async()=>{
 const f=await knownFixture();f.source.selectedModel='future-native-model-v99';f.dashboard.model.nativeMetadata={persistence:'available',revision:3,contentHash:'d'.repeat(64)};
 refreshSiteOwnerPreview(f.dashboard);
 const next=await f.producer.produce({revision:3,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog}),row=next.agentMetadata.agents.find(row=>row.role===f.source.roleId),appearance=next.ownerPreview.appearance.agents.find(agent=>agent.id===row.id);
 assert.equal(row.selection.model,'future-native-model-v99');assert.equal(row.applied.model,'gpt-6-astra');assert.equal(appearance.modelKnown,false);assert.equal(appearance.token,5);
});
test('missing old-dashboard effort time remains null rather than borrowing model or observation time',async()=>{
 const f=await knownFixture();delete f.source.reasoningEffortObservedUtc;
 refreshSiteOwnerPreview(f.dashboard);
 const next=await f.producer.produce({revision:3,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog}),row=next.agentMetadata.agents.find(row=>row.role===f.source.roleId);
 assert.equal(row.applied.reasoning,'high');assert.equal(row.applied.reasoningObservedUtc,null);assert.equal(row.applied.observedUtc,f.stamps.model);
});
test('shared same-read mapper preserves explicit null speed instead of borrowing retained derived speed or clocks',async()=>{
 const f=await knownFixture();f.source.serviceTier=null;f.source.serviceTierObservedUtc=null;
 refreshSiteOwnerPreview(f.dashboard);
 const bundle=await f.producer.produce({revision:3,dashboard:f.dashboard,plan:f.plan,catalog:f.catalog}),row=bundle.agentMetadata.agents.find(row=>row.role===f.source.roleId);
 assert.equal(row.applied.speed,null);assert.equal(row.applied.speedObservedUtc,null);
 const projector=createSiteAgentMetadataProjector(configuration);assert.deepEqual(projector({dashboard:f.dashboard,ownerPreview:bundle.ownerPreview}),bundle.agentMetadata);
 const mismatched=structuredClone(f.dashboard);mismatched.model.nativeMetadata.revision++;assert.throws(()=>projector({dashboard:mismatched,ownerPreview:bundle.ownerPreview}),/Same-read persisted/);
});
test('metadata browser contract rejects credentials, native UUIDs, private fields and selection masquerading as applied proof',async()=>{
 const f=await knownFixture(),c=createSiteAgentMetadataContract(configuration);for(const mutate of [m=>m.agents[0].selection.model='sk-proj-'+'a'.repeat(32),m=>m.agents[0].applied.model='11111111-1111-4111-8111-111111111111',m=>m.agents[0].applied.source='native-index-selection',m=>m.agents[0].applied.observedUtc=null,m=>m.agents[0].selection.model=null,m=>m.agents[0].id='role-foreign',m=>m.agents[0].toolArguments={},m=>m.prompt='private',m=>m.agents[0].activity.observedUtc=new Date(Date.parse(m.observedUtc)+6000).toISOString()]){const metadata=structuredClone(f.bundle.agentMetadata);mutate(metadata);assert.throws(()=>c.assertMetadata(metadata));}
});
test('metadata facet cannot disagree with owner names, role aliases, original source or metadata revision',async()=>{
 const f=await knownFixture(),c=createSiteBundleContract(configuration);for(const mutate of [b=>b.agentMetadata.agents[0].name='Different display name',b=>b.agentMetadata.revision++,b=>b.agentMetadata.contentHash='f'.repeat(64),b=>b.agentMetadata.observedUtc=new Date(Date.parse(b.observedUtc)-1).toISOString(),b=>b.agentMetadata.agents[0].selection.observedUtc=null]){const b=structuredClone(f.bundle);mutate(b);await assert.rejects(c.assertBundle(b));}
});
test('response freshness uses original source and receipt, preserves stale rows and refuses a forged current claim',async()=>{
 const f=await knownFixture(),c=createSiteAgentMetadataContract({worldId,roles}),metadata=f.bundle.agentMetadata,now=Date.parse(metadata.observedUtc),receivedUtc=new Date(now).toISOString();
 const response=c.response(metadata,receivedUtc,now);assert.equal(response.state,'current');c.assertResponse(response,{now});
 const stale=c.response(metadata,receivedUtc,now+45001);assert.equal(stale.state,'stale');assert.equal(stale.receivedUtc,receivedUtc);assert.equal(stale.observedUtc,metadata.observedUtc);assert.equal(stale.metadata,metadata);c.assertResponse(stale,{now:now+45001});assert.throws(()=>c.assertResponse({...stale,state:'current'},{now:now+45001}));
 const absent=c.response(null,null,now);assert.deepEqual(absent,{schemaVersion:1,kind:'owner-agent-metadata-response',state:'unavailable',receivedUtc:null,observedUtc:null,metadata:null});
});
