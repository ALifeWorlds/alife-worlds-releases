import test from 'node:test';
import assert from 'node:assert/strict';
import {createProjection} from '../lib/projection.mjs';
import {dashboardProgress} from '../web/dashboard-model.mjs';
import {publicWorldSnapshot} from '../lib/public-world.mjs';
import {assertPublicWorldSnapshot} from '../lib/public-world-contract.mjs';
import '../web/agent-outpost/agent-outpost.js';
const registry=[{id:'director',title:'Director',role:'director',responsibility:'Coordinate'}];
function source(){
 const task=(id,stage)=>({id,title:id,ownerRoleId:'director',sprintId:'s2',stage,accepted:stage==='Done',acceptanceEvidence:stage==='Done'?'Recorded actual goal result':null,steps:[{id:'step',title:'Step',complete:true,evidence:'Step complete'}]});
 return{observedUtc:'2026-11-08T08:00:00.000Z',agents:[],tasks:[task('launcher','Done'),task('dropdown','In Progress'),task('switch','In Progress'),task('planets','In Progress')],sprint:{id:'s2',title:'Sprint 2',taskIds:['launcher']},roadmap:{epic:{id:'epic',title:'Epic'},icon:{id:'icon',status:'Done',accepted:true,acceptanceEvidence:'Recorded actual amendment acceptance'},sprints:Array.from({length:7},(_,i)=>i===1?{id:'s2',title:'Sprint 2',status:'complete',taskIds:['launcher'],requiredGoalIds:['launcher','dropdown','switch','planets','icon'],remainingGoalIds:['dropdown','switch','planets'],requiredAmendmentRefs:['roadmap.icon']}:{id:'s'+(i+1),title:'Sprint '+(i+1),status:'planned',taskIds:[]})}};
}
test('sprint counts every required whole task and existing amendment once; epic counts complete sprints',async()=>{
 const input=source(),before=JSON.stringify(input),state=await createProjection(registry,input),p=dashboardProgress(state.model);
 assert.equal(JSON.stringify(input),before);assert.equal(state.model.tasks.length,4);assert.deepEqual(state.model.presentation.taskIds,['launcher','dropdown','switch','planets','icon']);
 assert.equal(p.sprint.percent,40);assert.equal(p.sprint.accepted,2);assert.equal(p.sprint.tasks,5);assert.equal(p.sprint.complete,false);assert.equal(state.model.roadmap.sprints[1].status,'planned');
 assert.equal(p.epic.percent,0);assert.equal(p.epic.accepted,0);assert.equal(p.epic.tasks,7);
 for(const t of input.tasks){t.stage='Done';t.accepted=true;t.acceptanceEvidence='Recorded completed goal';}
 const finished=dashboardProgress((await createProjection(registry,input)).model);assert.equal(finished.sprint.percent,100);assert.equal(finished.sprint.accepted,5);assert.equal(finished.epic.percent,14);assert.equal(finished.epic.accepted,1);assert.equal(finished.epic.tasks,7);
});
test('missing task or amendment references cannot disappear or create completion',async()=>{
 const input=source();input.roadmap.sprints[1].requiredGoalIds.push('missing');input.roadmap.sprints[1].requiredAmendmentRefs.push('roadmap.unresolved');
 const state=await createProjection(registry,input),p=dashboardProgress(state.model);assert.ok(state.model.presentation.taskIds.includes('missing'));assert.equal(p.sprint.complete,false);assert.equal(p.sprint.percent,null);assert.equal(p.epic.complete,false);assert.equal(p.epic.percent,null);
 const empty=source();empty.tasks=[];empty.sprint.taskIds=[];empty.roadmap.sprints=[];const q=dashboardProgress((await createProjection(registry,empty)).model);assert.equal(q.sprint.percent,null);assert.equal(q.epic.percent,null);assert.equal(q.epic.complete,false);
});
test('closed public summary retains task and sprint counts without exposing private amendment membership',async()=>{
 const state=await createProjection(registry,source()),dto=publicWorldSnapshot(state,registry,{worldId:'world-test'});assertPublicWorldSnapshot(dto);
 assert.deepEqual(dto.summary.current,{percent:40,accepted:2,tasks:5,units:2,total:5});assert.deepEqual(dto.summary.epic,{percent:0,accepted:0,tasks:7,units:0,total:7});
 assert.equal(dto.model.tasks.length,4);assert.equal(JSON.stringify(dto).includes('"icon"'),false);
});
