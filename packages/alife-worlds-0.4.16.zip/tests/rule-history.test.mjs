import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,rm,readdir,symlink,lstat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {archiveRuleHistory} from '../lib/rule-history.mjs';
import {emptyCatalog,checkRuleDocuments,applyRuleChange} from '../lib/rules.mjs';
import {generateAllRuleDocuments,checkAllRuleDocuments} from '../lib/agent-rules.mjs';

const source=fileURLToPath(new URL('../',import.meta.url)),sha=x=>createHash('sha256').update(x).digest('hex');
const stamp='2026-11-09T00:00:00.000Z';
const property=(id,count=20)=>({id,title:'Preserve '+id,description:'Keep the actual '+id+' requirement.',text:'Keep the current '+id+' behavior and its authorization.',active:true,implementation:'documented',origin:'human',history:Array.from({length:count},(_,i)=>({title:'Earlier '+id,text:'Prior '+id+' requirement '+i,active:true,supersededAt:stamp}))});
async function fixture(fn){const parent=path.join(source,'runtime/test-fixtures');await mkdir(parent,{recursive:true});const root=await mkdtemp(path.join(parent,'rule-history-'));try{
 for(const dir of ['rules','data','roles'])await mkdir(path.join(root,dir));
 for(const scope of ['plugin','world','universal']){const c=emptyCatalog(scope);c.ruleFormatVersion=2;c.groups=[{id:'safety',title:'Safety',properties:[property('one'),property('two',18)]}];await writeFile(path.join(root,'rules',scope+'.json'),JSON.stringify(c,null,2)+'\n');}
 await writeFile(path.join(root,'data/roles.json'),JSON.stringify([{id:'director',title:'Director'}]));await writeFile(path.join(root,'roles/SHARED.md'),'# Shared\nPreserve actual authority.\n');await writeFile(path.join(root,'roles/director.md'),'# Director\nPreserve this explicit fixture scope.\n');await generateAllRuleDocuments(root);await fn(root);
 }finally{assert(path.resolve(root).startsWith(path.resolve(parent)+path.sep));await rm(root,{recursive:true,force:true});}}
const input=(extra={})=>({scope:'plugin',expectedRevision:0,propertyIds:['safety.one'],requestId:'fixture-history-one',...extra});
const rule=root=>path.join(root,'rules/plugin.json');
const operation=async root=>path.join(root,'runtime/RuleHistory',(await readdir(path.join(root,'runtime/RuleHistory')))[0]);

test('exact selected history is archived privately before trimming; active fields and unrelated properties stay unchanged',()=>fixture(async root=>{
 const before=await readFile(rule(root)),old=JSON.parse(before),world=await readFile(path.join(root,'rules/world.json'));const result=await archiveRuleHistory(root,input());assert.equal(result.state,'applied');assert.equal(result.revision,1);assert.equal(result.documentsUpdated,true);
 const dir=await operation(root),archive=await readFile(path.join(dir,'catalog-before.json'));assert(archive.equals(before));assert.equal(sha(archive),result.beforeSha256);
 const current=JSON.parse(await readFile(rule(root)));assert.equal(current.revision,1);assert.deepEqual(current.groups[0].properties[0].history,old.groups[0].properties[0].history.slice(-12));
 const active=p=>{const {history,...rest}=p;return rest;};assert.deepEqual(active(current.groups[0].properties[0]),active(old.groups[0].properties[0]));assert.deepEqual(current.groups[0].properties[1],old.groups[0].properties[1]);assert.deepEqual(current.requests,old.requests);assert((await readFile(path.join(root,'rules/world.json'))).equals(world));
 await checkRuleDocuments(root);await checkAllRuleDocuments(root);const again=await archiveRuleHistory(root,input());assert.deepEqual(again,result);assert((await readFile(path.join(dir,'catalog-before.json'))).equals(before));
}));
test('world/universal scopes work and a short-history archive does not invent a revision or remove values',()=>fixture(async root=>{
 for(const scope of ['world','universal']){const result=await archiveRuleHistory(root,input({scope,requestId:'history-'+scope,propertyIds:['safety.one','safety.two']}));assert.equal(result.revision,1);assert.equal(result.changes.length,2);assert(result.changes.every(c=>c.retainedEntries===12));}
 const c=JSON.parse(await readFile(rule(root)));c.groups[0].properties[0].history=c.groups[0].properties[0].history.slice(0,3);await writeFile(rule(root),JSON.stringify(c)+'\n');const before=await readFile(rule(root)),result=await archiveRuleHistory(root,input({requestId:'short-history'}));assert.equal(result.revision,0);assert.equal(result.changes[0].removedEntries,0);assert((await readFile(rule(root))).equals(before));
}));
test('stale, duplicate, missing and malformed selections fail without changing rules or archiving unrelated properties',()=>fixture(async root=>{
 const before=await readFile(rule(root));for(const patch of [{expectedRevision:1},{scope:'agent'},{propertyIds:[]},{propertyIds:['safety.one','safety.one']},{propertyIds:['safety.missing']},{propertyIds:['../safety.one']},{requestId:'../escape'},{extra:'unsupported'}])await assert.rejects(archiveRuleHistory(root,input(patch)));assert((await readFile(rule(root))).equals(before));
 const accepted=await archiveRuleHistory(root,input());await assert.rejects(archiveRuleHistory(root,input({propertyIds:['safety.two']})),/conflicts/);await assert.rejects(archiveRuleHistory(root,input({expectedRevision:accepted.revision})),/conflicts/);
}));
test('completed request stays settled after later edits while altered recovery bytes are refused',()=>fixture(async root=>{
 const result=await archiveRuleHistory(root,input()),current=JSON.parse(await readFile(rule(root)));current.revision++;current.updatedAt=new Date().toISOString();current.groups[0].properties[0].text+=' Keep the later authorized amendment.';await writeFile(rule(root),JSON.stringify(current)+'\n');const later=await readFile(rule(root));assert.deepEqual(await archiveRuleHistory(root,input()),result);assert((await readFile(rule(root))).equals(later));
 const dir=await operation(root);await writeFile(path.join(dir,'catalog-before.json'),'tampered recovery');await assert.rejects(archiveRuleHistory(root,input()),/hash changed/);assert((await readFile(rule(root))).equals(later));
}));
test('unknown after-write outcome reconciles metadata/docs without repeating the catalogue write',()=>fixture(async root=>{
 const first=await archiveRuleHistory(root,input()),dir=await operation(root),file=path.join(dir,'receipt.json'),receipt=JSON.parse(await readFile(file));receipt.state='unknown';receipt.completedUtc=null;receipt.documentsUpdated=false;await writeFile(file,JSON.stringify(receipt));const before=await readFile(rule(root)),stat=await lstat(rule(root));
 const result=await archiveRuleHistory(root,input());assert.equal(result.state,'applied');assert.equal(result.archivedUtc,first.archivedUtc);assert((await readFile(rule(root))).equals(before));assert.equal((await lstat(rule(root))).mtimeMs,stat.mtimeMs);await checkAllRuleDocuments(root);
}));
test('unknown preimage or conflicting outcome never replays the original mutation',()=>fixture(async root=>{
 await archiveRuleHistory(root,input());const dir=await operation(root),file=path.join(dir,'receipt.json'),receipt=JSON.parse(await readFile(file));receipt.state='unknown';receipt.completedUtc=null;receipt.documentsUpdated=false;await writeFile(file,JSON.stringify(receipt));const original=await readFile(path.join(dir,'catalog-before.json'));await writeFile(rule(root),original);
 const result=await archiveRuleHistory(root,input());assert.equal(result.state,'unknown');assert((await readFile(rule(root))).equals(original));
 const changed=JSON.parse(original);changed.revision=2;changed.groups[0].properties[1].text+=' Later independent change.';await writeFile(rule(root),JSON.stringify(changed));const after=await readFile(rule(root));await assert.rejects(archiveRuleHistory(root,input()),/conflicts with current/);assert((await readFile(rule(root))).equals(after));
}));
test('redirected private runtime is refused without following it',async t=>fixture(async root=>{
 const outside=path.join(root,'outside');await mkdir(outside);try{await symlink(outside,path.join(root,'runtime'),process.platform==='win32'?'junction':'dir');}catch(e){if(['EPERM','EACCES','ENOTSUP'].includes(e.code)){t.skip('Host cannot create the redirect fixture');return;}throw e;}
 const before=await readFile(rule(root));await assert.rejects(archiveRuleHistory(root,input()),/Redirected/);assert.deepEqual(await readdir(outside),[]);assert((await readFile(rule(root))).equals(before));
}));
test('a full history refuses editing until explicit archival preserves it; built packets cannot be archived',()=>fixture(async root=>{
 const c=JSON.parse(await readFile(rule(root)));c.groups[0].properties[0]=property('one',100);c.groups[0].properties[0].history[0].implementation='implemented';await writeFile(rule(root),JSON.stringify(c)+'\n');
 const change={command:'/plugin retain current safe behavior',requestId:'later-edit',expectedRevision:0,groupId:'safety',groupTitle:'Safety',properties:[{id:'one',title:'Preserve one',description:'Keep the actual one requirement.',text:'Apply the next authorized safe behavior.'}]};
 assert.throws(()=>applyRuleChange(c,change),/archive/);const result=await archiveRuleHistory(root,input());assert.equal(result.changes[0].originalEntries,100);assert.equal(result.changes[0].removedEntries,88);const next=JSON.parse(await readFile(rule(root)));assert.equal(applyRuleChange(next,{...change,expectedRevision:1}).groups[0].properties[0].history.length,13);
 const original=JSON.parse(await readFile(path.join(root,result.archiveFile)));assert.equal(original.groups[0].properties[0].history.length,100);assert.equal(original.groups[0].properties[0].history[0].implementation,'implemented');
 await writeFile(path.join(root,'package-provenance.json'),'{}');await assert.rejects(archiveRuleHistory(root,input({expectedRevision:1,requestId:'blocked-packet'})),/read-only/);
}));
