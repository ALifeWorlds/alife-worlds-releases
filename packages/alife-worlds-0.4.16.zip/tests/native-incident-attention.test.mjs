import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import '../web/agent-outpost/agent-outpost.js';
import {createDemo} from '../lib/demo.mjs';
import {createProjection} from '../lib/projection.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
const api=globalThis.AgentOutpost;
const iso=value=>new Date(value).toISOString();

test('task dependencies remain task information without native fire or Support alarms',async()=>{
 const input=createDemo(registry,'blocked'),state=await createProjection(registry,input),projected=api.project(state.model,state.feed),worker=projected.stations.find(s=>s.agent.roleId==='worker2');
 assert.ok(worker.taskBlocker);assert.equal(worker.blocker,'');assert.equal(worker.nativeBlockerState,'unknown');assert.notEqual(worker.status,'Blocked');assert.equal(api.recordedFire(worker),false);assert.equal(projected.supportAlarm.active,false);assert.equal(projected.supportAlarm.issues.length,0);assert.equal(projected.stations.find(s=>s.agent.role==='support').responseActive,false);assert.ok(projected.blockedPackages.length);
 state.feed.error='Temporary feed loss';const stale=api.project(state.model,state.feed);assert.ok(stale.stations.find(s=>s.agent.roleId==='worker2').taskBlocker);assert.equal(stale.supportAlarm.active,false);assert.equal(stale.supportAlarm.state,'unknown');
});

test('native failures use original per-agent evidence and require a correlated real response to recover',async()=>{
 const now=Date.now(),feed={observedUtc:iso(now)},failure={turnId:'failed-turn',observedUtc:iso(now-1000),message:'Recorded failure'},health={activityState:'failure',activityObservedUtc:iso(now-1000),failure};
 assert.equal(api.nativeIncidentEvidence(health,feed,now).failure,true);
 for(const changed of [{...health,activityState:'working'},{...health,verifiedResponse:{turnId:'failed-turn',observedUtc:iso(now)}}])assert.equal(api.nativeIncidentEvidence(changed,feed,now).failure,true);
 const stale={...health,activityObservedUtc:iso(now),failure:{...failure,observedUtc:iso(now-130000)}};assert.equal(api.nativeIncidentEvidence(stale,feed,now).failure,false);assert.equal(api.nativeIncidentEvidence(stale,feed,now).unknownFailure,true);assert.equal(api.nativeIncidentEvidence(stale,feed,now).current,false);
 const recovered={...health,activityState:'working',activityObservedUtc:iso(now),verifiedResponse:{turnId:'new-turn',observedUtc:iso(now)}};assert.equal(api.nativeIncidentEvidence(recovered,feed,now).recovered,true);assert.equal(api.nativeIncidentEvidence(recovered,feed,now).failure,false);
 const input=createDemo(registry,'working'),state=await createProjection(registry,input),target=state.feed.agentHealth.find(h=>h.threadId===state.model.agents[0].threadId);delete target.verifiedResponse;Object.assign(target,health);let projected=api.project(state.model,state.feed);assert.equal(projected.supportAlarm.active,true);assert.equal(projected.supportAlarm.issues[0].kind,'agent-recovery');Object.assign(target,stale);projected=api.project(state.model,state.feed);assert.equal(projected.supportAlarm.active,false);assert.equal(projected.supportAlarm.state,'unknown');
});

test('genuine input holds its current location and work timers while the pose clock remains independent',async()=>{
 const source=await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8'),begin=source.indexOf("if(s.needsHumanInput&&s.status!=='Retirement Needed'&&!a.outdoorFall"),end=source.indexOf('if(defenseRun?.key===s.key',begin);assert.ok(begin>0&&end>begin);
 const a={work:{started:10,endsAt:20},fieldDueAt:15,relocation:{elapsed:1,seconds:4},walking:true,foot:{x:2},fastTrail:[1],modelTrail:[2],roadWait:true,stationarySeconds:9},s={key:'ant',status:'Waiting',needsHumanInput:true},origin={x:123,y:456,outside:false};
 for(let i=0;i<20;i++)vm.runInNewContext('for(const once of [1]){'+source.slice(begin,end)+'}',{s,a,dt:.05,antDrag:null,agentPosition:()=>api.holdAttentionPosition(a,origin,1600,1100)});
 assert.deepEqual(a.attention.position,origin);assert.equal(a.walking,false);assert.equal(a.foot,null);assert.equal(a.fastTrail.length,0);assert.equal(a.modelTrail.length,0);assert.equal(a.roadWait,false);assert.equal(a.relocation.elapsed,1);assert.ok(Math.abs(a.work.started-11)<1e-9);assert.ok(Math.abs(a.work.endsAt-21)<1e-9);assert.ok(Math.abs(a.fieldDueAt-16)<1e-9);
 assert.deepEqual(api.holdAttentionPosition(a,{x:999,y:999},1600,1100),{...origin,a:0});const resized=api.holdAttentionPosition(a,origin,800,550);assert.equal(resized.x,61.5);assert.equal(resized.y,228);assert.notDeepEqual(api.attentionLegs(0),api.attentionLegs(.2));
});

test('genuine blocked cues and summit dust retain readable screen size through fitting',()=>{
 for(const fit of [.08,.2,.5,1]){const marker=api.helpMarkerMetrics(29,fit,false,true),puff=api.summitPuffMetrics(29,fit);assert.ok(marker.radius*2*fit>=20);assert.ok(marker.lineWidth*fit>=1);assert.ok(marker.nameExtra>=0);assert.ok(puff.radius*fit>=22);assert.ok(puff.chip*fit>=3);assert.equal(puff.count,16);}
});
