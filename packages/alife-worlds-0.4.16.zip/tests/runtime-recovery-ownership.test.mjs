import test from 'node:test';
import assert from 'node:assert/strict';
import {matchesOwnedRuntimeProcess,reconcileRuntimeRecoveryJournal} from '../scripts/runtime-recovery/ownership.mjs';
const node='C:\\Program Files\\nodejs\\node.exe',driver='C:\\projects\\fixture\\runtime\\server.mjs',createdUtc='2026-11-01T10:00:00.1234567Z';
const record={pid:123,createdUtc},component={driver,adopt:[]};
const original={...record,executablePath:node,commandLine:'"'+node+'" '+driver+' --run'};
const matches=(p,parts={})=>matchesOwnedRuntimeProcess(p,{component,record,node,...parts});
test('owned runtime matches quoted and unquoted exact driver tokens across ordinary Windows paths',()=>{
 assert.equal(matches(original),true);assert.equal(matches({...original,commandLine:'"'+node+'" "'+driver+'" --run'}),true);
 const spaced='C:\\fixture project\\runtime\\server.mjs';assert.equal(matches({...original,commandLine:'"'+node+'" "'+spaced+'" --run'},{component:{driver:spaced,adopt:[]}}),true);
 assert.equal(matches({...original,commandLine:original.commandLine.replaceAll('\\','/').toUpperCase()}),true);
});
test('PID reuse, submillisecond creation differences and extra command tokens never acquire custody',()=>{
 for(const patch of [{pid:124},{createdUtc:'2026-11-01T10:00:00.1234568Z'},{createdUtc:'2026-11-01T10:00:00.123Z'},{executablePath:'C:\\other\\node.exe'},{commandLine:'"'+node+'" C:\\foreign\\program.mjs "'+driver+'" --run'},{commandLine:original.commandLine+' --extra'},{commandLine:'"'+node+'" '+driver+'.other --run'}])assert.equal(matches({...original,...patch}),false);
});
test('only an explicit old pinned driver may be adopted; malformed observations fail closed',()=>{
 const old='C:\\projects\\fixture\\runtime\\old-server.mjs',p={...original,commandLine:'"'+node+'" '+old+' --run'};
 assert.equal(matches(p),false);assert.equal(matches(p,{component:{driver,adopt:[{driver:old}]}}),true);
 assert.equal(matches(null),false);assert.equal(matches({...original,commandLine:null}),false);assert.equal(matchesOwnedRuntimeProcess(original),false);
});

test('restart reconciles a recorded spawn even when the last status write did not happen',()=>{
 const journal={schemaVersion:1,operations:[{id:'launch-1',component:'publisher',state:'launch-reserved'},{id:'launch-1',component:'publisher',state:'spawned',process:original}]};
 assert.deepEqual(reconcileRuntimeRecoveryJournal(journal,'publisher'),{records:[original],unsettledLaunchId:null});
 assert.deepEqual(reconcileRuntimeRecoveryJournal(journal,'local'),{records:[],unsettledLaunchId:null});
});
test('an interrupted or malformed new launch remains unknown and cannot borrow an older successful spawn',()=>{
 const operations=[{id:'old',component:'publisher',state:'launch-reserved'},{id:'old',component:'publisher',state:'spawned',process:original},{id:'next',component:'publisher',state:'launch-reserved'}];
 assert.deepEqual(reconcileRuntimeRecoveryJournal({schemaVersion:1,operations},'publisher'),{records:[],unsettledLaunchId:'next'});
 operations.push({id:'next',component:'publisher',state:'spawned',process:{pid:123}});
 assert.deepEqual(reconcileRuntimeRecoveryJournal({schemaVersion:1,operations},'publisher'),{records:[],unsettledLaunchId:'next'});
 operations.push({id:'next',component:'publisher',state:'launch-reconciled-no-child'});
 assert.deepEqual(reconcileRuntimeRecoveryJournal({schemaVersion:1,operations},'publisher'),{records:[],unsettledLaunchId:null});
 assert.throws(()=>reconcileRuntimeRecoveryJournal({schemaVersion:1,operations:{}},'publisher'),/unavailable/);
});
