import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {mergeWorldPreferences,mergeWorldAssets,customWorldAsset} from '../lib/world-customization.mjs';

test('customization merges only the intended scope and replacement is explicit',()=>{
 const saved={water:'blue',sound:{enabled:true,volume:.2},own:[1,2]},incoming={water:'red',sound:{enabled:false,newFlag:true},newOption:3};
 assert.deepEqual(mergeWorldPreferences(saved,incoming),{water:'blue',sound:{enabled:true,volume:.2,newFlag:true},own:[1,2],newOption:3});
 assert.deepEqual(mergeWorldPreferences(saved,incoming,'customize'),{water:'red',sound:{enabled:false,volume:.2,newFlag:true},own:[1,2],newOption:3});
 assert.deepEqual(mergeWorldPreferences(saved,incoming,'replace'),incoming);assert.equal(saved.water,'blue');
 for(const mode of ['preserve','customize','replace'])assert.throws(()=>mergeWorldPreferences({},JSON.parse('{"nested":{"__proto__":{}}}'),mode),/Unsafe/);
 const old=[{id:'art',sha256:'old'}],next=[{id:'art',sha256:'new'},{id:'font',sha256:'font'}];
 assert.deepEqual(mergeWorldAssets(old,next),[...old,next[1]]);assert.deepEqual(mergeWorldAssets(old,next,'customize'),next);assert.deepEqual(mergeWorldAssets(old,[],'replace'),[]);
});

test('only explicit public custom scene media paths are permitted',()=>{
 for(const name of ['custom-world/sky.webp','custom-world/town/renderer.mjs','custom-world/font.woff2'])assert.equal(customWorldAsset(name),true,name);
 for(const name of ['custom-world/../secret.png','custom-world/.env','custom-world/config.json','custom-world/.hidden/a.png','custom-world/a\\b.png','custom-world/a.png?x','/custom-world/a.png','assets/private.png'])assert.equal(customWorldAsset(name),false,name);
});

test('both bundled scenes label the actual speed aura and retain bounded fuller clouds',async()=>{
 for(const name of ['agent-outpost/agent-outpost.js','launcher-world113/renderer.js']){
  const text=await readFile(new URL('../web/'+name,import.meta.url),'utf8');assert(!text.includes('Department of Beautiful Chaos'));assert(text.includes('Blue aura · 1.5× movement speed'));assert(text.includes('fast:true'));
 }
 for(const name of ['agent-outpost/colony-art.js','launcher-world113/art.js']){
  const text=await readFile(new URL('../web/'+name,import.meta.url),'utf8');assert.match(text,/const thickness\s*=\s*1\.35/);assert.match(text,/wet\s*\?\s*\.76\s*:\s*\.62/);
 }
});
