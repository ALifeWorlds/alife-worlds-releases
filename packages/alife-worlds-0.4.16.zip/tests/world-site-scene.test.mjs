import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {WORLD_SCENE_FILES} from '../lib/world-profile.mjs';
import {publicWorldId} from '../lib/public-world.mjs';
import {stageWorldSiteScene,readWorldSiteScene} from '../lib/world-site-scene.mjs';
import {readOwnerPreviewQualification} from '../lib/owner-preview-qualification.mjs';
import {createDefaultWorldBackup} from '../lib/default-world-backup.mjs';
const source=fileURLToPath(new URL('../',import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex');

test('custom scene staging exports only selected media and retains the project across plugin refreshes',async()=>{
 const scratch=path.join(source,'runtime/test-fixtures');await mkdir(scratch,{recursive:true});const base=await mkdtemp(path.join(scratch,'scene-stage-'));
 try{
  const root=path.join(base,'project'),site=path.join(base,'site'),projectId='fictional-stage-project',worldId=publicWorldId(projectId);await mkdir(site);await mkdir(path.join(root,'.alife-worlds/runtime'),{recursive:true});
  await writeFile(path.join(root,'.alife-worlds/runtime/antfarm.config.json'),JSON.stringify({nativeReadOnly:true,nativeWorkspaceRoot:root,projectId}));
  const files=[...WORLD_SCENE_FILES.map(relative=>'web/'+relative),'web/custom-world/sky.webp'].map(relative=>{const bytes=Buffer.from('Custom fixture: '+relative);return{path:relative,sha256:sha(bytes),bytes:bytes.length};});
  const design={artDirection:'Fictional custom coast',assets:[],preferences:{water:'violet'}},manifest={schemaVersion:1,kind:'world-artifact',version:'3.0.0',design,files},artifactSha256=sha(JSON.stringify(manifest)),artifact=path.join(root,'.alife-worlds/world-release/artifacts',artifactSha256);
  await mkdir(artifact,{recursive:true});await writeFile(path.join(artifact,'manifest.json'),JSON.stringify(manifest));
  for(const row of files){const file=path.join(artifact,row.path);await mkdir(path.dirname(file),{recursive:true});await writeFile(file,'Custom fixture: '+row.path);}
  await writeFile(path.join(root,'.alife-worlds/world-release/ledger.json'),JSON.stringify({schemaVersion:1,projectId,worldId,projectRoot:root,releases:[{state:'prepared',version:'3.0.0',artifactSha256}]}));
  const profileFile=path.join(root,'.alife-worlds/world-profile.json');await writeFile(profileFile,JSON.stringify({schemaVersion:1,projectId,worldId,revision:2,...design,preferences:{...design.preferences,scene:{schemaVersion:1,renderer:'midnight-colony',version:'3.0.0',artifactSha256}}}));
  const before=await readFile(profileFile),staged=await stageWorldSiteScene({packageRoot:source,projectRoot:root,siteRoot:site,worldId}),qualification=await readOwnerPreviewQualification(source);
  assert.deepEqual(await stageWorldSiteScene({packageRoot:source,projectRoot:root,siteRoot:site,worldId}),staged);assert.deepEqual(await readFile(profileFile),before);
  const read=()=>readWorldSiteScene({siteRoot:site,reference:staged.scene,worldId,qualification});assert.equal((await read()).bytes.get('web/custom-world/sky.webp').toString(),'Custom fixture: web/custom-world/sky.webp');
  const exported=await readFile(path.join(site,staged.scene),'utf8');for(const privateText of [root,projectId,'runtime','artDirection'])assert(!exported.includes(privateText));
  await assert.rejects(stageWorldSiteScene({packageRoot:source,projectRoot:root,siteRoot:site,worldId:'foreign-world'}),/exact selected/);
  await writeFile(path.join(site,path.dirname(staged.scene),'web/custom-world/sky.webp'),'tampered');await assert.rejects(read(),/changed/);assert.deepEqual(await readFile(profileFile),before);
  const scene=JSON.parse(exported);scene.privatePath=root;await writeFile(path.join(site,staged.scene),JSON.stringify(scene));await assert.rejects(read(),/Foreign/);
 }finally{assert(path.resolve(base).startsWith(path.resolve(scratch)+path.sep));await rm(base,{recursive:true,force:true});}
});

test('default backup is an explicit read-only namespace with no selected-profile writes',async()=>{
 let defaultReads=0,snapshotReads=0;
 const handle=createDefaultWorldBackup({packageRoot:source,worldId:'fixture-world',readDefault:async()=>{defaultReads++;return{status:'ready',source:'qualified-default',selection:{files:[]}};},readSnapshot:async()=>{snapshotReads++;return{fixture:'sanitized actual source'};}});
 const call=(route,method='GET')=>handle(new Request('http://127.0.0.1:43210'+route,{method}));
 assert.equal(await call('/other'),null);assert.equal((await call('/default-world/','POST')).status,405);assert.equal(defaultReads,0);
 assert.equal((await call('/default-world/?project=foreign')).status,404);assert.equal(defaultReads,0);
 const page=await call('/default-world/'),html=await page.text();assert.equal(page.status,200);assert(html.includes('Default world backup'));assert(html.includes('/default-world/api/world-view'));assert(html.includes('<base href="/default-world/">'));
 assert.equal((await call('/default-world/','HEAD')).body,null);
 assert.deepEqual(await(await call('/default-world/api/world-view')).json(),{fixture:'sanitized actual source'});assert.equal(snapshotReads,1);
 assert.equal((await call('/default-world/private.json')).status,404);assert.equal((await call('/default-world/agent-outpost/agent-outpost.js')).status,404);
});
