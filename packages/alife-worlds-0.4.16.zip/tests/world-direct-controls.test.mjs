import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const renderer=readFileSync(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8');
const start=renderer.indexOf(' // Direct candidate controls apply preferences without granting audio or writing storage.');
const end=renderer.indexOf(' privacyButton.onclick=',start);
assert.ok(start>0&&end>start);
const directControls=renderer.slice(start,end);
const soundControl=renderer.slice(renderer.indexOf('function createSoundControl('),renderer.indexOf('function mount('));
const stopped=renderer.match(/ let worldVisible=true;const stopped=[^\r\n]+/)[0];

function fixture(){
 const calls={refresh:0,volume:[],draw:0,settle:0,storage:0,synthetic:0};
 class Node{constructor(){this.attributes={};}append(){}setAttribute(k,v){this.attributes[k]=v;}dispatchEvent(){calls.synthetic++;throw Error('Synthetic events forbidden');}click(){calls.synthetic++;throw Error('Synthetic clicks forbidden');}}
 const document={hidden:false,createElement:()=>new Node(),createTextNode:()=>new Node()},pause=new Node(),host={dataset:{}},samplePlayer={refresh(){calls.refresh++;},setVolume(v){calls.volume.push(v);return v;},setEnabled(){throw Error('Sound enablement forbidden');}};
 const context=vm.createContext({document,pause,host,samplePlayer,localStorage:{setItem(){calls.storage++;throw Error('Candidate persistence forbidden');}},onDraw:()=>calls.draw++,onSettle:()=>calls.settle++});
 vm.runInContext("let disposed=false,paused=false,volumeLevel=1,less=false,snapshot=null;const media={matches:false};function draw(){onDraw();}function settleTransits(){onSettle();}",context);
 vm.runInContext(stopped,context);vm.runInContext(soundControl,context);vm.runInContext("const soundUI=createSoundControl(document,{onVolume(){throw Error('Synthetic slider callback forbidden');}});",context);vm.runInContext(directControls,context);
 return{context,calls,pause,host,document,call(name,value){context.nextValue=value;return vm.runInContext(name+'(nextValue)',context);},run:s=>vm.runInContext(s,context)};
}

test('direct pause applies its real preference, motion UI and player refresh without persistence',()=>{
 const f=fixture();assert.equal(f.call('setPaused',true),true);assert.equal(f.pause.textContent,'Resume motion');assert.equal(f.pause.attributes['aria-pressed'],'true');assert.equal(f.host.dataset.motion,'paused');assert.equal(f.calls.settle,1);
 assert.equal(f.call('setPaused',false),false);assert.equal(f.pause.textContent,'Pause motion');assert.equal(f.host.dataset.motion,'running');assert.equal(f.calls.refresh,2);assert.equal(f.calls.draw,2);assert.equal(f.calls.storage,0);assert.equal(f.calls.synthetic,0);
 f.document.hidden=true;assert.equal(f.call('setPaused',false),false);assert.equal(f.host.dataset.motion,'paused');
});

test('direct volume updates retained level, actual slider and sample level while Sound stays muted',()=>{
 const f=fixture();for(const volume of [0,.37,1]){assert.equal(f.call('setVolume',volume),volume);assert.equal(f.run('volumeLevel'),volume);assert.equal(f.run('soundUI.range.value'),String(Math.round(volume*100)));assert.equal(f.run('soundUI.volumeBox.hidden'),true);assert.equal(f.run('soundUI.range.disabled'),true);}
 assert.deepEqual(f.calls.volume,[0,.37,1]);assert.equal(f.calls.storage,0);assert.equal(f.calls.synthetic,0);assert.equal(f.calls.refresh,0);
});

test('invalid values and disposed mounts return current values without applying side effects',()=>{
 const f=fixture();f.call('setPaused',true);f.call('setVolume',.4);const before=JSON.stringify(f.calls);
 for(const invalid of [null,undefined,0,1,'false',{}])assert.equal(f.call('setPaused',invalid),true);
 for(const invalid of [null,undefined,NaN,Infinity,-Infinity,-.1,1.1,'0.4',true,{}])assert.equal(f.call('setVolume',invalid),.4);
 assert.equal(JSON.stringify(f.calls),before);f.run('disposed=true');assert.equal(f.call('setPaused',false),true);assert.equal(f.call('setVolume',.9),.4);assert.equal(JSON.stringify(f.calls),before);
});

test('both renderer aliases expose the same direct mount controls',()=>{
 assert.equal(renderer,readFileSync(new URL('../web/launcher-world113/renderer.js',import.meta.url),'utf8'));
 assert.ok(renderer.includes('restoreVisualState,getResourceStatus,setPaused,setVolume,setWorldVersion('));
});
