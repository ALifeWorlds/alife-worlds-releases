import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,copyFile,cp,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import vm from 'node:vm';
import {webcrypto,createHash} from 'node:crypto';
import {createProjection} from '../lib/projection.mjs';import {createDemo} from '../lib/demo.mjs';import {customProjectRegistry} from './custom-project-registry.mjs';import {publicWorldSnapshot} from '../lib/public-world.mjs';import {assertPublicWorldSnapshot} from '../lib/public-world-contract.mjs';import {assertLocalAppearance,canonicalWorldJSON} from '../lib/local-world-appearance.mjs';import {PREVIEW_DESCRIPTOR,previewManifest} from '../lib/world-preview.mjs';
import {localWorldUrls,loadLauncherProfile,projectRootIdentity,loopbackOrigin,openConfiguredWorld,launcherResource,LAUNCHER_URI,LAUNCHER_MIME} from '../lib/world-launcher.mjs';
import {collectPackageInputs} from '../lib/plugin-version.mjs';
const source=fileURLToPath(new URL('../',import.meta.url)),scratch=path.join(source,'runtime/test-fixtures');
async function fixture(fn){
 await mkdir(scratch,{recursive:true});const base=await mkdtemp(path.join(scratch,'launcher-')),packageRoot=path.join(base,'package'),profilePath=path.join(base,'launcher-profile.json'),projectRoot=path.join(base,'private-project'),otherRoot=path.join(base,'other-project');
 for(const dir of [packageRoot,projectRoot,otherRoot,'web','scripts','lib','assets'].map(d=>path.isAbsolute(d)?d:path.join(packageRoot,d)))await mkdir(dir,{recursive:true});
 await writeFile(path.join(packageRoot,'package.json'),'{"name":"alife-worlds","version":"0.0.0"}\n');
 for(const rel of ['lib/world-launcher.mjs','lib/world-preview.mjs','lib/local-world-appearance.mjs','lib/public-world-contract.mjs','scripts/world-launcher.mjs','assets/icon.png','assets/icon-monochrome.svg','assets/icon-monochrome-dark.svg','web/audio.mjs','web/world-view.css','web/world-preview-art.mjs'])await copyFile(path.join(source,rel),path.join(packageRoot,rel));
 await cp(path.join(source,'web/launcher-world113'),path.join(packageRoot,'web/launcher-world113'),{recursive:true});await cp(path.join(source,'web/assets'),path.join(packageRoot,'web/assets'),{recursive:true});await cp(path.join(source,'web/agent-outpost/assets'),path.join(packageRoot,'web/agent-outpost/assets'),{recursive:true});await writeFile(path.join(packageRoot,'web/world-launcher.html'),(await readFile(path.join(source,'web/world-launcher.html'),'utf8')).replace('<title>ALife Worlds</title>','<title>Protocol test fixture only</title>'));
 const row={id:'one',label:'Local World',projectId:'PRIVATE-CANONICAL-PROJECT',worldId:'world-fixture',projectRoot,origin:'http://127.0.0.1:7491'};
 const save=(worlds,schemaVersion=1)=>writeFile(profilePath,JSON.stringify({schemaVersion,worlds}));
 const health=async(origin,override={})=>({schemaVersion:1,kind:'alife-world-launcher',projectId:row.projectId,worldId:row.worldId,projectRootSha256:await projectRootIdentity(projectRoot),origin,...override});
 const servers=[];
 async function server(handler){
  const calls=[],instance=http.createServer((req,res)=>{calls.push({method:req.method,url:req.url,headers:req.headers});handler(req,res);});
  await new Promise(resolve=>instance.listen(0,'127.0.0.1',resolve));servers.push(instance);
  return{instance,calls,origin:'http://127.0.0.1:'+instance.address().port};
 }
 try{await fn({base,packageRoot,profilePath,projectRoot,otherRoot,row,save,health,server,options:{packageRoot,profilePath}});}
 finally{for(const s of servers){s.closeAllConnections();await new Promise(resolve=>s.close(resolve));}
  assert.ok(path.resolve(base).startsWith(path.resolve(scratch)+path.sep));await rm(base,{recursive:true,force:true});
 }
}
const json=(res,value,status=200)=>{res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(value));};

test('empty invocation lists configured worlds but never probes, defaults or falls back',async()=>fixture(async f=>{
 let probes=0;const s=await f.server((q,r)=>{probes++;json(r,{});});await f.save([{...f.row,origin:s.origin}]);
 const out=await openConfiguredWorld({},f.options);assert.equal(out.status,'selection-required');assert.equal(out.selected,null);assert.deepEqual(out.worlds,[{id:'one',label:'Local World'}]);assert.equal(probes,0);
 const encoded=JSON.stringify(out);for(const privateText of [f.projectRoot,f.row.projectId,f.row.worldId,'projectRootSha256','profilePath'])assert.ok(!encoded.includes(privateText));
 const unknown=await openConfiguredWorld({worldId:'foreign'},f.options);assert.equal(unknown.status,'unavailable');assert.equal(unknown.selected,null);assert.equal(probes,0);
 await assert.rejects(openConfiguredWorld({worldId:'one',url:'https://example.com'},f.options),/configured worldId/);assert.equal(probes,0);
}));

test('profile rejects ambiguity, foreign origins, extra fields and missing roots',async()=>fixture(async f=>{
 assert.equal((await loadLauncherProfile(f.options)).status,'unconfigured');
 const invalid=['http://localhost:7491','https://127.0.0.1:7491','http://127.0.0.2:7491','http://2130706433:7491','http://127.0.0.1:0','http://127.0.0.1:65536','http://user@127.0.0.1:7491','http://127.0.0.1:7491/a','http://127.0.0.1:7491?x=1','https://example.com'];
 for(const origin of invalid){await f.save([{...f.row,origin}]);assert.equal((await loadLauncherProfile(f.options)).status,'unavailable',origin);}
 for(const patch of [{projectRoot:'relative'},{projectRoot:path.join(f.base,'absent')},{label:'https://private.example'},{credential:'PRIVATE-SECRET'}]){await f.save([{...f.row,...patch}]);assert.equal((await loadLauncherProfile(f.options)).status,'unavailable');}
 const two={...f.row,id:'two',projectId:'other-canonical',worldId:'world-other',projectRoot:f.otherRoot,origin:'http://127.0.0.1:7492'};
 for(const key of ['id','projectId','worldId','projectRoot','origin']){await f.save([f.row,{...two,[key]:f.row[key]}]);assert.equal((await loadLauncherProfile(f.options)).status,'unavailable',key);}
 await f.save([]);assert.equal((await loadLauncherProfile(f.options)).status,'unconfigured');
 await f.save([f.row]);await copyFile(f.profilePath,path.join(f.packageRoot,'profile.json'));assert.equal((await loadLauncherProfile({...f.options,profilePath:path.join(f.packageRoot,'profile.json')})).status,'unavailable');
 await writeFile(f.profilePath,'x'.repeat(65537));assert.equal((await loadLauncherProfile(f.options)).status,'unavailable');
 for(const profilePath of ['\\\\remote\\share\\profile.json','//remote/share/profile.json','\\\\?\\C:\\profile.json'])assert.equal((await loadLauncherProfile({...f.options,profilePath})).status,'unavailable');
 await assert.rejects(projectRootIdentity('\\\\remote\\share\\project'));
 assert.equal(loopbackOrigin('http://127.0.0.1:7491'),'http://127.0.0.1:7491');
}));

test('ready selection requires exact live project/root/world/origin and exposes only safe output',async()=>fixture(async f=>{
 let answer;const s=await f.server((q,r)=>json(r,answer));answer=await f.health(s.origin);await f.save([{...f.row,origin:s.origin}]);
 const out=await openConfiguredWorld({worldId:'one'},f.options);assert.equal(out.status,'ready');assert.deepEqual(out.selected,{id:'one',label:'Local World',viewerUrl:s.origin+'/?project=PRIVATE-CANONICAL-PROJECT',previewUrl:s.origin+'/world/view?project=world-fixture'});
 assert.equal(s.calls.length,1);assert.equal(s.calls[0].method,'GET');assert.equal(s.calls[0].url,'/api/world-launcher?project=PRIVATE-CANONICAL-PROJECT');assert.equal(s.calls[0].headers.authorization,undefined);assert.equal(s.calls[0].headers.cookie,undefined);
 for(const override of [{projectId:'foreign'},{worldId:'foreign'},{projectRootSha256:'0'.repeat(64)},{origin:'http://127.0.0.1:1'},{kind:'foreign'},{privateText:'PRIVATE-SECRET'}]){
  answer=await f.health(s.origin,override);const failed=await openConfiguredWorld({worldId:'one'},f.options);assert.equal(failed.status,'unavailable');assert.equal(failed.selected,null);assert.ok(!JSON.stringify(failed).includes('PRIVATE-SECRET'));
 }
}));

test('health refuses redirects, bad/oversized bodies and bounded hangs',async()=>fixture(async f=>{
 let mode='redirect';const s=await f.server((q,r)=>{
  if(mode==='redirect'){r.writeHead(302,{Location:'http://127.0.0.1:1/private'});r.end();}
  if(mode==='malformed'){r.writeHead(200,{'Content-Type':'application/json'});r.end('PRIVATE-SECRET{');}
  if(mode==='oversized'){r.writeHead(200,{'Content-Type':'application/json'});r.end('"'+('x'.repeat(9000))+'"');}
  if(mode==='html'){r.writeHead(200,{'Content-Type':'text/html'});r.end('PRIVATE-SECRET');}
 });
 await f.save([{...f.row,origin:s.origin}]);
 for(mode of ['redirect','malformed','oversized','html','hang']){
  const before=s.calls.length,start=Date.now(),out=await openConfiguredWorld({worldId:'one'},{...f.options,timeoutMs:100});
  assert.equal(out.status,'unavailable');assert.equal(out.selected,null);assert.ok(!JSON.stringify(out).includes('PRIVATE-SECRET'));assert.ok(Date.now()-start<2000);assert.equal(s.calls.length,before+1);
 }
}));

test('v8 assembled resource never requests frame/network origins or reads the private profile',async()=>fixture(async f=>{
 let probes=0;const server=await f.server((q,r)=>{probes++;json(r,{});});await f.save([{...f.row,origin:server.origin}]);const get=async()=>{const {contents:[r]}=await launcherResource(f.options);assert.equal(r.uri,'ui://alife-worlds/launcher/v8.html');assert.equal(r.uri,LAUNCHER_URI);assert.equal(r.mimeType,LAUNCHER_MIME);assert.match(r.text,/Protocol test fixture only/);assert.deepEqual(r._meta.ui.csp,{connectDomains:[],resourceDomains:[],frameDomains:[]});assert.ok(Buffer.byteLength(r.text)<=524288);assert.doesNotMatch(r.text,/<iframe\b/i);for(const secret of [f.projectRoot,f.row.projectId,'PRIVATE-SECRET'])assert.ok(!r.text.includes(secret));};await get();await writeFile(f.profilePath,'PRIVATE-SECRET{');await get();await rm(f.profilePath);await get();assert.equal(probes,0);await rm(path.join(f.packageRoot,'web/world-launcher.html'));await assert.rejects(launcherResource(f.options));
}));

async function client(f,fn){
 const child=spawn(process.execPath,[path.join(f.packageRoot,'scripts/world-launcher.mjs')],{cwd:f.packageRoot,env:{...process.env,ALIFE_WORLD_PROFILE:f.profilePath},stdio:['pipe','pipe','pipe'],windowsHide:true});
 let buffer='',stderr='',sequence=0;const pending=new Map(),messages=[];
 child.stderr.on('data',b=>{stderr+=b;});child.stdout.on('data',b=>{buffer+=b;let n;while((n=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,n);buffer=buffer.slice(n+1);const m=JSON.parse(line);messages.push(m);const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);p.resolve(m);}}});
 function request(method,params){const id=++sequence;const promise=new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Error('MCP reply timed out: '+stderr));},4000);pending.set(id,{resolve,reject,timer});});child.stdin.write(JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n');return {id,promise};}
 const notify=(method,params)=>child.stdin.write(JSON.stringify({jsonrpc:'2.0',method,params})+'\n');
 async function initialize(){const r=await request('initialize',{protocolVersion:'2025-11-25',capabilities:{},clientInfo:{name:'isolated-fixture',version:'1.0.0'}}).promise;notify('notifications/initialized',{});return r;}
 try{await fn({request,notify,initialize,child,messages,getStderr:()=>stderr});}
 finally{for(const p of pending.values())clearTimeout(p.timer);if(child.exitCode===null){const exited=once(child,'exit');child.stdin.end();const timeout=setTimeout(()=>child.kill(),2000);try{await exited;}finally{clearTimeout(timeout);}}}
}

test('real stdio enforces lifecycle and advertises only the selected launcher/resource',async()=>fixture(async f=>{
 await f.save([f.row]);await client(f,async c=>{
  assert.equal((await c.request('tools/list',{}).promise).error.code,-32000);
  const iconFile=path.join(f.packageRoot,'assets/icon.png'),originalIcon=await readFile(iconFile);assert.ok(originalIcon.length>65536&&originalIcon.length<=768*1024);
  const init=await c.initialize();assert.equal(init.result.protocolVersion,'2025-11-25');assert.equal(init.result.serverInfo.version,'0.0.0');const icons=init.result.serverInfo.icons;assert.equal(icons.length,2);for(const [i,icon]of icons.entries()){assert.equal(icon.mimeType,'image/svg+xml');assert.deepEqual(icon.sizes,['64x64']);assert.equal(icon.theme,i?'dark':'light');const bytes=Buffer.from(icon.src.slice('data:image/svg+xml;base64,'.length),'base64');assert.deepEqual(bytes,await readFile(path.join(f.packageRoot,i?'assets/icon-monochrome-dark.svg':'assets/icon-monochrome.svg')));}assert.deepEqual(await readFile(iconFile),originalIcon);
  // The same connection retains its one fixed descriptor, even if its fixture
  // asset changes. A new connection is required to inspect a changed package.
  await writeFile(iconFile,'not a PNG; synthetic fixture only');
  const tools=(await c.request('tools/list',{}).promise).result.tools;assert.deepEqual(tools[0].icons,icons);assert.deepEqual((await c.request('tools/list',{}).promise).result.tools[0].icons,icons);assert.deepEqual(tools.map(t=>t.name),['open_world','read_world_preview','read_world_art']);assert.equal(tools[0]._meta.ui.resourceUri,LAUNCHER_URI);assert.deepEqual(tools[0].outputSchema.properties.selected.anyOf[1].required,['id','label','viewerUrl','previewUrl']);assert.equal(tools[0].outputSchema.properties.selected.anyOf[1].additionalProperties,false);assert.deepEqual(tools[0]._meta['openai/ui'].entrypoints,[{type:'global'},{type:'thread'}]);assert.equal(tools[0].annotations.readOnlyHint,true);
  assert.equal((await c.request('resources/list',{}).promise).result.resources[0].uri,LAUNCHER_URI);
  const resource=(await c.request('resources/read',{uri:LAUNCHER_URI}).promise).result.contents[0];assert.equal(resource.mimeType,LAUNCHER_MIME);assert.deepEqual(resource._meta.ui.csp,{connectDomains:[],resourceDomains:[],frameDomains:[]});
  const empty=(await c.request('tools/call',{name:'open_world',arguments:{}}).promise).result;assert.equal(empty.structuredContent.status,'selection-required');assert.equal(empty.structuredContent.selected,null);assert.equal(Object.hasOwn(empty,'icons'),false);assert.ok(!JSON.stringify(empty).includes('data:image/'));assert.equal(Object.hasOwn(resource,'icons'),false);assert.ok(!JSON.stringify(resource).includes('data:image/'));
  for(const [method,params,code] of [
   ['tools/call',{name:'send_message',arguments:{}},-32602],
   ['tools/call',{name:'open_world',arguments:{url:'https://example.com'}},-32602],
   ['resources/read',{uri:'ui://alife-worlds/launcher/v1.html'},-32602],
   ['resources/read',{uri:'ui://alife-worlds/launcher/v2.html'},-32602],
   ['resources/read',{uri:'ui://alife-worlds/launcher/v3.html'},-32602],
   ['resources/read',{uri:'file://private-profile'},-32602],
   ['reset_project',{},-32601]
  ])assert.equal((await c.request(method,params).promise).error.code,code);
  await rm(path.join(f.packageRoot,'web/world-launcher.html'));assert.equal((await c.request('resources/read',{uri:LAUNCHER_URI}).promise).error.code,-32002);assert.equal(c.getStderr(),'');
 });
}));

test('invalid or oversized packaged icon is omitted from metadata without disabling the read-only launcher',async()=>fixture(async f=>{
 await rm(path.join(f.packageRoot,'assets/icon-monochrome.svg'));await rm(path.join(f.packageRoot,'assets/icon-monochrome-dark.svg'));const iconFile=path.join(f.packageRoot,'assets/icon.png'),original=await readFile(iconFile),corruptHeader=Buffer.from(original);corruptHeader[29]^=1;
 await f.save([]);
 for(const [name,bytes]of [['missing',null],['oversized',Buffer.alloc(768*1024+1)],['non-png',Buffer.from('synthetic non-PNG')],['corrupt-IHDR',corruptHeader]]){
  if(bytes===null)await rm(iconFile);else await writeFile(iconFile,bytes);
  await client(f,async c=>{
   const init=await c.initialize();assert.equal(Object.hasOwn(init.result.serverInfo,'icons'),false,name);
   await writeFile(iconFile,original);const tools=(await c.request('tools/list',{}).promise).result.tools;assert.deepEqual(tools.map(t=>t.name),['open_world','read_world_preview','read_world_art']);assert.equal(Object.hasOwn(tools[0],'icons'),false,name);assert.equal(tools[0].annotations.readOnlyHint,true);
   assert.deepEqual((await c.request('ping',{}).promise).result,{});const call=(await c.request('tools/call',{name:'open_world',arguments:{}}).promise).result;assert.equal(call.structuredContent.status,'unconfigured');assert.equal(Object.hasOwn(call,'icons'),false);assert.ok(!JSON.stringify(call).includes('data:image/'));assert.equal(c.getStderr(),'');
  });
 }
}));

test('stdio cancellation aborts only its bounded read',async()=>fixture(async f=>{
 let began;const started=new Promise(resolve=>{began=resolve;});const s=await f.server(()=>began());await f.save([{...f.row,origin:s.origin}]);
 await client(f,async c=>{await c.initialize();const request=c.request('tools/call',{name:'open_world',arguments:{worldId:'one'}});await started;c.notify('notifications/cancelled',{requestId:request.id});assert.equal((await request.promise).error.code,-32800);assert.equal(s.calls.length,1);assert.deepEqual((await c.request('ping',{}).promise).result,{});});
}));

test('portable/compat wiring includes the transport and excludes private profiles',async()=>{
 const read=async rel=>JSON.parse(await readFile(path.join(source,rel),'utf8'));
 const portable=await read('mcp.json'),compat=await read('.mcp.json'),manifest=await read('.codex-plugin/plugin.json');
 assert.equal(portable.$schema,'https://agent-plugins.org/schemas/1.0.0/mcp.schema.json');assert.deepEqual(Object.keys(portable.mcpServers),['alife-worlds']);
 const target=portable.mcpServers['alife-worlds'],token='$'+'{PLUGIN_ROOT}';assert.equal(target.type,'stdio');assert.equal(target.command,'node');assert.deepEqual(target.args,[token+'/scripts/world-launcher.mjs']);assert.equal(target.cwd,token);
 assert.deepEqual(compat.mcpServers['alife-worlds'],{command:target.command,args:target.args,cwd:target.cwd});assert.equal(manifest.mcpServers,'./.mcp.json');
 const files=await collectPackageInputs(source);for(const required of ['mcp.json','.mcp.json','scripts/world-launcher.mjs','lib/world-launcher.mjs'])assert.ok(files.includes(required));assert.ok(!files.some(f=>f.includes('launcher-profile.json')||f.startsWith('runtime/')));
});

test('opaque native project IDs retain exact health identity without weakening aliases or world IDs',async()=>fixture(async f=>{
 let answer;const s=await f.server((q,r)=>json(r,answer));
 for(const projectId of ['g-p-fixture-native-project','saved-local:opaque-fixture','opaque-'+('x'.repeat(249))]){
  answer=await f.health(s.origin,{projectId});await f.save([{...f.row,projectId,origin:s.origin}]);
  assert.equal((await loadLauncherProfile(f.options)).status,'configured');
  const result=await openConfiguredWorld({worldId:'one'},f.options);
  assert.equal(result.status,'ready');
  assert.equal(new URL(s.calls.at(-1).url,s.origin).searchParams.get('project'),projectId);
  assert.equal(result.selected.viewerUrl,s.origin+'/?project='+encodeURIComponent(projectId));
  const {viewerUrl,...selection}=result.selected;assert.ok(!JSON.stringify({...result,selected:selection}).includes(projectId));
  const picker=await openConfiguredWorld({},f.options);assert.equal(picker.status,'selection-required');assert.ok(!JSON.stringify(picker).includes(projectId));
  answer={...answer,projectId:projectId+'-different'};
  assert.equal((await openConfiguredWorld({worldId:'one'},f.options)).status,'unavailable');
 }
 for(const projectId of ['',null,' leading','trailing ','with\ncontrol','with\u007fcontrol','x'.repeat(257)]){
  await f.save([{...f.row,projectId,origin:s.origin}]);
  assert.equal((await loadLauncherProfile(f.options)).status,'unavailable');
 }
 for(const patch of [{id:'alias:invalid'},{worldId:'world:invalid'}]){
  await f.save([{...f.row,...patch,origin:s.origin}]);
  assert.equal((await loadLauncherProfile(f.options)).status,'unavailable');
 }
}));

test('local dashboard and spectator URLs keep their separate exact project identities',()=>{
 const project='PROJECT / 7?mode=private&x=#',urls=localWorldUrls('http://127.0.0.1:7491',project,'world-fixture');
 assert.equal(new URL(urls.operatorUrl).pathname,'/');assert.equal(new URL(urls.operatorUrl).searchParams.get('project'),project);assert.equal([...new URL(urls.operatorUrl).searchParams.keys()].length,1);
 assert.equal(urls.viewerUrl,'http://127.0.0.1:7491/world/view?project=world-fixture');
 for(const origin of ['https://outside.example','http://localhost:7491','http://name:secret@127.0.0.1:7491','http://127.0.0.1:7491/other'])assert.throws(()=>localWorldUrls(origin,project,'world-fixture'));
 assert.throws(()=>localWorldUrls('http://127.0.0.1:7491','bad\nproject','world-fixture'));
});


test('versioned private renderer descriptors preserve operator access and only attest supported inline identities',async()=>fixture(async f=>{let answer;const server=await f.server((q,r)=>json(r,answer));answer=await f.health(server.origin);const renderer={...PREVIEW_DESCRIPTOR,schemaVersion:2,appearance:'owner-local-v1'};await f.save([{...f.row,origin:server.origin,renderer}],2);const profile=await loadLauncherProfile(f.options);assert.equal(profile.status,'configured');assert.deepEqual(profile.worlds[0].renderer,renderer);assert.equal((await openConfiguredWorld({worldId:'one'},f.options)).status,'ready');await f.save([{...f.row,origin:server.origin,renderer:{...renderer,bundleId:'custom-uninstalled'}}],2);assert.equal((await openConfiguredWorld({worldId:'one'},f.options)).status,'ready');await f.save([{...f.row,origin:server.origin,renderer:{...renderer,path:'private'}}],2);assert.equal((await loadLauncherProfile(f.options)).status,'unavailable');}));


test('monochrome SVG containment fails closed and required inline assets are admitted without private runtime files',async()=>fixture(async f=>{const files=await collectPackageInputs(source);for(const rel of ['assets/icon.png','assets/icon-monochrome.svg','assets/icon-monochrome-dark.svg','lib/world-preview.mjs','lib/local-world-appearance.mjs','web/launcher-world113/renderer.js','web/launcher-world113/art.js','web/launcher-world113/manifest.json'])assert.ok(files.includes(rel),rel);assert.ok(!files.some(v=>v.includes('owner-preview015')||v.startsWith('runtime/')));for(const rel of ['assets/icon-monochrome.svg','assets/icon-monochrome-dark.svg']){const svg=await readFile(path.join(source,rel),'utf8');assert.match(svg,/viewBox="0 0 64 64"/);assert.match(svg,/fill="CanvasText"/);assert.doesNotMatch(svg,/<script|<image|href=|onload=|https?:\/\/(?!www\.w3\.org\/2000\/svg)/i);}await writeFile(path.join(f.packageRoot,'assets/icon-monochrome.svg'),'<svg><script>untrusted fixture</script></svg>');await f.save([]);await client(f,async c=>{const init=await c.initialize();assert.equal(init.result.serverInfo.icons[0].mimeType,'image/png');assert.ok(!JSON.stringify(init).includes('untrusted fixture'));});await rm(path.join(f.packageRoot,'assets/icon.png'));await client(f,async c=>{const init=await c.initialize();assert.equal(Object.hasOwn(init.result.serverInfo,'icons'),false);assert.equal((await c.request('ping',{}).promise).result!==undefined,true);});}));

test('owner inventory lists verified-root folder names without health probes or private paths',async()=>fixture(async f=>{
 const {ownerWorldProjects,openOwnerWorld}=await import('../lib/world-projects.mjs');
 let aHealth,bHealth;const a=await f.server((q,r)=>json(r,aHealth)),b=await f.server((q,r)=>json(r,bHealth));
 aHealth=await f.health(a.origin);bHealth=await f.health(b.origin,{projectId:'other-project',worldId:'world-other',projectRootSha256:await projectRootIdentity(f.otherRoot)});
 const rows=[{...f.row,origin:a.origin,renderer:{...PREVIEW_DESCRIPTOR}},{id:'two',label:'Saved alias label',projectId:'other-project',worldId:'world-other',projectRoot:f.otherRoot,origin:b.origin}];await f.save(rows,2);
 const options={...f.options,projectRoot:f.projectRoot,projectId:f.row.projectId,worldId:f.row.worldId,origin:a.origin,config:{}};
 const listing=await ownerWorldProjects(options);assert.equal(listing.source,'launcher-profile');assert.equal(listing.status,'configured');assert.equal(listing.currentId,'one');assert.deepEqual(listing.projects.map(row=>row.name),['private-project','other-project']);assert.deepEqual(listing.projects.map(row=>row.preview),['supported','unsupported']);assert.ok(listing.projects.every(row=>row.availability==='unconfirmed'));assert.equal(a.calls.length,0);assert.equal(b.calls.length,0);
 for(const text of [f.projectRoot,f.otherRoot,f.profilePath,'projectRootSha256','operatorUrl','viewerUrl',a.origin,b.origin])assert.ok(!JSON.stringify(listing).includes(text),text);
 const opened=await openOwnerWorld('two',options);assert.equal(opened.status,'ready');assert.equal(opened.selected.preview,'unsupported');assert.equal(opened.selected.operatorUrl,b.origin+'/?project=other-project');assert.equal(opened.selected.viewerUrl,b.origin+'/world/view?project=world-other');assert.equal(b.calls.length,1);assert.equal(a.calls.length,0);assert.equal(b.calls[0].url,'/api/world-launcher?project=other-project');
 const unchanged=await ownerWorldProjects(options);assert.deepEqual(unchanged,listing);assert.equal(b.calls.length,1);
 for(const mismatch of [{projectRoot:f.otherRoot},{projectId:'foreign'},{worldId:'foreign-world'},{origin:'http://127.0.0.1:1'}]){const failed=await ownerWorldProjects({...options,...mismatch});assert.equal(failed.status,'unavailable');assert.deepEqual(failed.projects,[]);}
 assert.equal(a.calls.length,0);assert.equal(b.calls.length,1);
}));
test('owner selection reuses exactly one selected health check and fails closed without fallback links',async()=>fixture(async f=>{
 const {ownerWorldProjects,openOwnerWorld}=await import('../lib/world-projects.mjs');let answer;const a=await f.server((q,r)=>json(r,{})),b=await f.server((q,r)=>json(r,answer));const other={id:'two',label:'Other',projectId:'other-project',worldId:'world-other',projectRoot:f.otherRoot,origin:b.origin};
 const healthy=await f.health(b.origin,{projectId:other.projectId,worldId:other.worldId,projectRootSha256:await projectRootIdentity(f.otherRoot)});answer=healthy;await f.save([{...f.row,origin:a.origin},other]);const options={...f.options,projectRoot:f.projectRoot,projectId:f.row.projectId,worldId:f.row.worldId,origin:a.origin,config:{}};
 for(const id of ['unknown','bad alias'])assert.equal((await openOwnerWorld(id,options)).selected,null);assert.equal(b.calls.length,0);assert.equal(a.calls.length,0);
 for(const patch of [{projectId:'foreign'},{worldId:'foreign'},{projectRootSha256:'0'.repeat(64)},{origin:a.origin},{secret:'PRIVATE'}]){answer={...healthy,...patch};const before=b.calls.length,result=await openOwnerWorld('two',options);assert.equal(result.status,'unavailable');assert.equal(result.selected,null);assert.equal(b.calls.length,before+1);assert.ok(!JSON.stringify(result).includes(b.origin));}
 answer={};const inventory=await ownerWorldProjects(options);assert.equal(inventory.projects.length,2);assert.ok(inventory.projects.every(row=>row.availability==='unconfirmed'));assert.equal(a.calls.length,0);
 const controller=new AbortController();controller.abort();const before=b.calls.length;assert.equal((await openOwnerWorld('two',{...options,signal:controller.signal})).selected,null);assert.equal(b.calls.length,before);await new Promise(resolve=>b.instance.close(resolve));const offline=await openOwnerWorld('two',options);assert.equal(offline.status,'unavailable');assert.equal(offline.selected,null);assert.equal((await ownerWorldProjects(options)).projects.length,2);assert.equal(a.calls.length,0);
}));
test('owner inventory uses explicit legacy compatibility only for a genuinely unconfigured profile',async()=>fixture(async f=>{
 const {ownerWorldProjects,openOwnerWorld}=await import('../lib/world-projects.mjs');const options={...f.options,projectRoot:f.projectRoot,projectId:f.row.projectId,worldId:f.row.worldId,origin:'http://127.0.0.1:7491',config:{worldProjects:[{id:'legacy-other',folderName:'Legacy other',worldId:'world-legacy',origin:'http://127.0.0.1:7492'}]}};
 const fallback=await ownerWorldProjects(options);assert.equal(fallback.source,'legacy-config');assert.equal(fallback.status,'legacy');assert.equal(fallback.currentId,'legacy-current');assert.equal(fallback.projects.length,2);assert.equal(fallback.projects[0].name,'private-project');assert.equal((await openOwnerWorld('legacy-1',options)).selected,null);assert.ok(!JSON.stringify(fallback).includes('http:'));
 await writeFile(f.profilePath,'PRIVATE malformed');assert.equal((await ownerWorldProjects(options)).status,'unavailable');
 await f.save([{...f.row,projectRoot:f.otherRoot}]);assert.equal((await ownerWorldProjects(options)).status,'unavailable');
 await f.save([f.row,{...f.row,id:'duplicate'}]);assert.equal((await ownerWorldProjects(options)).status,'unavailable');
 await f.save([{...f.row,projectRoot:path.join(f.base,'missing')}]);assert.equal((await ownerWorldProjects(options)).status,'unavailable');
 assert.equal((await ownerWorldProjects({...options,profilePath:'relative.json'})).status,'unavailable');
}));

test('folder labels use the verified real root for canonical dot-segment paths',async()=>fixture(async f=>{
 const root=f.projectRoot+path.sep+'.',parent=f.projectRoot+path.sep+'..'+path.sep+path.basename(f.projectRoot);for(const projectRoot of [root,parent]){await f.save([{...f.row,projectRoot}]);const profile=await loadLauncherProfile(f.options);assert.equal(profile.status,'configured');assert.equal(profile.worlds[0].folderName,'private-project');assert.equal(profile.worlds[0].projectRootSha256,await projectRootIdentity(f.projectRoot));}
}));
