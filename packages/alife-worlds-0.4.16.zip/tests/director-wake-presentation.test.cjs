const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const code=fs.readFileSync(path.join(__dirname,'../web/launcher-world113/renderer.js'),'utf8'),box={module:{exports:{}},require:()=>({}),URL};vm.runInNewContext(code,box);const api=box.module.exports,plain=v=>JSON.parse(JSON.stringify(v));
const scope={worldKey:'scene-inert-wake',artKey:'pine139',audienceKey:'owner-fixture'},worldId='inert-owner-world',issue='a'.repeat(64),requestId='11111111-1111-4111-8111-111111111111';
function harness(){let clock=Date.now(),record=null,calls=[],listener=null,unsubscribed=0,changed=0;
 const agent={threadId:'inert-ant',roleId:'worker1',role:'worker',title:'Inert ant',connected:true,onboarded:true},station={key:'worker1',agent,status:'Sleeping'},environment={model:{visualWorldKey:scope.worldKey,agents:[agent],tasks:[],cfg:{cards:{}}},feed:{observedUtc:new Date(clock).toISOString()},stations:[station],mode:'private',access:api.operatorDisplayPermissions('private',true,true),operatorPresentation:true,scope:{...scope}};
 let cap={state:'ready',worldId,observedUtc:new Date(clock).toISOString(),expiresUtc:new Date(clock+60000).toISOString(),aliases:[{agentAlias:'role-worker1',issueEpisodeId:issue}],nativeQueueConsumption:'unavailable'};
 const host={binding:{worldId,visualStateScope:{...scope}},readCapability:()=>cap,readStatus:selector=>{calls.push({read:plain(selector)});return record;},requestExistingTask:async intent=>{calls.push({request:plain(intent)});return record;},subscribe:fn=>{listener=fn;return()=>{unsubscribed++;};}};
 const presenter=api.createDirectorWakePresentation({host,getEnvironment:()=>environment,onChange:()=>changed++,now:()=>clock});presenter.connect();
 const response=state=>({schemaVersion:1,kind:'owner-director-request-status',worldId,requestId,eventId:'b'.repeat(64),originalRequestId:requestId,createdUtc:new Date(clock).toISOString(),delivery:{state,recordedUtc:new Date(clock).toISOString()},duplicate:false,nativeQueueConsumption:'unavailable',taskProgressChanged:false});
 const ui=(state,raw=true)=>({kind:'owner-director-ui-state',worldId,agentAlias:'role-worker1',issueEpisodeId:issue,requestId,state,response:raw?response(state):null});
 return{presenter,host,environment,station,agent,calls,ui,response,get cap(){return cap;},set cap(v){cap=v;},set record(v){record=v;},advance:ms=>clock+=ms,notify:()=>listener?.(),get unsubscribed(){return unsubscribed;},get changed(){return changed;}};
}
test('lease, current unique role alias and exact owner scope gate the existing Wake slot',async()=>{
 const h=harness(),spec=()=>h.presenter.presentation(h.station);assert.equal(spec().label,'Wake Up');assert.equal(spec().unavailable,false);
 for(const mode of ['public','private']){h.environment.mode=mode;h.environment.access=api.operatorDisplayPermissions(mode,true,true);assert.equal(spec().unavailable,false);assert.equal(h.environment.access.native,false);}
 h.environment.mode='view';h.environment.access=api.operatorDisplayPermissions('view',true,true);assert.equal(spec(),null);
 h.environment.mode='private';h.environment.access=api.operatorDisplayPermissions('private',true,false);assert.equal(spec(),null);
 h.environment.access=api.operatorDisplayPermissions('private',true,true);h.environment.operatorPresentation=false;assert.equal(spec(),null);h.environment.operatorPresentation=true;
 const binding=h.host.binding;for(const bad of [null,{...binding,visualStateScope:{...scope,artKey:'foreign'}}]){h.host.binding=bad;assert.equal(spec(),null);}h.host.binding={...binding,worldId:'other'};assert.equal(spec().unavailable,true);assert.equal(spec().issueEpisodeId,null);h.host.binding=binding;
 const cap=h.cap;for(const bad of [null,{...cap,extra:true},{...cap,worldId:'other'},{...cap,aliases:[]},{...cap,expiresUtc:cap.observedUtc},{...cap,aliases:[{agentAlias:'role-worker1',issueEpisodeId:'fake'}]},{...cap,aliases:[...cap.aliases,...cap.aliases]}]){h.cap=bad;assert.equal(spec().unavailable,true);assert.equal(spec().issueEpisodeId,null);}h.cap=cap;
 for(const field of ['connected','onboarded']){h.agent[field]=false;assert.equal(spec().unavailable,true);h.agent[field]=true;}
 h.agent.nativeArchived=true;assert.equal(spec().unavailable,true);delete h.agent.nativeArchived;
 h.environment.model.agents.push({...h.agent});assert.equal(spec(),null);h.environment.model.agents.pop();
 const role=h.agent.roleId;delete h.agent.roleId;assert.equal(spec(),null);h.agent.roleId=role;
 for(const change of [()=>h.environment.model.cfg.paused=true,()=>h.station.needsHumanInput=true,()=>h.station.taskBlocker='inert blocker']){change();assert.equal(spec().unavailable,true);h.environment.model.cfg.paused=false;h.station.needsHumanInput=false;h.station.taskBlocker='';}
 h.advance(60001);assert.equal(spec().unavailable,true);assert.equal(h.calls.filter(c=>c.request).length,0);h.presenter.dispose();assert.equal(h.unsubscribed,1);
});
test('trusted Wake emits only the four-field intent once; each original receipt locks without changing work',async()=>{
 for(const state of ['pending','saved','reserved','queued','unknown','received','not-sent']){
  const h=harness(),before=JSON.stringify([h.environment.model,h.environment.feed]),captured=h.presenter.presentation(h.station);h.record=h.ui(state,!['pending','unknown'].includes(state));
  // Callback supplies a real journal-backed UI record; the pre-click reader has none.
  const original=h.host.readStatus;h.host.readStatus=()=>null;
  assert.equal((await h.presenter.activate({isTrusted:false},h.station,captured)).activated,false);
  const pending=h.presenter.activate({isTrusted:true},h.station,captured);assert.equal(h.presenter.presentation(h.station).unavailable,true);
  assert.equal((await h.presenter.activate({isTrusted:true},h.station,captured)).activated,false);await pending;h.host.readStatus=original;
  assert.deepEqual(h.calls.filter(c=>c.request).map(c=>c.request),[{worldId,action:'request-existing-task',agentAlias:'role-worker1',issueEpisodeId:issue}]);
  const after=h.presenter.presentation(h.station);assert.equal(after.requestState.state,state);assert.equal(after.unavailable,true);assert.equal((await h.presenter.activate({isTrusted:true},h.station,captured)).activated,false);
  assert.equal(JSON.stringify([h.environment.model,h.environment.feed]),before);if(state==='received')assert.match(after.reason,/Assignment, working state and task completion are not confirmed/);h.presenter.dispose();
 }
 const h=harness(),captured=h.presenter.presentation(h.station);h.cap={...h.cap,aliases:[{agentAlias:'role-worker1',issueEpisodeId:'c'.repeat(64)}]};assert.equal((await h.presenter.activate({isTrusted:true},h.station,captured)).activated,false);assert.equal(h.calls.filter(c=>c.request).length,0);
});
test('uncertainty, retained originals, scope withdrawal and the mounted room lifecycle stay isolated',async()=>{
 const h=harness(),captured=h.presenter.presentation(h.station);h.host.requestExistingTask=async()=>{throw Error('inert lost reply');};assert.equal((await h.presenter.activate({isTrusted:true},h.station,captured)).state,'unknown');assert.equal(h.presenter.presentation(h.station).label,'Delivery unknown');
 h.record=h.ui('unknown',false);h.advance(61000);assert.equal(h.presenter.presentation(h.station).requestState.state,'unknown');assert.equal(h.calls.at(-1).read.issueEpisodeId,null);
 for(const bad of [{...h.ui('received'),response:null},{...h.ui('queued'),worldId:'foreign'},{...h.ui('queued'),requestId:'invalid'}]){h.record=bad;assert.notEqual(h.presenter.presentation(h.station).requestState?.state,'received');assert.equal(h.presenter.presentation(h.station).unavailable,true);}
 h.presenter.dispose();h.presenter.dispose();assert.equal(h.unsubscribed,1);assert.equal(h.presenter.presentation(h.station),null);
 const late=harness();let resolve;late.host.requestExistingTask=()=>new Promise(r=>resolve=r);const pending=late.presenter.activate({isTrusted:true},late.station,late.presenter.presentation(late.station));late.environment.mode='view';late.presenter.contextChanged();resolve(late.ui('received'));assert.equal((await pending).withdrawn,true);assert.equal(late.presenter.presentation(late.station),null);late.presenter.dispose();
 const {makeMount,sample}=require('./director-wake-mount-fixture.cjs'),d=await sample();d.model.visualWorldKey=scope.worldKey;for(const a of d.model.agents){a.connected=true;a.onboarded=true;}for(const row of d.feed.agentHealth){row.activityState='idle';row.activityObservedUtc=d.feed.observedUtc;}
 const mountHost=harness(),roleId=d.model.agents[0].roleId;mountHost.cap.aliases=[{agentAlias:'role-'+roleId,issueEpisodeId:issue}];mountHost.host.readStatus=()=>null;let sends=0;mountHost.host.requestExistingTask=async intent=>{sends++;assert.deepEqual(plain(intent),{worldId,action:'request-existing-task',agentAlias:'role-'+roleId,issueEpisodeId:issue});return{...mountHost.ui('queued'),agentAlias:'role-'+roleId};};
 const before=JSON.stringify(d),f=await makeMount(d.model,d.feed,scope,{cosmeticOnly:true,operatorPresentation:true,presentationMode:'private',directorRequestHost:mountHost.host,roomLabelPlacement:'top',farmCommandHost:{sendAction(){throw Error('Legacy command path forbidden');}}});
 const nodes=n=>[n,...(n.children||[]).flatMap(nodes)],buttons=()=>nodes(f.mounted.host).filter(n=>n.classList?.contains('ag-command-button'));
 const button=buttons().find(b=>b.textContent==='Wake Up'&&!b.disabled);assert(button,'actual existing room Wake button');await button.onclick({isTrusted:true});assert.equal(sends,1);assert(buttons().some(b=>b.textContent==='Queued'&&b.disabled));assert.equal(f.browserFetches,0);assert.equal(JSON.stringify(d),before);
 f.mounted.setPresentationMode('view');assert.equal(buttons().length,0);f.mounted.destroy();assert.equal(mountHost.unsubscribed,1);assert.equal(f.frames.size,0);assert.equal(f.observers.size,0);assert.equal(f.audioDestroyed,1);
});
