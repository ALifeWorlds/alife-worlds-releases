import test from 'node:test';
import assert from 'node:assert/strict';
import {applyNativeActivity,nativeActivityProjection,validNativeActivity,NATIVE_ACTIVITY_LIMIT} from '../lib/native-activity.mjs';
const threadId='00000000-0000-0000-0000-000000000001',t='2026-11-09T12:00:00.000Z';
const consume=(state,type,payload,at=t)=>applyNativeActivity(state,{type,payload,timestamp:at},{threadId});
const start=()=>{const s={};consume(s,'event_msg',{type:'task_started',turn_id:'turn-one'});return s;};
test('a resolved input request clears on the recorded reply, even before the next tool starts',()=>{
 const state=start(),at=second=>'2026-11-09T12:00:0'+second+'.000Z';
 const ask=(name,id,second)=>consume(state,'response_item',{type:'function_call',name,call_id:id},at(second));
 const end=(id,second)=>consume(state,'response_item',{type:'function_call_output',call_id:id},at(second));
 ask('request_user_input','first',1);ask('request_user_input_async','second',2);
 end('first',3);end('second',4);
 assert.equal(state.needsHumanInput,true);
 consume(state,'event_msg',{type:'user_message',turn_id:'turn-one'},at(1));
 assert.equal(state.needsHumanInput,true,'an older reply cannot clear the newer question');
 consume(state,'response_item',{type:'message',role:'user'},at(5));
 assert.equal(state.needsHumanInput,false);assert.equal(state.activityState,'unknown');assert.equal(state.inputClosedUtc,at(5));assert.equal(state.observedUtc,at(2));
 ask('request_user_input','third',6);end('third',7);assert.equal(state.needsHumanInput,false);
 consume(state,'response_item',{type:'function_call',name:'read_file',call_id:'work'},at(8));
 assert.equal(state.activityState,'working');assert.equal(state.observedUtc,at(8));
});
test('custom tools become working at actual start and finish without inspecting their bodies',()=>{
 const s=start();consume(s,'response_item',{type:'custom_tool_call',call_id:'call-one',name:'exec',input:'PRIVATE INPUT'},'2026-11-09T12:00:01.000Z');
 assert.equal(s.activityState,'working');assert.equal(s.observedUtc,'2026-11-09T12:00:01.000Z');assert.equal(s.nativeActivity.phase,'started');
 consume(s,'response_item',{type:'custom_tool_call_output',call_id:'call-one',output:'PRIVATE OUTPUT'},'2026-11-09T12:00:02.000Z');assert.equal(s.nativeActivity.phase,'completed');assert(!JSON.stringify(nativeActivityProjection(s)).includes('PRIVATE'));
});
test('safe observed research/fetch/message/handoff events keep original IDs and occurrence times',()=>{
 const s=start();for(const [tool,kind]of [['search_query','research'],['read_thread','fetch'],['send_message_to_thread','message'],['handoff_thread','handoff']]){
  consume(s,'event_msg',{type:'item_completed',thread_id:threadId,turn_id:'turn-one',item:{type:'McpToolCall',id:tool,tool,status:'completed',arguments:{secret:'SECRET'},result:{secret:'SECRET'}}},'2026-11-09T12:00:03.000Z');assert.equal(s.nativeActivity.kind,kind);
 }const before=JSON.stringify(nativeActivityProjection(s));consume(s,'event_msg',{type:'item_completed',thread_id:threadId,turn_id:'turn-one',item:{type:'McpToolCall',id:'handoff_thread',tool:'handoff_thread',status:'completed'}},'2026-11-09T12:01:03.000Z');assert.equal(JSON.stringify(nativeActivityProjection(s)),before);assert.equal(s.observedUtc,'2026-11-09T12:00:03.000Z');assert(!before.includes('SECRET'));
});
test('terminal/input guards, settings, token counters and polling never invent work',()=>{
 const s=start();consume(s,'event_msg',{type:'task_complete',turn_id:'turn-one'},'2026-11-09T12:00:10.000Z');const before=JSON.stringify(s);
 consume(s,'response_item',{type:'custom_tool_call_output',call_id:'trailing'},'2026-11-09T12:00:11.000Z');assert.equal(JSON.stringify(s),before);
 consume(s,'event_msg',{type:'token_count',info:{any:'SECRET'}},'2026-11-09T12:00:12.000Z');assert.equal(JSON.stringify(s),before);
 nativeActivityProjection(s);nativeActivityProjection(s);assert.equal(JSON.stringify(s),before);
 consume(s,'event_msg',{type:'task_started',turn_id:'turn-two'},'2026-11-09T12:01:00.000Z');assert.equal(s.activityState,'working');
 consume(s,'response_item',{type:'custom_tool_call',call_id:'ask',name:'request_user_input_async'},'2026-11-09T12:01:01.000Z');assert.equal(s.needsHumanInput,true);assert.equal(s.activityState,'waiting');
 consume(s,'response_item',{type:'custom_tool_call_output',call_id:'ask'},'2026-11-09T12:01:02.000Z');assert.equal(s.activityState,'waiting');
});
test('closed safe event contract, bounded history and exact identity refuse foreign/extra data',()=>{
 const s=start();for(let i=0;i<40;i++)consume(s,'event_msg',{type:'item_completed',thread_id:threadId,turn_id:'turn-one',item:{type:'CommandExecution',id:'cmd-'+i,status:'completed'}},new Date(Date.parse(t)+i*1000).toISOString());
 const p=nativeActivityProjection(s);assert.equal(p.nativeEvents.length,NATIVE_ACTIVITY_LIMIT);assert(p.nativeEvents.every(validNativeActivity));assert.equal(validNativeActivity({...p.nativeActivity,input:'secret'}),false);
 assert.throws(()=>consume(s,'event_msg',{type:'item_completed',thread_id:'foreign',item:{type:'WebSearch'}}),/identity/);
 p.nativeEvents[0].kind='invalid';assert.notEqual(nativeActivityProjection(s).nativeEvents[0].kind,'invalid');
});

test('archived members leave active projection without transferring historical task ownership or leaking native events',async()=>{
 const {createProjection}=await import('../lib/projection.mjs'),{publicWorldSnapshot}=await import('../lib/public-world.mjs');
 const registry=[{id:'world-requests',title:'World',role:'world',responsibility:''},{id:'support',title:'Support',role:'support',responsibility:''}],s=start();
 const value=await createProjection(registry,{observedUtc:t,agents:[{roleId:'world-requests',instanceId:threadId,connected:true,activityState:'working',observedUtc:t,...nativeActivityProjection(s)},{roleId:'support',connected:false,archived:true}],tasks:[{id:'history',title:'Historical task',ownerRoleId:'support',stage:'Done',accepted:true,acceptanceEvidence:'Existing proof'}]},Date.parse(t));
 assert.deepEqual(value.model.agents.map(a=>a.roleId),['world-requests']);assert.equal(value.model.tasks[0].ownerRoleId,'support');assert.equal(value.feed.roster.length,1);assert(value.feed.agentHealth[0].nativeEvents.length>0);
 const publicValue=publicWorldSnapshot(value,registry,{worldId:'world-00000000000000'}),encoded=JSON.stringify(publicValue);assert(!encoded.includes('nativeActivity'));assert(!encoded.includes('nativeEvents'));
});
