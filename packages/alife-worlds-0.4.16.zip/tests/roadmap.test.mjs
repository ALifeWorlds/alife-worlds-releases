import {writeTestConfig} from './test-config.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,rm} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createProjection,loadRegistry} from '../lib/projection.mjs';
import {createApp} from '../server.mjs';
import '../web/agent-outpost/agent-outpost.js';
const registry=await loadRegistry(),F=globalThis.AgentOutpost;
function fixture(){
 const stamp=new Date().toISOString();
 return {schemaVersion:1,projectName:'Local authoring',observedUtc:stamp,
  sprint:{id:'foundation',title:'Foundation',taskIds:['foundation-site']},
  roadmap:{goal:'Recover a shippable plugin in this folder.',status:'Foundation in progress',currentFocus:'Show the staged plan.',coreRoles:['director','support','world-requests'],constraints:['Older plugin is paused and reference-only.'],
   epic:{id:'recovery',title:'Plugin recovery',goal:'A shippable local authoring source.',acceptance:['Verified native state','A scoped release candidate']},
   sprints:[{id:'foundation',title:'Foundation',goal:'Record the plan.',status:'current',taskIds:['foundation-site'],exitCriteria:['Current roadmap is visible']},{id:'package',title:'Package',goal:'Build the later candidate.',status:'planned',taskIds:['future-package'],exitCriteria:['Candidate verified']}]},
  agents:[{roleId:'world-requests',instanceId:'fixture-world',connected:true,activityState:'working',observedUtc:stamp,taskIds:['foundation-site']}],
  tasks:[{id:'foundation-site',ownerRoleId:'world-requests',sprintId:'foundation',title:'Show recovery roadmap',goal:'Readable current plan',stage:'In Progress',current:'Implement the display',next:'Host verification',scope:'Dashboard and projection',acceptance:['Visible plan','No fabricated completion'],dependencies:[],steps:[{id:'display',title:'Show plan',complete:false}]},
   {id:'future-package',ownerRoleId:'world-requests',sprintId:'package',title:'Future package',stage:'Done',dependencies:['foundation-site'],steps:[{id:'package',title:'Package later',complete:true,evidence:'Isolated fixture evidence'}],accepted:true,acceptanceEvidence:'Isolated fixture acceptance'}],events:[]};
}
test('roadmap projects canonical goals, sequence/dependencies and complete current/next cards',async()=>{
 const s=await createProjection(registry,fixture()),r=s.model.roadmap,t=s.model.tasks[0];
 assert.equal(s.project.goal,'Recover a shippable plugin in this folder.');assert.equal(r.epic.acceptance.length,2);assert.deepEqual(r.coreRoles,['director','support','world-requests']);assert.deepEqual(r.sprints[1].dependencySprintIds,['foundation']);
 assert.equal(t.current,'Implement the display');assert.equal(t.next,'Host verification');assert.equal(t.scope,'Dashboard and projection');assert.deepEqual(t.acceptance,['Visible plan','No fabricated completion']);assert.equal(t.ownerRoleId,'world-requests');
 assert.equal(s.model.cfg.cards[t.id].current,t.current);assert.equal(s.model.cfg.cards[t.id].next,t.next);assert.equal(s.model.tasks[1].inCurrentSprint,false);assert.equal(s.model.agents.length,registry.length);
});
test('future accepted work remains in full roadmap but cannot complete current sprint or task tree',async()=>{
 const s=await createProjection(registry,fixture()),p=F.project(s.model,s.feed),station=p.stations.find(s=>s.agent.role==='world-requests');
 assert.equal(s.model.tasks.length,2);assert.ok(s.model.cfg.cards['future-package']);assert.equal(p.tasks.length,1);assert.equal(p.sprint.tasks,1);assert.equal(p.sprint.accepted,0);assert.equal(p.sprint.percent,0);assert.equal(p.sprint.units,0);assert.equal(station.task.id,'foundation-site');assert.equal(station.p,0);assert.equal(station.working,true);
});
test('future QA/blockers stay outside current execution while empty selection retains required members',async()=>{
 const d=fixture();d.tasks[1].stage='QA';d.tasks[1].condition='blocked';d.tasks[1].blocker='Future dependency';d.tasks[1].accepted=false;
 let s=await createProjection(registry,d),p=F.project(s.model,s.feed);assert.equal(p.qaPackages.length,0);assert.equal(p.blockedPackages.length,0);
 d.sprint.taskIds=[];s=await createProjection(registry,d);p=F.project(s.model,s.feed);assert.equal(s.model.tasks.length,2);assert.equal(p.tasks.length,1);assert.equal(p.sprint.percent,0);assert.equal(p.sprint.complete,false);assert.equal(p.stations.find(s=>s.agent.role==='world-requests').task.id,'foundation-site');
});
test('root selected sprint owns scope and can infer missing taskIds without including later sprints',async()=>{
 const d=fixture();delete d.sprint.taskIds;let s=await createProjection(registry,d);assert.deepEqual(s.model.presentation.taskIds,['foundation-site']);
 d.sprint.id='unplanned';s=await createProjection(registry,d);assert.deepEqual(s.model.presentation.taskIds,[]);assert.equal(F.project(s.model,s.feed).sprint.percent,null);
});
test('roadmap projection bounds known display fields and excludes arbitrary source/private fields',async()=>{
 const d=fixture();d.roadmap.secret='PRIVATE-ROADMAP';d.roadmap.goal='x'.repeat(9000);d.roadmap.epic.instructions='PRIVATE-EPIC';d.roadmap.epic.acceptance.push({transcript:'PRIVATE-ACCEPTANCE'});d.roadmap.sprints[0].runtime={token:'PRIVATE-SPRINT'};d.tasks[0].scope={secret:'PRIVATE-SCOPE'};d.tasks[0].acceptance.push({secret:'PRIVATE-TASK'});d.tasks[0].steps[0].evidence={secret:'PRIVATE-EVIDENCE'};d.tasks[0].credentials='PRIVATE-CREDENTIALS';
 const s=await createProjection(registry,d);assert.equal(s.model.roadmap.goal.length,4000);assert.equal(s.model.tasks[0].scope,'');assert.equal(s.model.tasks[0].milestone.steps[0].evidence,null);assert.equal(s.model.tasks[0].milestone.steps[0].complete,false);assert.ok(!JSON.stringify(s).includes('PRIVATE-'));
});
test('ambiguous sprint membership, duplicate sprint IDs, foreign selected scope and excess sprints fail closed',async()=>{
 for(const kind of ['duplicate','membership','selected','limit']){const d=fixture();if(kind==='duplicate')d.roadmap.sprints[1].id='foundation';if(kind==='membership')d.roadmap.sprints[1].taskIds.push('foundation-site');if(kind==='selected')d.sprint.taskIds=['future-package'];if(kind==='limit')d.roadmap.sprints=Array.from({length:33},(_,i)=>({id:'s'+i}));await assert.rejects(createProjection(registry,d));}
});
test('HTTP dashboard serves roadmap foundation and safely projected scope with commands still disabled',async()=>{
 const testHome=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));await mkdir(testHome,{recursive:true});const dir=await mkdtemp(path.join(testHome,'roadmap-test-'));
 const d=fixture();d.roadmap.private='PRIVATE-HTTP';const app=await createApp({configFile:await writeTestConfig(dir),mode:'live',nativeReadOnly:true,adapter:{readSnapshot:async()=>d},journalPath:path.join(dir,'journal.json')});
 try{const url=await app.listen(0),root=await(await fetch(url)).text();assert.ok(root.includes('id="alife-world-first"'));assert.ok(root.includes('id="wf-work"'));const html=await(await fetch(url+'/operator')).text();assert.ok(html.includes('id="recovery-roadmap"'));assert.ok(html.includes('id="current-sprint-title"'));assert.ok(html.includes('aria-label="Project plan"'));assert.ok(html.includes('Your project’s goals and sprint plan.'));assert.ok(html.includes('Progress reflects recorded work.'));assert.doesNotMatch(html,/Changes to the older plugin are paused|Documents\/GitHub\/alife-worlds|current coordination workspace/);assert.ok(html.includes('src="/boot.js"'));
  const data=await(await fetch(url+'/api/dashboard')).json();assert.equal(data.model.roadmap.sprints.length,2);assert.equal(data.model.tasks.filter(t=>t.inCurrentSprint).length,1);assert.equal(data.feed.farmFacts.commands.transportEnabled,false);assert.ok(!JSON.stringify(data).includes('PRIVATE-HTTP'));
 }finally{await new Promise(resolve=>app.server.close(resolve));assert.ok(path.resolve(dir).startsWith(path.resolve(testHome)+path.sep));await rm(dir,{recursive:true,force:true});}
});
