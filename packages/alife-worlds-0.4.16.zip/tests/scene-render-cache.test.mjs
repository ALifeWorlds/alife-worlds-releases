import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';

const context={};
vm.runInNewContext(readFileSync(new URL('../web/agent-outpost/colony-art.js',import.meta.url),'utf8'),context);
vm.runInNewContext(readFileSync(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8'),context);
const {createSceneGrassLayer}=context.AgentOutpost;
function fixture(){
 const canvases=[],paints=[],images=[],stack=[];
 let matrix={a:.5,b:0,c:0,d:.5,e:0,f:0};
 const ctx={canvas:{width:1200,height:850},globalAlpha:1,globalCompositeOperation:'source-over',filter:'none',getTransform:()=>({...matrix}),save(){stack.push({...matrix});},restore(){matrix=stack.pop();},setTransform(a,b,c,d,e,f){matrix={a,b,c,d,e,f};},drawImage(...args){images.push(args);}};
 const makeCanvas=()=>{const canvas={width:0,height:0,getContext:()=>({setTransform(...args){canvas.transform=args;}})};canvases.push(canvas);return canvas;};
 const layer=createSceneGrassLayer(makeCanvas,(g,spec)=>paints.push({g,spec}));
 const spec={width:2400,artScale:1,seed:42,lakes:[],environment:{season:'summer',day:true,sidewalkBottom:214}};
 return{ctx,layer,spec,canvases,paints,images};
}
test('unchanged frames reuse the same native-resolution grass layer and restore the drawing transform',()=>{
 const f=fixture(),before=f.ctx.getTransform();
 for(let i=0;i<30;i++)assert.equal(f.layer.draw(f.ctx,f.spec),true);
 assert.equal(f.paints.length,1);assert.equal(f.canvases.length,1);assert.equal(f.images.length,30);
 assert.equal(f.canvases[0].width,1200);assert.equal(f.canvases[0].height,159);
 assert.deepEqual(f.canvases[0].transform,[.5,0,0,.5,0,0]);assert.deepEqual(f.ctx.getTransform(),before);
 assert.ok(f.images.every(args=>args[0]===f.canvases[0]&&args.length===3));
});
test('world, geometry, season, day, palette and raster changes discard stale pixels',()=>{
 const f=fixture();f.layer.draw(f.ctx,f.spec);
 for(const edit of [s=>s.seed++,s=>s.lakes=[{points:[[1,2],[3,4],[5,6]]}],s=>s.environment.season='winter',s=>s.environment.day=false,s=>s.environment.grassPalette={shadow:'#000000',low:'#111111',mid:'#222222',high:'#333333'},s=>s.environment.sidewalkBottom++,s=>f.ctx.canvas.width++]){
  const old=f.canvases.at(-1),count=f.paints.length;edit(f.spec);f.layer.draw(f.ctx,f.spec);assert.equal(f.paints.length,count+1);assert.equal(old.width,1);assert.equal(old.height,1);
 }
 const last=f.canvases.at(-1);f.layer.clear();assert.equal(last.width,1);assert.equal(last.height,1);
});
test('unsupported transforms, blending and oversized surfaces retain the original painter without extra allocation',()=>{
 for(const change of [ctx=>ctx.setTransform(.5,0,0,.5,2,0),ctx=>ctx.globalAlpha=.5,ctx=>ctx.globalCompositeOperation='multiply',ctx=>ctx.filter='blur(1px)',ctx=>ctx.canvas.width=100000]){
  const f=fixture();change(f.ctx);assert.equal(f.layer.draw(f.ctx,f.spec),false);assert.equal(f.canvases.length,0);assert.equal(f.images.length,0);assert.equal(f.paints[0].g,f.ctx);
 }
});
