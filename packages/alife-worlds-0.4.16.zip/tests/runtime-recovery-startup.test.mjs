import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');

test('actual Windows supervisor preserves an occupied listener and never replays an interrupted publisher launch',{skip:process.platform!=='win32',timeout:25000},async()=>{
 const source=fileURLToPath(new URL('../scripts/runtime-recovery/',import.meta.url)),scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));
 await fs.mkdir(scratch,{recursive:true});const root=await fs.mkdtemp(path.join(scratch,'recovery-startup-'));
 const server=http.createServer((req,res)=>{res.writeHead(200);res.end('{}');});let child=null;
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{
  const sourceFiles=[];for(const name of ['supervisor.mjs','ownership.mjs','inspect-process.ps1']){const bytes=await fs.readFile(path.join(source,name)),target=path.join(root,name);await fs.writeFile(target,bytes);sourceFiles.push({path:target,sha256:sha(bytes)});}
  const components=[];for(const name of ['local','publisher']){const driver=path.join(root,name+'-driver.mjs'),bytes=Buffer.from('import fs from "node:fs";fs.writeFileSync(new URL("./unintended.txt",import.meta.url),"unexpected launch");');await fs.writeFile(driver,bytes);components.push({name,driver,pins:[{path:driver,sha256:sha(bytes)}],adopt:[]});}
  const spec={schemaVersion:1,kind:'approved-alife-world-runtime-supervisor',worldId:'world-fixture',projectId:'fixture-project',projectRootSha256:'a'.repeat(64),plugin:'0.3.7',world:'1.3.4',website:'1.1.5',source:'a'.repeat(40),node:process.execPath,localOrigin:'http://127.0.0.1:'+server.address().port,sourceFiles,components};
  await fs.writeFile(path.join(root,'supervisor-spec.json'),JSON.stringify(spec));
  await fs.writeFile(path.join(root,'effect-journal.json'),JSON.stringify({schemaVersion:1,operations:[{id:'interrupted-publisher-launch',component:'publisher',state:'launch-reserved'}]}));
  child=spawn(process.execPath,[path.join(root,'supervisor.mjs')],{cwd:root,windowsHide:true,stdio:['pipe','ignore','pipe']});let diagnostic='';child.stderr.on('data',part=>{if(diagnostic.length<4096)diagnostic+=part.toString().slice(0,4096-diagnostic.length);});child.stdin.end(JSON.stringify({ownerBearer:'fixture-only-not-a-real-credential'})+'\n');
  let status=null;const deadline=Date.now()+16000;
  while(Date.now()<deadline){try{status=JSON.parse(await fs.readFile(path.join(root,'status.json'),'utf8'));break;}catch{}if(child.exitCode!==null)break;await new Promise(resolve=>setTimeout(resolve,200));}
  assert(status,'Supervisor did not reach its bounded fixture status: '+diagnostic);
  assert.equal(status.components.find(c=>c.name==='local').status,'listener-present-not-owned');
  assert.equal(status.components.find(c=>c.name==='publisher').status,'launch-outcome-unknown');
  assert.equal((JSON.parse(await fs.readFile(path.join(root,'effect-journal.json'),'utf8'))).operations.length,1);
  await assert.rejects(fs.access(path.join(root,'unintended.txt')),{code:'ENOENT'});
 }finally{
  if(child&&child.exitCode===null)await new Promise(resolve=>{child.once('exit',resolve);child.kill();});
  await new Promise(resolve=>server.close(resolve));const target=path.resolve(root);assert(target.startsWith(path.resolve(scratch)+path.sep));assert.equal((await fs.realpath(target)).toLowerCase(),target.toLowerCase());await fs.rm(target,{recursive:true,force:true});
 }
});
