import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createApp} from '../server.mjs';
import {publicWorldId} from '../lib/public-world.mjs';
import {createLocalOwnerFrameHandler} from '../lib/owner-frame-http.mjs';

async function fixture(run,{owner=true,service=true}={}){
 let origin='',calls=0;const handler=createLocalOwnerFrameHandler({getOrigin:()=>origin,isOwner:()=>owner,getService:()=>service?{async ownerFrameResponse(request,authority){calls++;assert.equal(authority.ownerAuthorized,true);return new Response(JSON.stringify({method:request.method,path:new URL(request.url).pathname,body:['GET','HEAD'].includes(request.method)?null:await request.text()}),{headers:{'content-type':'application/json','cache-control':'no-store'}});}}:null});
 const server=http.createServer(async(req,res)=>{if(!await handler(req,res)){res.writeHead(404);res.end();}});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;
 try{await run({origin,getCalls:()=>calls});}finally{await new Promise(resolve=>server.close(resolve));}
}
test('actual local request/response adapter routes owner resources and body without another listener or source read',async()=>fixture(async({origin,getCalls})=>{
 const response=await fetch(origin+'/api/owner-world-release?project=world-fixture');assert.equal(response.status,200);assert.equal(response.headers.get('cache-control'),'no-store');assert.equal((await response.json()).path,'/api/owner-world-release');
 const put=await fetch(origin+'/world-frame/'+'a'.repeat(64)+'/snapshot',{method:'PUT',body:'actual service input'});assert.equal(put.status,200);assert.equal((await put.json()).body,'actual service input');
 const head=await fetch(origin+'/owner-frame-client.mjs',{method:'HEAD'});assert.equal(head.status,200);assert.equal(await head.text(),'');assert.equal(getCalls(),3);
 assert.equal((await fetch(origin+'/unrelated')).status,404);assert.equal(getCalls(),3);
}));
test('loopback host, origin, browser site and actual owner checks precede every provider call',async()=>fixture(async({origin,getCalls})=>{
 for(const headers of [{Host:'foreign.invalid'},{Origin:'https://foreign.invalid'},{'Sec-Fetch-Site':'cross-site'}]){const status=await new Promise((resolve,reject)=>{const request=http.get(origin+'/owner-frame-client.mjs',{headers},response=>{response.resume();response.once('end',()=>resolve(response.statusCode));});request.once('error',reject);});assert.equal(status,403);}
 assert.equal(getCalls(),0);
}));
test('missing owner or provider remains unavailable without fallback or dispatch',async()=>{
 assert.throws(()=>createLocalOwnerFrameHandler({getOrigin:()=>''}),/owner gate/);
 await fixture(async({origin,getCalls})=>{assert.equal((await fetch(origin+'/owner-frame-client.mjs')).status,403);assert.equal(getCalls(),0);},{owner:false});
 await fixture(async({origin,getCalls})=>{assert.equal((await fetch(origin+'/owner-frame-client.mjs')).status,503);assert.equal(getCalls(),0);},{service:false});
});

test('actual createApp consumes the configured frame factory while unconfigured projects remain unavailable',async()=>{
 const scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));await fs.mkdir(scratch,{recursive:true});const directory=await fs.mkdtemp(path.join(scratch,'owner-frame-http-'));
 const configFile=path.join(directory,'config.json');await fs.writeFile(configFile,JSON.stringify({mode:'demo',projectId:'fixture-project',commandsEnabled:false}));
 try{for(const configured of [false,true]){let calls=0;const ownerFrameService=configured?({origin,projectId,worldId,readCurrentState})=>{calls++;assert.equal(projectId,'fixture-project');assert.match(worldId,/^world-/);assert.equal(typeof readCurrentState,'function');return {ownerFrameResponse(request,{ownerAuthorized}){assert.equal(new URL(request.url).origin,origin);assert.equal(ownerAuthorized,true);return new Response('{"configured":true}',{headers:{'content-type':'application/json'}});}};}:null;
  const app=await createApp({configFile,journalPath:path.join(directory,'journal.json'),ownerFrameService}),origin=await app.listen(0);
  try{assert.equal((await fetch(origin+'/api/owner-world-release?project='+publicWorldId('fixture-project'))).status,configured?200:503);assert.equal(calls,configured?1:0);}finally{await new Promise(resolve=>app.server.close(resolve));}
 }}finally{const target=path.resolve(directory);assert(target.startsWith(path.resolve(scratch)+path.sep));await fs.rm(target,{recursive:true,force:true});}
});
