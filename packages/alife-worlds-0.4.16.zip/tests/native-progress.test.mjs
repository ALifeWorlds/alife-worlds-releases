import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {applyNativeProgress} from '../lib/native-progress.mjs';
const threadId='native-progress-fixture',timestamp='2026-11-09T14:42:36.795Z';
const row=text=>({type:'response_item',timestamp,payload:{type:'message',role:'assistant',channel:'commentary',thread_id:threadId,content:[{type:'output_text',text}]}});
test('native terminal LF and CRLF preserve deliberate progress and original raw-event identity',()=>{
 for(const ending of ['', '\n','\r\n']){
  const text='[ALife activity] Updating sprint delivery records | Checking the current website'+ending,state={};
  applyNativeProgress(state,row(text),{threadId});
  assert.equal(state.progressUpdate.headline,'Updating sprint delivery records');
  assert.equal(state.progressUpdate.detail,'Checking the current website');
  assert.equal(state.progressUpdate.recordedUtc,timestamp);
  assert.equal(state.progressUpdate.id,'activity-'+createHash('sha256').update(threadId+'\0'+timestamp+'\0'+text).digest('hex').slice(0,14));
 }
});
test('terminal newline support retains private-content, actor, phase and multiline refusals',()=>{
 const good='[ALife activity] Checking the website | Reading the sprint layout';
 for(const text of [good+'\n\n',good+'\r\n\r\n',good+'\r',good.replace(' | ','\n | '),'Normal commentary\n','[ALife activity] Reading C:\\Users\\private\n']){
  const state={};applyNativeProgress(state,row(text),{threadId});assert.equal(state.progressUpdate,undefined);
 }
 for(const patch of [{role:'user'},{channel:'final'},{channel:'analysis'},{thread_id:'foreign'},{type:'reasoning'}]){
  const event=row(good+'\n');Object.assign(event.payload,patch);const state={};applyNativeProgress(state,event,{threadId});assert.equal(state.progressUpdate,undefined);
 }
 const state={};applyNativeProgress(state,row(good+'\n'),{threadId});applyNativeProgress(state,{type:'event_msg',payload:{type:'turn_started'}},{threadId});assert.equal(state.progressUpdate,null);
});
