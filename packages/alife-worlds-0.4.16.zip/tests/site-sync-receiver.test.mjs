import test from 'node:test';
import assert from 'node:assert/strict';
import {createSiteSnapshotStore,createSiteBundleService} from '../lib/site-sync-receiver.mjs';
import {configuration,siteBundleFixture,r2Fixture,project,worldId} from './site-sync-fixture.mjs';
import {createSiteConnectionWorker} from '../lib/site-sync-worker.mjs';

const ownerGet=path=>new Request('https://owner.example'+path);
function legacy(observedUtc){return{schemaVersion:1,project,revision:1,observedUtc,agents:[{role:'director',name:'Fixture Director',connected:true,onboarded:true,selection:{model:null,source:null,observedUtc:null,state:'unknown'},applied:{model:null,source:null,observedUtc:null,state:'unknown',reasoning:null,speed:null,reasoningObservedUtc:null,speedObservedUtc:null},activity:{state:'working',observedUtc,terminal:false,needsHumanInput:false}}]};}

test('legacy accepted retry reconciles before source expiry without refreshing source, work or receipt',async()=>{
 let now=Date.now();const value=legacy(new Date(now).toISOString()),store=r2Fixture(),service=createSiteSnapshotStore({project,clock:()=>now});
 const first=await(await service.publish(store,value)).json();now+=60000;
 const retry=await service.publish(store,value),receipt=await retry.json();assert.equal(retry.status,200);assert.equal(receipt.duplicate,true);assert.equal(receipt.receivedUtc,first.receivedUtc);assert.equal(store.puts.length,1);
 const read=await(await service.response(store)).json();assert.equal(read.state,'stale');assert.equal(read.snapshot.agents[0].activity.observedUtc,value.agents[0].activity.observedUtc);
 const conflicting=structuredClone(value);conflicting.agents[0].name='Conflicting name';assert.equal((await service.publish(store,conflicting)).status,409);
 const empty=r2Fixture();assert.equal((await service.publish(empty,value)).status,400);assert.equal(empty.puts.length,0);
});
test('full bundle is one atomic head and all owner responses keep its original receipt and observations',async()=>{
 const now=Date.now(),f=await siteBundleFixture({observedUtc:new Date(now).toISOString()}),store=r2Fixture(),service=createSiteBundleService({...configuration,clock:()=>now});
 assert.equal((await service.publish(store,f.bundle)).status,200);assert.equal(store.rows.size,1);
 const workspace=await(await service.response(ownerGet('/api/workspace'),store)).json(),preview=await(await service.response(ownerGet('/api/owner-world-preview'),store)).json(),catalog=await(await service.response(ownerGet('/api/world-catalog'),store)).json();
 assert.deepEqual(workspace.snapshot,f.bundle.workspace);assert.deepEqual(preview,f.bundle.ownerPreview);assert.deepEqual(catalog.catalog,f.bundle.catalog);assert.equal(workspace.receivedUtc,catalog.receivedUtc);assert.equal(workspace.snapshot.observedUtc,preview.snapshot.observedUtc);
 const metadata=await(await service.response(ownerGet('/api/agent-metadata'),store)).json();assert.deepEqual(metadata.metadata,f.bundle.agentMetadata);assert.equal(metadata.receivedUtc,workspace.receivedUtc);assert.equal(metadata.observedUtc,workspace.snapshot.observedUtc);
 assert.equal((await service.response(ownerGet('/api/workspace?project=world-foreign'),store)).status,404);assert.equal((await service.response(new Request('https://owner.example/api/workspace',{method:'POST'}),store)).status,405);
});
test('current accepted v2 retry survives expiry, while owner world reads expire and other owner envelopes become stale',async()=>{
 let now=Date.now();const f=await siteBundleFixture({observedUtc:new Date(now).toISOString()}),store=r2Fixture(),service=createSiteBundleService({...configuration,clock:()=>now});
 const first=await(await service.publish(store,f.bundle)).json();now+=60000;
 const retry=await(await service.publish(store,f.bundle)).json();assert.equal(retry.duplicate,true);assert.equal(retry.receivedUtc,first.receivedUtc);assert.equal(store.puts.length,1);
 assert.equal((await service.response(ownerGet('/api/owner-world-preview'),store)).status,503);
 assert.equal((await(await service.response(ownerGet('/api/workspace'),store)).json()).state,'stale');assert.equal((await(await service.response(ownerGet('/api/world-catalog'),store)).json()).state,'stale');
 const metadata=await(await service.response(ownerGet('/api/agent-metadata'),store)).json();assert.equal(metadata.state,'stale');assert.equal(metadata.receivedUtc,first.receivedUtc);assert.equal(metadata.observedUtc,f.bundle.observedUtc);
 const empty=r2Fixture();assert.equal((await service.publish(empty,f.bundle)).status,400);assert.equal(empty.puts.length,0);
});
test('a delayed older bundle cannot overwrite a concurrently accepted newer bundle',async()=>{
 const now=Date.now(),older=(await siteBundleFixture({revision:1,observedUtc:new Date(now-2000).toISOString()})).bundle,newer=(await siteBundleFixture({revision:2,observedUtc:new Date(now-1000).toISOString(),metadataRevision:2})).bundle;
 let release,entered;const delayed=new Promise(r=>{entered=r;}),gate=new Promise(r=>{release=r;});let held=false;
 const store=r2Fixture({beforePut:async call=>{if(JSON.parse(call.text).bundle.revision===1&&!held){held=true;entered();await gate;}}}),service=createSiteBundleService({...configuration,clock:()=>now});
 const pending=service.publish(store,older);await delayed;assert.equal((await service.publish(store,newer)).status,200);release();assert.equal((await pending).status,409);
 const saved=JSON.parse([...store.rows.values()][0]);assert.equal(saved.bundle.revision,2);assert.equal(saved.bundle.ownerPreview.metadata.revision,2);assert.equal(store.puts.filter(p=>p.applied).length,1);
});
test('same revision mismatches, old source and metadata regression never alter the atomic head',async()=>{
 const now=Date.now(),f=await siteBundleFixture({revision:2,metadataRevision:2,observedUtc:new Date(now-1000).toISOString()}),store=r2Fixture(),service=createSiteBundleService({...configuration,clock:()=>now});await service.publish(store,f.bundle);
 const changed=structuredClone(f.bundle);changed.workspace.project.name='Changed under same revision';assert.equal((await service.publish(store,changed)).status,409);
 const old=(await siteBundleFixture({revision:3,metadataRevision:2,observedUtc:new Date(now-2000).toISOString()})).bundle;assert.equal((await service.publish(store,old)).status,409);
 const regressed=(await siteBundleFixture({revision:3,metadataRevision:1,observedUtc:new Date(now).toISOString()})).bundle;assert.equal((await service.publish(store,regressed)).status,409);
 const hashChanged=(await siteBundleFixture({revision:3,metadataRevision:2,observedUtc:new Date(now).toISOString()})).bundle;hashChanged.ownerPreview.metadata.contentHash='f'.repeat(64);hashChanged.agentMetadata.contentHash='f'.repeat(64);assert.equal((await service.publish(store,hashChanged)).status,409);assert.equal(store.puts.length,1);
});
test('lost committed reply reconciles the original bundle and an unknown nonwrite is never blindly repeated',async()=>{
 const f=await siteBundleFixture();let lost=false;const store=r2Fixture({afterPut:()=>{if(!lost){lost=true;throw Error('Fixture lost reply');}}}),service=createSiteBundleService(configuration);
 const response=await service.publish(store,f.bundle),first=await response.json();assert.equal(response.status,200);assert.equal(first.duplicate,true);assert.equal(store.puts.length,1);
 const retry=await(await service.publish(store,f.bundle)).json();assert.equal(retry.receivedUtc,first.receivedUtc);assert.equal(store.puts.length,1);
 let attempts=0;const unknown={async get(){return null;},async put(){attempts++;throw Error('Unknown effect');}};assert.equal((await service.publish(unknown,f.bundle)).status,503);assert.equal(attempts,1);
});
test('unsupported conditional storage fails closed and contention has a four-write bound',async()=>{
 const f=await siteBundleFixture(),service=createSiteBundleService(configuration);let unsupported=0;
 await assert.rejects(service.publish({async get(){return null;},async put(){unsupported++;return undefined;}},f.bundle),/Conditional Site storage/);assert.equal(unsupported,1);
 let conflicts=0;const contended={async get(){return null;},async put(key,text,options){assert(options.onlyIf instanceof Headers);conflicts++;return null;}};assert.equal((await service.publish(contended,f.bundle)).status,409);assert.equal(conflicts,4);
});

test('owner Rules read the stored same-state facet, preserve original clocks and fail unavailable on null/expiry',async()=>{
 let now=Date.now();const f=await siteBundleFixture({observedUtc:new Date(now).toISOString()}),store=r2Fixture(),service=createSiteBundleService({...configuration,clock:()=>now});assert.equal((await service.response(ownerGet('/api/rule-library'),store)).status,503);await service.publish(store,f.bundle);
 const rules=await(await service.response(ownerGet('/api/rule-library?project='+worldId),store)).json();assert.deepEqual(rules,f.bundle.ruleLibrary);const row=JSON.parse([...store.rows.values()][0]),original=JSON.stringify(row);await service.response(ownerGet('/api/rule-library'),store);assert.equal(JSON.stringify(JSON.parse([...store.rows.values()][0])),original);
 const absent={...f.bundle,revision:2,ruleLibrary:null};await service.publish(store,absent);assert.equal((await service.response(ownerGet('/api/rule-library'),store)).status,503);assert.equal((await service.response(ownerGet('/api/workspace'),store)).status,200);assert.equal((await(await service.response(ownerGet('/api/agent-metadata'),store)).json()).observedUtc,f.bundle.observedUtc);
 const current={...f.bundle,revision:3};await service.publish(store,current);now+=45001;assert.equal((await service.response(ownerGet('/api/rule-library'),store)).status,503);assert.equal(JSON.parse([...store.rows.values()][0]).receivedUtc,row.receivedUtc);assert.equal(store.puts.length,3);
});

test('legacy v2 head without Rules can be replaced by a higher current bundle without defaults or storage bypass',async()=>{
 const now=Date.now(),f=await siteBundleFixture({observedUtc:new Date(now).toISOString()}),store=r2Fixture(),service=createSiteBundleService({...configuration,clock:()=>now}),old=structuredClone(f.bundle);delete old.ruleLibrary;await service.publish(store,old);assert.equal((await service.response(ownerGet('/api/rule-library'),store)).status,503);assert.equal((await service.response(ownerGet('/api/workspace'),store)).status,200);
 assert.equal((await service.publish(store,{...f.bundle,revision:2})).status,200);assert.deepEqual(await(await service.response(ownerGet('/api/rule-library'),store)).json(),f.bundle.ruleLibrary);assert.equal(store.puts.length,2);assert.notEqual(store.puts[1].match,null);
});

test('live Rules use the existing owner/origin/world/method gates before storage and relay keys grant no visitor identity',async()=>{
 const store=r2Fixture();let reads=0;const get=store.get;store.get=(...args)=>{reads++;return get(...args);};const service=createSiteBundleService(configuration),worker=createSiteConnectionWorker({bundleService:service,isOwner:r=>r.headers.get('X-Fixture-Owner')==='yes',isServicePublisher:()=>true}),env={PROJECT_SCOPE:project,SNAPSHOTS:store,BUNDLE_SYNC_KEY:'fixture-key-never-published-0123456789'},call=(path,options={})=>worker.fetch(new Request('https://owner.example'+path,options),env),owner={'X-Fixture-Owner':'yes'};
 assert.equal((await call('/api/rule-library')).status,401);assert.equal((await call('/api/rule-library',{headers:{'X-ALife-Sync-Key':env.BUNDLE_SYNC_KEY}})).status,401);for(const path of ['/api/rule-library?project=world-foreign','/api/rule-library?extra=1','/api/rule-library?project='+worldId+'&project='+worldId])assert.equal((await call(path,{headers:owner})).status,404);assert.equal((await call('/api/rule-library',{headers:{...owner,Origin:'https://foreign.example'}})).status,403);assert.equal((await call('/api/rule-library',{headers:{...owner,'Sec-Fetch-Site':'cross-site'}})).status,403);assert.equal((await call('/api/rule-library',{method:'POST',headers:owner})).status,405);assert.equal(reads,0);assert.equal(store.puts.length,0);assert.equal((await call('/api/rule-library',{headers:owner})).status,503);
});
