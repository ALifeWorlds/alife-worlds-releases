import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {mkdtemp, readFile, writeFile, realpath, lstat, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {digest, eventIdFor} from '../lib/owner-director-contract.mjs';
import {createOwnerDirectorService} from '../lib/owner-director-service.mjs';
import {createDirectorDirectoryStore, createFixedDirectorCli,
  createOwnerDirectorDispatcher} from '../lib/owner-director-node.mjs';

// Entirely fictional identities. No installed CLI, service, native chat or browser is used.
const at = Date.parse('2026-11-10T21:00:00.000Z'), H = 'a'.repeat(64), Q = 'b'.repeat(64);
const owner = 'c'.repeat(64), publisher = 'd'.repeat(64), issue = 'e'.repeat(64);
const threadId = '11111111-1111-4111-8111-111111111111';
const requestId = '22222222-2222-4222-8222-222222222222';
const attemptId = '33333333-3333-4333-8333-333333333333';
const queueId = '44444444-4444-4444-8444-444444444444';
const c = {projectId: 'fixture-project', worldId: 'fixture-world', qualificationSha256: Q,
  ownerOrigin: 'https://fixture.invalid', ownerSubjectHash: owner, publisherSubjectHash: publisher};
const s = {schemaVersion: 1, requestId, worldId: c.worldId, action: 'request-existing-task',
  agentAlias: 'fixture-worker', issueEpisodeId: issue};
async function makeProof(input = s) {
  const body = {schemaVersion: 1, kind: 'owner-director-request', projectId: c.projectId,
    worldId: c.worldId, eventId: await eventIdFor(input, c), requestId: input.requestId,
    reporterHash: owner, createdUtc: new Date(at).toISOString(), qualificationSha256: Q, request: input};
  return {...body, proofSha256: await digest(body)};
}
const cap = () => ({schemaVersion: 1, kind: 'owner-director-capability',
  projectId: c.projectId, worldId: c.worldId, qualificationSha256: Q,
  observedUtc: new Date(at).toISOString(), expiresUtc: new Date(at + 45000).toISOString(),
  aliases: [{agentAlias: s.agentAlias, issueEpisodeId: issue}]});
function bucket() {
  const values = new Map(); let lost = null;
  return {
    values, loseNextContaining(v) { lost = v; },
    async get(key) {
      if (!values.has(key)) return null;
      const text = values.get(key);
      return {size: Buffer.byteLength(text), text: async () => text};
    },
    async put(key, text, options) {
      if (options?.onlyIf?.get('If-None-Match') === '*' && values.has(key)) return null;
      values.set(key, text);
      if (lost && key.includes(lost)) { lost = null; throw Error('Fixture response lost after durable write'); }
      return {etag: 'fixture-etag'};
    },
    async list({prefix, limit, cursor}) {
      const keys = [...values.keys()].filter(k => k.startsWith(prefix)).sort();
      const start = Number(cursor || 0), slice = keys.slice(start, start + limit);
      return {objects: slice.map(key => ({key})), truncated: start + limit < keys.length,
        cursor: String(start + limit)};
    }
  };
}
function serviceFixture() {
  const b = bucket(); let time = at;
  // WeakMap stands for the trusted host's already-authenticated identity. An
  // attacker-controlled identity header grants no authority in this fixture.
  const identities = new WeakMap();
  const service = createOwnerDirectorService({configuration: c, now: () => time,
    authenticate: async r => identities.get(r)});
  async function call(route, method = 'GET', body, kind = 'owner', headers = {}) {
    const request = new Request(c.ownerOrigin + route, {method,
      headers: {...(body ? {'Content-Type': 'application/json'} : {}),
        ...(kind === 'owner' && method === 'POST' ?
          {origin: c.ownerOrigin, 'sec-fetch-site': 'same-origin'} : {}), ...headers},
      ...(body ? {body: JSON.stringify(body)} : {})});
    if (kind) identities.set(request, {kind, subjectHash: kind === 'owner' ? owner : publisher,
      projectId: c.projectId, worldId: c.worldId});
    const response = await service.handle(request, {BUCKET: b});
    return {status: response.status, value: await response.json()};
  }
  return {b, call, setTime: n => { time = n; }};
}
function memoryStore() {
  const records = new Map();
  return {records, async read(id) { return structuredClone(records.get(id) || null); },
    async reserve(id, v) { if (records.has(id)) return false; records.set(id, structuredClone(v)); return true; },
    async replace(id, v) { records.set(id, structuredClone(v)); }};
}
function dispatchFixture({store = memoryStore(), cloud, cli, verifyCurrentIssue, verifyOwnIntake} = {}) {
  let calls = 0, claimCalls = 0;
  const claims = new Map();
  const remote = cloud || {
    async claim(v) {
      claimCalls++;
      if (claims.has(v.eventId)) return {ok: true, applied: false, attemptId: claims.get(v.eventId),
        proofSha256: v.proofSha256};
      claims.set(v.eventId, v.attemptId);
      return {ok: true, applied: true, attemptId: v.attemptId, proofSha256: v.proofSha256};
    },
    async putReceipt(v) { return {ok: true, attemptId: v.attemptId, proofSha256: v.proofSha256}; }
  };
  const transport = cli || {target: {threadId, executionCwd: 'fixture-cwd'}, verify: async () => true,
    async queue(message) { calls++; assert.match(message, /Agent alias: fixture-worker/);
      assert.match(message, /Attempt: /); return {exitCode: 0, queueReceiptId: queueId}; }};
  const d = createOwnerDirectorDispatcher({configuration: c, cli: transport, store, cloud: remote,
    verifyCurrentIssue: verifyCurrentIssue || (async () => true),
    verifyOwnIntake: verifyOwnIntake || (async () => true), now: () => at, newId: () => attemptId});
  return {d, store, cloud: remote, calls: () => calls, claimCalls: () => claimCalls};
}


async function temporaryFixture(t,prefix) {
 const parent=await realpath(tmpdir()),dir=await mkdtemp(path.join(parent,prefix));
 t.after(async()=>{const actual=await realpath(dir),stat=await lstat(dir);
  assert.equal(path.dirname(actual),parent);assert(path.basename(actual).startsWith(prefix));
  assert(stat.isDirectory()&&!stat.isSymbolicLink());await rm(actual,{recursive:true,force:true});});
 return dir;
}

test('actual owner identity, publisher separation, exact origin, closed input and fresh exact alias required', async () => {
  const f = serviceFixture();
  assert.equal((await f.call('/api/director-capability', 'PUT', cap(), 'publisher')).status, 200);
  assert.equal((await f.call('/api/director-requests', 'POST', s, null,
    {'oai-authenticated-user-id': 'spoofed', origin: c.ownerOrigin, 'sec-fetch-site': 'same-origin'})).status, 403);
  assert.equal((await f.call('/api/director-requests', 'POST', s, 'publisher')).status, 403);
  assert.equal((await f.call('/api/director-requests', 'POST', s, 'owner', {origin: 'https://other.invalid'})).status, 403);
  assert.equal((await f.call('/api/director-requests', 'POST', {...s, threadId})).status, 400);
  assert.equal((await f.call('/api/director-requests', 'POST', {...s, issueEpisodeId: H})).status, 409);
  f.setTime(at + 45001);
  assert.equal((await f.call('/api/director-requests', 'POST', s)).status, 503);
  assert.equal(f.b.values.size, 1);
});

test('parallel same-issue clicks coalesce; response loss reconciles same IDs/time and expired capability allows readback only', async () => {
  const f = serviceFixture();
  await f.call('/api/director-capability', 'PUT', cap(), 'publisher');
  f.b.loseNextContaining('/requests/');
  const second = {...s, requestId: '55555555-5555-4555-8555-555555555555'};
  const results = await Promise.all([f.call('/api/director-requests', 'POST', s),
    f.call('/api/director-requests', 'POST', second)]);
  assert(results.every(x => x.status === 201));
  assert.equal(results[0].value.eventId, results[1].value.eventId);
  assert.equal([...f.b.values.keys()].filter(k => k.includes('/events/')).length, 1);
  f.setTime(at + 90000);
  const retry = await f.call('/api/director-requests', 'POST', s);
  assert.equal(retry.status, 200); assert.equal(retry.value.createdUtc, new Date(at).toISOString());
  assert.equal(retry.value.nativeQueueConsumption, 'unavailable');
  assert.equal((await f.call('/api/director-requests', 'POST', {...s, issueEpisodeId: H})).status, 409);
});

test('separate processes cannot both dispatch; unknown cloud claim and native outcomes never replay after restart', async () => {
  const p = await makeProof(), a = dispatchFixture();
  const b = dispatchFixture({cloud: a.cloud});
  const results = await Promise.all([a.d.dispatch(p), b.d.dispatch(p)]);
  assert.equal(a.calls() + b.calls(), 1);
  assert(results.some(x => x.state === 'unknown'));
  const f = dispatchFixture({cloud: {claim: async () => { throw Error('lost after possible claim'); },
    putReceipt: async () => { throw Error('unreachable'); }}});
  assert.equal((await f.d.dispatch(p)).state, 'unknown');
  const restarted = dispatchFixture({store: f.store});
  assert.equal((await restarted.d.dispatch(p)).attempted, false); assert.equal(restarted.calls(), 0);
  const uncertain = dispatchFixture({cli: {target: {threadId, executionCwd: 'fixture-cwd'},
    verify: async () => true, queue: async () => { throw Error('unknown native result'); }}});
  assert.equal((await uncertain.d.dispatch(p)).state, 'unknown');
  assert.equal((await uncertain.d.dispatch(p)).attempted, false);
});

test('issue revoked after claim is known not-sent; lost safe receipt uploads retry without another queue', async () => {
  const p = await makeProof(); let reads = 0;
  const revoked = dispatchFixture({verifyCurrentIssue: async () => ++reads === 1});
  assert.equal((await revoked.d.dispatch(p)).state, 'not-sent'); assert.equal(revoked.calls(), 0);
  const base = dispatchFixture(); let uploads = 0;
  const remote = {claim: base.cloud.claim, putReceipt: async v => {
    if (++uploads === 1) throw Error('receipt response lost');
    return {ok: true, attemptId: v.attemptId, proofSha256: v.proofSha256};
  }};
  const f = dispatchFixture({cloud: remote});
  await assert.rejects(f.d.dispatch(p), /receipt response lost/);
  assert.equal(f.calls(), 1);
  assert.equal((await f.d.dispatch(p)).state, 'queued'); assert.equal(f.calls(), 1);
});

test('queued is not received; actual bound Director intake is required and original receipt cannot change', async () => {
  const p = await makeProof(); let trusted = false;
  const f = dispatchFixture({verifyOwnIntake: async () => trusted});
  const queued = await f.d.dispatch(p); assert.equal(queued.state, 'queued');
  const own = {schemaVersion: 1, kind: 'actual-owner-director-intake', projectId: c.projectId,
    worldId: c.worldId, eventId: p.eventId, proofSha256: p.proofSha256, attemptId, directorThreadId: threadId,
    executionCwd: 'fixture-cwd', sourceTurnId: '66666666-6666-4666-8666-666666666666',
    sourceMessageId: '77777777-7777-4777-8777-777777777777', recordedUtc: new Date(at).toISOString(), receivedUtc: null};
  await assert.rejects(f.d.receive(own), /provenance/);
  trusted = true;
  await assert.rejects(f.d.receive({...own, directorThreadId: queueId}), /bound Director/);
  assert.equal((await f.d.receive(own)).state, 'received');
  assert.equal((await f.d.dispatch(p)).state, 'received'); assert.equal(f.calls(), 1);
  await assert.rejects(f.d.receive({...own, sourceMessageId: queueId}), /intake changed/);
  assert.equal((await f.d.receive(own)).nativeQueueConsumption, 'unavailable');
});

test('actual private-directory reservation survives a reconstructed store and corrupted state fails closed', async t => {
  const dir = await temporaryFixture(t, 'alife-director-store-fixture-');
  const store = await createDirectorDirectoryStore(dir), p = await makeProof(), f = dispatchFixture({store});
  await f.d.dispatch(p);
  const next = dispatchFixture({store: await createDirectorDirectoryStore(dir)});
  assert.equal((await next.d.dispatch(p)).attempted, false); assert.equal(next.calls(), 0);
  const queued = await store.read(p.eventId), received = {...queued, state: 'received',
    cloudReceipt: {...queued.cloudReceipt, state: 'received', intakeSha256: H}};
  await store.replace(p.eventId, received);
  await assert.rejects(store.replace(p.eventId, queued), /cannot regress/);
  const lock = path.join(dir, p.eventId + '.json.lock');
  await writeFile(lock, 'fixture-crashed-writer-lock', {flag: 'wx'});
  await assert.rejects(store.replace(p.eventId, received), {code: 'EEXIST'});
  assert.equal(await readFile(lock, 'utf8'), 'fixture-crashed-writer-lock');
  await writeFile(path.join(dir, p.eventId + '.json'), '{partial');
  await assert.rejects(next.d.dispatch(p)); assert.equal(next.calls(), 0);
});

test('fixed CLI uses pinned files, exact target and argument array; wrong target output and changed binding cannot qualify', async t => {
  const dir = await temporaryFixture(t, 'alife-director-cli-fixture-');
  const files = Object.fromEntries(['node', 'cli', 'vendor', 'binding', 'membership', 'guard']
    .map(n => [n, path.join(dir, n + '.fixture')]));
  await Promise.all(['node', 'cli', 'vendor'].map(n => writeFile(files[n], 'inert-fixture-' + n)));
  const binding = {schemaVersion:1, projectId:c.projectId, threadId, roleId:'director', hostId:'local', projectRoot:dir};
  const members = {logicalProjectId: c.projectId, members: [{roleId: 'director', threadId,
    hostId: 'local', lifecycle: 'active', executionCwd: dir}]};
  await writeFile(files.binding, JSON.stringify(binding)); await writeFile(files.membership, JSON.stringify(members));
  const module = fileURLToPath(new URL('../lib/owner-director-node.mjs', import.meta.url));
  const pins = [];
  for (const file of [files.node, files.cli, files.vendor, files.binding, module]) {
    const data = await readFile(file);
    pins.push({path: file, sha256: createHash('sha256').update(data).digest('hex'), maxBytes: 262144});
  }
  const g = {schemaVersion: 1, kind: 'owner-director-cli-guard', projectId: c.projectId,
    worldId: c.worldId, projectRoot: dir, executionCwd: dir, directorThreadId: threadId,
    directorBindingPath: files.binding, membershipPath: files.membership, nodePath: files.node,
    cliPath: files.cli, cliExecutablePath: files.vendor, pins};
  const raw = JSON.stringify(g); await writeFile(files.guard, raw);
  const guardSha256 = createHash('sha256').update(raw).digest('hex'); let calls = 0, wrong = false;
  const cli = await createFixedDirectorCli({guardPath: files.guard, guardSha256,
    expectedContext: {...c, qualificationSha256: guardSha256},
    spawnImpl(command, argv, options) {
      calls++; assert.equal(command, files.node);
      assert.deepEqual(argv, [files.cli, 'queue', '--thread', threadId, '--message', 'server prompt']);
      assert.equal(options.shell, false); assert.equal(options.windowsHide, true); assert.equal(options.cwd, dir);
      const child = new EventEmitter(); child.stdout = new EventEmitter(); child.stderr = new EventEmitter();
      child.kill = () => {};
      queueMicrotask(() => { child.stdout.emit('data', Buffer.from('Queued message ' + queueId +
        ' for thread ' + (wrong ? requestId : threadId) + '.\n')); child.emit('close', 0); });
      return child;
    }});
  assert.equal((await cli.queue('server prompt')).queueReceiptId, queueId);
  wrong = true; assert.equal((await cli.queue('server prompt')).queueReceiptId, null);
  await writeFile(files.membership, JSON.stringify({...members, members: [{...members.members[0], lifecycle: 'archived'}]}));
  await assert.rejects(cli.queue('server prompt'), /membership/); assert.equal(calls, 2);
  await writeFile(files.membership, JSON.stringify(members));
  await writeFile(files.binding, JSON.stringify({...binding, threadId: queueId}));
  await assert.rejects(cli.queue('server prompt'), /pin changed/); assert.equal(calls, 2);
});

test('service cloud reservation response loss never permits a second attempt and receipts require original proof', async () => {
  const f = serviceFixture(); await f.call('/api/director-capability', 'PUT', cap(), 'publisher');
  const saved = await f.call('/api/director-requests', 'POST', s);
  const p = (await f.call('/api/director-event?eventId=' + saved.value.eventId, 'GET', null, 'publisher')).value;
  const r = {schemaVersion: 1, kind: 'owner-director-delivery', projectId: c.projectId,
    worldId: c.worldId, eventId: p.eventId, proofSha256: p.proofSha256, qualificationSha256: Q,
    attemptId, state: 'reserved', recordedUtc: new Date(at).toISOString(), queueReceiptId: null, intakeSha256: null};
  f.b.loseNextContaining('/reserved.json');
  const claim = await f.call('/api/director-delivery', 'PUT', r, 'publisher');
  assert.equal(claim.value.applied, false);
  const again = await f.call('/api/director-delivery', 'PUT', {...r, attemptId: queueId}, 'publisher');
  assert.equal(again.value.applied, false); assert.equal(again.value.attemptId, attemptId);
  assert.equal((await f.call('/api/director-delivery', 'PUT', {...r, state: 'queued',
    queueReceiptId: queueId, proofSha256: H}, 'publisher')).status, 409);
  assert.equal((await f.call('/api/director-outbox', 'GET', null, 'publisher')).value.items.length, 0);
  assert.equal((await f.call('/api/director-requests?requestId=' + requestId)).value.delivery.state, 'unknown');
});
