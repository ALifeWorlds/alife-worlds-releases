import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile,cp,rm,realpath} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {vendorHostedSiteSource} from '../lib/hosted-site-build.mjs';
import {assertOwnerRuleLibraryResponse,selectRuleLibraryPacket} from '../web/owner-rule-library.mjs';
import {portableClipboard,parsePortableImport} from '../lib/portable-definitions.mjs';
import {createSiteBundleContract} from '../lib/site-sync-bundle.mjs';
import {createSiteBundleProducer} from '../lib/site-sync-producer.mjs';
import {canonicalWorldJSON} from '../lib/local-world-appearance.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {siteBundleFixture,r2Fixture,projectId,project,worldId,roles} from './site-sync-fixture.mjs';
import {WORLD_SCENE_FILES} from '../lib/world-profile.mjs';
import {stageWorldSiteScene,readWorldSiteScene} from '../lib/world-site-scene.mjs';
import {readOwnerPreviewQualification} from '../lib/owner-preview-qualification.mjs';
const source=fileURLToPath(new URL('../',import.meta.url)),sha=value=>createHash('sha256').update(value).digest('hex');
const privateProbe='PRIVATE_RUNTIME_SENTINEL_hosted_boundary_only';
function optionalEsbuildEntry(){const explicit=process.env.ALIFE_TEST_ESBUILD_ENTRY;if(explicit){if(!path.isAbsolute(explicit))throw Error('ALIFE_TEST_ESBUILD_ENTRY must be an absolute esbuild entry.');return explicit;}try{return createRequire(path.join(source,'package.json')).resolve('esbuild');}catch{return null;}}

async function fixture(esbuild,fn){
 const scratch=path.join(source,'runtime/test-fixtures');await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'hosted-build-')),input=path.join(root,'input-package'),site=path.join(root,'site');
 try{
  await mkdir(input);await mkdir(site);for(const name of ['lib','web','rules'])await cp(path.join(source,name),path.join(input,name),{recursive:true});await cp(path.join(source,'world/owner-site-template'),path.join(input,'world/owner-site-template'),{recursive:true});for(const name of ['package.json','LICENSE'])await cp(path.join(source,name),path.join(input,name));
  const manifest=JSON.parse(await readFile(path.join(input,'web/launcher-world113/manifest.json'),'utf8'));
  const aliases={'agent-outpost.js':'renderer','colony-art.js':'art','agent-outpost.css':'css'};for(const [name,hash]of Object.entries(manifest.sourceInputs)){const entry=manifest.assets[aliases[name]];assert(entry,'approved source alias '+name);const bytes=await readFile(path.join(input,entry.path));assert.equal(sha(bytes),hash,'approved source input '+name);assert.equal(sha(bytes),entry.sha256);assert.equal(bytes.length,entry.bytes);await writeFile(path.join(input,'web/agent-outpost',name),bytes);}
  for(const name of ['runtime/private.json','.alife-worlds/agent-bindings.json','data/agent-bindings.json','agent-homes/private/checkpoint.json','antfarm.config.json','.env']){const file=path.join(input,name);await mkdir(path.dirname(file),{recursive:true});await writeFile(file,privateProbe);}
  await mkdir(path.join(site,'.openai'));await writeFile(path.join(site,'.openai/hosting.json'),JSON.stringify({project_id:'hosted-test-fixture',static:false}));await writeFile(path.join(site,'package.json'),JSON.stringify({name:'hosted-boundary-fixture',private:true,type:'module'}));
  await mkdir(path.join(site,'node_modules/esbuild'),{recursive:true});await writeFile(path.join(site,'node_modules/esbuild/package.json'),JSON.stringify({name:'esbuild',version:'0.0.0-fixture-resolution-only',main:esbuild}));assert.equal(await realpath(createRequire(path.join(site,'package.json')).resolve('esbuild')),await realpath(esbuild));
  const vendored=await vendorHostedSiteSource({packageRoot:input,siteRoot:site}),descriptor={schemaVersion:manifest.schemaVersion,bundleId:manifest.bundleId,worldVersion:manifest.worldVersion,artifactSha256:manifest.artifactSha256},context={schemaVersion:1,access:'owner-private',worldId,roles,websiteVersion:'7.4.2',worldVersion:'1.0.2',ownerOrigin:'https://owner.test',publicOrigin:null,framePath:'/operator',projectName:'Fixture <owner> "world"',creatorLabel:'Fixture creator',renderer:descriptor,qualifiedGalleryRenderer:descriptor},config={schemaVersion:1,context,legacyStorageKey:'fixture-original-row'};
  const builder=await import(pathToFileURL(path.join(vendored.destination,'lib/hosted-site-build.mjs')));await fn({root,input,site,packageRoot:vendored.destination,manifest,descriptor,context,config,vendored,buildHostedOwnerSite:builder.buildHostedOwnerSite});
 }finally{assert(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));await rm(root,{recursive:true,force:true});}
}

test('selected custom Site scenes survive default vendor refresh, keep a backup and reject tampering',async t=>{
 const esbuild=optionalEsbuildEntry();if(!esbuild){t.skip('Missing optional Site build dependency.');return;}
 await fixture(esbuild,async f=>{
  const root=path.join(f.root,'custom-project');await mkdir(path.join(root,'.alife-worlds/runtime'),{recursive:true});
  await writeFile(path.join(root,'.alife-worlds/runtime/antfarm.config.json'),JSON.stringify({nativeReadOnly:true,nativeWorkspaceRoot:root,projectId}));
  const qualification=await readOwnerPreviewQualification(f.packageRoot),files=[],data=new Map();
  for(const row of qualification.files){let bytes=await readFile(path.join(f.packageRoot,row.path));if(row.path.endsWith('agent-outpost.css'))bytes=Buffer.concat([bytes,Buffer.from('\n/* Custom scene must survive plugin updates. */\n')]);files.push({path:row.path,sha256:sha(bytes),bytes:bytes.length});data.set(row.path,bytes);}
  const extra=Buffer.from('fixture custom webp bytes');files.push({path:'web/custom-world/sky.webp',sha256:sha(extra),bytes:extra.length});data.set(files.at(-1).path,extra);
  const design={artDirection:'My custom world',assets:[],preferences:{water:'violet'}},manifest={schemaVersion:1,kind:'world-artifact',version:'2.0.0',design,files},artifactSha256=sha(JSON.stringify(manifest)),artifact=path.join(root,'.alife-worlds/world-release/artifacts',artifactSha256);
  await mkdir(artifact,{recursive:true});await writeFile(path.join(artifact,'manifest.json'),JSON.stringify(manifest));
  for(const [name,bytes]of data){await mkdir(path.dirname(path.join(artifact,name)),{recursive:true});await writeFile(path.join(artifact,name),bytes);}
  const profile={schemaVersion:1,projectId,worldId,revision:7,...design,preferences:{...design.preferences,scene:{schemaVersion:1,renderer:'midnight-colony',version:'2.0.0',artifactSha256}}};
  const profileFile=path.join(root,'.alife-worlds/world-profile.json');await writeFile(profileFile,JSON.stringify(profile));
  await writeFile(path.join(root,'.alife-worlds/world-release/ledger.json'),JSON.stringify({schemaVersion:1,projectId,worldId,projectRoot:root,releases:[{version:'2.0.0',state:'prepared',artifactSha256}]}));
  const before=await readFile(profileFile),staged=await stageWorldSiteScene({packageRoot:f.packageRoot,siteRoot:f.site,projectRoot:root,worldId});assert.deepEqual(await readFile(profileFile),before);
  await assert.rejects(stageWorldSiteScene({packageRoot:f.packageRoot,siteRoot:f.site,projectRoot:root,worldId:'foreign-world'}),/exact selected/);
  const config={...f.config,scene:staged.scene,context:{...f.context,worldVersion:'2.0.0'}};
  await f.buildHostedOwnerSite({packageRoot:f.packageRoot,siteRoot:f.site,config});
  const generated=await import(pathToFileURL(path.join(f.site,'generated/owner-site-data.mjs'))+'?custom');
  const custom=Buffer.from(generated.assets['/agent-outpost/agent-outpost.css'].base64,'base64'),backup=Buffer.from(generated.assets['/default-world/agent-outpost/agent-outpost.css'].base64,'base64');
  assert(custom.includes(Buffer.from('Custom scene must survive')));assert(!backup.includes(Buffer.from('Custom scene must survive')));assert.equal(generated.assets['/custom-world/sky.webp'].type,'image/webp');assert(generated.assets['/default-world/']);
  const exported=await readFile(path.join(f.site,staged.scene),'utf8');assert(!exported.includes(root));assert(!exported.includes(projectId));assert(!exported.includes('runtime'));
  await vendorHostedSiteSource({packageRoot:f.input,siteRoot:f.site});
  const selected=await readWorldSiteScene({siteRoot:f.site,reference:staged.scene,worldId,qualification});assert(selected.bytes.get('web/agent-outpost/agent-outpost.css').equals(custom));assert.deepEqual(await readFile(profileFile),before);
  await writeFile(path.join(f.site,path.dirname(staged.scene),'web/custom-world/sky.webp'),'tampered');
  await assert.rejects(f.buildHostedOwnerSite({packageRoot:f.packageRoot,siteRoot:f.site,config}),/changed/);
  const sceneFile=path.join(f.site,staged.scene),scene=JSON.parse(await readFile(sceneFile,'utf8'));scene.privatePath=root;await writeFile(sceneFile,JSON.stringify(scene));
  await assert.rejects(readWorldSiteScene({siteRoot:f.site,reference:staged.scene,worldId,qualification}),/Foreign/);
 });
});

test('clean portable Site build and actual generated Worker retain owner Rules, release identity and bounded authority',async t=>{
 const esbuild=optionalEsbuildEntry();if(!esbuild){t.skip('Missing optional Site build dependency: install esbuild or set absolute ALIFE_TEST_ESBUILD_ENTRY.');return;}await fixture(esbuild,async f=>{
 const buildHostedOwnerSite=f.buildHostedOwnerSite;
 const build=await buildHostedOwnerSite({packageRoot:f.packageRoot,siteRoot:f.site,config:f.config}),pkg=JSON.parse(await readFile(path.join(f.packageRoot,'package.json'),'utf8')),builtFile=path.join(f.site,'dist/server/index.js'),worker=(await import(pathToFileURL(builtFile))).default;
 const owner={'oai-authenticated-user-id':'fixture-owner'},pairing='fixture-pairing-key-never-shipped-20261109',storage=r2Fixture();let reads=0,writes=0;const env={PROJECT_SCOPE:project,BUNDLE_SYNC_KEY:pairing,SNAPSHOTS:{get:async key=>{reads++;return storage.get(key);},put:async(...args)=>{writes++;return storage.put(...args);}}};
 const call=(route,options={})=>worker.fetch(new Request('https://owner.test'+route,options),env);

 await t.test('actual private page ends its Sprint section with Rules and exports separate human/AI portable definitions',async()=>{
  const response=await call('/',{headers:owner});assert.equal(response.status,200);const html=await response.text(),plan=html.slice(html.indexOf('id="wf-plan"'),html.indexOf('</main>'));assert(plan.includes('id="wf-rule-library"'));assert(plan.indexOf('id="wf-rule-library"')>plan.indexOf('id="wf-sprint-list"'));assert.match(plan,/id="wf-rule-library"[^>]*>.*?<\/div>\s*<\/section>\s*$/s);
  assert.equal((await call('/api/rule-library?project='+f.context.worldId,{headers:owner})).status,503,'packaged defaults do not impersonate a synchronized effective library');
  const client=await(await call('/workspace.js',{headers:owner})).text();for(const label of ['Plugin rules','World rules','AI instructions','Copy import','Clone definition','Agent model settings'])assert(client.includes(label));assert(!client.includes(privateProbe));
 });

 await t.test('non-owner credentials do not substitute for trusted Site identity; wrong worlds/origins/writes refuse before storage',async()=>{
  const before=reads;for(const route of ['/','/operator?embed=1&project='+f.context.worldId+'&hostOrigin=https%3A%2F%2Fowner.test','/workspace.js','/api/rule-library','/api/workspace','/api/agent-metadata']){assert.equal((await call(route)).status,401);assert.equal((await call(route,{headers:{Authorization:'Bearer visitor-forgery','X-Owner-Id':'fixture-owner','X-ALife-Sync-Key':pairing}})).status,401);}
  for(const route of ['/?project=world-foreign','/api/rule-library?project=world-foreign','/api/workspace?project=world-foreign','/api/agent-metadata?project=world-foreign'])assert.equal((await call(route,{headers:owner})).status,404);assert.equal((await call('/api/rule-library?project='+f.context.worldId+'&project='+f.context.worldId,{headers:owner})).status,404);assert.equal((await call('/api/rule-library?extra=1',{headers:owner})).status,404);assert.equal((await call('/api/rule-library',{method:'POST',headers:owner})).status,405);assert.equal((await call('/',{method:'DELETE',headers:owner})).status,405);assert.equal((await call('/api/rule-library',{headers:{...owner,Origin:'https://foreign.test'}})).status,403);assert.equal((await worker.fetch(new Request('https://foreign.test/',{headers:owner}),env)).status,403);assert.equal(reads,before);assert.equal(writes,0);
 });

 await t.test('paired release verification exposes exact independent versions and cannot become browser owner authority',async()=>{
  assert.equal((await call('/api/site-release')).status,401);assert.equal((await call('/api/site-release',{headers:{'X-ALife-Sync-Key':'visitor-forgery-key-that-is-long-enough'}})).status,401);assert.equal((await call('/api/site-release',{headers:{'X-ALife-Sync-Key':pairing,Origin:f.context.ownerOrigin}})).status,405);assert.equal((await call('/api/site-release?project='+f.context.worldId,{headers:owner})).status,405);assert.equal((await call('/api/site-release',{method:'PUT',headers:owner})).status,405);
  for(const headers of [owner,{'X-ALife-Sync-Key':pairing}]){const response=await call('/api/site-release',{headers});assert.equal(response.status,200);const record=await response.json();assert.equal(record.kind,'owner-site-release');assert.equal(record.packageVersion,pkg.version);assert.equal(record.websiteVersion,'7.4.2');assert.equal(record.worldVersion,'1.0.2');assert.equal(record.renderer.worldVersion,f.descriptor.worldVersion);assert.notEqual(record.worldVersion,record.renderer.worldVersion);assert.equal(record.assetSetSha256,build.assetSetSha256);assert.equal(record.rules.length,2);for(const rule of record.rules){const catalog=JSON.parse(await readFile(path.join(f.packageRoot,'rules',rule.scope+'.json'),'utf8'));assert.equal(rule.properties,catalog.groups.reduce((n,g)=>n+g.properties.filter(p=>p.active).length,0));}assert.equal(record.synchronization.state,'unavailable');}
  assert.equal(writes,0);
 });

 await t.test('qualified asset bytes/ETags and escaped private frame context survive the real build without private artifacts',async()=>{
  const response=await call('/agent-outpost/agent-outpost.js',{headers:owner});assert.equal(response.status,200);assert.equal(sha(Buffer.from(await response.arrayBuffer())),f.manifest.assets.renderer.sha256);assert.equal(response.headers.get('etag'),'"'+f.manifest.assets.renderer.sha256+'"');const frame=await(await call('/operator?embed=1&project='+f.context.worldId+'&hostOrigin=https%3A%2F%2Fowner.test',{headers:owner})).text();assert(frame.includes('data-owner-context="{&quot;'));assert(frame.includes('&lt;owner&gt;'));assert(!frame.includes('__OWNER_HOSTED_CONTEXT__'));assert(frame.includes('/owner-hosted-world.mjs'));
  const generated=await import(pathToFileURL(path.join(f.site,'generated/owner-site-data.mjs')));for(const [route,asset]of Object.entries(generated.assets)){assert(!/\/(?:runtime|data|agent-homes|\.alife-worlds)\//.test(route));assert.equal(sha(Buffer.from(asset.base64,'base64')),asset.sha256);assert.equal(Buffer.from(asset.base64,'base64').includes(Buffer.from(privateProbe)),false);}const inventory=JSON.parse(await readFile(path.join(f.packageRoot,'hosted-source.json'),'utf8'));assert(inventory.files.every(p=>/^(?:lib\/|web\/|rules\/|world\/owner-site-template\/|package\.json$|LICENSE$)/.test(p)));const bytes=await readFile(builtFile);assert(!bytes.includes(Buffer.from(privateProbe)));assert(!bytes.includes(Buffer.from(pairing)));assert.equal(build.privateRuntimeIncluded,false);assert.equal(build.worldVersion,'1.0.2');
 });

 await t.test('actual generated Worker reads effective rule overrides from its atomic owner bundle and exports no private history',async()=>{
  const current=await siteBundleFixture(),catalogs={},expected=new Map();
  for(const scope of ['plugin','world']){const raw=JSON.parse(await readFile(path.join(f.packageRoot,'rules',scope+'.json'),'utf8')),catalog=structuredClone(raw),group=catalog.groups.find(group=>group.properties.some(property=>property.active)),property=group.properties.find(property=>property.active);catalog.revision+=7;property.title='Fixture effective '+scope+' override';property.description='Human label for the synchronized fictional override.';property.text='When this fixture applies\nUse this effective '+scope+' instruction from the actual selected-project observation.\n\nRequired behavior\nPreserve the original source clocks and require the existing owner gate.\n\nSafety\nDo not export private history or invent acceptance.';property.history=[{privateText:privateProbe}];catalog.requests=[{privateText:privateProbe}];catalogs[scope]=catalog;expected.set(scope,{revision:catalog.revision,groupId:group.id,id:property.id,title:property.title,description:property.description,text:property.text,packagedRevision:raw.revision});}
  current.dashboard.ruleCatalog=catalogs;current.dashboard.ownerPreview=structuredClone(current.bundle.ownerPreview);current.dashboard.ownerPreview.renderer=f.descriptor;current.dashboard.ownerPreview.appearance.renderer=f.descriptor;current.catalog.worlds[0].connection.target.url=f.context.ownerOrigin+'/';
  const producer=createSiteBundleProducer({project,projectId,worldId,registry,renderer:f.descriptor,ownerOrigin:f.context.ownerOrigin,oracle:globalThis.AgentOutpost}),bundle=await producer.produce({revision:1,dashboard:current.dashboard,plan:current.plan,catalog:current.catalog}),contract=createSiteBundleContract({project,worldId,roles,renderer:f.descriptor,ownerOrigin:f.context.ownerOrigin});await contract.assertBundle(bundle);assert(bundle.ruleLibrary);
  const publish=await call('/api/owner-bundle',{method:'PUT',headers:{'Content-Type':'application/json','X-ALife-Sync-Key':pairing},body:JSON.stringify(bundle)});assert.equal(publish.status,200,await publish.clone().text());assert.equal(storage.rows.size,1);assert.equal(writes,1);
  const response=await call('/api/rule-library?project='+worldId,{headers:owner});assert.equal(response.status,200);const library=assertOwnerRuleLibraryResponse(await response.json(),{worldId});assert.equal(JSON.stringify(library).includes(privateProbe),false);
  for(const scope of ['plugin','world']){const wanted=expected.get(scope),row=library.scopes.find(row=>row.scope===scope),group=row.packet[scope].groups.find(group=>group.id===wanted.groupId),property=group.properties.find(property=>property.id===wanted.id);assert.equal(row.revision,wanted.revision);assert.equal(property.title,wanted.title);assert.equal(property.description,wanted.description);assert.equal(property.text,wanted.text);assert.equal(Object.hasOwn(property,'history'),false);assert.equal(Object.hasOwn(row.packet[scope],'requests'),false);for(const selection of [{scope},{scope,groupId:group.id},{scope,groupId:group.id,propertyId:property.id}]){const packet=selectRuleLibraryPacket(library,selection);assert.deepEqual(parsePortableImport(portableClipboard(packet)),packet);assert.equal(JSON.stringify(packet).includes(privateProbe),false);}}
  const release=await(await call('/api/site-release',{headers:owner})).json();for(const row of release.rules)assert.equal(row.revision,expected.get(row.scope).packagedRevision,'release counts remain packaged provenance, separate from effective rules');
  const [key,original]=[...storage.rows.entries()][0],saved=JSON.parse(original),oldReceipt={...saved,receivedUtc:new Date(Date.now()-45001).toISOString()};storage.rows.set(key,JSON.stringify(oldReceipt));assert.equal((await call('/api/rule-library',{headers:owner})).status,503,'expired receipt cannot serve current Rules');
  const shift=value=>typeof value==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(value)?new Date(Date.parse(value)-60000).toISOString():Array.isArray(value)?value.map(shift):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).map(([key,value])=>[key,shift(value)])):value;
  const oldSource={bundle:shift(saved.bundle),receivedUtc:new Date().toISOString()};oldSource.bundle.ownerPreview.appearance.snapshotSha256=sha(canonicalWorldJSON(oldSource.bundle.ownerPreview.snapshot));await contract.assertBundle(oldSource.bundle);storage.rows.set(key,JSON.stringify(oldSource));assert.equal((await call('/api/rule-library',{headers:owner})).status,503,'fresh receipt cannot renew an expired rule source');storage.rows.set(key,original);
  current.dashboard.ruleCatalog=null;const withoutRules=await producer.produce({revision:2,dashboard:current.dashboard,plan:current.plan,catalog:current.catalog});assert.equal(withoutRules.ruleLibrary,null);const accepted=await call('/api/owner-bundle',{method:'PUT',headers:{'Content-Type':'application/json','X-ALife-Sync-Key':pairing},body:JSON.stringify(withoutRules)});assert.equal(accepted.status,200,await accepted.clone().text());assert.equal((await call('/api/rule-library',{headers:owner})).status,503);const workspace=await call('/api/workspace',{headers:owner});assert.equal(workspace.status,200);assert.equal((await workspace.json()).snapshot.worldId,worldId);
 });

 await t.test('actual pinned current frame needs owner identity and uses its qualified assets and independent World label',async()=>{
  const path='/api/owner-world-release?project='+f.context.worldId;
  for(const route of [path,'/owner-frame-client.mjs','/world-frame/'+f.descriptor.artifactSha256+'/'])for(const headers of [{},{'X-ALife-Sync-Key':pairing}])assert.equal((await call(route,{headers})).status,401,'service pairing alone does not become a browser owner');
  const response=await call(path,{headers:owner});assert.equal(response.status,200,await response.clone().text());const offer=await response.json();assert.deepEqual(offer.current.renderer,f.descriptor);assert.equal(offer.previous,null);assert.equal(offer.current.framePath,'/world-frame/'+f.descriptor.artifactSha256+'/');
  const frame=await call(offer.current.framePath,{headers:owner});assert.equal(frame.status,200);const html=await frame.text();assert(html.includes('name="alife-world-version" content="1.0.2"'));assert(html.includes(offer.current.framePath+'context'));assert(html.includes('/owner-frame-client.mjs'));
  const client=await call('/owner-frame-client.mjs',{headers:owner});assert.equal(client.status,200);assert((await client.text()).includes('createOwnerOperatorViewport'));
  const asset=await call(offer.current.resourceBase+'agent-outpost/agent-outpost.js',{headers:owner});assert.equal(asset.status,200);assert.equal(sha(Buffer.from(await asset.arrayBuffer())),f.manifest.assets.renderer.sha256);
  assert.equal((await call('/api/owner-world-release?project=world-foreign',{headers:owner})).status,404);
 });

 await t.test('explicit unsupported/custom renderers and one changed pinned asset refuse; omitted fresh-build renderer is intentional',async()=>{
  for(const renderer of [null,{...f.descriptor,bundleId:'foreign-style'}])await assert.rejects(buildHostedOwnerSite({packageRoot:f.packageRoot,siteRoot:f.site,config:{...f.config,context:{...f.context,renderer}}}),/unsupported selected renderer/);
  await assert.rejects(buildHostedOwnerSite({packageRoot:f.packageRoot,siteRoot:f.site,config:{...f.config,context:{...f.context,access:'local-owner'}}}),/explicitly private owner Site/);
  await assert.rejects(buildHostedOwnerSite({packageRoot:f.packageRoot,siteRoot:f.site,config:{...f.config,context:{...f.context,framePath:'/unregistered-frame'}}}),/\/operator/);
  const selected={...f.config.context};delete selected.renderer;const defaultBuild=await buildHostedOwnerSite({packageRoot:f.packageRoot,siteRoot:f.site,config:{...f.config,context:selected}});assert.deepEqual(defaultBuild.renderer,f.descriptor);assert.equal(defaultBuild.worldVersion,'1.0.2');const before=sha(await readFile(builtFile)),rendererFile=path.join(f.packageRoot,f.manifest.assets.renderer.path),original=await readFile(rendererFile),changed=Buffer.from(original);changed[0]^=1;await writeFile(rendererFile,changed);await assert.rejects(buildHostedOwnerSite({packageRoot:f.packageRoot,siteRoot:f.site,config:f.config}),/Qualified world asset changed: renderer/);assert.equal(sha(await readFile(builtFile)),before);await writeFile(rendererFile,original);
  const inputFile=path.join(f.input,'web/agent-outpost/agent-outpost.js');await writeFile(inputFile,'unqualified independent artwork');await assert.rejects(vendorHostedSiteSource({packageRoot:f.input,siteRoot:f.site}),/clean qualified source snapshot/);
 });
});});
