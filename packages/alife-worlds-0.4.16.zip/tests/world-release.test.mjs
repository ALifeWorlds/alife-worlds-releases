import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,rm,lstat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID,createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {worldVersion,compareWorldVersions,nextWorldVersion,worldDisplayTitle,validateWorldDefinition} from '../lib/world-definition.mjs';
import * as api from '../lib/world-release.mjs';
import {WORLD_SCENE_FILES,readWorldProfile,readWorldSceneFile} from '../lib/world-profile.mjs';
const source=fileURLToPath(new URL('../',import.meta.url)),scratch=path.join(source,'runtime/test-fixtures'),sha=s=>createHash('sha256').update(s).digest('hex');
const definition={schemaVersion:1,version:'1.0.0',state:'definition',artifactSha256:null,surfaces:[]};
async function fixture(fn,{bootstrap=false}={}){
 await mkdir(scratch,{recursive:true});const base=await mkdtemp(path.join(scratch,'world-release-')),root=path.join(base,'project'),packet=path.join(base,'packet'),codexHome=path.join(base,'codex');
 await mkdir(root);await mkdir(path.join(packet,'world'),{recursive:true});await writeFile(path.join(packet,'world/world-release.json'),JSON.stringify(definition));const projectId=randomUUID(),actors={};
 const day=new Date().toISOString().slice(0,10).replaceAll('-','/'),sessionDir=path.join(codexHome,'sessions',day);await mkdir(sessionDir,{recursive:true});
 const bindings={schemaVersion:1,projectId,projectRoot:root,agents:[]};
 for(const id of ['director','support','world-requests','technical-support']){
  const threadId=randomUUID(),home=id,homePath=path.join(root,home),sessionPath=path.join(sessionDir,'rollout-fixture-'+threadId+'.jsonl');await mkdir(homePath);
  await writeFile(sessionPath,JSON.stringify({type:'session_meta',payload:{id:threadId,cwd:root}})+'\n');await writeFile(path.join(homePath,'receipt.json'),JSON.stringify({schemaVersion:1,roleId:id,threadId,projectId,workspacePath:root,homePath,accessVerified:true,contractsFullRead:true,retirementVersion:1}));
  actors[id]={threadId,sessionPath};bindings.agents.push({id,home,threadId,sessionPath});
 }
 const bindingFile=path.join(root,bootstrap?'.alife-worlds/agent-bindings.json':'data/agent-bindings.json');await mkdir(path.dirname(bindingFile),{recursive:true});await writeFile(bindingFile,JSON.stringify(bindings));
 if(bootstrap)await writeFile(path.join(root,'.alife-worlds/bootstrap.json'),JSON.stringify({schemaVersion:1,projectId,projectRoot:root,effects:[]}));
 const proof=actors.director,ledgerFile=path.join(root,'.alife-worlds/world-release/ledger.json'),profileFile=path.join(root,'.alife-worlds/world-profile.json');
 const artifactRoot=path.join(base,'artifact');await mkdir(path.join(artifactRoot,'web'),{recursive:true});await writeFile(path.join(artifactRoot,'web/app.mjs'),'export const scene="fixture";\n');
 const evidence=path.join(base,'reduced-evidence.json'),recovery=path.join(base,'retained-recovery.json');await writeFile(evidence,JSON.stringify({fixture:true,result:'source-check-only'}));await writeFile(recovery,JSON.stringify({fixture:true,retained:'old-world'}));
 const init=()=>api.initializeWorldRelease(packet,root,{requestId:'init',explicitInitialize:true},proof);
 const profileInput={requestId:'profile',expectedRevision:0,artDirection:'Fixture paper world',assets:[],preferences:{sound:{enabled:true},reducedMotion:false},surfaces:[{id:'local',kind:'local',url:'http://127.0.0.1:43210/',optedOut:false},{id:'private',kind:'private',url:'https://private.example.test/world',optedOut:false},{id:'public',kind:'public',url:'https://public.example.test/world',optedOut:true}],automaticUpdates:true};
 const prepareInput={requestId:'prepare',version:'1.0.0',artifactRoot,files:['web/app.mjs'],summary:'Fixture world update',sourceReference:'fixture-commit',checks:{source:'PASS',native:'Unknown',physical:'Not checked'}};
 const profile=()=>api.saveWorldProfile(root,profileInput,proof),prepare=()=>api.prepareWorldRelease(root,prepareInput,proof),readLedger=()=>readFile(ledgerFile,'utf8').then(JSON.parse),ready=async()=>{await init();await profile();return prepare();};
 try{await fn({base,root,packet,codexHome,projectId,actors,proof,bindings,bindingFile,ledgerFile,profileFile,artifactRoot,evidence,recovery,init,profile,profileInput,prepare,prepareInput,readLedger,ready});}
 finally{const target=path.resolve(base);assert.ok(target.startsWith(path.resolve(scratch)+path.sep));await rm(target,{recursive:true,force:true});}
}
test('world versions compare numerically and title display keeps canonical numeric identity',()=>{
 assert.equal(worldVersion('1.0.0'),'1.0.0');assert.equal(worldDisplayTitle('1.0.0'),'World 1.0');assert.equal(worldDisplayTitle('1.0.1'),'World 1.0.1');assert.equal(worldDisplayTitle('1.1.0'),'World 1.1');assert.equal(compareWorldVersions('1.10.0','1.9.9'),1);assert.equal(nextWorldVersion('1.9.9','minor'),'1.10.0');
 for(const v of ['01.0.0','1.0','1.0.0-beta','1.0.9007199254740992'])assert.throws(()=>worldVersion(v));assert.deepEqual(validateWorldDefinition(definition),definition);assert.throws(()=>validateWorldDefinition({...definition,surfaces:['invented-deployed']}));
});
test('read-only uninitialized report creates no records and makes no deployed claim',()=>fixture(async f=>{
 const r=await api.readWorldReleaseReport(f.packet,f.root,f.proof);assert.equal(r.status,'uninitialized-no-deployed-claim');assert.deepEqual(r.surfaces,[]);await assert.rejects(lstat(f.ledgerFile),e=>e.code==='ENOENT');
}));
test('initialization preserves legacy binding identities and records definition only',()=>fixture(async f=>{
 const before=await readFile(f.bindingFile),r=await f.init();assert.equal(r.status,'initialized-definition');assert.equal(r.deployedVersion,null);assert.equal((await f.init()).status,'existing-private-world-records');assert.deepEqual(await readFile(f.bindingFile),before);assert.equal((await f.readLedger()).events.length,1);
}));
test('new bootstrap bindings use the same exact-context guard',()=>fixture(async f=>{await f.init();assert.equal((await f.readLedger()).projectId,f.projectId);},{bootstrap:true}));
test('foreign chat, non-owner and absent own custody cannot write private records',()=>fixture(async f=>{
 await assert.rejects(api.initializeWorldRelease(f.packet,f.root,{requestId:'x',explicitInitialize:true},{...f.proof,threadId:randomUUID()}),/selected project/);
 await assert.rejects(api.initializeWorldRelease(f.packet,f.root,{requestId:'x',explicitInitialize:true},f.actors['technical-support']),/Only the bound/);
 await writeFile(path.join(f.root,'director/receipt.json'),'{}');await assert.rejects(f.init(),/custody receipt/);await assert.rejects(lstat(f.ledgerFile),e=>e.code==='ENOENT');
}));
test('private profile saves exact assets and preferences with idempotence and revision guards',()=>fixture(async f=>{
 await f.init();const art=path.join(f.base,'art.png');await writeFile(art,'fixture-art');f.profileInput.assets=[{id:'paper',path:art,license:'Fixture license',provenance:'Fictional test reference'}];
 const result=await f.profile();assert.equal(result.revision,1);assert.deepEqual(await f.profile(),result);const p=JSON.parse(await readFile(f.profileFile,'utf8'));assert.equal(p.assets[0].sha256,sha('fixture-art'));assert.equal(p.automaticUpdates,true);assert.equal(p.surfaces[2].optedOut,true);
 await assert.rejects(api.saveWorldProfile(f.root,{...f.profileInput,artDirection:'changed'},f.proof),/reused/);await assert.rejects(api.saveWorldProfile(f.root,{...f.profileInput,requestId:'other'},f.proof),/reread and merge/);
 await assert.rejects(api.saveWorldProfile(f.root,{...f.profileInput,requestId:'secret',expectedRevision:1,preferences:{apiKey:'invalid'}},f.proof),/credential field/);
}));

test('routine profile refresh preserves saved art, nested preferences, assets, opt-outs and update consent',()=>fixture(async f=>{
 await f.init();const art=path.join(f.base,'custom.png');await writeFile(art,'custom-art');
 f.profileInput.assets=[{id:'sky',path:art}];await f.profile();
 const before=JSON.parse(await readFile(f.profileFile,'utf8'));
 await api.saveWorldProfile(f.root,{...f.profileInput,requestId:'routine',expectedRevision:1,artDirection:'Bundled default',assets:[],preferences:{sound:{enabled:false,volume:.4},newOption:true},surfaces:[],automaticUpdates:false},f.proof);
 const after=JSON.parse(await readFile(f.profileFile,'utf8'));
 assert.equal(after.artDirection,before.artDirection);assert.deepEqual(after.assets,before.assets);assert.deepEqual(after.preferences.sound,{enabled:true,volume:.4});assert.deepEqual(after.surfaces,before.surfaces);assert.equal(after.automaticUpdates,true);
 const effect=(await f.readLedger()).effects.filter(row=>row.kind==='profile-save').at(-1);assert.deepEqual(effect.previous,before);
 await api.saveWorldProfile(f.root,{...f.profileInput,requestId:'customize',expectedRevision:2,mode:'customize',artDirection:'New requested scene',assets:[],preferences:{sound:{enabled:false}},surfaces:[],automaticUpdates:false},f.proof);
 const custom=JSON.parse(await readFile(f.profileFile,'utf8'));assert.equal(custom.artDirection,'New requested scene');assert.deepEqual(custom.assets,before.assets);assert.deepEqual(custom.preferences.sound,{enabled:false,volume:.4});assert.deepEqual(custom.surfaces,before.surfaces);
}));

async function sceneFiles(f){
 for(const relative of WORLD_SCENE_FILES){const file=path.join(f.artifactRoot,'web',relative);await mkdir(path.dirname(file),{recursive:true});await writeFile(file,'custom fixture '+relative);}
 const file=path.join(f.artifactRoot,'web/custom-world/sky.webp');await mkdir(path.dirname(file),{recursive:true});await writeFile(file,'own custom sky');
 return [...WORLD_SCENE_FILES.map(file=>'web/'+file),'web/custom-world/sky.webp'];
}

test('custom world stages without changing the active profile and activates once with retained recovery',()=>fixture(async f=>{
 await f.init();await f.profile();const before=await readFile(f.profileFile),files=await sceneFiles(f);
 const art=path.join(f.base,'sky.webp');await writeFile(art,'new custom sky');
 const candidate=await api.prepareWorldRelease(f.root,{...f.prepareInput,files,profileUpdate:{mode:'customize',artDirection:'My own woodland',assets:[{id:'sky',path:art,license:'Own fixture art'}],preferences:{sky:'custom'}}},f.proof);
 assert.deepEqual(await readFile(f.profileFile),before,'staging must preserve active scene');
 const request={requestId:'activate',expectedRevision:1,version:candidate.version};
 assert.deepEqual(await api.activateWorldRelease(f.root,request,f.proof),{status:'saved-private-profile',revision:2});
 assert.deepEqual(await api.activateWorldRelease(f.root,request,f.proof),{status:'saved-private-profile',revision:2});
 const profile=JSON.parse(await readFile(f.profileFile,'utf8'));assert.equal(profile.artDirection,'My own woodland');assert.deepEqual(profile.surfaces,JSON.parse(before).surfaces);assert.equal(profile.automaticUpdates,true);assert.equal(await readFile(profile.assets[0].path,'utf8'),'new custom sky');
 const selected=await readWorldProfile({packageRoot:f.packet,projectRoot:f.root,projectId:f.projectId});assert.equal(selected.status,'ready');assert.equal(selected.kind,'custom');assert.equal((await readWorldSceneFile(selected,'custom-world/sky.webp')).toString(),'own custom sky');
 await assert.rejects(readWorldSceneFile(selected,'custom-world/other.webp'),/not selected/);
 const effect=(await f.readLedger()).effects.filter(row=>row.kind==='profile-save').at(-1);assert.deepEqual(effect.previous,JSON.parse(before));
 await writeFile(path.join(candidate.recoveryPath,'web/custom-world/sky.webp'),'tampered');
 assert.equal((await readWorldProfile({packageRoot:f.packet,projectRoot:f.root,projectId:f.projectId})).status,'unavailable');
}));

test('incomplete, corrupt and stale custom candidates cannot replace the current profile',()=>fixture(async f=>{
 await f.ready();const before=await readFile(f.profileFile);
 await assert.rejects(api.activateWorldRelease(f.root,{requestId:'incomplete',expectedRevision:1,version:'1.0.0'},f.proof),/missing required/);assert.deepEqual(await readFile(f.profileFile),before);
 const files=await sceneFiles(f),candidate=await api.prepareWorldRelease(f.root,{...f.prepareInput,requestId:'complete',version:'1.0.1',files},f.proof);
 await writeFile(path.join(candidate.recoveryPath,'web/custom-world/sky.webp'),'corrupt');
 await assert.rejects(api.activateWorldRelease(f.root,{requestId:'corrupt',expectedRevision:1,version:'1.0.1'},f.proof),/changed|differs/);assert.deepEqual(await readFile(f.profileFile),before);
 await api.prepareWorldRelease(f.root,{...f.prepareInput,requestId:'later',version:'1.0.2',files},f.proof);
 await api.saveWorldProfile(f.root,{...f.profileInput,requestId:'human-edit',expectedRevision:1,mode:'customize',artDirection:'Later human edit'},f.proof);
 const changed=await readFile(f.profileFile);
 await assert.rejects(api.activateWorldRelease(f.root,{requestId:'stale',expectedRevision:1,version:'1.0.2'},f.proof),/changed after preview/);
 await assert.rejects(api.activateWorldRelease(f.root,{requestId:'stale-new-revision',expectedRevision:2,version:'1.0.2'},f.proof),/another profile revision/);assert.deepEqual(await readFile(f.profileFile),changed);
}));
test('legacy evidence and recovery stay unversioned with readable real hosting identifiers',()=>fixture(async f=>{
 await f.init();await f.profile();const req={requestId:'legacy',surfaceId:'private',label:'Previous private world',hostingVersionId:'5',evidence:[{path:f.evidence}],recovery:[{path:f.recovery}],note:'Historical fixture only'};
 const r=await api.recordLegacyWorldSurface(f.root,req,f.proof);assert.equal(r.status,'recorded-unversioned-history');assert.equal(r.recoveryVerified,true);assert.deepEqual(await api.recordLegacyWorldSurface(f.root,req,f.proof),r);
 const report=await api.readWorldReleaseReport(f.packet,f.root,f.proof);assert.equal(report.legacy[0].worldVersion,null);assert.equal(report.surfaces[0].deployedVersion,null);assert.equal(report.surfaces[0].hostingVersionId,'5');
 const markdown=await api.readWorldReleaseReport(f.packet,f.root,f.proof,{format:'markdown'});assert.match(markdown,/Previous private world/);assert.match(markdown,/world version Unknown/);assert.match(markdown,new RegExp(path.basename(f.recovery)));
}));
test('prepared release has hash-verified immutable world/design files and readable changes/check limits',()=>fixture(async f=>{
 const r=await f.ready();assert.equal(r.status,'prepared-not-deployed');const manifest=JSON.parse(await readFile(path.join(r.recoveryPath,'manifest.json'),'utf8'));assert.equal(sha(JSON.stringify(manifest)),r.artifactSha256);assert.equal(await readFile(path.join(r.recoveryPath,'web/app.mjs'),'utf8'),'export const scene="fixture";\n');assert.equal(manifest.design.artDirection,'Fixture paper world');assert.deepEqual(await f.prepare(),r);
 const report=await api.readWorldReleaseReport(f.packet,f.root,f.proof);assert.deepEqual(report.surfaces,[]);const markdown=await api.readWorldReleaseReport(f.packet,f.root,f.proof,{format:'markdown'});assert.match(markdown,/Fixture world update/);assert.match(markdown,/fixture-commit/);assert.match(markdown,/Not checked/);assert.match(markdown,new RegExp(report.releases[0].preparedAt));
 await writeFile(path.join(f.artifactRoot,'web/app.mjs'),'changed');await assert.rejects(api.prepareWorldRelease(f.root,{...f.prepareInput,requestId:'changed'},f.proof),/immutable/);
}));
test('changed profile art is refused before a release or effect is invented',()=>fixture(async f=>{
 await f.init();const art=path.join(f.base,'custom.png');await writeFile(art,'old');f.profileInput.assets=[{id:'art',path:art}];await f.profile();await writeFile(art,'new');await assert.rejects(f.prepare(),/saved art changed/);assert.equal((await f.readLedger()).effects.some(e=>e.kind==='artifact-snapshot'),false);
}));
test('surface reservations require exact prepared artifact and preserve opted-out and other surfaces',()=>fixture(async f=>{
 await f.ready();await assert.rejects(api.reserveWorldSurfaceUpdate(f.root,{requestId:'opted',surfaceId:'public',version:'1.0.0'},f.proof),/opted out/);
 await assert.rejects(api.reserveWorldSurfaceUpdate(f.root,{requestId:'missing',surfaceId:'local',version:'1.0.1'},f.proof),/No prepared/);
 const req={requestId:'surface',surfaceId:'private',version:'1.0.0'},r=await api.reserveWorldSurfaceUpdate(f.root,req,f.proof);assert.equal(r.status,'reserved-not-published');assert.equal(r.surface.kind,'private');assert.equal((await api.reserveWorldSurfaceUpdate(f.root,req,f.proof)).canPublish,false);assert.deepEqual(Object.keys((await f.readLedger()).surfaces),['private']);
 await api.recordWorldSurfaceResult(f.root,{operationId:r.operationId,status:'unknown',hostingVersionId:null,evidence:[]},f.proof);await assert.rejects(api.reserveWorldSurfaceUpdate(f.root,{...req,requestId:'replay'},f.proof),/original pending/);
}));
test('actual deployment and verification remain separate and exact provider revision is checked',()=>fixture(async f=>{
 await f.ready();const r=await api.reserveWorldSurfaceUpdate(f.root,{requestId:'surface',surfaceId:'private',version:'1.0.0'},f.proof),base={operationId:r.operationId,hostingVersionId:'6',evidence:[{path:f.evidence}]};
 await assert.rejects(api.recordWorldSurfaceResult(f.root,{...base,status:'verified',verificationKind:'surface-acceptance'},f.proof),/deployment plus/);
 await assert.rejects(api.recordWorldSurfaceResult(f.root,{...base,status:'deployed',evidence:[]},f.proof),/evidence required/);
 await api.recordWorldSurfaceResult(f.root,{...base,status:'deployed'},f.proof);let s=(await f.readLedger()).surfaces.private;assert.equal(s.deployedVersion,'1.0.0');assert.equal(s.verifiedVersion,null);
 await assert.rejects(api.recordWorldSurfaceResult(f.root,{...base,status:'verified',hostingVersionId:'7',verificationKind:'surface-acceptance'},f.proof),/receipt changed/);
 await api.recordWorldSurfaceResult(f.root,{...base,status:'verified',verificationKind:'surface-acceptance'},f.proof);s=(await f.readLedger()).surfaces.private;assert.equal(s.verifiedVersion,'1.0.0');assert.equal(s.hostingVersionId,'6');await assert.rejects(api.recordWorldSurfaceResult(f.root,{...base,status:'deployed'},f.proof),/immutable/);
}));
test('tampered recovery files and changed history chain are refused',()=>fixture(async f=>{
 const r=await f.ready();await writeFile(path.join(r.recoveryPath,'web/app.mjs'),'tamper');await assert.rejects(api.reserveWorldSurfaceUpdate(f.root,{requestId:'surface',surfaceId:'private',version:'1.0.0'},f.proof),/snapshot changed/);
 const l=await f.readLedger();l.events[0].type='edited';await writeFile(f.ledgerFile,JSON.stringify(l));await assert.rejects(api.readWorldReleaseReport(f.packet,f.root,f.proof),/history chain changed/);
}));
test('rollback is a concrete diff and retained recovery plan with zero restoration effects',()=>fixture(async f=>{
 const r=await f.ready();await writeFile(path.join(f.artifactRoot,'web/app.mjs'),'current user work');const before=await readFile(f.ledgerFile),plan=await api.worldRollbackPlan(f.root,{version:'1.0.0',targetRoot:f.artifactRoot},f.proof);assert.equal(plan.filesRestored,0);assert.equal(plan.surfacesRestored,0);assert.equal(plan.diff.length,1);assert.equal(plan.recoveryPath,r.recoveryPath);assert.equal(await readFile(path.join(f.artifactRoot,'web/app.mjs'),'utf8'),'current user work');assert.deepEqual(await readFile(f.ledgerFile),before);
}));
test('world title reservation uses exact native identity and supported result/readback without hidden renaming',()=>fixture(async f=>{
 await f.init();const thread={id:f.actors['world-requests'].threadId,kind:'codex',hostId:'local',cwd:f.root,projectId:f.projectId,title:'World Requests'},req={requestId:'title',version:'1.0.0',nativeThread:thread};
 await assert.rejects(api.reserveWorldTitleUpdate(f.root,{...req,nativeThread:{...thread,id:randomUUID()}},f.proof),/supported current/);
 const r=await api.reserveWorldTitleUpdate(f.root,req,f.proof);assert.equal(r.status,'reserved-not-renamed');assert.equal(r.toolRequest.arguments.title,'World 1.0');assert.equal((await api.reserveWorldTitleUpdate(f.root,req,f.proof)).canRename,false);
 const record={operationId:r.operationId,nativeResult:{threadId:thread.id},readback:{...thread,title:'World 1.0'}};
 await assert.rejects(api.recordWorldTitleUpdate(f.root,{...record,readback:{...record.readback,cwd:f.base}},f.proof),/readback required/);const result=await api.recordWorldTitleUpdate(f.root,record,f.proof);assert.equal(result.status,'verified-native-title');assert.deepEqual(await api.recordWorldTitleUpdate(f.root,record,f.proof),result);
}));
test('CLI report binds actual cwd/thread and reads history without modifying it',()=>fixture(async f=>{
 await f.ready();const before=await readFile(f.ledgerFile),script=path.join(source,'scripts/world-release.mjs'),env={...process.env,CODEX_THREAD_ID:f.proof.threadId,CODEX_HOME:f.codexHome};
 const r=spawnSync(process.execPath,[script,'report','--format','markdown'],{cwd:f.root,env,encoding:'utf8'});assert.equal(r.status,0,r.stderr);assert.match(r.stdout,/Fixture world update/);assert.deepEqual(await readFile(f.ledgerFile),before);
 const foreign=spawnSync(process.execPath,[script,'report'],{cwd:f.base,env,encoding:'utf8'});assert.equal(foreign.status,1);assert.match(foreign.stderr,/selected project/);
}));

test('new release versions advance numerically while exact older artifact retries remain valid',()=>fixture(async f=>{
 await f.ready();
 await api.prepareWorldRelease(f.root,{...f.prepareInput,requestId:'one-nine',version:'1.9.0'},f.proof);
 await api.prepareWorldRelease(f.root,{...f.prepareInput,requestId:'one-ten',version:'1.10.0'},f.proof);
 for(const version of ['0.9.0','1.0.1','1.9.9'])await assert.rejects(api.prepareWorldRelease(f.root,{...f.prepareInput,requestId:'lower-'+version,version},f.proof),/advance numerically/);
 assert.equal((await f.prepare()).status,'prepared-not-deployed');
}));
test('an interrupted original profile application reconciles its saved content without another request',()=>fixture(async f=>{
 await f.init();await f.profile();const l=await f.readLedger(),e=l.effects.find(e=>e.kind==='profile-save');e.state='reserved';await writeFile(f.ledgerFile,JSON.stringify(l));
 assert.equal((await f.profile()).revision,1);assert.equal(JSON.parse(await readFile(f.profileFile,'utf8')).revision,1);assert.equal((await f.readLedger()).effects.find(e=>e.kind==='profile-save').state,'saved');
}));
test('unknown original snapshot reconciles retained immutable files without recopying changed source',()=>fixture(async f=>{
 const r=await f.ready(),l=await f.readLedger(),e=l.effects.find(e=>e.kind==='artifact-snapshot');e.state='unknown';await writeFile(f.ledgerFile,JSON.stringify(l));await writeFile(path.join(f.artifactRoot,'web/app.mjs'),'later user change');
 const restored=await api.reconcileWorldSnapshot(f.root,e.id,f.proof);assert.equal(restored.artifactSha256,r.artifactSha256);assert.equal((await f.readLedger()).releases.length,1);assert.equal(await readFile(path.join(f.artifactRoot,'web/app.mjs'),'utf8'),'later user change');
}));

test('older surface acceptance and profile retargeting cannot overwrite a newer selected destination',()=>fixture(async f=>{
 await f.ready();const first=await api.reserveWorldSurfaceUpdate(f.root,{requestId:'first',surfaceId:'private',version:'1.0.0'},f.proof);
 await api.recordWorldSurfaceResult(f.root,{operationId:first.operationId,status:'deployed',hostingVersionId:'6',evidence:[{path:f.evidence}]},f.proof);
 await api.prepareWorldRelease(f.root,{...f.prepareInput,requestId:'next',version:'1.1.0'},f.proof);await api.reserveWorldSurfaceUpdate(f.root,{requestId:'second',surfaceId:'private',version:'1.1.0'},f.proof);
 await assert.rejects(api.recordWorldSurfaceResult(f.root,{operationId:first.operationId,status:'verified',hostingVersionId:'6',evidence:[{path:f.evidence}],verificationKind:'surface-acceptance'},f.proof),/superseded/);
 const surfaces=f.profileInput.surfaces.map(s=>s.id==='private'?{...s,url:'https://other.example.test/'}:s);await assert.rejects(api.saveWorldProfile(f.root,{...f.profileInput,requestId:'retarget',expectedRevision:1,surfaces},f.proof),/cannot be retargeted/);const row=(await f.readLedger()).surfaces.private;assert.equal(row.requestedVersion,'1.1.0');assert.equal(row.state,'pending');
}));

test('world artifacts retain named sprite metadata and font license without admitting private files',()=>fixture(async f=>{
 await f.init();await f.profile();
 const assetRoot='web/agent-outpost/assets/artifact-fixture';
 const companions=[
  [assetRoot+'/sprites.json','{"schemaVersion":1,"sprites":[]}\n'],
  [assetRoot+'/art-provenance.json','{"schemaVersion":1,"provenance":"Neutral fixture art"}\n'],
  [assetRoot+'/room-names.LICENSE.txt','Neutral fixture font legal notice.\n']
 ];
 await mkdir(path.join(f.artifactRoot,assetRoot),{recursive:true});
 for(const [relative,contents]of companions)await writeFile(path.join(f.artifactRoot,relative),contents);
 const request={...f.prepareInput,requestId:'named-artifact-companions',files:[...f.prepareInput.files,...companions.map(([relative])=>relative)]};
 const result=await api.prepareWorldRelease(f.root,request,f.proof);
 assert.equal(result.status,'prepared-not-deployed');
 const manifest=JSON.parse(await readFile(path.join(result.recoveryPath,'manifest.json'),'utf8'));
 assert.equal(manifest.files.length,4);
 assert.equal(sha(JSON.stringify(manifest)),result.artifactSha256);
 for(const [relative,contents]of companions){
  assert.equal(manifest.files.find(row=>row.path===relative).sha256,sha(contents));
  assert.equal(await readFile(path.join(result.recoveryPath,relative),'utf8'),contents);
 }
 const ledgerBefore=await readFile(f.ledgerFile);
 for(const denied of ['web/private-notes.txt','web/preferences.json','web/runtime/sprites.json']){
  await assert.rejects(api.prepareWorldRelease(f.root,{...request,requestId:'deny-'+path.basename(denied),files:[...request.files,denied]},f.proof),/Only selected immutable world\/design assets/);
  assert.deepEqual(await readFile(f.ledgerFile),ledgerBefore);
 }
}));


async function mappedFixture(f){
 const executionCwd=path.join(f.root,'.git');await mkdir(executionCwd);const nativeProjectId=randomUUID(),provider=path.join(f.base,'context.mjs'),config=path.join(f.root,'.alife-worlds/world-release/context-provider.json');
 const members=f.bindings.agents.map(a=>({schemaVersion:1,canonicalRoot:f.root,logicalProjectId:f.projectId,nativeProjectId,roleId:a.id,threadId:a.threadId,sessionPath:a.sessionPath,executionCwd,home:path.join(f.root,a.home),lifecycle:'active'}));
 for(const m of members)await writeFile(m.sessionPath,JSON.stringify({type:'session_meta',payload:{id:m.threadId,cwd:f.root}})+'\n'+JSON.stringify({type:'event_msg',payload:{type:'thread_settings_applied',thread_settings:{cwd:executionCwd}}})+'\n');
 const saveProvider=async rows=>{await writeFile(provider,'const members='+JSON.stringify(rows)+';export async function resolveWorldReleaseActor({threadId}){return members.find(m=>m.threadId===threadId);};');await writeFile(config,JSON.stringify({schemaVersion:1,kind:'authorized-world-release-context-provider',projectRoot:f.root,provider:{path:provider,sha256:sha(await readFile(provider))}}));};await saveProvider(members);
 const run=(command='report',input=null,extra={})=>spawnSync(process.execPath,[path.join(source,'scripts/world-release.mjs'),command,'--project-root',f.root],{cwd:executionCwd,env:{...process.env,CODEX_THREAD_ID:f.proof.threadId,CODEX_HOME:f.codexHome,...extra},input:input===null?undefined:JSON.stringify(input),encoding:'utf8',windowsHide:true});return{executionCwd,nativeProjectId,members,provider,config,saveProvider,run};
}
test('mapped release context requires explicit pinned authority and preserves logical/native project separation',()=>fixture(async f=>{
 await f.init();const m=await mappedFixture(f),before=await readFile(f.actors.director.sessionPath);const report=m.run();assert.equal(report.status,0,report.stderr);assert.equal(JSON.parse(report.stdout).projectId,f.projectId);assert.notEqual(m.nativeProjectId,f.projectId);
 const target=f.actors['world-requests'],r=m.run('reserve-title',{requestId:'mapped-title',version:'1.0.0',nativeThread:{id:target.threadId,kind:'codex',hostId:'local',cwd:m.executionCwd,projectId:m.nativeProjectId,title:'Old title'}});assert.equal(r.status,0,r.stderr);assert.equal(JSON.parse(r.stdout).status,'reserved-not-renamed');assert.deepEqual(await readFile(f.actors.director.sessionPath),before);
}));
test('mapped release context rejects wrong actor, cwd, provider bytes, archived membership and logical namespace as native title evidence',()=>fixture(async f=>{
 await f.init();const m=await mappedFixture(f),before=await readFile(f.ledgerFile);let r=m.run('report',null,{CODEX_THREAD_ID:randomUUID()});assert.notEqual(r.status,0);r=spawnSync(process.execPath,[path.join(source,'scripts/world-release.mjs'),'report','--project-root',f.root],{cwd:f.root,env:{...process.env,CODEX_THREAD_ID:f.proof.threadId},encoding:'utf8',windowsHide:true});assert.notEqual(r.status,0);
 const t=f.actors['world-requests'];r=m.run('reserve-title',{requestId:'bad-native-project',version:'1.0.0',nativeThread:{id:t.threadId,kind:'codex',hostId:'local',cwd:m.executionCwd,projectId:f.projectId,title:'Old'}});assert.notEqual(r.status,0);assert.match(r.stderr,/native metadata/);
 await writeFile(m.provider,'// changed\n'+await readFile(m.provider,'utf8'));r=m.run();assert.notEqual(r.status,0);assert.match(r.stderr,/provider changed/);await m.saveProvider(m.members.map(x=>x.threadId===f.proof.threadId?{...x,lifecycle:'archived'}:x));r=m.run();assert.notEqual(r.status,0);assert.match(r.stderr,/Active exact mapped actor/);assert.deepEqual(await readFile(f.ledgerFile),before);
}));
test('mapped session context remains exact and default projects do not accept moved native cwd',()=>fixture(async f=>{
 await f.init();const m=await mappedFixture(f);await rm(m.config);let r=m.run();assert.notEqual(r.status,0);assert.match(r.stderr,/moved to another project/);await m.saveProvider(m.members);await writeFile(f.proof.sessionPath,JSON.stringify({type:'session_meta',payload:{id:f.proof.threadId,cwd:f.root}})+'\n'+JSON.stringify({type:'turn_context',payload:{cwd:path.join(f.base,'foreign')}})+'\n');r=m.run();assert.notEqual(r.status,0);assert.match(r.stderr,/moved to another project/);
}));
