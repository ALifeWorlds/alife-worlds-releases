import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {hostedOwnerContext,createHostedOwnerWorld,HOSTED_OWNER_PREVIEW_LIMIT} from '../web/owner-hosted-world.mjs';
const context=()=>({schemaVersion:1,access:'owner-private',worldId:'world-hosted-fixture',ownerOrigin:'https://owner.test',worldVersion:'1.0.1',renderer:{schemaVersion:1,bundleId:'qualified-renderer',worldVersion:'1.3.3',artifactSha256:'a'.repeat(64)}});
function harness({ctx=context(),fetcher}={}){
 const calls={mounts:[],versions:[],renders:[],resolved:[],order:[],unavailable:0,disposed:0,destroyed:0,visible:[]},listeners=new Map(),timers=new Map();let timerId=0,cached=null,accept=true;
 const nodes=new Map([['owner-hosted-world',{dataset:{}}],['world-anchor',{}],['world-profile-status',{hidden:false,textContent:''}]]),documentRef={hidden:false,getElementById:id=>nodes.get(id),addEventListener:(k,v)=>listeners.set('document:'+k,v),removeEventListener:k=>listeners.delete('document:'+k)};
 const windowRef={location:{origin:'https://owner.test',pathname:'/operator',search:'?embed=1&project=world-hosted-fixture&hostOrigin=https%3A%2F%2Fowner.test',hash:''},parent:{location:{origin:'https://owner.test'}},setTimeout(fn,delay){const id=++timerId;timers.set(id,{fn,delay});return id;},clearTimeout:id=>timers.delete(id),addEventListener:(k,v)=>listeners.set(k,v),removeEventListener:k=>listeners.delete(k)};
 const input={model:{marker:'actual-joined-model'},feed:{observedUtc:'2026-11-09T12:00:00.000Z',error:null},snapshot:{summary:{current:{percent:40,tasks:5,accepted:2},epic:{percent:25,tasks:4,accepted:1}}}};
 const farm={host:{},setAudioPreferenceKey(){},setWorldVersion:v=>calls.versions.push(v),setWorldVisible:v=>calls.visible.push(v),render:(...args)=>{calls.order.push('render');calls.renders.push(args);},destroy:()=>calls.destroyed++},viewport={resolve:async preview=>{calls.resolved.push(preview);calls.order.push('resolve');return input;},rendered:value=>{calls.order.push('rendered');assert.equal(value,input);if(accept)cached=input;return accept;},cachedInput:()=>cached,unavailable:()=>calls.unavailable++,dispose:()=>calls.disposed++};
 const renderer={mount:(anchor,options)=>{assert.equal(anchor,nodes.get('world-anchor'));calls.mounts.push(options);return farm;}},preview={schemaVersion:3,kind:'owner-world-preview',worldId:ctx.worldId};
 const api=createHostedOwnerWorld({context:ctx,windowRef,documentRef,renderer,viewportFactory:()=>viewport,fetcher:fetcher??(async(url,options)=>{calls.request={url,options};return Response.json(preview);}),autoStart:false});
 return {api,calls,nodes,documentRef,windowRef,input,preview,timers,listeners,setAccept:v=>{accept=v;}};
}

test('hosted private frame requires exact same-origin parent, selected world and closed embed query before mounting',()=>{
 const h=harness(),ctx=context();assert.equal(hostedOwnerContext(ctx,{windowRef:h.windowRef}),ctx);
 for(const change of [w=>w.location.pathname='/',w=>w.location.search+='&project=world-hosted-fixture',w=>w.location.search+='&extra=1',w=>w.location.search=w.location.search.replace('world-hosted-fixture','world-foreign'),w=>w.parent.location.origin='https://foreign.test',w=>w.parent=w]){const w={...h.windowRef,location:{...h.windowRef.location},parent:{location:{origin:'https://owner.test'}}};change(w);assert.equal(hostedOwnerContext(ctx,{windowRef:w}),null);}
 assert.equal(hostedOwnerContext({...ctx,access:'local-owner'},{windowRef:h.windowRef}),null);assert.equal(hostedOwnerContext({...ctx,renderer:undefined},{windowRef:h.windowRef}),null);assert.equal(hostedOwnerContext({...ctx,worldVersion:'planned'},{windowRef:h.windowRef}),null);h.api.dispose();
});

test('hosted frame renders only joined v3 data, forwards canonical summaries and acknowledges after actual render',async()=>{
 const h=harness();await h.api.refresh();assert.deepEqual(h.calls.order,['resolve','render','rendered']);assert.equal(h.calls.mounts[0].presentationMode,'view');assert.equal(h.calls.mounts[0].cosmeticOnly,true);assert.equal(h.calls.mounts[0].farmCommandHost,undefined);assert.equal(h.calls.mounts[0].productPrivacyHost,undefined);assert.equal(h.calls.mounts[0].defaultWorld,true);assert.deepEqual(h.calls.versions,['1.0.1']);assert.equal(h.calls.renders[0][0],h.input.model);assert.equal(h.calls.renders[0][1],h.input.feed);assert.equal(h.calls.renders[0][2].sprint,h.input.snapshot.summary.current);assert.equal(h.calls.renders[0][2].epic,h.input.snapshot.summary.epic);assert.equal(h.nodes.get('owner-hosted-world').dataset.sourceState,'ready');assert.equal(h.calls.request.url,'https://owner.test/api/owner-world-preview?project=world-hosted-fixture');assert.equal(h.calls.request.options.redirect,'error');assert.equal(h.calls.request.options.credentials,'same-origin');assert.equal(h.calls.request.options.method,'GET');assert.equal([...h.timers.values()].filter(t=>t.delay===5000).length,1);h.api.dispose();
});

test('missing qualified art and selected world version never borrow a renderer compatibility version',()=>{
 const h=harness({ctx:{...context(),worldVersion:null,renderer:null}});assert.equal(h.calls.mounts[0].defaultWorld,false);assert.deepEqual(h.calls.versions,[null]);h.api.dispose();
});

test('failed render acknowledgment and unavailable reads retain input with its original time and stop ready claims',async()=>{
 let good=true;const h=harness({fetcher:async()=>good?Response.json({schemaVersion:3,kind:'owner-world-preview',worldId:'world-hosted-fixture'}):new Response(null,{status:503})});await h.api.refresh();good=false;await h.api.refresh();assert.equal(h.nodes.get('owner-hosted-world').dataset.sourceState,'unavailable');assert.equal(h.calls.renders.at(-1)[1].observedUtc,h.input.feed.observedUtc);assert.equal(h.calls.renders.at(-1)[1].error,'Owner world updates unavailable');good=true;h.setAccept(false);await h.api.refresh();assert.equal(h.nodes.get('owner-hosted-world').dataset.sourceState,'unavailable');assert(h.calls.unavailable>=2);h.api.dispose();
});

test('owner access loss or a foreign identity destroys a previously rendered private scene without replaying it',async()=>{
 for(const failure of [new Response(null,{status:401}),new Response(null,{status:403}),Response.json({schemaVersion:3,kind:'owner-world-preview',worldId:'world-foreign'})]){
  let first=true;const h=harness({fetcher:async()=>first?Response.json({schemaVersion:3,kind:'owner-world-preview',worldId:'world-hosted-fixture'}):failure});await h.api.refresh();first=false;const renders=h.calls.renders.length;await h.api.refresh();assert.equal(h.calls.destroyed,1);assert.equal(h.calls.disposed,1);assert.equal(h.calls.renders.length,renders);assert.equal(h.timers.size,0);h.api.unavailable();await h.api.refresh();assert.equal(h.calls.renders.length,renders);
 }
});

test('queued receipts, foreign/legacy inputs and oversized responses cannot enter the viewport join',async()=>{
 for(const body of [{ok:true,applied:true,worldId:'world-hosted-fixture'},{schemaVersion:1,kind:'owner-world-preview',worldId:'world-hosted-fixture'},{schemaVersion:3,kind:'owner-world-preview',worldId:'world-foreign'}]){const h=harness({fetcher:async()=>Response.json(body)});await h.api.refresh();assert.equal(h.calls.resolved.length,0);assert.equal(h.nodes.get('owner-hosted-world').dataset.sourceState,'unavailable');h.api.dispose();}
 const h=harness({fetcher:async()=>new Response('x',{headers:{'Content-Type':'application/json','Content-Length':String(HOSTED_OWNER_PREVIEW_LIMIT+1)}})});await h.api.refresh();assert.equal(h.calls.resolved.length,0);h.api.dispose();
});

test('one bounded reader aborts at8seconds, on hide and pagehide without a second poller or late render',async()=>{
 let signal;const h=harness({fetcher:async(url,options)=>{signal=options.signal;return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Error('Aborted')),{once:true}));}}),pending=h.api.refresh();await h.api.refresh();assert.equal(h.calls.resolved.length,0);const deadline=[...h.timers.values()].find(t=>t.delay===8000);assert(deadline);deadline.fn();await pending;assert.equal(signal.aborted,true);assert.equal(h.calls.renders.length,0);
 h.documentRef.hidden=true;h.listeners.get('document:visibilitychange')();assert.equal([...h.timers.values()].filter(t=>t.delay===5000).length,0);assert.equal(h.calls.visible.at(-1),false);h.listeners.get('pagehide')();assert.equal(h.calls.disposed,1);assert.equal(h.calls.destroyed,1);assert.equal(h.listeners.size,0);await h.api.refresh();assert.equal(h.calls.resolved.length,0);
});

test('portable frame template contains only canonical resource paths and a non-executable escaped context slot',async()=>{
 const html=await readFile(new URL('../web/owner-site/world-frame.html',import.meta.url),'utf8');for(const path of ['/agent-outpost/agent-outpost.css','/owner-world-viewport.css','/owner-hosted-world.mjs'])assert(html.includes(path));assert(html.includes('data-owner-context="__OWNER_HOSTED_CONTEXT__"'));assert(!html.includes('http'));assert(!html.includes('OWNER_SITE_CONTEXT='));
});
