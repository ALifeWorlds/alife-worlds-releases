import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,copyFile,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {collectPackageInputs} from '../lib/plugin-version.mjs';
import {checkAttribution} from '../lib/attribution-check.mjs';
const source=fileURLToPath(new URL('../',import.meta.url)),scratch=path.join(source,'runtime/test-fixtures');
async function fixture(fn){await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'attribution-'));try{for(const file of await collectPackageInputs(source)){const to=path.join(root,file);await mkdir(path.dirname(to),{recursive:true});await copyFile(path.join(source,file),to);}await fn(root);}finally{assert.ok(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));await rm(root,{recursive:true,force:true});}}
const read=(root,file)=>readFile(path.join(root,file),'utf8');
test('existing notices, contributor links and governance documents ship in the public packet',async()=>{const report=await checkAttribution(source);assert.equal(report.status,'PASS');assert.equal(report.legalOwnershipVerified,false);const files=await collectPackageInputs(source);for(const name of ['CONTRIBUTING.md','CONTRIBUTORS.md','GOVERNANCE.md','BRANDING.md','THIRD_PARTY_NOTICES.md'])assert.ok(files.includes(name));});
test('MIT, font and JSON attribution whitespace is harmless while deleting original notices fails',()=>fixture(async root=>{
 const license=await read(root,'LICENSE');await writeFile(path.join(root,'LICENSE'),license.replace(/\r?\n/g,'\r\n\r\n'));
 const audio=JSON.parse(await read(root,'web/assets/audio/LICENSES.json'));await writeFile(path.join(root,'web/assets/audio/LICENSES.json'),JSON.stringify(audio));assert.equal((await checkAttribution(root)).status,'PASS');
 await writeFile(path.join(root,'LICENSE'),license.replace('Copyright (c) 2026 Ant Farm package contributors','Copyright (c) 2026 Someone Else'));assert.equal((await checkAttribution(root)).status,'FAIL');
 await writeFile(path.join(root,'LICENSE'),license);const font='web/agent-outpost/assets/midnight-colony-reference-20261107/room-names-regular.LICENSE.txt';await writeFile(path.join(root,font),'License omitted');assert.ok((await checkAttribution(root)).errors.some(e=>e.file===font));
}));
test('new third-party terms, dependencies and unclear copyright claims require review without denying legitimate submissions',()=>fixture(async root=>{
 await mkdir(path.join(root,'lib/new-component'));await writeFile(path.join(root,'lib/new-component/LICENSE'),'Copyright (c) 2026 New Contributor\nSPDX-License-Identifier: Apache-2.0\n');const p=JSON.parse(await read(root,'package.json'));p.dependencies={'new-component':'1.0.0'};await writeFile(path.join(root,'package.json'),JSON.stringify(p));
 const audio=JSON.parse(await read(root,'web/assets/audio/LICENSES.json'));audio.assets.push({file:'new-sound.mp3',author:'A contributor',license:'Review required'});await writeFile(path.join(root,'web/assets/audio/LICENSES.json'),JSON.stringify(audio));
 const result=await checkAttribution(root);assert.equal(result.status,'PASS');for(const code of ['NEW_LICENSE_OR_NOTICE_FILE','NEW_OR_UNCLEAR_COPYRIGHT_OR_SPDX_NOTICE','NEW_OR_CHANGED_DEPENDENCY_LICENSE_REVIEW','NEW_THIRD_PARTY_ATTRIBUTION_RECORD'])assert.ok(result.reviewItems.some(e=>e.code===code));
}));
test('changing existing asset authors and removing contributor-document access are detected',()=>fixture(async root=>{
 const audio=JSON.parse(await read(root,'web/assets/audio/LICENSES.json'));audio.assets[0].author='Unverified replacement';await writeFile(path.join(root,'web/assets/audio/LICENSES.json'),JSON.stringify(audio));await writeFile(path.join(root,'README.md'),(await read(root,'README.md')).replace('](CONTRIBUTORS.md)','](missing.md)'));const result=await checkAttribution(root);assert.ok(result.errors.some(e=>e.code==='EXISTING_ATTRIBUTION_CHANGED'));assert.ok(result.errors.some(e=>e.code==='GOVERNANCE_DOCUMENT_NOT_ACCESSIBLE'));
}));
test('an exact Git base flags removed notice claims without treating Git as copyright proof',()=>fixture(async root=>{
 const git=args=>execFileSync('git',args,{cwd:root,encoding:'utf8',stdio:['ignore','pipe','pipe']});git(['init','-q']);git(['config','user.name','Fixture contributor']);git(['config','user.email','fixture@example.invalid']);await writeFile(path.join(root,'lib/fixture-notice.js'),'// Copyright (c) 2025 Fixture contributor\n');git(['add','LICENSE','lib/fixture-notice.js']);git(['commit','-qm','Fixture attribution baseline']);const base=git(['rev-parse','HEAD']).trim();await writeFile(path.join(root,'lib/fixture-notice.js'),'// Implementation preserved; notice removed\n');const result=await checkAttribution(root,{baseRef:base});assert.ok(result.reviewItems.some(e=>e.code==='BASE_NOTICE_REMOVAL_REQUIRES_HUMAN_REVIEW'));assert.equal(result.legalOwnershipVerified,false);
}));
