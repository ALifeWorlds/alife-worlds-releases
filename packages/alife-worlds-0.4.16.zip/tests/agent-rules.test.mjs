import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {emptyCatalog,readRuleCatalogs} from '../lib/rules.mjs';
import {readAgentRuleCatalogs,saveScopedRuleChange,getAgentRuleContract,checkAllRuleDocuments,generateAllRuleDocuments,generatedAgentRuleFiles} from '../lib/agent-rules.mjs';
const scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));
const shared=await readFile(new URL('../roles/SHARED.md',import.meta.url),'utf8');
async function fixture(fn){
 await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'agent-rules-test-'));
 try{
  for(const dir of ['rules','data','roles'])await mkdir(path.join(root,dir));
  await writeFile(path.join(root,'data','roles.json'),JSON.stringify([{id:'director',title:'Director'},{id:'worker1',title:'Worker One'}]));
  await writeFile(path.join(root,'roles','SHARED.md'),shared);
  await writeFile(path.join(root,'roles','director.md'),'# Director\nOwn priorities and independent acceptance.\n');
  await writeFile(path.join(root,'roles','worker1.md'),'# Worker One\nImplement assigned work and retain custody.\n');
  for(const scope of ['plugin','world'])await writeFile(path.join(root,'rules',scope+'.json'),JSON.stringify(emptyCatalog(scope)));
  await fn(root);
 }finally{assert.ok(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));await rm(root,{recursive:true,force:true});}
}
const change=(scope='agent',extra={})=>({command:scope==='agent'?'/rule keep a clear decision log':'/universal preserve the request source',requestId:'one',expectedRevision:0,groupId:'communication',groupTitle:'Communication',properties:[{id:'clarity',title:'Clarity',text:'Keep a clear decision log.'}],...extra});
test('per-agent change affects the verified invoking role only',()=>fixture(async root=>{
 await saveScopedRuleChange(root,change(),{agentRoleId:'director'});
 const c=await readAgentRuleCatalogs(root);assert.equal(c.agents.director.revision,1);assert.equal(c.agents.worker1,undefined);assert.equal(c.universal.revision,0);
 const director=await getAgentRuleContract(root,'director'),worker=await getAgentRuleContract(root,'worker1');
 assert.ok(director.text.includes('Keep a clear decision log.'));assert.ok(!worker.text.includes('Keep a clear decision log.'));
 await checkAllRuleDocuments(root);
}));
test('missing, unknown, traversal and cross-role contexts fail before changing a registry',()=>fixture(async root=>{
 for(const context of [{},{agentRoleId:'unknown'},{agentRoleId:'../director'}])await assert.rejects(saveScopedRuleChange(root,change(),context),/role|Verify/);
 await assert.rejects(saveScopedRuleChange(root,change('agent',{agentRoleId:'worker1'}),{agentRoleId:'director'}),/invoking role/);
 assert.deepEqual((await readAgentRuleCatalogs(root)).agents,{});
}));
test('universal additions reach every creation contract with complete retirement/settings baseline',()=>fixture(async root=>{
 await saveScopedRuleChange(root,change('universal',{properties:[{id:'source',title:'Source',text:'Retain the exact authorized request source.'}]}));
 for(const id of ['director','worker1']){
  const c=await getAgentRuleContract(root,id);assert.ok(c.text.includes('Retain the exact authorized request source.'));
  assert.ok(c.text.includes('When retirement is authorized'));assert.ok(c.text.includes('ONE sequential successor'));
  assert.ok(c.text.includes('Preserve the human-selected model'));assert.ok(c.text.includes('onboarding.support-owned-creation'));
  assert.equal(c.shared,shared);
 }
 const docs=await generatedAgentRuleFiles(root);assert.ok(docs['docs/AGENT_RULES.md'].includes('Director (director)'));assert.ok(docs['docs/AGENT_RULES.md'].includes('Worker One (worker1)'));
}));
test('an agent cannot duplicate or replace an active universal property',()=>fixture(async root=>{
 await saveScopedRuleChange(root,change('universal'));
 await assert.rejects(saveScopedRuleChange(root,change(),{agentRoleId:'director'}),/universal/);
 await assert.rejects(saveScopedRuleChange(root,change('agent',{groupId:'other',properties:[{id:'same',title:'Same',text:'Keep a clear decision log.'}]}),{agentRoleId:'director'}),/universal/);
 assert.deepEqual((await readAgentRuleCatalogs(root)).agents,{});
}));
test('universal collisions with existing role additions fail without overwriting either scope',()=>fixture(async root=>{
 await saveScopedRuleChange(root,change(),{agentRoleId:'director'});
 await assert.rejects(saveScopedRuleChange(root,change('universal')),/universal/);
 const c=await readAgentRuleCatalogs(root);assert.equal(c.universal.revision,0);assert.equal(c.agents.director.revision,1);
}));
test('role retries are idempotent and revisions stay independent across roles',()=>fixture(async root=>{
 const request=change();await saveScopedRuleChange(root,request,{agentRoleId:'director'});await saveScopedRuleChange(root,request,{agentRoleId:'director'});
 await saveScopedRuleChange(root,change(),{agentRoleId:'worker1'});
 let c=await readAgentRuleCatalogs(root);assert.equal(c.agents.director.revision,1);assert.equal(c.agents.worker1.revision,1);
 await assert.rejects(saveScopedRuleChange(root,change('agent',{requestId:'two'}),{agentRoleId:'director'}),/revision/);
 await assert.rejects(saveScopedRuleChange(root,change('agent',{properties:[{id:'clarity',title:'Clarity',text:'Different intent.'}]}),{agentRoleId:'director'}),/reused/);
}));
test('the shared authoring lock permits one winner for concurrent scopes',()=>fixture(async root=>{
 const results=await Promise.allSettled([saveScopedRuleChange(root,change(),{agentRoleId:'director'}),saveScopedRuleChange(root,change('universal',{groupId:'safety',properties:[{id:'source',title:'Source',text:'Retain request provenance.'}]}))]);
 assert.equal(results.filter(r=>r.status==='fulfilled').length,1);await checkAllRuleDocuments(root);
}));
test('private agent/universal values are refused and manual generated-doc drift is caught',()=>fixture(async root=>{
 for(const scope of ['agent','universal'])await assert.rejects(saveScopedRuleChange(root,change(scope,{properties:[{id:'secret',title:'Secret',text:'C:/Users/private/session'}]}),{agentRoleId:'director'}),/private/);
 await generateAllRuleDocuments(root);await writeFile(path.join(root,'docs','AGENT_RULES.md'),'stale');
 await assert.rejects(checkAllRuleDocuments(root),/out of date/);await generateAllRuleDocuments(root);await checkAllRuleDocuments(root);
}));

test('the actual source creation bundle includes contextual creation authority and the full retirement policy',async()=>{
 const root=fileURLToPath(new URL('../',import.meta.url)),bundle=await getAgentRuleContract(root,'director');
 assert.ok(bundle.text.includes('one-time first Agent Support bootstrap'));
 assert.ok(bundle.text.includes('Thereafter Agent Support alone creates authorized missing World Requests'));
 assert.ok(!bundle.text.includes('A missing Support is an explicit dependency, not permission for another role to create agents.'));
 assert.ok(bundle.text.includes('ONE sequential successor'));
 assert.ok(bundle.text.includes('human-approved model/settings'));
 assert.ok(bundle.text.includes('approved core creation baseline'));
 assert.ok(!bundle.text.includes('Otherwise omit model and thinking'));
 assert.ok(!bundle.text.includes('Missing settings approval is a human dependency'));
 assert.ok(bundle.text.includes('No agent or native identity')===false||bundle.text.includes('custody'));
});

test('rereading a stale bootstrap edit preserves an independently saved launcher property',()=>fixture(async root=>{
 const launcher={command:'/plugin require the selected launcher',requestId:'launcher',expectedRevision:0,groupId:'launcher',groupTitle:'Launcher',properties:[{id:'open-worlds',title:'Open worlds',text:'Use the human-selected launcher wording.'}]};
 const bootstrap={command:'/plugin record selected bootstrap gates',requestId:'bootstrap',expectedRevision:0,groupId:'bootstrap',groupTitle:'Bootstrap',properties:[{id:'readiness',title:'Readiness',text:'Require real bindings and receipts.'}]};
 await saveScopedRuleChange(root,launcher);
 await assert.rejects(saveScopedRuleChange(root,bootstrap),/revision changed/);
 const before=await readRuleCatalogs(root,{allowMissing:false});
 await saveScopedRuleChange(root,{...bootstrap,expectedRevision:before.plugin.revision});
 const after=await readRuleCatalogs(root,{allowMissing:false});
 assert.deepEqual(after.plugin.groups.find(g=>g.id==='launcher'),before.plugin.groups.find(g=>g.id==='launcher'));
 assert.ok(after.plugin.groups.find(g=>g.id==='bootstrap'));
 await checkAllRuleDocuments(root);
}));
