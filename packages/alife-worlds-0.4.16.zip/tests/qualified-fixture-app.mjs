// Test-only qualified package fixture; production source remains fail-closed until sealed.
import assert from 'node:assert/strict';
import {mkdir,copyFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {collectPackageInputs,packageFingerprint,sealVersion,checkPluginVersion} from '../lib/plugin-version.mjs';
import {publicWorldId} from '../lib/public-world.mjs';
const sourceRoot=fileURLToPath(new URL('../',import.meta.url));
export async function createQualifiedFixtureApp(directory,{projectId}={}){
 const packet=path.join(directory,'packet');
 for(const relative of await collectPackageInputs(sourceRoot)){const target=path.join(packet,relative);await mkdir(path.dirname(target),{recursive:true});await copyFile(path.join(sourceRoot,relative),target);}
 const fingerprint=await packageFingerprint(packet,await collectPackageInputs(packet));
 assert.equal((await sealVersion(packet,fingerprint)).releaseState,'released');
 await writeFile(path.join(packet,'data/agent-bindings.json'),JSON.stringify({schemaVersion:1,projectId:projectId??publicWorldId(packet),projectRoot:packet,agents:[]}));
 assert.equal((await checkPluginVersion(packet)).releaseState,'released');
 return (await import(pathToFileURL(path.join(packet,'server.mjs')).href)).createApp;
}
