import test from 'node:test';
import assert from 'node:assert/strict';
import {createOwnerAgentSettings,OWNER_AGENT_SETTINGS_LIMIT} from '../web/owner-agent-settings.mjs';
import {createSiteAgentMetadataContract} from '../lib/site-agent-metadata.mjs';
import '../web/agent-outpost/agent-outpost.js';
const roles=[{id:'helper',title:'Helper',role:'worker'}],worldId='world-settings-fixture';
class Node{
 constructor(tag,doc){this.tagName=tag;this.ownerDocument=doc;this.dataset={};this.attributes={};this.children=[];this.listeners=new Map();this._text='';}
 set textContent(v){this._text=String(v);this.children=[];}get textContent(){return this._text+this.children.map(n=>n.textContent).join('');}
 append(...nodes){for(const node of nodes){if(node.tagName==='#fragment')this.append(...node.children);else this.children.push(node);}}replaceChildren(...nodes){this._text='';this.children=[];this.append(...nodes);}
 setAttribute(k,v){this.attributes[k]=String(v);}addEventListener(k,v){this.listeners.set(k,v);}removeEventListener(k){this.listeners.delete(k);}querySelectorAll(){return descendants(this).filter(n=>n.tagName==='details'&&n.dataset.agentAlias);}
}
const descendants=root=>root.children.flatMap(n=>[n,...descendants(n)]);
function harness(){
 const at=Date.now(),iso=delta=>new Date(at+delta).toISOString(),name='<b>Real helper</b>',metadata={schemaVersion:2,kind:'owner-agent-metadata',worldId,observedUtc:iso(0),revision:3,contentHash:'a'.repeat(64),agents:[{id:'role-helper',role:'helper',name,connected:true,onboarded:true,selection:{model:'future-family-7',source:'native-index-selection',observedUtc:iso(-1000),state:'current'},applied:{model:'gpt-6.1-sol',source:'turn_context',observedUtc:iso(-2000),state:'current',reasoning:'xhigh',speed:'default',reasoningObservedUtc:iso(-2000),speedObservedUtc:iso(-2000)},activity:{state:'idle',observedUtc:iso(-2000),terminal:true,needsHumanInput:false}}]},contract=createSiteAgentMetadataContract({worldId,roles}),response=contract.response(metadata,iso(0),at);
 const doc={hidden:false,listeners:new Map(),createElement:tag=>new Node(tag,doc),createDocumentFragment:()=>new Node('#fragment',doc),addEventListener(k,v){this.listeners.set(k,v);},removeEventListener(k){this.listeners.delete(k);}},container=new Node('div',doc),root=new Node('main',doc);root.dataset={workspaceAudience:'owner',operatorMode:'public'};root.querySelector=()=>container;
 let mutation,reads=0,reply=response;const events=new Map(),win={location:{href:'https://owner.test/',origin:'https://owner.test'},setTimeout,clearTimeout,addEventListener:(k,v)=>events.set(k,v),removeEventListener:k=>events.delete(k),MutationObserver:class{constructor(fn){mutation=fn;}observe(){}disconnect(){}}},api=createOwnerAgentSettings({root,worldId,roles,documentRef:doc,windowRef:win,now:()=>at,fetcher:async(url,options)=>{reads++;assert.equal(url,'https://owner.test/api/agent-metadata?project='+worldId);assert.equal(options.credentials,'same-origin');assert.equal(options.redirect,'error');return reply instanceof Response?reply:Response.json(reply);}}),workspace={available:true,current:true,worldId,observedUtc:metadata.observedUtc,agents:[{alias:'role-helper',name}]};
 return{api,container,root,doc,win,events,metadata,response,contract,workspace,at,iso,mutate:()=>mutation(),reads:()=>reads,setReply:value=>{reply=value;}};
}
function fields(container){const list=descendants(container).find(n=>n.tagName==='dl'),result={};for(let i=0;i<list.children.length;i+=2)result[list.children[i].textContent]=list.children[i+1].textContent;return result;}

test('owner settings show literal selected/applied IDs separately, exact provenance/clocks and neutral unknown-family art',()=>{
 const h=harness();h.api.observeWorkspace(h.workspace);assert.equal(h.reads(),0);assert.equal(h.api.update(h.response),true);const f=fields(h.container);assert.equal(f['Selected model'],'future-family-7');assert.equal(f['Last applied model'],'gpt-6.1-sol');assert.equal(f['Selection source'],'native-index-selection');assert.equal(f['Applied model source'],'turn_context');assert.equal(f['Selection observed UTC'],h.metadata.agents[0].selection.observedUtc);assert.equal(f['Applied reasoning'],'xhigh');assert.equal(f['Applied speed'],'Standard (default)');assert.equal(f['Speed evidence'],'Current');assert.equal(globalThis.AgentOutpost.modelStyle(f['Selected model']).color,'#7c8088');const title=descendants(h.container).find(n=>n.tagName==='strong');assert.equal(title.textContent,'<b>Real helper</b>');assert.equal(title.children.length,0);h.api.dispose();
});

test('stale overall records never promote field Current and missing/old speed never invents current Standard',()=>{
 const h=harness();h.api.observeWorkspace(h.workspace);const stale=structuredClone(h.response);stale.state='stale';assert.equal(h.api.update(stale),true);let f=fields(h.container);assert.equal(f['Selection evidence'],'Last verified');assert.equal(f['Applied model evidence'],'Last verified');assert.equal(f['Speed evidence'],'Last verified');assert.match(h.container.textContent,/Current settings are unconfirmed/);
 const oldSpeed=structuredClone(h.response);oldSpeed.metadata.agents[0].applied.speedObservedUtc=h.iso(-180000);oldSpeed.metadata.agents[0].applied.reasoningObservedUtc=h.iso(-180000);h.api.update(oldSpeed);assert.equal(fields(h.container)['Speed evidence'],'Last verified');assert.equal(fields(h.container)['Reasoning evidence'],'Last verified');const missing=structuredClone(h.response);Object.assign(missing.metadata.agents[0].applied,{speed:null,speedObservedUtc:null});h.api.update(missing);f=fields(h.container);assert.equal(f['Applied speed'],'Unknown');assert.equal(f['Speed evidence'],'Unknown');h.api.dispose();
});

test('foreign or different-clock/name metadata is withheld instead of mixed with a workspace record',()=>{
 const h=harness();h.api.observeWorkspace(h.workspace);h.api.update(h.response);const different=structuredClone(h.response);different.observedUtc=h.iso(-1000);different.metadata.observedUtc=h.iso(-1000);assert.equal(h.api.update(different),false);assert.equal(descendants(h.container).some(n=>n.tagName==='dl'),false);
 h.api.observeWorkspace({...h.workspace,agents:[{alias:'role-helper',name:'Changed name'}]});assert.equal(h.api.update(h.response),false);h.api.observeWorkspace(h.workspace);const foreign=structuredClone(h.response);foreign.metadata.worldId='world-foreign';assert.throws(()=>h.api.update(foreign));assert.equal(descendants(h.container).some(n=>n.tagName==='dl'),false);const empty=structuredClone(h.response);empty.metadata.agents=[];h.api.observeWorkspace({...h.workspace,agents:[]});assert.equal(h.api.update(empty),true);assert.match(h.container.textContent,/No active agent settings/);h.api.dispose();
});

test('existing workspace notifications drive only an open owner disclosure, preserving unchanged records and clearing View',async()=>{
 const h=harness(),section=h.container.children[0];h.api.observeWorkspace(h.workspace);assert.equal(h.reads(),0);section.open=true;section.listeners.get('toggle')();await new Promise(setImmediate);assert.equal(h.reads(),1);const row=descendants(h.container).find(n=>n.dataset.agentAlias);row.open=true;
 h.root.listeners.get('alife-workspace-refresh')({detail:h.workspace});await new Promise(setImmediate);assert.equal(h.reads(),2);assert.equal(descendants(h.container).find(n=>n.dataset.agentAlias),row);assert.equal(row.open,true);assert.doesNotMatch(h.container.textContent,/Reading selected/);
 h.root.dataset.operatorMode='view';h.mutate();assert.equal(descendants(h.container).some(n=>n.tagName==='dl'),false);h.api.dispose();assert.equal(h.events.size,0);
});

test('owner metadata reader rejects auth loss, oversized bodies and foreign URLs without retaining current settings',async()=>{
 const h=harness();h.api.observeWorkspace(h.workspace);h.container.children[0].open=true;await h.api.refresh();assert.equal(h.reads(),1);h.setReply(new Response(null,{status:403}));await h.api.refresh();assert.equal(descendants(h.container).some(n=>n.tagName==='dl'),false);h.setReply(new Response('x',{headers:{'Content-Type':'application/json','Content-Length':String(OWNER_AGENT_SETTINGS_LIMIT+1)}}));await h.api.refresh();assert.equal(descendants(h.container).some(n=>n.tagName==='dl'),false);h.container.dataset.agentMetadataSource='https://foreign.test/api/agent-metadata';await h.api.refresh();assert.equal(h.reads(),3);h.api.dispose();
});
