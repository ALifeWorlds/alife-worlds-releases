import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,rm,access} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {emptyCatalog,parseRuleCommand,applyRuleChange,validateCatalog,worldPrompt,exportRulePrompt,ruleDisplay,readRuleCatalogs,saveRuleChange,generateRuleDocuments,checkRuleDocuments} from '../lib/rules.mjs';
import {createApp} from '../server.mjs';
import {writeTestConfig} from './test-config.mjs';
import {createQualifiedFixtureApp} from './qualified-fixture-app.mjs';
const scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));
const change=(scope='world',extra={})=>({command:scope==='world'?'/world make the floor green' :'/plugin sync before pushing',requestId:'request-one',expectedRevision:0,groupId:'floor',groupTitle:'Floor',properties:[{id:'color',title:'Color',text:'Green'}],...extra});
async function fixture(fn){await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'rules-test-'));await mkdir(path.join(root,'rules'));for(const scope of ['plugin','world'])await writeFile(path.join(root,'rules',scope+'.json'),JSON.stringify(emptyCatalog(scope)));try{await fn(root);}finally{assert.ok(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));await rm(root,{recursive:true,force:true});}}

test('rule commands distinguish plugin/world, list/export and invalid input',()=>{
 assert.equal(parseRuleCommand('/world floor green').scope,'world');assert.equal(parseRuleCommand('/rule concise replies').scope,'agent');assert.equal(parseRuleCommand('/universal preserve custody').scope,'universal');assert.equal(parseRuleCommand('/plugin publish changes').scope,'plugin');assert.equal(parseRuleCommand('/world list').operation,'list');assert.equal(parseRuleCommand('/rule export').operation,'export');
 for(const s of ['/world','/rule   ','/reset world','floor green'])assert.throws(()=>parseRuleCommand(s));assert.throws(()=>applyRuleChange(emptyCatalog('world'),change('plugin')));
});
test('compatible floor properties merge without replacing independent values',()=>{
 let c=applyRuleChange(emptyCatalog('world'),change());c=applyRuleChange(c,change('world',{command:'/world floor side view',requestId:'request-two',expectedRevision:1,properties:[{id:'perspective',title:'Perspective',text:'Side view'}]}));
 assert.equal(c.groups.length,1);assert.deepEqual(c.groups[0].properties.map(p=>p.id),['color','perspective']);assert.ok(worldPrompt(c).includes('### Color\n'));assert.ok(worldPrompt(c).includes('**AI instructions**\n\nGreen'));assert.ok(worldPrompt(c).includes('### Perspective\n'));assert.ok(worldPrompt(c).includes('**AI instructions**\n\nSide view'));
});
test('same-property correction leaves one active value, inactive history and idempotent effects',()=>{
 let c=applyRuleChange(emptyCatalog('world'),change());const update=change('world',{command:'/world change floor to blue',requestId:'request-two',expectedRevision:1,properties:[{id:'color',title:'Color',text:'Blue'}]});c=applyRuleChange(c,update);assert.equal(c.groups[0].properties.length,1);assert.equal(c.groups[0].properties[0].text,'Blue');assert.equal(c.groups[0].properties[0].history[0].text,'Green');assert.ok(!worldPrompt(c).includes('Green'));assert.equal(applyRuleChange(c,update),c);assert.throws(()=>applyRuleChange(c,{...update,properties:[{id:'color',title:'Color',text:'Red'}]}),/reused/);
});
test('disabling one property preserves the rest of its group and excludes inactive values from export',()=>{
 let c=applyRuleChange(emptyCatalog('world'),change('world',{properties:[{id:'color',title:'Color',text:'Green'},{id:'perspective',title:'Perspective',text:'Side view'}]}));c=applyRuleChange(c,change('world',{command:'/world remove floor color',requestId:'request-two',expectedRevision:1,properties:[{id:'color',operation:'disable'}]}));assert.equal(c.groups[0].properties.length,2);assert.equal(c.groups[0].properties[1].active,true);assert.ok(!worldPrompt(c).includes('Green'));assert.ok(worldPrompt(c).includes('Side view'));
});
test('registry validation refuses stale revisions, duplicate identities/text and unbounded fields',()=>{
 const c=applyRuleChange(emptyCatalog('world'),change());assert.throws(()=>applyRuleChange(c,change('world',{requestId:'new',expectedRevision:0})),/revision/);
 for(const kind of ['group','property','text','length']){const d=structuredClone(c);if(kind==='group')d.groups.push(structuredClone(d.groups[0]));if(kind==='property')d.groups[0].properties.push(structuredClone(d.groups[0].properties[0]));if(kind==='text')d.groups[0].properties.push({...d.groups[0].properties[0],id:'other'});if(kind==='length')d.groups[0].properties[0].text='x'.repeat(4001);assert.throws(()=>validateCatalog(d));}
});
test('independent exports retain grouped scope and filter request/history metadata from display',()=>{
 const world=applyRuleChange(emptyCatalog('world'),change()),plugin=applyRuleChange(emptyCatalog('plugin'),change('plugin',{groupId:'delivery',groupTitle:'Delivery',properties:[{id:'sync',title:'Sync',text:'Fetch before pushing completed source.'}]}));
 assert.ok(worldPrompt(world).includes('## Floor'));assert.ok(!worldPrompt(world).includes('Fetch before pushing'));assert.ok(exportRulePrompt(plugin).includes('## Delivery'));assert.ok(!exportRulePrompt(plugin).includes('Color: Green'));assert.ok(!JSON.stringify(ruleDisplay({plugin,world})).includes('requests'));assert.ok(!JSON.stringify(ruleDisplay({plugin,world})).includes('sha256'));
});
test('private world/plugin values are rejected before saving or publishing a rule view',async()=>fixture(async root=>{
 for(const value of ['C:/Users/private/world','\\\\host\\private\\world','session 20000000-0000-0000-0000-000000000000','password=private-value']){
  for(const active of [true,false]){const request=change('world',{properties:[{id:'color',title:'Color',text:value,active}]});await assert.rejects(saveRuleChange(root,request),/private/);assert.equal((await readRuleCatalogs(root)).world.revision,0);}
 }
 const c=applyRuleChange(emptyCatalog('plugin'),change('plugin',{properties:[{id:'secret',title:'Secret',text:'api_key=private-value'}]}));assert.throws(()=>ruleDisplay({plugin:c,world:emptyCatalog('world')}),/private/);
}));
test('inactive text stays out of the browser and private group metadata cannot be saved',async()=>fixture(async root=>{
 let world=applyRuleChange(emptyCatalog('world'),change());world=applyRuleChange(world,change('world',{command:'/world remove floor color',requestId:'two',expectedRevision:1,properties:[{id:'color',operation:'disable'}]}));
 const view=ruleDisplay({plugin:emptyCatalog('plugin'),world});assert.equal(view.world.groups[0].properties[0].text,null);assert.ok(!JSON.stringify(view).includes('Green'));assert.ok(!worldPrompt(world).includes('Green'));
 await assert.rejects(saveRuleChange(root,change('world',{groupTitle:'C:/private/title'})),/private/);assert.equal((await readRuleCatalogs(root)).world.revision,0);
}));

test('atomic persistence/generation is repeatable, detects drift and serializes concurrent edits',async()=>fixture(async root=>{
 const request=change();await saveRuleChange(root,request);await checkRuleDocuments(root);await saveRuleChange(root,request);assert.equal((await readRuleCatalogs(root)).world.revision,1);
 await writeFile(path.join(root,'docs','WORLD_RULES.md'),'wrong document');await assert.rejects(checkRuleDocuments(root),/out of date/);await generateRuleDocuments(root);await checkRuleDocuments(root);
 const edits=await Promise.allSettled([saveRuleChange(root,change('world',{requestId:'two',expectedRevision:1,properties:[{id:'view',title:'View',text:'Front facing'}]})),saveRuleChange(root,change('world',{requestId:'three',expectedRevision:1,properties:[{id:'lighting',title:'Lighting',text:'Warm'}]}))]);assert.equal(edits.filter(e=>e.status==='fulfilled').length,1);await checkRuleDocuments(root);await assert.rejects(access(path.join(root,'rules','.edit-lock')));
}));
test('read-only rule API exports both scopes, excludes metadata and refuses mutation',async()=>fixture(async root=>{
 const createFixtureApp=await createQualifiedFixtureApp(root);const app=await createFixtureApp({configFile:await writeTestConfig(root)});try{const url=await app.listen(0),d=await(await fetch(url+'/api/dashboard')).json();assert.ok(d.ruleCatalog.plugin.groups.some(g=>g.id==='delivery'));assert.ok(d.ruleCatalog.world.groups.some(g=>g.title==='Sound'));assert.ok(!JSON.stringify(d.ruleCatalog).includes('human-delivery-rule-20261105-v1'));
 const world=await(await fetch(url+'/api/rule-export?scope=world')).text(),plugin=await(await fetch(url+'/api/rule-export?scope=plugin')).text();assert.ok(world.includes('Shareable world prompt'));const sync=d.ruleCatalog.plugin.groups.find(g=>g.id==='delivery').properties.find(p=>p.id==='sync-before-push');assert.equal(sync.active,true);assert.ok(plugin.includes(sync.title));assert.ok(plugin.includes(sync.text));assert.ok(!world.includes(sync.text));assert.equal((await fetch(url+'/api/rule-export?scope=../plugin')).status,400);assert.equal((await fetch(url+'/api/rule-export?scope=world',{method:'POST'})).status,405);assert.equal((await fetch(url+'/rules/plugin.json')).status,404);assert.equal((await fetch(url+'/rules/agents.json')).status,404);assert.equal((await fetch(url+'/api/rule-export?scope=agent')).status,400);assert.equal((await fetch(url+'/api/rule-export?scope=universal')).status,400);assert.equal(d.feed.farmFacts.commands.transportEnabled,false);
 }finally{await new Promise(resolve=>app.server.close(resolve));}
}));
