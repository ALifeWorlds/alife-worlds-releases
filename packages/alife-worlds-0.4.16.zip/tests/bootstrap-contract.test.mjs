import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,readdir,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {readRuleCatalogs} from '../lib/rules.mjs';
import {readAgentRuleCatalogs,readRoleDefinitions,getAgentRuleContract,checkAllRuleDocuments,generateAllRuleDocuments} from '../lib/agent-rules.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
test('source-backed startup contract retains explicit authority and separate native proof',async()=>{
 const {universal}=await readAgentRuleCatalogs(root),creation=universal.groups.find(g=>g.id==='onboarding').properties.find(p=>p.id==='support-owned-creation');
 assert.ok(['documented','implemented'].includes(creation.implementation));
 for(const phrase of ['explicit user-invoked new-project setup','one-time first Agent Support bootstrap','exact selected folder/native project and conversation context','no existing or pending Agent Support','no unresolved launch','approved core creation baseline','without asking again','approved-settings guard','reconcile unknown launches','wait for Agent Support own distinct real binding','full instructions/retirement reading and custody acknowledgement','Thereafter Agent Support alone creates','cannot be reused for recovery/replacement'])assert.ok(creation.text.includes(phrase),phrase);
 const plugin=(await readRuleCatalogs(root,{allowMissing:false})).plugin,group=plugin.groups.find(g=>g.id==='bootstrap');
 assert.deepEqual(group.properties.map(p=>p.id),['selected-context','core-scope','readiness']);
 assert.ok(group.properties.every(p=>['documented','implemented'].includes(p.implementation)));
 assert.ok(group.properties.find(p=>p.id==='core-scope').text.includes('There is no fixed-20 startup'));
 assert.ok(group.properties.find(p=>p.id==='readiness').text.includes('Source fixtures do not prove native startup'));
 assert.ok(group.properties.find(p=>p.id==='readiness').text.includes('distinct real core bindings'));
});
test('every catalogued role exports the selected exception without reactivating Support-only history',async()=>{
 const catalogs=await readAgentRuleCatalogs(root),roles=await readRoleDefinitions(root);
 assert.deepEqual(roles.map(r=>r.id),['director','support','world-requests']);
 assert.deepEqual((await readdir(path.join(root,'roles'))).sort(),['SHARED.md','director.md','support.md','world-requests.md'].sort());
 for(const role of roles){
  const c=await getAgentRuleContract(root,role.id,catalogs);
  assert.ok(c.text.includes('one-time first Agent Support bootstrap'));
  assert.ok(c.text.includes('ONE sequential successor'));
  assert.ok(c.text.includes('Preserve the human-selected model'));
  assert.ok(c.text.includes('approved core creation baseline'));
  assert.ok(!c.text.includes('Otherwise omit model and thinking'));
  assert.ok(!c.text.includes('Missing settings approval is a human dependency'));
  assert.ok(!c.text.includes('If no approved creation model is established, ask'));
  assert.ok(!c.text.includes('A missing Support is an explicit dependency, not permission for another role to create agents.'));
 }
 const inherited=catalogs.universal.groups.find(g=>g.id==='onboarding').properties.find(p=>p.id==='complete-inheritance');
 assert.ok(inherited.text.includes('Required behavior\nBefore launch, the authorized creator under onboarding.support-owned-creation includes'));
 assert.ok(inherited.description);
 const doc=await readFile(new URL('../docs/UNIVERSAL_AGENT_RULES.md',import.meta.url),'utf8');
 assert.ok(!doc.includes('Agent Support alone performs authorized creation.'));
 await checkAllRuleDocuments(root);
});

test('three-core contract fixture exports only core packets while preserving an external project roster',async()=>{
 const scratch=path.join(root,'runtime','test-fixtures');await mkdir(scratch,{recursive:true});
 const fixture=await mkdtemp(path.join(scratch,'core-contract-'));
 try{
  for(const dir of ['data','roles','rules','docs','prompts','world'])await mkdir(path.join(fixture,dir));
  const ids=['director','support','world-requests'];
  const current=JSON.parse(await readFile(path.join(root,'data','roles.json'),'utf8')),core=ids.map(id=>current.find(r=>r.id===id));
  assert.ok(core.every(Boolean));await writeFile(path.join(fixture,'data','roles.json'),JSON.stringify(core));
  for(const name of ['SHARED',...ids])await writeFile(path.join(fixture,'roles',name+'.md'),await readFile(path.join(root,'roles',name+'.md')));
  for(const scope of ['plugin','world','universal'])await writeFile(path.join(fixture,'rules',scope+'.json'),await readFile(path.join(root,'rules',scope+'.json')));
  const agentStore=JSON.parse(await readFile(path.join(root,'rules','agents.json'),'utf8'));
  agentStore.agents=Object.fromEntries(Object.entries(agentStore.agents).filter(([id])=>ids.includes(id)));
  await writeFile(path.join(fixture,'rules','agents.json'),JSON.stringify(agentStore));
  const privateRoster=JSON.stringify([{id:'existing-specialist',title:'Existing specialist',custody:'unchanged fixture'}]);
  const external=path.join(fixture,'project-roster.private.json');await writeFile(external,privateRoster);
  assert.deepEqual((await readRoleDefinitions(fixture)).map(r=>r.id),ids);
  assert.deepEqual((await readdir(path.join(fixture,'roles'))).sort(),['SHARED.md','director.md','support.md','world-requests.md'].sort());
  for(const id of ids){
   const contract=await getAgentRuleContract(fixture,id);
   assert.ok(contract.text.includes('one-time first Agent Support bootstrap'));
   assert.ok(contract.text.includes('ONE sequential successor'));
   assert.ok(contract.text.includes('Preserve the human-selected model'));
  }
  await assert.rejects(getAgentRuleContract(fixture,'existing-specialist'),/Unknown invoking role/);
  await generateAllRuleDocuments(fixture);await checkAllRuleDocuments(fixture);
  const docs=await readFile(path.join(fixture,'docs','AGENT_RULES.md'),'utf8');
  assert.equal((docs.match(/^## [^#]/gm)||[]).length,3);
  assert.ok(!docs.includes('Agent Worker #1'));
  assert.equal(await readFile(external,'utf8'),privateRoster);
 }finally{
  assert.ok(path.resolve(fixture).startsWith(path.resolve(scratch)+path.sep));
  await rm(fixture,{recursive:true,force:true});
 }
});
