// Source integration only: actual compiled child/viewport/join/readiness/swap;
// DOM, Root HTTP callbacks, art loading and World drawing are stand-ins.
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {setImmediate as turn} from 'node:timers/promises';
import {candidateFixture} from './mounted-replacement-fixture.mjs';
import {renderOwnerMountedReplacementModule,renderOwnerFrameClientModule,renderOwnerFrameDocument,renderOwnerSite} from '../lib/owner-site.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {createProjectWorldGallery} from '../web/project-world-gallery.mjs';
import {assertPrivateWorldCatalogResponse} from '../lib/private-world-catalog-contract.mjs';
const oldRenderer={schemaVersion:1,bundleId:'colony-world133',worldVersion:'1.3.3',artifactSha256:'c'.repeat(64)},nextRenderer={schemaVersion:1,bundleId:'colony-world134',worldVersion:'1.3.4',artifactSha256:'a'.repeat(64)};
const parentSource='const OWNER_SITE_CONTEXT='+JSON.stringify({renderer:oldRenderer})+';\n'+await renderOwnerMountedReplacementModule();
const {createOwnerMountedReplacement,createExistingWorldFramePreview}=await import('data:text/javascript;base64,'+Buffer.from(parentSource+'\nexport {createOwnerMountedReplacement,createExistingWorldFramePreview};').toString('base64'));
const frameSource=await renderOwnerFrameClientModule();
const {createOwnerFrameClient}=await import('data:text/javascript;base64,'+Buffer.from(frameSource+'\nexport {createOwnerFrameClient};').toString('base64'));
class Element extends EventTarget{
 constructor({connected=false}={}){super();this.rootConnected=connected;this.children=[];this.dataset={};this.style={setProperty(key,value){this[key]=value;},removeProperty(key){delete this[key];}};this.attrs=new Map();this.classes=new Set();this.classList={add:(...names)=>names.forEach(name=>this.classes.add(name)),remove:(...names)=>names.forEach(name=>this.classes.delete(name))};}
 get isConnected(){return this.parentNode?this.parentNode.isConnected:this.rootConnected;}
 get parentElement(){return this.parentNode??null;}get nextSibling(){const nodes=this.parentNode?.children;return nodes?.[nodes.indexOf(this)+1]??null;}
 append(...nodes){for(const node of nodes){node.remove();this.children.push(node);node.parentNode=this;}}
 prepend(node){node.remove();this.children.unshift(node);node.parentNode=this;}
 moveBefore(node,next){node.remove();const i=next?this.children.indexOf(next):-1;this.children.splice(i<0?this.children.length:i,0,node);node.parentNode=this;}
 replaceChildren(...nodes){for(const node of this.children)node.parentNode=null;this.children=[];this.append(...nodes);}
 contains(node){return this.children.some(child=>child===node||child.contains?.(node));}
 setAttribute(k,v){this.attrs.set(k,String(v));}getAttribute(k){return this.attrs.get(k)??null;}hasAttribute(k){return this.attrs.has(k);}removeAttribute(k){this.attrs.delete(k);}
 remove(){if(this.parentNode){this.parentNode.children=this.parentNode.children.filter(node=>node!==this);this.parentNode=null;}}
 querySelector(){return null;}querySelectorAll(){return [];}focus(){}
 click(){throw Error('Synthetic click forbidden');}
}
function message(target,data,source,origin){const event=new MessageEvent('message',{data,origin});Object.defineProperty(event,'source',{value:source});target.dispatchEvent(event);}
const drain=async predicate=>{for(let i=0;i<200;i++){if(predicate?.())return;await turn();}if(predicate)assert.ok(predicate(),'Expected integration condition did not settle');};
async function fixture(){
 const clock={value:Date.now()},origin='http://127.0.0.1:43123',worldId='world-candidate-fixture';
 const oldPreview=await candidateFixture({now:clock.value,renderer:oldRenderer}),newPreview=await candidateFixture({now:clock.value,renderer:nextRenderer}),finalPreview=await candidateFixture({now:clock.value,renderer:nextRenderer,revision:2});
 const visual={worldKey:oldPreview.snapshot.model.visualWorldKey,artKey:'art-'+'d'.repeat(64),audienceKey:'audience-'+'e'.repeat(64)};
 const makeContext=renderer=>{const base='/world-frame/'+renderer.artifactSha256+'/';return{schemaVersion:1,kind:'owner-world-frame',worldId,access:'local-owner',ownerOrigin:origin,websiteVersion:'1.1.5',renderer,framePath:base,snapshotPath:base+'snapshot',resourceBase:base+'assets/',visualStateScope:{...visual}};};
 const oldContext=makeContext(oldRenderer),nextContext=makeContext(nextRenderer);
 let selected=oldContext,previous=null,offerStatus=200,offerReads=0,revocations=0,privateReceiver={recorded:true},holdCandidate=false;
 const prefs={mode:'public',paused:false,volume:0.37,soundEnabled:false},statuses=[],frames=[],loads=[],messages=[];
 const windowRef=new EventTarget();Object.assign(windowRef,{location:new URL(origin),setTimeout,clearTimeout});
 const worldWrap=new Element({connected:true}),scene=new Element();worldWrap.append(scene);
 const parentDocument={hidden:false,activeElement:null,createElement:type=>type==='iframe'?makeFrame():new Element()};
 async function rootFetch(url){
  const value=new URL(url);if(value.pathname==='/api/owner-world-release'){offerReads++;return new Response(JSON.stringify({schemaVersion:1,kind:'owner-world-release',worldId,access:'local-owner',ownerOrigin:origin,websiteVersion:'1.1.5',current:selected,previous}),{status:offerStatus,headers:{'Content-Type':'application/json'}});}
  const ctx=[oldContext,nextContext].find(item=>value.pathname===item.framePath+'context');assert.ok(ctx,'Only protected Root context paths may be fetched');return new Response(JSON.stringify(ctx),{headers:{'Content-Type':'application/json'}});
 }
 function makeFrame(){
  const frame=new Element(),child=new EventTarget();frames.push(frame);frame.title='Fixture world';frame.className='';frame.contentWindow=child;
  child.postMessage=(data,target)=>{assert.equal(target,origin);queueMicrotask(()=>message(child,data,child.parent,origin));};
  frame.start=async()=>{
   const ctx=frame.src.includes(nextRenderer.artifactSha256)?nextContext:oldContext;let current=ctx===nextContext?newPreview:oldPreview,volume=1,destroyed=false;
   const main=new Element({connected:true}),anchor=new Element(),profile=new Element(),host=new Element(),controls=new Element(),pause=new Element(),range=new Element();main.append(anchor,profile);pause.setAttribute('aria-pressed','false');range.value='100';host.dataset.mode='view';
   host.querySelector=value=>value==='.ag-controls'?controls:null;controls.querySelector=value=>value==='.ag-pause-toggle'?pause:value==='input[type=range]'?range:null;
   const doc=new EventTarget(),meta=value=>({getAttribute:()=>value});Object.assign(doc,{hidden:false,title:'Synthetic fixture',head:new Element(),body:new Element(),documentElement:new Element(),createElement:()=>new Element()});
   doc.querySelector=value=>value==='main'?main:value==='meta[name="alife-owner-context"]'?meta(ctx.framePath+'context'):value==='meta[name="alife-world-version"]'?meta(''):null;doc.getElementById=id=>id==='world-anchor'?anchor:id==='world-profile-status'?profile:null;
   Object.assign(child,{location:new URL(frame.src),setTimeout,clearTimeout,parent:{postMessage:(data,target)=>{assert.equal(target,origin);messages.push({type:data.type,receiverReady:data.receiverReady,preview:!!data.preview});queueMicrotask(()=>message(windowRef,data,child,origin));}},WorldAudio:{SAMPLE_FILES:{step:'step.mp3'},createSamplePlayer(){return{};}}});
   frame.restores=[];frame.renders=[];frame.imports=[];
   const farm={host,audio:{state:()=>({enabled:false,volume})},getResourceStatus:()=>({ready:!destroyed,art:'ready',font:'ready',disposed:destroyed}),setPresentationMode:mode=>{host.dataset.mode=mode;},setWorldVersion:value=>{frame.actualVersion=value;},setAudioPreferenceKey(){},setPaused:value=>{pause.setAttribute('aria-pressed',String(value));return value;},setVolume:value=>{volume=value;range.value=String(Math.round(value*100));return value;},render:(model,feed)=>frame.renders.push({model,feed}),captureVisualState:()=>frame.interacting?{captured:false,reason:'interaction-active',capsule:null}:{captured:true,reason:'captured',capsule:{fixture:'compatible pose'}},async restoreVisualState(capsule){frame.restores.push(capsule);if(ctx===nextContext){current=finalPreview;await frame.client.refresh();}return{applied:true,reason:'restored',actors:1};},destroy(){destroyed=true;frame.destroyed=true;}};
   child.AgentOutpost={mount(){main.prepend(host);return farm;}};
   frame.client=createOwnerFrameClient({windowRef:child,documentRef:doc,now:()=>clock.value,loadStyle:async url=>{loads.push(url);},importModule:async url=>{frame.imports.push(url);if(ctx===nextContext&&holdCandidate)await new Promise(resolve=>{frame.releaseImport=resolve;});return{};},fetcher:async url=>{const path=new URL(url).pathname;assert.ok(path===ctx.framePath+'context'||path===ctx.snapshotPath);return new Response(JSON.stringify(path===ctx.snapshotPath?current:ctx),{headers:{'Content-Type':'application/json'}});}});
   frame.profile=profile;const starting=frame.client.start();frame.dispatchEvent(new Event('load'));return starting;
  };return frame;
 }
 const activeFrame=makeFrame();activeFrame.src=new URL(oldContext.framePath,origin).href;scene.append(activeFrame);
 const append=scene.append.bind(scene);scene.append=(...nodes)=>{append(...nodes);for(const frame of nodes)if(frame.start)queueMicrotask(()=>void frame.start());};
 const runtime=createOwnerMountedReplacement({scene,activeFrame,context:{...oldContext,renderer:oldRenderer,qualifiedGalleryRenderer:oldRenderer},getPreferences:()=>prefs,onRevoke(){revocations++;privateReceiver=null;},onStatus:value=>statuses.push(value),documentRef:parentDocument,windowRef,fetcher:rootFetch,now:()=>clock.value});
 void activeFrame.start();assert.equal(await runtime.refresh({force:true}),true);try{await drain(()=>runtime.getCurrentInput()!==null);}catch(error){console.log({state:activeFrame.client.state(),status:activeFrame.profile.textContent,renders:activeFrame.renders.length,messages,statuses});runtime.dispose();throw error;}
 return{runtime,scene,worldWrap,parentDocument,windowRef,activeFrame,frames,prefs,clock,loads,statuses,origin,oldContext,nextContext,selectNext(){selected=nextContext;previous=oldContext;},setCandidateHeld:value=>{holdCandidate=value;},setOfferStatus:value=>{offerStatus=value;},offerReads:()=>offerReads,revocations:()=>revocations,privateReceiver:()=>privateReceiver};
}
test('compiled parent and actual child swap only after real final metadata2 proof; receiver refs commit before reveal in the same scene',async()=>{
 const f=await fixture();let bound=f.activeFrame,commits=0,cleanups=0;
 f.runtime.subscribe(({frame,preview,joined})=>{const before=bound;return{commit(){assert.equal(frame.style.visibility,'hidden');assert.equal(f.activeFrame.isConnected,true);assert.ok(f.scene.children.some(node=>node.className==='wf-transfer-shield'));assert.equal(joined.snapshot,preview.snapshot);assert.equal(joined.metadataMarker.revision,2);bound=frame;commits++;},rollback(){bound=before;},disposePrevious(){cleanups++;}};});
 try{f.selectNext();assert.equal(await f.runtime.refresh({force:true}),true);await drain(()=>f.runtime.getActiveFrame()!==f.activeFrame);
  const next=f.runtime.getActiveFrame();assert.equal(bound,next);assert.equal(commits,1);assert.equal(cleanups,1);assert.equal(next.parentElement,f.scene);assert.equal(f.scene.parentElement,f.worldWrap);assert.equal(next.style.visibility,'');assert.equal(next.inert,false);assert.equal(f.activeFrame.isConnected,false);assert.equal(f.activeFrame.destroyed,true);assert.equal(f.runtime.getCurrentInput().joined.metadataMarker.revision,2);assert.deepEqual(next.restores,[{fixture:'compatible pose'}]);assert.equal(next.actualVersion,null);assert.equal(f.runtime.diagnostics().sessions,1);assert.ok(next.imports.every(url=>url.startsWith(f.origin+f.nextContext.resourceBase+'agent-outpost/')));assert.ok(f.loads.every(url=>!url.includes('/assets/web/')));
 }finally{f.runtime.dispose();}
});
test('temporary Root loss retains the original receiver and automatically retries on the existing refresh path with backoff',async()=>{
 const f=await fixture();try{f.selectNext();f.setOfferStatus(503);const before=f.offerReads();assert.equal(await f.runtime.refresh({force:true}),false);assert.equal(f.runtime.getActiveFrame(),f.activeFrame);assert.equal(f.activeFrame.isConnected,true);assert.ok(f.runtime.diagnostics().nextRead>f.clock.value);
  await f.runtime.refresh();assert.equal(f.offerReads(),before+1);f.setOfferStatus(200);f.clock.value+=4000;assert.equal(await f.runtime.refresh(),true);await drain(()=>f.runtime.getActiveFrame()!==f.activeFrame);assert.equal(f.runtime.diagnostics().revoked,false);
 }finally{f.runtime.dispose();}
});
test('actual Root revocation clears parent private receiver data, child caches, pending frames and scene',async()=>{
 const f=await fixture();try{f.setOfferStatus(403);assert.equal(await f.runtime.refresh({force:true}),false);await drain(()=>f.activeFrame.destroyed===true);assert.equal(f.runtime.diagnostics().revoked,true);assert.equal(f.runtime.diagnostics().sessions,0);assert.equal(f.runtime.getCurrentInput(),null);assert.equal(f.privateReceiver(),null);assert.equal(f.revocations(),1);assert.equal(f.scene.children.length,0);assert.equal(f.activeFrame.client.state().receiverReady,false);
 }finally{f.runtime.dispose();}
});
test('compiled documents preserve pinned paths, explicit actual version metadata, full dependency closure and accepted green checkbox styles',async()=>{
 const f=await fixture();try{
  const owner={schemaVersion:1,access:'local-owner',worldId:f.oldContext.worldId,roles:registry.map(({id,title,role})=>({id,title,role:role||id})),websiteVersion:'1.1.5',worldVersion:null,ownerOrigin:f.origin,publicOrigin:null,framePath:f.oldContext.framePath,projectName:'Synthetic world',creatorLabel:'Fixture',renderer:oldRenderer,qualifiedGalleryRenderer:nextRenderer};
  const resources=await renderOwnerSite(owner);assert.ok(resources.page.includes('src="'+f.oldContext.framePath+'"'));assert.ok(!resources.page.includes('worldViewport=1'));assert.doesNotThrow(()=>new vm.Script(resources.client));assert.ok(resources.css.includes('b9ef91'));assert.ok(resources.css.includes('input[type=checkbox]:disabled{opacity:1;filter:none}'));assert.equal(resources.frameClient,frameSource);const compiledDocument=new Function(resources.frameDocumentModule+'\nreturn renderOwnerFrameDocument;')();assert.equal(compiledDocument(f.nextContext,{worldVersion:'1.3.4'}),renderOwnerFrameDocument(f.nextContext,{worldVersion:'1.3.4'}));
  assert.ok(resources.page.includes('id="wf-rule-library"'));assert.ok(resources.page.includes('id="wf-agent-settings"'));assert.ok(resources.client.includes('createOwnerRuleLibraryClient'));assert.ok(resources.client.includes('createOwnerAgentSettings'));assert.ok(resources.client.includes('alife-workspace-refresh'));
  const html=renderOwnerFrameDocument(f.nextContext,{worldVersion:'9.2.1'});assert.ok(html.includes('name="alife-world-version" content="9.2.1"'));assert.ok(renderOwnerFrameDocument(f.nextContext).includes('name="alife-world-version" content=""'));assert.ok(!html.includes('<base'));assert.ok(frameSource.includes('pinnedFrame:true'));
 }finally{f.runtime.dispose();}
});
test('a real preference change cancels a booting candidate, retains old world and disposes the child through the actual wire',async()=>{
 const f=await fixture();let next;
 try{f.setCandidateHeld(true);f.selectNext();await f.runtime.refresh({force:true});await drain(()=>f.frames.length===2&&f.frames[1].releaseImport);next=f.frames[1];assert.equal(next.style.visibility,'hidden');
  f.prefs.volume=0.8;f.runtime.preferencesChanged();await drain(()=>next.client.state().disposed);assert.equal(next.isConnected,false);assert.equal(f.runtime.getActiveFrame(),f.activeFrame);assert.equal(f.runtime.diagnostics().sessions,1);next.releaseImport();await drain();assert.equal(f.runtime.getActiveFrame(),f.activeFrame);assert.equal(next.client.state().receiverReady,false);
 }finally{next?.client?.dispose();next?.releaseImport?.();f.runtime.dispose();}
});
test('actual capture refusal for an active drag retains the original mount and removes the final-transfer shield',async()=>{
 const f=await fixture();try{f.activeFrame.interacting=true;f.selectNext();await f.runtime.refresh({force:true});await drain(()=>f.frames.length===2&&f.frames[1].client?.state().disposed);assert.equal(f.runtime.getActiveFrame(),f.activeFrame);assert.equal(f.activeFrame.isConnected,true);assert.equal(f.activeFrame.destroyed,undefined);assert.equal(f.scene.children.length,1);assert.equal(f.scene.children[0],f.activeFrame);assert.ok(f.statuses.some(value=>value.reason==='Current world interaction is active'));
 }finally{f.runtime.dispose();}
});
test('gallery approval is inherited only from the independently established exact Root world/art/audience scope',async()=>{
 const f=await fixture();try{assert.deepEqual(f.runtime.getGalleryRenderer(),oldRenderer);f.selectNext();await f.runtime.refresh({force:true});await drain(()=>f.runtime.getActiveFrame()!==f.activeFrame);assert.deepEqual(f.runtime.getGalleryRenderer(),nextRenderer);}finally{f.runtime.dispose();}
 const changed=await fixture();try{changed.nextContext.visualStateScope.artKey='art-'+'e'.repeat(64);changed.selectNext();await changed.runtime.refresh({force:true});await drain(()=>changed.runtime.getActiveFrame()!==changed.activeFrame);assert.equal(changed.runtime.getGalleryRenderer(),null);}finally{changed.runtime.dispose();}
});
test('the actual gallery rebind preserves the same scene and selected live project through an approved renderer commit',async()=>{
 const f=await fixture(),container=new Element({connected:true}),worldId=f.oldContext.worldId,at=new Date(f.clock.value).toISOString();
 const catalogResponse={schemaVersion:1,kind:'owner-world-catalog-response',state:'current',receivedUtc:at,catalog:{schemaVersion:1,kind:'owner-world-catalog',worldId,observedUtc:at,sourceState:'current',currentId:'project-one',worlds:[{id:'project-one',name:'Synthetic project',connection:{state:'ready',checkedUtc:at,target:{kind:'this-computer',url:f.origin+'/?project='+worldId}}}]}};
 const getCurrentInput=()=>({catalogResponse,...(f.runtime.getCurrentInput()??{preview:null,joined:null})});
 const gallery=createProjectWorldGallery({document:f.parentDocument,container,expectedWorldId:worldId,ownerOrigin:f.origin,approvedRenderer:f.runtime.getGalleryRenderer(),assertCatalogResponse:assertPrivateWorldCatalogResponse,getCurrentInput,createPreview:({host,project,renderer,onStatus})=>createExistingWorldFramePreview({host,project,renderer,approvedRenderer:f.runtime.getGalleryRenderer(),scene:f.scene,frame:f.runtime.getActiveFrame(),worldId,currentId:'project-one',getCurrentInput,syncVisibility(){},onStatus})});
 gallery.setActive(true);assert.equal(gallery.getDiagnostics().previewInstances,1);assert.notEqual(f.scene.parentElement,f.worldWrap);const originalScene=f.scene;
 f.runtime.subscribe(({qualifiedGalleryRenderer})=>{const previous=f.runtime.getGalleryRenderer();return{commit(){gallery.setApprovedRenderer(qualifiedGalleryRenderer);},rollback(){gallery.setApprovedRenderer(previous);},disposePrevious(){gallery.update();}};});
 try{f.selectNext();await f.runtime.refresh({force:true});await drain(()=>f.runtime.getActiveFrame()!==f.activeFrame);assert.equal(f.scene,originalScene);assert.notEqual(f.scene.parentElement,f.worldWrap);assert.equal(f.scene.contains(f.runtime.getActiveFrame()),true);assert.equal(gallery.getDiagnostics().previewInstances,1);assert.equal(gallery.getDiagnostics().cleanupFailures,0);assert.equal(gallery.element.children[0].dataset.projectId,'project-one');assert.equal(gallery.element.children[0].dataset.preview,'live');
 }finally{gallery.dispose();f.runtime.dispose();}
});
