import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,copyFile,rm,lstat,readdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync,spawn} from 'node:child_process';
import {once} from 'node:events';
import {collectPackageInputs,readPluginManifests,nextVersion,validateVersion,packageFingerprint,checkPluginVersion,sealVersion,RELEASE_FILE,FINGERPRINT_ALGORITHM} from '../lib/plugin-version.mjs';

const source=fileURLToPath(new URL('../',import.meta.url)),scratch=path.join(source,'runtime','test-fixtures');
const readJson=async(root,rel)=>JSON.parse(await readFile(path.join(root,rel),'utf8'));
const writeJson=(root,rel,value)=>writeFile(path.join(root,rel),JSON.stringify(value,null,2)+'\n');
async function fixture(fn){
 await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'plugin-version-'));
 try{
  for(const rel of await collectPackageInputs(source)){const target=path.join(root,rel);await mkdir(path.dirname(target),{recursive:true});await copyFile(path.join(source,rel),target);}
  for(const rel of ['package.json','plugin.json','.codex-plugin/plugin.json'])await writeJson(root,rel,{...await readJson(root,rel),version:'0.1.1'});
  await writeJson(root,RELEASE_FILE,{schemaVersion:1,name:'alife-worlds',fingerprintAlgorithm:FINGERPRINT_ALGORITHM,releases:[]});
  await fn(root);
 }finally{
  const absolute=path.resolve(root),allowed=path.resolve(scratch)+path.sep;
  assert.ok(absolute.startsWith(allowed));await rm(absolute,{recursive:true,force:true});
 }
}
function command(root,script,args=[]){
 const result=spawnSync(process.execPath,[path.join(root,script),...args],{cwd:root,encoding:'utf8',timeout:30000,maxBuffer:4*1024*1024});
 if(result.error)throw result.error;
 return {status:result.status,stdout:result.stdout,stderr:result.stderr};
}
function build(root,candidate=true){return command(root,'scripts/build-plugin.mjs',candidate?['--candidate']:[]);}
function success(result){assert.equal(result.status,0,result.stderr||result.stdout);return JSON.parse(result.stdout.trim());}

test('normal versions reject legacy labels and bump semantic components safely',()=>{
 for(const value of ['0.1.0-foundation.1','01.1.1','1.2','1.2.3+build','9007199254740992.0.0',null])assert.throws(()=>validateVersion(value),/X.Y.Z/);
 assert.equal(nextVersion('0.1.1','patch'),'0.1.2');
 assert.equal(nextVersion('0.9.9','minor'),'0.10.0');
 assert.equal(nextVersion('0.9.9','major'),'1.0.0');
 assert.throws(()=>nextVersion('0.1.1','automatic'),/patch, minor or major/);
 assert.throws(()=>nextVersion('9007199254740991.0.0','major'),/X.Y.Z/);
});

test('every manifest must match canonical package version before packaging',async()=>fixture(async root=>{
 for(const rel of ['package.json','plugin.json','.codex-plugin/plugin.json']){
  const before=await readJson(root,rel);await writeJson(root,rel,{...before,version:'0.1.2'});
  const failed=build(root);assert.notEqual(failed.status,0);assert.match(failed.stderr,/version\/identity mismatch/);
  await writeJson(root,rel,before);
 }
 assert.equal((await readPluginManifests(root)).version,'0.1.1');
 await assert.rejects(lstat(path.join(root,'.plugin-build','alife-worlds')),{code:'ENOENT'});
}));

test('unchanged qualification builds do not bump and unsealed candidates cannot activate',async()=>fixture(async root=>{
 const denied=build(root,false);assert.notEqual(denied.status,0);assert.match(denied.stderr,/not sealed/);
 const first=success(build(root)),second=success(build(root));
 assert.equal(first.version,'0.1.1');assert.equal(second.version,first.version);assert.equal(second.contentFingerprint,first.contentFingerprint);
 assert.notEqual(first.output,second.output);
 assert.deepEqual((await readJson(root,RELEASE_FILE)).releases,[]);
 await assert.rejects(lstat(path.join(root,'.plugin-build','alife-worlds')),{code:'ENOENT'});
}));

test('changed released content is refused without replacing active output; explicit patch qualifies',async()=>fixture(async root=>{
 const first=success(build(root));
 success(command(root,'scripts/plugin-version.mjs',['seal',first.contentFingerprint]));
 const active=success(build(root,false)),provenance=await readFile(path.join(active.output,'package-provenance.json'),'utf8');
 const originalLedger=await readFile(path.join(root,RELEASE_FILE),'utf8');
 await writeFile(path.join(root,'README.md'),(await readFile(path.join(root,'README.md'),'utf8'))+'\nA real release-content change.\n');
 const refused=build(root,false);assert.notEqual(refused.status,0);assert.match(refused.stderr,/Released plugin content changed/);
 assert.equal(await readFile(path.join(active.output,'package-provenance.json'),'utf8'),provenance);
 assert.equal(await readFile(path.join(root,RELEASE_FILE),'utf8'),originalLedger);
 const bump=success(command(root,'scripts/plugin-version.mjs',['bump','patch']));assert.equal(bump.version,'0.1.2');
 for(const rel of bump.files)assert.equal((await readJson(root,rel)).version,'0.1.2');
 const next=success(build(root));assert.notEqual(next.contentFingerprint,first.contentFingerprint);
 success(command(root,'scripts/plugin-version.mjs',['seal',next.contentFingerprint]));
 assert.equal(success(build(root,false)).version,'0.1.2');
 const ledger=await readJson(root,RELEASE_FILE);assert.deepEqual(ledger.releases.map(r=>r.version),['0.1.1','0.1.2']);
 assert.equal(ledger.releases[0].fingerprint,first.contentFingerprint);
 await assert.rejects(lstat(path.join(root,'.git')),{code:'ENOENT'});
}));

test('unchanged released rebuilds preserve history and exclude local runtime/private state',async()=>fixture(async root=>{
 const first=success(build(root));await sealVersion(root,first.contentFingerprint);
 const ledger=await readFile(path.join(root,RELEASE_FILE),'utf8');
 await mkdir(path.join(root,'runtime','private'),{recursive:true});await writeFile(path.join(root,'runtime','private','note.json'),'{"private":"fixture-only"}');
 await writeFile(path.join(root,'data','project-state.json'),'{"private":"fixture-only"}');
 for(let i=0;i<2;i++){const result=success(build(root));assert.equal(result.version,'0.1.1');assert.equal(result.contentFingerprint,first.contentFingerprint);assert.equal(result.releaseState,'released');}
 assert.equal(await readFile(path.join(root,RELEASE_FILE),'utf8'),ledger);
 assert.equal((await readPluginManifests(root)).version,'0.1.1');
}));

test('fingerprint tolerates text checkout newlines but detects binary changes',async()=>fixture(async root=>{
 const initial=await packageFingerprint(root);await sealVersion(root,initial);
 const readme=await readFile(path.join(root,'README.md'),'utf8');
 await writeFile(path.join(root,'README.md'),readme.replaceAll('\r\n','\n').replaceAll('\n','\r\n'));
 assert.equal((await checkPluginVersion(root)).contentFingerprint,initial);
 const icon=await readFile(path.join(root,'assets','icon.png'));icon[0]^=1;await writeFile(path.join(root,'assets','icon.png'),icon);
 const refused=build(root);assert.notEqual(refused.status,0);assert.match(refused.stderr,/Released plugin content changed/);
}));

test('seal requires the exact qualified fingerprint and never rewrites a released version',async()=>fixture(async root=>{
 const before=await readFile(path.join(root,RELEASE_FILE),'utf8');
 await assert.rejects(sealVersion(root,'0'.repeat(64)),/Qualified fingerprint does not match/);
 assert.equal(await readFile(path.join(root,RELEASE_FILE),'utf8'),before);
 const fingerprint=await packageFingerprint(root);assert.equal((await sealVersion(root,fingerprint)).recorded,true);
 const sealed=await readFile(path.join(root,RELEASE_FILE),'utf8');
 assert.equal((await sealVersion(root,fingerprint)).recorded,false);
 assert.equal(await readFile(path.join(root,RELEASE_FILE),'utf8'),sealed);
 await writeFile(path.join(root,'docs','version-fixture.md'),'New package content.\n');
 await assert.rejects(sealVersion(root,await packageFingerprint(root)),/Released plugin content changed/);
 assert.equal(await readFile(path.join(root,RELEASE_FILE),'utf8'),sealed);
}));

async function holdWindowsPublication(directory,releaseAfterMarker){
 const code=releaseAfterMarker
  ? "const fs=require('node:fs'),path=require('node:path'),base=path.dirname(process.cwd());const timer=setInterval(()=>{if(fs.readdirSync(base).filter(n=>n.startsWith('build-')).some(n=>fs.existsSync(path.join(base,n,'package-provenance.json')))){clearInterval(timer);setTimeout(()=>process.exit(0),250);}},20);setTimeout(()=>process.exit(2),10000);process.stdout.write('ready');"
  : "process.stdout.write('ready');setTimeout(()=>process.exit(0),10000);";
 const child=spawn(process.execPath,['-e',code],{cwd:directory,stdio:['ignore','pipe','pipe'],windowsHide:true}),ended=once(child,'exit');
 let timer;
 try{await Promise.race([once(child.stdout,'data'),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Publication lock fixture did not start.')),3000);})]);}
 catch(e){if(child.exitCode===null&&child.signalCode===null)child.kill();await ended;throw e;}
 finally{clearTimeout(timer);}
 return {child,ended,async stop(){if(child.exitCode===null&&child.signalCode===null)child.kill();await ended;}};
}
test('Windows transient publication sharing retries the same move and preserves the sealed previous packet',{skip:process.platform!=='win32'},async()=>fixture(async root=>{
 const first=success(build(root));await sealVersion(root,first.contentFingerprint);const installed=success(build(root,false)),active=installed.output;
 const ledger=await readFile(path.join(root,RELEASE_FILE),'utf8');await writeFile(path.join(active,'fixture-owned-before.txt'),'Retain this exact fixture history.');
 const lock=await holdWindowsPublication(active,true);
 try{
  const out=success(build(root,false));assert.ok(out.publicationRetries>0);assert.ok(out.publicationRetries<=12);
  assert.equal(out.contentFingerprint,first.contentFingerprint);assert.equal(out.releaseState,'released');
  const previous=(await readdir(path.join(root,'.plugin-build'))).filter(n=>n.startsWith('previous-'));assert.ok(previous.length>=1);
  const retained=await Promise.all(previous.map(n=>readFile(path.join(root,'.plugin-build',n,'fixture-owned-before.txt'),'utf8').catch(e=>{if(e.code==='ENOENT')return null;throw e;})));
  assert.ok(retained.includes('Retain this exact fixture history.'));
  assert.equal(await readFile(path.join(root,RELEASE_FILE),'utf8'),ledger);
 }finally{await lock.stop();}
}));
test('Windows persistent publication sharing fails closed without deleting the active packet or recovery stage',{skip:process.platform!=='win32'},async()=>fixture(async root=>{
 const first=success(build(root));await sealVersion(root,first.contentFingerprint);const installed=success(build(root,false)),active=installed.output;
 const before=await readFile(path.join(active,'package-provenance.json'),'utf8'),ledger=await readFile(path.join(root,RELEASE_FILE),'utf8');
 await writeFile(path.join(active,'fixture-owned-before.txt'),'Keep this exact active fixture.');
 const lock=await holdWindowsPublication(active,false),start=Date.now();
 try{
  const result=build(root,false);assert.notEqual(result.status,0);assert.match(result.stderr,/EBUSY|EPERM|EACCES/);
  assert.ok(Date.now()-start>=1500);assert.ok(Date.now()-start<6000);
  assert.equal(await readFile(path.join(active,'package-provenance.json'),'utf8'),before);
  assert.equal(await readFile(path.join(active,'fixture-owned-before.txt'),'utf8'),'Keep this exact active fixture.');
  assert.equal(await readFile(path.join(root,RELEASE_FILE),'utf8'),ledger);
  assert.ok((await readdir(path.join(root,'.plugin-build'))).some(n=>n.startsWith('build-')));
 }finally{await lock.stop();}
}));
