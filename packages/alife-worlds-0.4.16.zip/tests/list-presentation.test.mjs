import test from 'node:test';
import assert from 'node:assert/strict';
import {configureScrollableList,preserveListPositions} from '../web/list-presentation.mjs';

const node=()=>({dataset:{},attributes:{},scrollTop:0,scrollLeft:0,setAttribute(k,v){this.attributes[k]=v;}});
test('five records stay natural; a sixth enables keyboard scrolling without dropping records',()=>{
 const list=node();list.children=Array.from({length:6},(_,id)=>({id}));
 configureScrollableList(list,5,'Assignments');assert.equal(list.dataset.longList,'false');assert.equal(list.tabIndex,-1);
 configureScrollableList(list,6,'Assignments');assert.equal(list.dataset.longList,'true');assert.equal(list.tabIndex,0);assert.equal(list.attributes['aria-label'],'Assignments · 6 items');assert.equal(list.children.length,6);
 configureScrollableList(list,0,'Assignments');assert.equal(list.dataset.longList,'false');assert.equal(list.tabIndex,-1);
});
test('refresh restores matching scroll regions without moving an unrelated or new list',()=>{
 const old=configureScrollableList(node(),20,'Assignments','actor:a');old.scrollTop=213;old.scrollLeft=17;
 let rows=[old];const restore=preserveListPositions({querySelectorAll:()=>rows});
 const next=configureScrollableList(node(),21,'Renamed actor assignments','actor:a'),other=configureScrollableList(node(),8,'Other actor','actor:b');other.scrollTop=35;rows=[next,other];restore();
 assert.equal(next.scrollTop,213);assert.equal(next.scrollLeft,17);assert.equal(other.scrollTop,35);
});
