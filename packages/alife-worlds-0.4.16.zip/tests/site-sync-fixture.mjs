// Fictional transport fixtures only. No native connection, Site or credentials.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createProjection} from '../lib/projection.mjs';
import {createDemo} from '../lib/demo.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {publicWorldId,publicWorldSnapshot} from '../lib/public-world.mjs';
import {createSiteBundleProducer} from '../lib/site-sync-producer.mjs';
import {createOwnerPreviewProjector} from '../lib/owner-preview-handler.mjs';
import {assertPublicWorldSnapshot} from '../lib/public-world-contract.mjs';
import {createLocalAppearance,LOCAL_PALETTE} from '../lib/local-world-appearance.mjs';
import '../web/launcher-world113/renderer.js';

export const projectId='11111111-1111-4111-8111-111111111111';
export const project='project-'+createHash('sha256').update(projectId).digest('hex').slice(0,24);
export const worldId=publicWorldId(projectId);
export const renderer={schemaVersion:1,bundleId:'fixture-world',worldVersion:'1.3.3',artifactSha256:'a'.repeat(64)};
export const ownerOrigin='https://owner.example';
export const roles=registry.map(({id,title,role})=>({id,title,role:role||id}));
export const configuration={project,worldId,roles,renderer,ownerOrigin};
export function refreshSiteOwnerPreview(dashboard){
 dashboard.ownerPreview=createOwnerPreviewProjector({registry,worldId,publicWorldSnapshot,assertPublicWorldSnapshot,createLocalAppearance,oracle:globalThis.AgentOutpost,descriptor:renderer,includeMetadata:true,palette:LOCAL_PALETTE})(dashboard);
 return dashboard.ownerPreview;
}
export async function siteBundleFixture({observedUtc=new Date().toISOString(),revision=1,metadataRevision=1}={}){
 const plan=createDemo(registry,'working');plan.observedUtc=new Date(Date.parse(observedUtc)-60000).toISOString();
 const dashboard=await createProjection(registry,plan);dashboard.project={...dashboard.project,id:projectId,name:'Fixture World'};dashboard.feed.observedUtc=observedUtc;
 dashboard.model.nativeMetadata={persistence:'available',revision:metadataRevision,contentHash:'b'.repeat(64)};
 for(const agent of dashboard.model.agents)Object.assign(agent,{model:null,modelSpeed:null,reasoningEffort:null,appliedModel:null,appliedModelState:'unknown',appliedModelSource:null,appliedModelObservedUtc:null,selectedModel:null,selectedModelState:'unknown',selectedModelSource:null,selectedModelObservedUtc:null,modelPresentationSource:'unknown',nameSource:'registry-fallback',nameState:'unknown',nameObservedUtc:null});
 dashboard.ruleCatalog=Object.fromEntries(['plugin','world'].map(scope=>[scope,{scope,revision:1,groups:[{id:'fixture-rules',title:'Fixture '+scope+' group',properties:[{id:'safe',title:'Fixture '+scope+' label',description:'A human fixture description.',text:'Follow the selected fixture '+scope+' instruction.',active:true,history:[{text:'HISTORICAL_FIXTURE_ONLY'}]},{id:'inactive',title:'Inactive fixture',text:'INACTIVE_FIXTURE_ONLY',active:false}]}]}]));
 refreshSiteOwnerPreview(dashboard);
 const catalog={schemaVersion:1,kind:'owner-world-catalog',worldId,observedUtc,sourceState:'current',currentId:'current',worlds:[{id:'current',name:'Fixture World',connection:{state:'ready',checkedUtc:observedUtc,target:{kind:'owner-private',url:ownerOrigin+'/'}}},{id:'other',name:'Other registered world',connection:{state:'unavailable',checkedUtc:null,target:null}}]};
 const producer=createSiteBundleProducer({project,projectId,worldId,registry,renderer,ownerOrigin,oracle:globalThis.AgentOutpost});
 const bundle=await producer.produce({revision,dashboard,plan,catalog});dashboard.ownerPreview=bundle.ownerPreview;
 return{bundle,producer,dashboard,plan,catalog};
}
export function r2Fixture({beforePut,afterPut}={}){
 const rows=new Map(),puts=[];
 const object=(key,text)=>({key,size:Buffer.byteLength(text),etag:createHash('sha256').update(text).digest('hex'),get httpEtag(){return JSON.stringify(this.etag);}});
 const store={rows,puts,async get(key){const text=rows.get(key);return text===undefined?null:{...object(key,text),text:async()=>text};},async put(key,text,options){
  assert(options?.onlyIf instanceof Headers,'R2 write must use an atomic conditional header');
  const match=options.onlyIf.get('If-Match'),absent=options.onlyIf.get('If-None-Match');
  assert(match!==null&&absent===null||match===null&&absent==='*','Exactly one compare/create precondition');
  const call={key,text,match,absent,applied:false};puts.push(call);await beforePut?.(call,store);
  const current=rows.get(key);if(absent==='*'&&current!==undefined||match!==null&&(current===undefined||object(key,current).httpEtag!==match))return null;
  rows.set(key,text);call.applied=true;const result=object(key,text);await afterPut?.(call,store);return result;
 }};return store;
}
