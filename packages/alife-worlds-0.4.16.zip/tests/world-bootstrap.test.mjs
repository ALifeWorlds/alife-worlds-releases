import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,rm,lstat,copyFile,symlink} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID,createHash} from 'node:crypto';
import {spawn,spawnSync} from 'node:child_process';
import {once} from 'node:events';
import {collectPackageInputs,packageFingerprint,sealVersion} from '../lib/plugin-version.mjs';
import {prepareWorld,acknowledgeRole,reserveCreation,recordCreated,inspectWorld,nativeSessionMetadata,findNativeSession,runtimeForWorld,recordWorldService,includeProject,coreResetPlan,BOOTSTRAP_DIR,privateLauncherProfileTarget,beginWorld,resolveInvokingProject,approvedCreationSettings,awaitRoleBinding,reserveContinuation,recordContinuation,reserveDirectorTitle,recordDirectorTitle} from '../lib/world-bootstrap.mjs';
const source=fileURLToPath(new URL('../',import.meta.url)),scratch=path.join(source,'runtime/test-fixtures');
const sha=b=>createHash('sha256').update(b).digest('hex');
async function fixture(fn){
 await mkdir(scratch,{recursive:true});const base=await mkdtemp(path.join(scratch,'world-bootstrap-')),root=path.join(base,'project'),foreign=path.join(base,'other-project'),codexHome=path.join(base,'native-fixture');
 const packet=path.join(base,'packet');for(const file of await collectPackageInputs(source)){const dest=path.join(packet,file);await mkdir(path.dirname(dest),{recursive:true});await copyFile(path.join(source,file),dest);}
 await mkdir(root);await mkdir(foreign);await writeFile(path.join(root,'AGENTS.md'),'# Fixture project\nPreserve the human project and existing actors.\n');await writeFile(path.join(root,'.gitignore'),'existing-user-rule\n');
 const projectId=randomUUID(),foreignId=randomUUID(),threads={director:randomUUID(),support:randomUUID(),'world-requests':randomUUID()};
 async function native(id,workspace=root,{daysAgo=0,model='gpt-6.1-sol',effort='xhigh',extra=[]}={}){
  const day=new Date();day.setUTCDate(day.getUTCDate()-daysAgo);const folder=path.join(codexHome,'sessions',String(day.getUTCFullYear()),String(day.getUTCMonth()+1).padStart(2,'0'),String(day.getUTCDate()).padStart(2,'0'));await mkdir(folder,{recursive:true});
  const file=path.join(folder,'rollout-fixture-'+id+'.jsonl'),stamp=new Date().toISOString();
  const rows=[{timestamp:stamp,type:'session_meta',payload:{id,cwd:workspace}},{timestamp:stamp,type:'turn_context',payload:{cwd:workspace,model,effort,service_tier:'default'}},...extra,{timestamp:stamp,type:'event_msg',payload:{type:'task_completed',turn_id:'fixture'}}];
  await writeFile(file,rows.map(r=>JSON.stringify(r)).join('\n')+'\n');
  return {threadId:id,sessionPath:file};
 }
 const director=await native(threads.director,root,{model:'existing-selected-model',effort:'high'});
 const request={projectRoot:root,projectId,projectName:'Fixture World',goal:'Set up this isolated fictional world only.',explicitSetup:true,settings:{model:'gpt-6.1-sol',thinking:'xhigh',approvedByHuman:true},existingAgents:[]};
 const stateFile=path.join(root,BOOTSTRAP_DIR,'bootstrap.json'),state=()=>readFile(stateFile,'utf8').then(JSON.parse),slotPath=id=>path.join(root,BOOTSTRAP_DIR,'agents',id);
 async function acknowledge(id,actor,operationId){const s=await state();return acknowledgeRole(root,id,actor,{fullRead:true,contractSha256:s.roles[id].contractSha256,operationId});}
 async function bind(id,reservation,creator){
  const context=await native(threads[id]);await recordCreated(root,id,reservation.operationId,{threadId:threads[id],hostId:'local',projectId,cwd:root,codexHome},creator);await acknowledge(id,context,reservation.operationId);return context;
 }
 async function connected(){
  await prepareWorld(packet,request,director);await acknowledge('director',director);
  const s=await reserveCreation(root,'support',director),support=await bind('support',s,director);
  const w=await reserveCreation(root,'world-requests',support),world=await bind('world-requests',w,support);
  return {support,world,s,w};
 }
 try{await fn({base,root,packet,foreign,codexHome,projectId,foreignId,threads,native,director,request,stateFile,state,slotPath,acknowledge,bind,connected});}
 finally{const resolved=path.resolve(base);assert.ok(resolved.startsWith(path.resolve(scratch)+path.sep));await rm(resolved,{recursive:true,force:true});}
}
test('setup refuses missing approval and a foreign current session before creating project data',async()=>fixture(async f=>{
 await assert.rejects(prepareWorld(f.packet,{...f.request,settings:{...f.request.settings,approvedByHuman:false}},f.director),/human-approved/);
 const foreign=await f.native(randomUUID(),f.foreign);await assert.rejects(prepareWorld(f.packet,f.request,foreign),/selected project/);
 await assert.rejects(lstat(path.join(f.root,BOOTSTRAP_DIR)),e=>e.code==='ENOENT');
 assert.equal(await readFile(path.join(f.root,'.gitignore'),'utf8'),'existing-user-rule\n');
}));
test('project snapshot is neutral, complete inheritance is materialized, and repeat setup preserves it',async()=>fixture(async f=>{
 await mkdir(path.join(f.root,'data'));await writeFile(path.join(f.root,'data/private-task.json'),'DO-NOT-COPY-PRIVATE-TASK');
 const out=await prepareWorld(f.packet,f.request,f.director);assert.equal(out.status,'onboarding');assert.equal(out.roles.length,3);assert.equal(out.roles.find(r=>r.id==='support').title,'Agent Support');
 const s=await f.state(),full=await readFile(path.join(f.slotPath('support'),'AGENT.md'),'utf8');
 assert.ok(full.includes(await readFile(path.join(source,'roles/SHARED.md'),'utf8')));assert.ok(full.includes(await readFile(path.join(source,'docs/MASTER-PROMPT.md'),'utf8')));
 assert.ok(full.includes('Preserve the human project and existing actors.'));
 const checkpoint=JSON.parse(await readFile(path.join(f.slotPath('support'),'checkpoint.json'),'utf8'));assert.equal(checkpoint.fullInstructions,full);
 assert.equal(sha(full),s.roles.support.contractSha256);
 const neutral=JSON.parse(await readFile(path.join(out.runtimeRoot,'data/project-state.json'),'utf8'));assert.deepEqual(neutral.agents,[]);assert.deepEqual(neutral.tasks,[]);assert.deepEqual(neutral.events,[]);
 await assert.rejects(readFile(path.join(out.runtimeRoot,'data/private-task.json')),e=>e.code==='ENOENT');
 const before=await readFile(f.stateFile,'utf8');await prepareWorld(f.packet,f.request,f.director);assert.equal(await readFile(f.stateFile,'utf8'),before);
 assert.equal(await readFile(path.join(f.root,'.gitignore'),'utf8'),'existing-user-rule\n/.alife-worlds/\n');
 await assert.rejects(prepareWorld(f.packet,{...f.request,projectId:randomUUID()},f.director),/identity changed/);
}));
test('interrupted materialization resumes its original snapshot without resetting the episode',async()=>fixture(async f=>{
 const out=await prepareWorld(f.packet,f.request,f.director),s=await f.state();s.phase='preparing';await writeFile(f.stateFile,JSON.stringify(s));
 await rm(path.join(out.runtimeRoot,'package.json'));
 const result=await prepareWorld(f.packet,f.request,f.director);assert.equal(result.status,'onboarding');assert.equal((await f.state()).episodeId,s.episodeId);assert.ok(await readFile(path.join(out.runtimeRoot,'package.json')));
}));
test('Director creates only Agent Support, which creates World Requests after its own receipt',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);
 await assert.rejects(reserveCreation(f.root,'support',f.director),/onboarded Director/);await f.acknowledge('director',f.director);
 const reservation=await reserveCreation(f.root,'support',f.director);
 assert.equal(reservation.canCreate,true);assert.equal(reservation.toolRequest.tool,'create_thread');
 assert.equal(reservation.toolRequest.arguments.title,'Agent Support');assert.equal(reservation.toolRequest.arguments.model,'gpt-6.1-sol');assert.equal(reservation.toolRequest.arguments.thinking,'xhigh');
 assert.deepEqual(reservation.toolRequest.arguments.target,{type:'project',projectId:f.projectId,environment:{type:'local'}});
 assert.ok(reservation.toolRequest.arguments.prompt.includes(await readFile(path.join(f.slotPath('support'),'AGENT.md'),'utf8')));
 const checkpoint=JSON.parse(await readFile(path.join(f.slotPath('support'),'checkpoint.json'),'utf8'));assert.equal(checkpoint.initialPrompt,reservation.toolRequest.arguments.prompt);
 assert.equal((await reserveCreation(f.root,'support',f.director)).canCreate,false);
 await assert.rejects(reserveCreation(f.root,'world-requests',f.director),/Agent Support/);
 await assert.rejects(acknowledgeRole(f.root,'support',f.director,{fullRead:true,contractSha256:(await f.state()).roles.support.contractSha256,operationId:reservation.operationId}),/another role/);
 const support=await f.bind('support',reservation,f.director);
 const wr=await reserveCreation(f.root,'world-requests',support);await f.bind('world-requests',wr,support);
 const out=await inspectWorld(f.root);assert.equal(out.status,'core-connected');assert.equal(new Set(out.roles.map(r=>r.threadId)).size,3);
 assert.ok(out.roles.every(r=>r.connected&&r.onboarded));assert.equal(out.roles[0].managedCreated,false);
 assert.equal(out.roles[0].appliedSettings.model,'existing-selected-model');assert.ok(out.roles.slice(1).every(r=>r.appliedSettings.model==='gpt-6.1-sol'&&r.appliedSettings.reasoningEffort==='xhigh'));
 assert.equal((await reserveCreation(f.root,'support',f.director)).status,'reuse');
}));
test('queued or unknown launches are not replayed and foreign native returns are refused',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);
 const r=await reserveCreation(f.root,'support',f.director),before=await readFile(f.stateFile,'utf8');
 await assert.rejects(recordCreated(f.root,'support',r.operationId,{threadId:randomUUID(),hostId:'local',projectId:f.foreignId,cwd:f.foreign},f.director),/selected project/);
 assert.equal(await readFile(f.stateFile,'utf8'),before);
 const q=await recordCreated(f.root,'support',r.operationId,{clientThreadId:'pending-fixture',hostId:'local',projectId:f.projectId,cwd:f.root},f.director);assert.equal(q.status,'queued');
 const again=await reserveCreation(f.root,'support',f.director);assert.equal(again.canCreate,false);assert.equal(again.operationId,r.operationId);assert.equal(again.clientThreadId,'pending-fixture');
 await assert.rejects(recordCreated(f.root,'support',r.operationId,{threadId:f.threads.director,hostId:'local',projectId:f.projectId,cwd:f.root},f.director),/duplicate|Invalid/);
 assert.equal((await inspectWorld(f.root)).unknownEffects.length,1);
}));
test('existing same-folder agents and explicitly included other folders are protected from core reset',async()=>fixture(async f=>{
 const existingId=randomUUID(),existing=await f.native(existingId);
 f.request.existingAgents=[{threadId:existingId,title:'Existing project helper',projectId:f.projectId,projectRoot:f.root,sessionPath:existing.sessionPath}];
 const {support}=await f.connected();const before=await f.state();
 assert.equal(before.existingAgents.length,1);assert.equal(before.existingAgents[0].managedCreated,false);assert.equal(before.existingAgents[0].readOnly,true);
 const outsideId=randomUUID(),outside=await f.native(outsideId,f.foreign);
 const request={projectRoot:f.foreign,projectId:f.foreignId,projectName:'Other project',explicitInclude:true,members:[{threadId:outsideId,title:'Existing external agent',projectId:f.foreignId,projectRoot:f.foreign,sessionPath:outside.sessionPath}]};
 await assert.rejects(includeProject(f.root,{...request,explicitInclude:false},f.director),/Explicit other-project/);
 await includeProject(f.root,request,f.director);await includeProject(f.root,request,f.director);
 const s=await f.state();assert.equal(s.externalSources.length,1);assert.equal(s.externalSources[0].members[0].readOnly,true);
 const plan=await coreResetPlan(f.root,{explicitReset:true,projectId:f.projectId},support);
 assert.deepEqual(plan.targets.map(t=>t.roleId).sort(),['support','world-requests']);assert.equal(plan.nativeEffectsPerformed,0);
 for(const id of [f.threads.director,existingId,outsideId]){assert.ok(plan.preservedThreadIds.includes(id));assert.ok(!plan.targets.some(t=>t.threadId===id));}
 const foreignBytes=await readFile(outside.sessionPath,'utf8');await coreResetPlan(f.root,{explicitReset:true,projectId:f.projectId},support);assert.equal(await readFile(outside.sessionPath,'utf8'),foreignBytes);
 await assert.rejects(coreResetPlan(f.root,{explicitReset:false,projectId:f.projectId},support),/Explicit reset/);
}));
test('reset waits for unresolved effects; protected existing identities cannot become newly created core',async()=>fixture(async f=>{
 const existing=await f.native(randomUUID());f.request.existingAgents=[{threadId:existing.threadId,title:'Pre-existing',projectId:f.projectId,projectRoot:f.root,sessionPath:existing.sessionPath}];
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);const r=await reserveCreation(f.root,'support',f.director);
 await assert.rejects(recordCreated(f.root,'support',r.operationId,{threadId:existing.threadId,hostId:'local',projectId:f.projectId,cwd:f.root,codexHome:f.codexHome},f.director),/Invalid|duplicate/);
 const support=await f.bind('support',r,f.director);await reserveCreation(f.root,'world-requests',support);
 await assert.rejects(coreResetPlan(f.root,{explicitReset:true,projectId:f.projectId},support),/pending or unknown/);
}));
test('exact native metadata lookup supports older sessions and exposes no prompt content',async()=>fixture(async f=>{
 const id=randomUUID(),old=await f.native(id,f.foreign,{daysAgo:12,extra:[{type:'response_item',payload:{type:'message',content:'PRIVATE-FIXTURE-PROMPT'}}]});
 const found=await findNativeSession(id,f.foreign,{codexHome:f.codexHome});assert.equal(found.sessionPath,old.sessionPath);assert.ok(!JSON.stringify(found).includes('PRIVATE-FIXTURE-PROMPT'));
 await assert.rejects(nativeSessionMetadata(old.sessionPath,{threadId:id,projectRoot:f.root}),/selected project/);
}));
test('the vendored read-only service starts on its own ephemeral port with three synthetic native bindings',async()=>fixture(async f=>{
 await sealVersion(f.packet,await packageFingerprint(f.packet)); // Only this disposable fixture qualifies its default scene.
 const {world}=await f.connected(),before=await readFile(path.join(f.root,'AGENTS.md'),'utf8');
 const child=spawn(process.execPath,[path.join(source,'scripts/bootstrap-world.mjs'),'start-world','--project-root',f.root],{cwd:f.root,env:{...process.env,CODEX_THREAD_ID:f.threads['world-requests'],CODEX_HOME:f.codexHome},stdio:['ignore','pipe','pipe'],windowsHide:true});
 let output='',stderr='';child.stderr.on('data',b=>{stderr+=b;});
 try{
  const result=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Fixture service startup timed out: '+stderr)),20000);child.once('exit',code=>{clearTimeout(timer);reject(Error('Fixture service exited '+code+': '+stderr));});child.stdout.on('data',b=>{output+=b;try{const value=JSON.parse(output);if(value.status==='world-started'){clearTimeout(timer);resolve(value);}}catch{}});});
  assert.match(result.origin,/^http:\/\/127\.0\.0\.1:\d+$/);assert.equal(result.commandsEnabled,false);
  assert.equal(result.operatorUrl,result.origin+'/?project='+encodeURIComponent(f.projectId));
  const full=await fetch(result.operatorUrl);assert.equal(full.status,200);const fullHtml=await full.text();for(const marker of ['id="alife-world-first"','id="wf-world"','id="wf-work"'])assert.ok(fullHtml.includes(marker));
  const operator=await fetch(result.origin+'/operator?project='+encodeURIComponent(f.projectId));assert.equal(operator.status,200);const operatorHtml=await operator.text();for(const marker of ['id="task-board"','id="rule-library"','src="/app.mjs"'])assert.ok(operatorHtml.includes(marker));
  assert.equal((await fetch(result.origin+'/?project=foreign-fixture')).status,404);
  const context=await runtimeForWorld(f.root,world),health=await fetch(result.origin+'/api/world-launcher?project='+f.projectId).then(r=>r.json());
  assert.equal(health.projectRootSha256,context.rootSha256);assert.equal(health.projectId,f.projectId);
  const view=await fetch(result.origin+'/api/world-view?project='+context.worldId).then(r=>r.json());assert.equal(view.summary.connected,3);
  assert.equal(result.viewerUrl,result.origin+'/world/view?project='+context.worldId);const spectator=await fetch(result.viewerUrl).then(r=>r.text());assert.ok(spectator.includes('world-view.mjs'));assert.ok(!spectator.includes('id="task-board"'));assert.equal((await fetch(result.origin+'/?project='+context.worldId)).status,404);assert.equal((await fetch(result.origin+'/world/view?project='+f.projectId)).status,404);
  const legacy=await f.state();delete legacy.world.operatorUrl;await writeFile(f.stateFile,JSON.stringify(legacy,null,2)+'\n');
  const beforeReuse=await readFile(f.stateFile,'utf8');
  const reused=spawnSync(process.execPath,[path.join(f.packet,'scripts/bootstrap-world.mjs'),'start-world'],{cwd:f.root,env:{...process.env,CODEX_THREAD_ID:f.threads['world-requests'],CODEX_HOME:f.codexHome},encoding:'utf8',windowsHide:true,timeout:10000});
  assert.equal(reused.status,0,reused.stderr);const existing=JSON.parse(reused.stdout);assert.equal(existing.status,'existing-world');assert.equal(existing.pid,child.pid);assert.equal(existing.origin,result.origin);assert.equal(existing.operatorUrl,result.operatorUrl);assert.equal(existing.viewerUrl,result.viewerUrl);assert.equal(await readFile(f.stateFile,'utf8'),beforeReuse);
  const profile=path.join(f.base,'private-launcher.json'),other={id:'other',label:'Other project',projectId:f.foreignId,worldId:'world-foreign-fixture',projectRoot:f.foreign,origin:'http://127.0.0.1:1'};await writeFile(profile,JSON.stringify({schemaVersion:1,worlds:[other]}));
  const register=spawnSync(process.execPath,[path.join(f.packet,'scripts/bootstrap-world.mjs'),'register-launcher'],{cwd:f.root,env:{...process.env,CODEX_THREAD_ID:f.threads['world-requests'],CODEX_HOME:f.codexHome,ALIFE_WORLD_PROFILE:profile},input:JSON.stringify({explicitRegister:true}),encoding:'utf8',windowsHide:true,timeout:10000});assert.equal(register.status,0,register.stderr);const registered=JSON.parse(register.stdout);assert.equal(registered.operatorUrl,result.operatorUrl);assert.equal(registered.viewerUrl,result.viewerUrl);assert.equal(registered.otherWorldsPreserved,1);assert.deepEqual(JSON.parse(await readFile(profile,'utf8')).worlds[0],other);assert.equal(await readFile(f.stateFile,'utf8'),beforeReuse);
  const recorded=await recordWorldService(f.root,result.origin,child.pid,world);assert.equal(recorded.pid,child.pid);
  assert.equal(await readFile(path.join(f.root,'AGENTS.md'),'utf8'),before);
 }finally{
  if(child.exitCode===null){const ended=once(child,'exit');child.kill('SIGTERM');await ended;}
 }
}));

test('private profile registration rejects package/cache destinations and redirected parents before any write',async()=>fixture(async f=>{
 const nested=path.join(f.base,'private-config','nested','profile.json');
 assert.equal(await privateLauncherProfileTarget(f.packet,nested,{codexHome:f.codexHome}),nested);
 await assert.rejects(lstat(path.dirname(nested)),e=>e.code==='ENOENT');
 await assert.rejects(privateLauncherProfileTarget(f.packet,path.join(f.packet,'new','profile.json'),{codexHome:f.codexHome}),/package or plugin-cache/);
 await assert.rejects(privateLauncherProfileTarget(f.packet,path.join(f.codexHome,'plugins','cache','different','profile.json'),{codexHome:f.codexHome}),/package or plugin-cache/);
 const redirected=path.join(f.base,'redirected');
 await symlink(f.foreign,redirected,process.platform==='win32'?'junction':'dir');
 await assert.rejects(privateLauncherProfileTarget(f.packet,path.join(redirected,'new','profile.json'),{codexHome:f.codexHome}),/Redirected/);
 await assert.rejects(lstat(path.join(f.foreign,'new')),e=>e.code==='ENOENT');
}));

test('opaque saved-project identities survive preparation, native payloads and explicit external inclusion',async()=>fixture(async f=>{
 const opaque='saved-local:opaque-fixture',linked='g-p-fixture-opaque';
 f.request.projectId=opaque;
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);
 assert.equal((await inspectWorld(f.root)).projectId,opaque);
 const r=await reserveCreation(f.root,'support',f.director,{contractRoot:f.packet});
 assert.equal(r.toolRequest.arguments.target.projectId,opaque);
 const outside=await f.native(randomUUID(),f.foreign);
 await includeProject(f.root,{projectRoot:f.foreign,projectId:linked,projectName:'Explicit fixture mapping',explicitInclude:true,members:[{threadId:outside.threadId,title:'External fixture actor',projectId:linked,projectRoot:f.foreign,sessionPath:outside.sessionPath}]},f.director);
 assert.equal((await f.state()).externalSources[0].projectId,linked);
}));

test('current universal and project instructions refresh only the unreserved incoming role with recoverable preimages',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);
 const directorBefore=await readFile(path.join(f.slotPath('director'),'AGENT.md'),'utf8'),old=await readFile(path.join(f.slotPath('support'),'AGENT.md'),'utf8'),oldCheckpoint=await readFile(path.join(f.slotPath('support'),'checkpoint.json'),'utf8');
 const universalFile=path.join(f.packet,'rules','universal.json'),u=JSON.parse(await readFile(universalFile,'utf8'));
 u.groups.push({id:'fixture-current',title:'Fixture current instruction',properties:[{id:'preservation',title:'Current preservation instruction',description:'Keep the latest fixture custody instruction during intake.',text:'Preserve the newest fixture custody instruction.',active:true,implementation:'documented',origin:'human',history:[]}]});
 u.revision++;await writeFile(universalFile,JSON.stringify(u));
 await writeFile(path.join(f.root,'AGENTS.md'),'# Fixture project\nUse the newest fixture project instruction.\n');
 const r=await reserveCreation(f.root,'support',f.director,{contractRoot:f.packet}),s=await f.state();
 assert.ok(r.toolRequest.arguments.prompt.includes('Preserve the newest fixture custody instruction.'));
 assert.ok(r.toolRequest.arguments.prompt.includes('Use the newest fixture project instruction.'));
 assert.ok(r.toolRequest.arguments.prompt.includes(path.join(f.packet,'scripts/bootstrap-world.mjs')));
 const updated=await readFile(path.join(f.slotPath('support'),'AGENT.md'),'utf8');
 assert.notEqual(updated,old);assert.equal(sha(updated),s.roles.support.contractSha256);
 assert.equal(await readFile(path.join(f.slotPath('director'),'AGENT.md'),'utf8'),directorBefore);
 const recovery=JSON.parse(await readFile(path.join(f.root,BOOTSTRAP_DIR,'contract-recovery',s.roles.support.contractRefresh.id+'.json'),'utf8'));
 assert.equal(recovery.files['AGENT.md'].before,old);assert.equal(recovery.files['checkpoint.json'].before,oldCheckpoint);
 const reservedBytes=await readFile(path.join(f.slotPath('support'),'checkpoint.json'),'utf8');
 await writeFile(path.join(f.root,'AGENTS.md'),'# Fixture project\nA later change must not replay an existing reservation.\n');
 const again=await reserveCreation(f.root,'support',f.director,{contractRoot:f.packet});
 assert.equal(again.canCreate,false);assert.equal(again.operationId,r.operationId);
 assert.equal(await readFile(path.join(f.slotPath('support'),'checkpoint.json'),'utf8'),reservedBytes);
 assert.equal((await f.state()).effects.length,1);
}));

test('an edited draft is preserved and blocks creation instead of silently replacing its custody',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);
 const file=path.join(f.slotPath('support'),'AGENT.md'),original=await readFile(file,'utf8'),edited=original+'\nHuman draft change that needs reconciliation.\n';
 await writeFile(file,edited);await writeFile(path.join(f.root,'AGENTS.md'),'# New fixture instruction\n');
 await assert.rejects(reserveCreation(f.root,'support',f.director,{contractRoot:f.packet}),/recorded draft/);
 assert.equal(await readFile(file,'utf8'),edited);assert.equal((await f.state()).roles.support.creation,null);
}));

test('interrupted draft refresh resumes exact recovered bytes before one new reservation',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);
 await writeFile(path.join(f.root,'AGENTS.md'),'# Changed fixture project\nCarry this current instruction.\n');
 await reserveCreation(f.root,'support',f.director,{contractRoot:f.packet});
 const s=await f.state(),slot=s.roles.support,recovery=JSON.parse(await readFile(path.join(f.root,BOOTSTRAP_DIR,'contract-recovery',slot.contractRefresh.id+'.json'),'utf8'));
 // Simulate the prior disk boundary: recovery/state persisted, one file replaced, no native reservation emitted.
 slot.creation=null;slot.contractSha256=recovery.fromContractSha256;slot.retirementSha256=sha(recovery.files['RETIREMENT.md'].before);slot.contractRefresh.state='pending';s.effects=[];
 await writeFile(f.stateFile,JSON.stringify(s));
 await writeFile(path.join(f.slotPath('support'),'AGENT.md'),recovery.files['AGENT.md'].after);
 for(const name of ['RETIREMENT.md','checkpoint.json'])await writeFile(path.join(f.slotPath('support'),name),recovery.files[name].before);
 const r=await reserveCreation(f.root,'support',f.director,{contractRoot:f.packet});
 assert.equal(r.canCreate,true);assert.ok(r.toolRequest.arguments.prompt.includes('Carry this current instruction.'));
 assert.equal((await f.state()).roles.support.contractRefresh.state,'applied');assert.equal((await f.state()).effects.length,1);
}));

async function fixtureProfile(f,value={schemaVersion:1,approvedByHuman:true,model:'gpt-6.1-sol',thinking:'xhigh'}){
 const file=path.join(f.base,'core-creation-profile.json');await writeFile(file,JSON.stringify(value));return file;
}
function fixtureContext(f){return {nativeThread:{id:f.threads.director,kind:'codex',hostId:'local',projectId:null,cwd:f.root},nativeProjects:[{projectId:f.projectId,projectKind:'local',hostId:'local',path:f.root,label:'Fixture World'}],goal:f.request.goal,existingAgents:[]};}

test('automatic begin derives the unique saved path despite null thread projectId and loads the approved private baseline',async()=>fixture(async f=>{
 const profile=await fixtureProfile(f),out=await beginWorld(f.packet,fixtureContext(f),f.director,{projectRoot:f.root,creationProfilePath:profile});
 assert.equal(out.projectId,f.projectId);assert.equal(out.projectRoot,f.root);assert.equal(out.roles.length,3);
 await f.acknowledge('director',f.director);const r=await reserveCreation(f.root,'support',f.director);
 assert.equal(r.toolRequest.arguments.model,'gpt-6.1-sol');assert.equal(r.toolRequest.arguments.thinking,'xhigh');
 assert.equal(r.toolRequest.arguments.target.projectId,f.projectId);
 assert.equal((await f.state()).roles.director.threadId,f.threads.director);
 assert.equal((await inspectWorld(f.root)).roles[0].appliedSettings.model,'existing-selected-model');
 assert.ok(!r.toolRequest.arguments.prompt.includes('undefined'));
}));
test('automatic context refuses foreign, ambiguous and cloud-only mappings before any project effect',async()=>fixture(async f=>{
 const ctx=fixtureContext(f),input={projectRoot:f.root,thread:ctx.nativeThread,projects:ctx.nativeProjects};
 await assert.rejects(resolveInvokingProject({...input,thread:{...input.thread,cwd:f.foreign}},f.director),/actual invoking/);
 await assert.rejects(resolveInvokingProject({...input,thread:{...input.thread,projectId:f.foreignId}},f.director),/identities conflict/);
 await assert.rejects(resolveInvokingProject({...input,projects:[...input.projects,{...input.projects[0],projectId:f.foreignId}]},f.director),/unique/);
 await assert.rejects(resolveInvokingProject({...input,projects:[{...input.projects[0],projectKind:'chatgpt',hostId:null}]},f.director),/unique/);
 await assert.rejects(lstat(path.join(f.root,BOOTSTRAP_DIR)),e=>e.code==='ENOENT');
 assert.equal(await readFile(path.join(f.root,'.gitignore'),'utf8'),'existing-user-rule\n');
}));
test('private creation policy is bounded, approved and external; explicit approved overrides remain deliberate',async()=>fixture(async f=>{
 const profile=await fixtureProfile(f);assert.deepEqual(await approvedCreationSettings(f.packet,undefined,{profilePath:profile}),{model:'gpt-6.1-sol',thinking:'xhigh',approvedByHuman:true});
 for(const value of [
  {schemaVersion:1,approvedByHuman:false,model:'gpt-6.1-sol',thinking:'xhigh'},
  {schemaVersion:1,approvedByHuman:true,model:'gpt-6.1-sol',thinking:'unsupported'},
  {schemaVersion:1,approvedByHuman:true,model:'gpt-6.1-sol',thinking:'xhigh',extra:'not-allowed'}
 ]){await writeFile(profile,JSON.stringify(value));await assert.rejects(approvedCreationSettings(f.packet,undefined,{profilePath:profile}));}
 await writeFile(profile,'x'.repeat(8193));await assert.rejects(approvedCreationSettings(f.packet,undefined,{profilePath:profile}),/oversized/);
 await assert.rejects(approvedCreationSettings(f.packet,undefined,{profilePath:path.join(f.base,'missing-policy.json')}),/unavailable/);
 await assert.rejects(approvedCreationSettings(f.packet,undefined,{profilePath:path.join(f.packet,'profile.json')}),/package/);
 const override={model:'fixture-human-choice',thinking:'high',approvedByHuman:true};
 assert.deepEqual(await approvedCreationSettings(f.packet,override,{profilePath:path.join(f.base,'missing-policy.json')}),override);
 await assert.rejects(approvedCreationSettings(f.packet,{...override,approvedByHuman:false}),/human-approved/);
 const redirected=path.join(f.base,'redirected-policy');await symlink(f.foreign,redirected,process.platform==='win32'?'junction':'dir');
 await writeFile(path.join(f.foreign,'profile.json'),JSON.stringify({schemaVersion:1,approvedByHuman:true,model:'gpt-6.1-sol',thinking:'xhigh'}));
 await assert.rejects(approvedCreationSettings(f.packet,undefined,{profilePath:path.join(redirected,'profile.json')}),/Redirected/);
}));
test('existing approved schema1 episode reuses its core identities and homes without a new profile or re-setup',async()=>fixture(async f=>{
 await f.connected();const s=await f.state();s.source.version='0.1.5';await writeFile(f.stateFile,JSON.stringify(s));
 const stateBefore=await readFile(f.stateFile,'utf8'),bindingsBefore=await readFile(path.join(f.root,BOOTSTRAP_DIR,'agent-bindings.json'),'utf8');
 const homes=await Promise.all(['director','support','world-requests'].map(id=>readFile(path.join(f.slotPath(id),'checkpoint.json'),'utf8')));
 const out=await beginWorld(f.packet,fixtureContext(f),f.director,{projectRoot:f.root,creationProfilePath:path.join(f.base,'missing-policy.json')});
 assert.equal(out.status,'core-connected');assert.equal(await readFile(f.stateFile,'utf8'),stateBefore);
 assert.equal(await readFile(path.join(f.root,BOOTSTRAP_DIR,'agent-bindings.json'),'utf8'),bindingsBefore);
 assert.deepEqual(await Promise.all(['director','support','world-requests'].map(id=>readFile(path.join(f.slotPath(id),'checkpoint.json'),'utf8'))),homes);
 assert.equal((await reserveCreation(f.root,'support',f.director)).canCreate,false);
}));
test('finite own binding handshake accepts early receipt then original creator binding without another launch',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);
 const r=await reserveCreation(f.root,'support',f.director),support=await f.native(f.threads.support);
 assert.equal((await f.acknowledge('support',support,r.operationId)).status,'awaiting-creator-binding');
 assert.equal((await awaitRoleBinding(f.root,'support',support,{operationId:r.operationId,timeoutMs:0})).status,'awaiting-creator-binding');
 await assert.rejects(awaitRoleBinding(f.root,'support',f.director,{operationId:r.operationId,timeoutMs:0}),/Own pending/);
 const waiting=awaitRoleBinding(f.root,'support',support,{operationId:r.operationId,timeoutMs:1000});
 await new Promise(resolve=>setTimeout(resolve,50));
 await recordCreated(f.root,'support',r.operationId,{threadId:f.threads.support,hostId:'local',projectId:f.projectId,cwd:f.root,codexHome:f.codexHome},f.director);
 assert.equal((await waiting).status,'bound');assert.equal((await f.state()).effects.filter(e=>e.kind==='native-create').length,1);
}));
test('startup continuation reserves the exact existing child once and preserves unknown sends',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);
 const r=await reserveCreation(f.root,'support',f.director),support=await f.bind('support',r,f.director);
 const continued=await reserveContinuation(f.root,'support',f.director,{contractRoot:f.packet});
 assert.equal(continued.canSend,true);assert.equal(continued.toolRequest.tool,'send_message_to_thread');
 assert.equal(continued.toolRequest.arguments.threadId,f.threads.support);
 const before=await readFile(f.stateFile,'utf8'),again=await reserveContinuation(f.root,'support',f.director);
 assert.equal(again.canSend,false);assert.equal(again.operationId,continued.operationId);assert.equal(await readFile(f.stateFile,'utf8'),before);
 await assert.rejects(recordContinuation(f.root,'support',continued.operationId,{threadId:f.threads['world-requests']},f.director),/original same-core/);
 await assert.rejects(coreResetPlan(f.root,{explicitReset:true,projectId:f.projectId},support),/pending or unknown/);
 await recordContinuation(f.root,'support',continued.operationId,{threadId:f.threads.support},f.director);
 assert.equal((await reserveContinuation(f.root,'support',f.director)).canSend,false);
 await reserveCreation(f.root,'world-requests',support);
 assert.equal((await reserveContinuation(f.root,'support',f.director)).status,'already-progressing');
 assert.equal((await f.state()).effects.filter(e=>e.kind==='native-continue').length,1);
}));
test('incoming contracts retain full ancestor instructions and the explicit core destination scope',async()=>fixture(async f=>{
 const inherited='# Fixture ancestor instructions\nUnrelated orchestration helpers use the approved helper home.\n';
 await writeFile(path.join(f.base,'AGENTS.md'),inherited);await prepareWorld(f.packet,f.request,f.director);
 const full=await readFile(path.join(f.slotPath('support'),'AGENT.md'),'utf8');
 assert.ok(full.includes(inherited));assert.ok(full.includes(await readFile(path.join(f.root,'AGENTS.md'),'utf8')));
 assert.ok(full.includes('this exact project for its core chats, homes and runtime'));
 assert.equal(await readFile(path.join(f.base,'AGENTS.md'),'utf8'),inherited);
}));
test('actual begin CLI uses its invoking cwd and isolated approved policy without folder or model inputs',async()=>fixture(async f=>{
 const profile=await fixtureProfile(f),result=spawnSync(process.execPath,[path.join(f.packet,'scripts/bootstrap-world.mjs'),'begin'],{cwd:f.root,env:{...process.env,CODEX_THREAD_ID:f.threads.director,CODEX_HOME:f.codexHome,ALIFE_CORE_CREATION_PROFILE:profile},input:JSON.stringify(fixtureContext(f)),encoding:'utf8',windowsHide:true,timeout:15000});
 assert.equal(result.status,0,result.stderr);const out=JSON.parse(result.stdout);assert.equal(out.projectRoot,f.root);assert.equal(out.projectId,f.projectId);assert.equal(out.status,'onboarding');
 assert.equal((await f.state()).settings.model,'gpt-6.1-sol');assert.equal((await f.state()).settings.thinking,'xhigh');
 assert.equal((await f.state()).effects.length,0);
}));

test('new-only world display request comes from the neutral definition without claiming native title verification',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);
 const sr=await reserveCreation(f.root,'support',f.director),support=await f.bind('support',sr,f.director);
 const wr=await reserveCreation(f.root,'world-requests',support);assert.equal(wr.toolRequest.arguments.title,'World 1.0');let s=await f.state();assert.equal(s.roles['world-requests'].worldDefinitionVersion,'1.0.0');
 const row=(await inspectWorld(f.root)).roles.find(r=>r.id==='world-requests');assert.equal(row.title,'World Requests');assert.equal(row.requestedDisplayTitle,'World 1.0');assert.equal(row.observedDisplayTitle,null);
}));
test('an older episode retains its original requested world title and approved settings',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);
 const sr=await reserveCreation(f.root,'support',f.director),support=await f.bind('support',sr,f.director),s=await f.state();delete s.roles['world-requests'].requestedDisplayTitle;delete s.roles['world-requests'].worldDefinitionVersion;await writeFile(f.stateFile,JSON.stringify(s));
 await prepareWorld(f.packet,f.request,f.director);const wr=await reserveCreation(f.root,'world-requests',support);assert.equal(wr.toolRequest.arguments.title,'World Requests');assert.deepEqual((await f.state()).settings,s.settings);assert.equal((await f.state()).episodeId,s.episodeId);
}));

function directorMetadata(f,title='Create this fixture world'){return{id:f.threads.director,kind:'codex',hostId:'local',cwd:f.root,projectId:f.projectId,title};}
async function titleReady(f,title){f.request.nativeThread=directorMetadata(f,title);await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);}
test('fresh Director title reserves the exact invoking chat once and verifies only matching native results/readback',async()=>fixture(async f=>{
 f.request.nativeThread=directorMetadata(f);await prepareWorld(f.packet,f.request,f.director);await assert.rejects(reserveDirectorTitle(f.root,directorMetadata(f),f.director),/onboarded Director/);await f.acknowledge('director',f.director);
 const before=await f.state(),homeBefore=await readFile(path.join(f.slotPath('director'),'AGENT.md')),r=await reserveDirectorTitle(f.root,directorMetadata(f),f.director);
 assert.equal(r.canRename,true);assert.deepEqual(r.toolRequest,{tool:'set_thread_title',arguments:{source:'codex',threadId:f.threads.director,title:'Director'}});
 assert.equal((await reserveDirectorTitle(f.root,directorMetadata(f),f.director)).canRename,false);assert.equal((await f.state()).effects.filter(e=>e.kind==='native-director-title').length,1);
 const result={status:'verified',nativeResult:{threadId:f.threads.director,title:'Director'},nativeThread:directorMetadata(f,'Director')};
 await assert.rejects(recordDirectorTitle(f.root,r.operationId,{...result,nativeResult:{threadId:randomUUID()}},f.director),/supported Director rename result/);
 await assert.rejects(recordDirectorTitle(f.root,r.operationId,{...result,nativeThread:{...result.nativeThread,cwd:f.foreign}},f.director),/supported invoking Director/);
 await assert.rejects(recordDirectorTitle(f.root,r.operationId,{...result,nativeResult:{threadId:f.threads.director,title:'Wrong returned title'}},f.director),/supported Director rename result/);
 await assert.rejects(recordDirectorTitle(f.root,r.operationId,{...result,nativeThread:directorMetadata(f,'Other title')},f.director),/readback does not match/);
 assert.equal((await recordDirectorTitle(f.root,r.operationId,result,f.director)).status,'director-title-verified');assert.equal((await recordDirectorTitle(f.root,r.operationId,result,f.director)).status,'director-title-verified');
 const after=await f.state();assert.deepEqual(after.settings,before.settings);assert.equal(after.episodeId,before.episodeId);assert.equal(after.roles.director.threadId,before.roles.director.threadId);assert.deepEqual(await readFile(path.join(f.slotPath('director'),'AGENT.md')),homeBefore);assert.equal((await inspectWorld(f.root)).roles[0].observedDisplayTitle,'Director');
}));
test('already named Director requires no native rename operation',async()=>fixture(async f=>{
 await titleReady(f,'Director');const r=await reserveDirectorTitle(f.root,directorMetadata(f,'Director'),f.director);assert.equal(r.status,'already-matching');assert.equal(r.canRename,false);assert.equal((await f.state()).effects.length,0);
}));
test('a title changed after initial setup capture is preserved permanently',async()=>fixture(async f=>{
 await titleReady(f,'Create this fixture world');const r=await reserveDirectorTitle(f.root,directorMetadata(f,'My chosen project title'),f.director);assert.equal(r.status,'preserved-changed-title');assert.equal(r.canRename,false);assert.equal((await reserveDirectorTitle(f.root,directorMetadata(f),f.director)).canRename,false);assert.equal((await f.state()).effects.length,0);
}));
test('old episodes receive no automatic title intent on reuse and keep their names and settings',async()=>fixture(async f=>{
 await titleReady(f,'My original title');const old=await f.state();delete old.roles.director.titleUpdate;await writeFile(f.stateFile,JSON.stringify(old));await prepareWorld(f.packet,{...f.request,nativeThread:directorMetadata(f,'My custom established title')},f.director);
 assert.equal((await reserveDirectorTitle(f.root,directorMetadata(f,'My custom established title'),f.director)).status,'preserve-existing-director-title');assert.equal((await f.state()).roles.director.titleUpdate,undefined);assert.deepEqual((await f.state()).settings,old.settings);assert.equal((await f.state()).episodeId,old.episodeId);
}));
test('unknown title outcome never replays; actual observed state can reconcile without a fabricated tool return',async()=>fixture(async f=>{
 await titleReady(f);const r=await reserveDirectorTitle(f.root,directorMetadata(f),f.director);await recordDirectorTitle(f.root,r.operationId,{status:'unknown'},f.director);
 const retry=await reserveDirectorTitle(f.root,directorMetadata(f),f.director);assert.equal(retry.canRename,false);assert.equal(retry.operationId,r.operationId);assert.equal((await inspectWorld(f.root)).unknownEffects.some(e=>e.id===r.operationId),true);
 const observed=await recordDirectorTitle(f.root,r.operationId,{status:'observed',nativeThread:directorMetadata(f,'Director')},f.director);assert.equal(observed.status,'director-title-observed');assert.equal((await inspectWorld(f.root)).unknownEffects.length,0);
 await assert.rejects(recordDirectorTitle(f.root,r.operationId,{status:'unknown'},f.director),/cannot be downgraded/);
}));
test('failed or unavailable title action stays explicit without blocking independent core reservation',async()=>{for(const status of ['failed','unavailable'])await fixture(async f=>{
 await titleReady(f);const r=await reserveDirectorTitle(f.root,directorMetadata(f),f.director);await recordDirectorTitle(f.root,r.operationId,{status},f.director);assert.equal((await reserveDirectorTitle(f.root,directorMetadata(f),f.director)).canRename,false);assert.equal((await inspectWorld(f.root)).roles[0].titleState,status);assert.equal((await reserveCreation(f.root,'support',f.director)).canCreate,true);
});});
test('foreign initial title metadata is refused before any private setup or ignore write',async()=>fixture(async f=>{
 await assert.rejects(prepareWorld(f.packet,{...f.request,nativeThread:{...directorMetadata(f),id:randomUUID()}},f.director),/supported invoking Director/);await assert.rejects(lstat(path.join(f.root,BOOTSTRAP_DIR)),e=>e.code==='ENOENT');assert.equal(await readFile(path.join(f.root,'.gitignore'),'utf8'),'existing-user-rule\n');
}));
test('a foreign actor or target cannot reserve another Director title',async()=>fixture(async f=>{
 await titleReady(f);const other=await f.native(randomUUID());await assert.rejects(reserveDirectorTitle(f.root,directorMetadata(f),other),/onboarded Director/);await assert.rejects(reserveDirectorTitle(f.root,{...directorMetadata(f),id:randomUUID()},f.director),/supported invoking Director/);assert.equal((await f.state()).effects.length,0);
}));
test('automatic begin captures the actual supported title with null projectId and reserves the same Director',async()=>fixture(async f=>{
 const thread={...directorMetadata(f),projectId:null},projects=[{projectKind:'local',hostId:'local',path:f.root,projectId:f.projectId,label:'Fixture World'}];
 await beginWorld(f.packet,{nativeThread:thread,nativeProjects:projects,settings:f.request.settings},f.director,{projectRoot:f.root});assert.equal((await f.state()).roles.director.titleUpdate.initialTitle,thread.title);await f.acknowledge('director',f.director);assert.equal((await reserveDirectorTitle(f.root,thread,f.director)).toolRequest.arguments.threadId,f.threads.director);
}));
test('missing initial supported title is explicit and does not infer permission to rename',async()=>fixture(async f=>{
 await prepareWorld(f.packet,f.request,f.director);await f.acknowledge('director',f.director);const r=await reserveDirectorTitle(f.root,directorMetadata(f),f.director);assert.equal(r.status,'unavailable-initial-director-title');assert.equal(r.canRename,false);assert.equal((await f.state()).effects.length,0);
}));
test('bootstrap CLI exposes the real structured title reservation and result sequence',async()=>fixture(async f=>{
 await titleReady(f);const script=path.join(source,'scripts/bootstrap-world.mjs'),env={...process.env,CODEX_THREAD_ID:f.threads.director,CODEX_HOME:f.codexHome};
 const reserve=spawnSync(process.execPath,[script,'reserve-director-title'],{cwd:f.root,env,input:JSON.stringify({nativeThread:directorMetadata(f)}),encoding:'utf8'});assert.equal(reserve.status,0,reserve.stderr);const r=JSON.parse(reserve.stdout);assert.equal(r.canRename,true);
 const record=spawnSync(process.execPath,[script,'record-director-title'],{cwd:f.root,env,input:JSON.stringify({operationId:r.operationId,status:'verified',nativeResult:{threadId:f.threads.director,title:'Director'},nativeThread:directorMetadata(f,'Director')}),encoding:'utf8'});assert.equal(record.status,0,record.stderr);assert.equal(JSON.parse(record.stdout).status,'director-title-verified');
}));
