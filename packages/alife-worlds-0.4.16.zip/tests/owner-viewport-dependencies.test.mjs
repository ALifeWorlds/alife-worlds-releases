import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {renderOwnerViewportModule} from '../lib/owner-site.mjs';
import {createProjection} from '../lib/projection.mjs';
import {createDemo} from '../lib/demo.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {publicWorldSnapshot} from '../lib/public-world.mjs';
import {createLocalAppearance} from '../lib/local-world-appearance.mjs';
import '../web/launcher-world113/renderer.js';

test('compiled owner viewport includes the snapshot validator required by its real appearance join',async()=>{
 const worldId='world-viewport-fixture';
 const renderer={schemaVersion:1,bundleId:'viewport-fixture',worldVersion:'1.0.0',artifactSha256:'a'.repeat(64)};
 const state=await createProjection(registry,createDemo(registry,'working'));
 state.feed.observedUtc=new Date().toISOString();
 for(const agent of state.model.agents){agent.model=null;agent.modelSpeed=null;agent.reasoningEffort=null;}
 const snapshot=publicWorldSnapshot(state,registry,{worldId});
 const appearance=createLocalAppearance(state,registry,snapshot,renderer,{oracle:globalThis.AgentOutpost,digestJSON:text=>createHash('sha256').update(text).digest('hex')});
 const names=snapshot.model.agents.map(agent=>({id:agent.threadId,name:'Fixture agent',source:'registry-fallback',observedUtc:null,state:'unknown'}));
 const agents=names.map(agent=>({id:agent.id,modelState:'unknown',modelSource:null,modelObservedUtc:null,selectedState:'unknown',selectedSource:null,selectedObservedUtc:null,presentationSource:'unknown',appliedToken:null}));
 const preview={schemaVersion:3,kind:'owner-world-preview',worldId,renderer,snapshot,appearance,names,metadata:{revision:1,contentHash:'b'.repeat(64),agents}};
 // Expose the compiled helper only in this test; production exports stay unchanged.
 const source=await renderOwnerViewportModule();
 const {createOwnerPreviewJoin}=await import('data:text/javascript;base64,'+Buffer.from(source+'\nexport {createOwnerPreviewJoin};').toString('base64'));
 const join=createOwnerPreviewJoin(renderer);
 const input=await join.ownerWorldInput(preview,{expectedWorldId:worldId});
 assert.equal(input.snapshot,snapshot);
 assert.equal(input.model.agents.length,registry.length);
 const invalid=structuredClone(preview);invalid.snapshot.extra='invalid';
 await assert.rejects(join.ownerWorldInput(invalid,{expectedWorldId:worldId}));
});
