import test from 'node:test';
import assert from 'node:assert/strict';
import {planWorldSourceVersion} from '../lib/world-source-version.mjs';

const upstream=()=>({version:'0.3.4',commit:'a'.repeat(40),contentFingerprint:'b'.repeat(64)});
const local=()=>({version:'0.4.2',contentFingerprint:'c'.repeat(64),hasLocalChanges:true});
const plan=(changes={})=>planWorldSourceVersion({upstream:upstream(),candidate:local(),...changes});
const upstreamOnly=u=>({version:u.version,contentFingerprint:u.contentFingerprint,hasLocalChanges:false});

test('upstream-only source uses the exact full upstream version and independent baseline/candidate identities',()=>{
 const u=upstream(),input={upstream:u,candidate:upstreamOnly(u)},before=structuredClone(input),result=planWorldSourceVersion(input);
 assert.equal(result.title,'World 0.3.4');assert.equal(result.trackingVersion,'0.3.4');assert.equal(result.unchanged,false);
 assert.deepEqual(result.baseline,u);assert.deepEqual(result.candidate,input.candidate);assert.deepEqual(input,before);
 assert.notEqual(result.baseline,u);assert.notEqual(result.candidate,input.candidate);
 assert.ok(Object.isFrozen(result)&&Object.isFrozen(result.baseline)&&Object.isFrozen(result.candidate));
 assert.deepEqual(Object.keys(result).sort(),['baseline','candidate','schemaVersion','title','trackingVersion','unchanged']);
});

test('local source uses the supplied qualified candidate without silently bumping or retagging it',()=>{
 const result=plan();assert.equal(result.title,'World 0.4.2');assert.equal(result.trackingVersion,'0.4.2');assert.deepEqual(result.candidate,local());assert.deepEqual(result.baseline,upstream());
 for(const version of ['0.4.3','0.5.0','1.0.0'])assert.equal(plan({candidate:{...local(),version}}).title,'World '+version);
});

test('identical qualified update reconciles repeatedly with no second version bump',()=>{
 const first=plan(),second=plan({previous:first}),third=plan({previous:second});
 assert.equal(first.unchanged,false);assert.equal(second.unchanged,true);assert.equal(third.unchanged,true);assert.equal(third.trackingVersion,'0.4.2');assert.deepEqual(second,third);
});

test('changed qualified bytes cannot reuse a tracking version and a newer exact candidate is accepted',()=>{
 const previous=plan();assert.throws(()=>plan({previous,candidate:{...local(),contentFingerprint:'d'.repeat(64)}}),/cannot be reused/);
 const next=plan({previous,candidate:{version:'0.4.3',contentFingerprint:'d'.repeat(64),hasLocalChanges:true}});
 assert.equal(next.title,'World 0.4.3');assert.equal(next.unchanged,false);
});

test('new upstream import cannot reset the previous higher local tracking version',()=>{
 const previous=plan(),nextUpstream={version:'0.3.5',commit:'d'.repeat(40),contentFingerprint:'e'.repeat(64)};
 assert.throws(()=>plan({upstream:nextUpstream,candidate:upstreamOnly(nextUpstream),previous}),/downgrade/);
 assert.throws(()=>plan({upstream:nextUpstream,candidate:{...local(),version:'0.4.1'},previous}),/downgrade/);
 const next=plan({upstream:nextUpstream,candidate:{...local(),version:'0.4.3',contentFingerprint:'f'.repeat(64)},previous});assert.equal(next.title,'World 0.4.3');assert.deepEqual(next.baseline,nextUpstream);
});

test('later upstream-only release may advance tracking without masquerading as a served-world artifact',()=>{
 const u={version:'0.5.0',commit:'d'.repeat(40),contentFingerprint:'e'.repeat(64)},result=plan({upstream:u,candidate:upstreamOnly(u),previous:plan()});
 assert.equal(result.title,'World 0.5.0');assert.equal(result.candidate.hasLocalChanges,false);assert.equal(result.unchanged,false);
 for(const key of ['worldVersion','servedVersion','nativeBinding','renamed','deployed'])assert.equal(Object.hasOwn(result,key),false);
});

test('version comparison is numeric and rejects candidate/upstream or tracking downgrades',()=>{
 const u={...upstream(),version:'9.9.9'},candidate={...local(),version:'9.10.0'},previous=plan({upstream:u,candidate});
 assert.equal(previous.title,'World 9.10.0');assert.throws(()=>plan({upstream:u,candidate:{...candidate,version:'9.9.9'}}),/exceed/);
 assert.throws(()=>plan({upstream:u,candidate:{...candidate,version:'9.9.10'},previous}),/downgrade/);
});

test('explicit local-change flags must agree with exact upstream/candidate identities',()=>{
 const u=upstream();for(const candidate of [
  {...local(),hasLocalChanges:false},
  {...upstreamOnly(u),contentFingerprint:'e'.repeat(64)},
  {...local(),version:u.version},
  {...local(),version:'0.3.3'},
  {...local(),contentFingerprint:u.contentFingerprint},
 ])assert.throws(()=>plan({candidate}),/upstream|exceed|Local changes/);
});

test('full strict SemVer, commit and fingerprints are required without coercion or unknown fields',()=>{
 for(const version of ['0.4','01.4.2','0.4.2+build','0.4.2-rc.1',' 0.4.2','9007199254740992.0.0',null,4])assert.throws(()=>plan({candidate:{...local(),version}}),/X.Y.Z/);
 for(const commit of ['a'.repeat(7),'A'.repeat(40),'g'.repeat(40),'a'.repeat(41),null])assert.throws(()=>plan({upstream:{...upstream(),commit}}),/commit/);
 for(const contentFingerprint of ['c'.repeat(63),'C'.repeat(64),'g'.repeat(64),null])assert.throws(()=>plan({candidate:{...local(),contentFingerprint}}),/fingerprint/);
 for(const hasLocalChanges of ['true',1,null,undefined])assert.throws(()=>plan({candidate:{...local(),hasLocalChanges}}),/explicit boolean/);
 assert.throws(()=>planWorldSourceVersion({upstream:upstream(),candidate:local(),nativeThreadId:'private'}),/unsupported fields/);
 assert.throws(()=>plan({upstream:{...upstream(),qualified:true}}),/unsupported fields/);
 assert.throws(()=>plan({candidate:{...local(),contentFingerprint:undefined}}),/fingerprint/);
});

test('malformed previous record cannot authorize a label or overwrite a different identity',()=>{
 const good=plan();for(const previous of [
  {...good,schemaVersion:2},{...good,unchanged:'yes'},{...good,title:'World 0.4'},
  {...good,trackingVersion:'0.4.1'},{...good,candidate:{...good.candidate,hasLocalChanges:false}},
  {...good,nativeResult:'completed'},[],null,
 ]){if(previous===null)continue;assert.throws(()=>plan({previous}),/previous|Previous|upstream-only|object/i);}
 assert.equal(plan({previous:null}).unchanged,false);
});

test('upstream version reuse, immutable-commit mismatch and baseline downgrade are refused',()=>{
 const previous=plan(),candidate={...local(),version:'0.4.3',contentFingerprint:'f'.repeat(64)};
 assert.throws(()=>plan({previous,candidate,upstream:{...upstream(),commit:'d'.repeat(40),contentFingerprint:'e'.repeat(64)}}),/upstream version cannot be reused/);
 assert.throws(()=>plan({previous,candidate,upstream:{...upstream(),version:'0.3.5'}}),/same upstream commit/);
 assert.throws(()=>plan({previous,candidate,upstream:{...upstream(),version:'0.3.3',commit:'d'.repeat(40)}}),/baseline downgrade/);
});

test('unchanged payload/version can record newly verified baseline metadata without a new title',()=>{
 const previous=plan(),u={...upstream(),commit:'d'.repeat(40)},result=plan({previous,upstream:u});
 assert.equal(result.unchanged,true);assert.equal(result.title,previous.title);assert.equal(result.baseline.commit,u.commit);assert.notEqual(result.baseline.commit,previous.baseline.commit);
});

test('input accessors, inherited authority and unsupported data shapes are rejected without invoking getters',()=>{
 let reads=0;const u=upstream();Object.defineProperty(u,'version',{enumerable:true,get(){reads++;return'0.3.4';}});
 assert.throws(()=>plan({upstream:u}),/not accessors/);assert.equal(reads,0);
 assert.throws(()=>planWorldSourceVersion(Object.create({upstream:upstream(),candidate:local()})),/plain data object/);
 for(const input of [undefined,null,[],false])assert.throws(()=>planWorldSourceVersion(input),/plain data object/);
 const input={upstream:upstream(),candidate:local()};Object.defineProperty(input,'privateBinding',{value:'hidden'});assert.throws(()=>planWorldSourceVersion(input),/unsupported fields/);
});
