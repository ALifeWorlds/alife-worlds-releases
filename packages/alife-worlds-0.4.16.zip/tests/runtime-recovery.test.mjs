import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs/promises';
import {validateRuntimeRecoveryRecipe,materializeRuntimeRecovery} from '../lib/runtime-recovery.mjs';
const projectRoot=path.resolve('fixture-project'),driver=path.join(projectRoot,'.alife-worlds','approved-driver.mjs');
const hash='a'.repeat(64);
function recipe(){return {schemaVersion:1,explicitAutomaticRecovery:true,worldId:'world-fixture',projectId:'fixture-project',projectRootSha256:hash,plugin:'0.3.7',world:'1.3.4',website:'1.1.5',source:'a'.repeat(40),localOrigin:'http://127.0.0.1:12345',ownerOrigin:null,node:process.execPath,components:[{name:'local',driver,pins:[{path:driver,sha256:hash}],adopt:[]}]};}
test('local-only recovery carries exact private bindings without requiring a private-site credential',()=>{
 const input=recipe(),result=validateRuntimeRecoveryRecipe(input,{projectRoot});assert.deepEqual(result,input);result.components[0].pins.pop();assert.equal(input.components[0].pins.length,1);
 const privateRecipe=recipe();privateRecipe.ownerOrigin='https://fixture.invalid';privateRecipe.components.push({...structuredClone(privateRecipe.components[0]),name:'publisher'});assert.deepEqual(validateRuntimeRecoveryRecipe(privateRecipe,{projectRoot}),privateRecipe);
});
test('recovery refuses foreign paths, substituted executables, unpinned adoption and extra process roles',()=>{
 const edits=[r=>r.node=path.join(projectRoot,'other-node.exe'),r=>r.components[0].driver=path.resolve('other-project','driver.mjs'),r=>r.components[0].pins=[],r=>r.components[0].pins[0].path=path.resolve('other-project','input.json'),r=>r.components[0].name='public-publisher',r=>r.components[0].adopt=[{pid:1,createdUtc:new Date().toISOString(),driver:path.join(projectRoot,'unpinned.mjs')}],r=>r.components[0].arguments=['--arbitrary']];
 for(const edit of edits){const value=recipe();edit(value);assert.throws(()=>validateRuntimeRecoveryRecipe(value,{projectRoot}));}
});
test('explicit scope, exact loopback/private origins, source revision and no-secret recipe remain mandatory',()=>{
 const edits=[r=>r.explicitAutomaticRecovery=false,r=>r.localOrigin='http://192.0.2.1:12345',r=>r.localOrigin+='/?project=other',r=>r.source='unconfirmed',r=>r.plugin='latest',r=>r.ownerBearer='must-never-enter-configuration',r=>r.ownerOrigin='https://unused.invalid',r=>{r.components.push({...structuredClone(r.components[0]),name:'publisher'});r.ownerOrigin='http://fixture.invalid';}];
 for(const edit of edits){const value=recipe();edit(value);assert.throws(()=>validateRuntimeRecoveryRecipe(value,{projectRoot}));}
});
test('unsupported host fails before any packet, filesystem, credential or task access',async()=>{
 await assert.rejects(materializeRuntimeRecovery({platform:'linux'}),/unavailable on this host/);
});

test('an existing approved connection keeper prevents preparing a competing recovery runtime',async()=>{
 const temp=await fs.mkdtemp(path.join(os.tmpdir(),'alife-recovery-test-'));
 try{
  await fs.mkdir(path.join(temp,'.alife-worlds','connection-supervisor'),{recursive:true});
  await fs.writeFile(path.join(temp,'.alife-worlds','connection-supervisor','connection.json'),'{}');
  await assert.rejects(materializeRuntimeRecovery({platform:'win32',projectRoot:temp,packageRoot:path.join(temp,'missing-packet')}),/Existing approved connection supervisor/);
  await assert.rejects(fs.access(path.join(temp,'.alife-worlds','runtime-recovery')));
 }finally{
  assert.ok(path.resolve(temp).startsWith(path.resolve(os.tmpdir())+path.sep));
  assert.ok(path.basename(temp).startsWith('alife-recovery-test-'));
  await fs.rm(temp,{recursive:true,force:true});
 }
});
