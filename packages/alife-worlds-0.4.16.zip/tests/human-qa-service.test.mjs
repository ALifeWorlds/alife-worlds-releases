import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {createHumanQaService} from '../lib/human-qa-service.mjs';
import {qaDigest,HUMAN_QA_ATTESTATION} from '../lib/human-qa-contract.mjs';

const origin='https://owner.example',worldId='world-fixture';
class Bucket{
 constructor(){this.rows=new Map();this.failAfterPut=null;}
 async get(key){const r=this.rows.get(key);return r?{size:Buffer.byteLength(r.text),etag:r.etag,httpEtag:JSON.stringify(r.etag),text:async()=>r.text}:null;}
 async put(key,text,opts={}){
  const old=this.rows.get(key),h=opts.onlyIf;
  if(h?.get('If-None-Match')==='*'&&old)return null;
  if(h?.get('If-Match')&&h.get('If-Match')!==JSON.stringify(old?.etag))return null;
  const row={text,etag:randomUUID()};this.rows.set(key,row);
  if(this.failAfterPut?.(key))throw Error('lost response');return{etag:row.etag};
 }
 async list({prefix,limit,cursor}){const all=[...this.rows.keys()].filter(k=>k.startsWith(prefix)).sort(),start=cursor?Number(cursor):0,keys=all.slice(start,start+limit);
  return{objects:keys.map(key=>({key})),truncated:start+limit<all.length,cursor:String(start+limit)};}
}
const clock=()=>Date.parse('2026-11-09T06:00:00.000Z');
const service=()=>createHumanQaService({worldId,ownerOrigin:origin,ownerPrivate:true,now:clock});
const goal=(entryId='goal1',prior=null)=>({entryId,goalId:entryId,taskIds:['task1'],candidateId:'candidate1',title:'Finished fixture goal',goal:'Confirm the finished behavior.',
 candidate:{websiteVersion:'1.0.0',pluginVersion:'0.2.28',worldVersion:'1.2.3'},surface:{id:'owner',label:'Private website',url:origin+'/'},
 optional:false,reviewState:prior?'historical':'current',prior:prior??{state:'unconfirmed',reportedUtc:null,proofId:null}});
async function manifest(goals=[goal()],time='2026-11-09T05:00:00.000Z'){
 const body={schemaVersion:1,kind:'owner-human-qa-manifest',worldId,sourceRecordedUtc:time,goals};return{...body,manifestId:await qaDigest(body)};
}
const req=(path,method='GET',body,headers={})=>new Request(origin+path,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...headers},...(body?{body:JSON.stringify(body)}:{})});
const browser={'oai-authenticated-user-id':'fixture-owner',Origin:origin,'Sec-Fetch-Site':'same-origin'};
const body=m=>({schemaVersion:1,requestId:randomUUID(),worldId,manifestId:m.manifestId,entryId:m.goals[0].entryId,candidateId:m.goals[0].candidateId,
 surfaceId:m.goals[0].surface.id,result:'pass',attestation:HUMAN_QA_ATTESTATION});
async function setup(goals){const s=service(),b=new Bucket(),m=await manifest(goals);assert.equal((await s.handle(req('/api/qa-goals','PUT',m),{BUCKET:b})).status,200);return{s,b,m};}
const json=async r=>({status:r.status,value:await r.json()});

test('human report requires authenticated exact-origin visitor; service alone cannot invent a pass',async()=>{
 const{s,b,m}=await setup();for(const headers of [{},{Origin:origin},{...browser,Origin:'https://evil.example'},{...browser,'Sec-Fetch-Site':'cross-site'}]){
 const r=await s.handle(req('/api/qa-verifications','POST',body(m),headers),{BUCKET:b});assert.ok([401,403].includes(r.status));}
 assert.equal([...b.rows.keys()].filter(k=>k.includes('/events/')).length,0);
 assert.equal((await s.handle(req('/api/qa-goals','PUT',m,browser),{BUCKET:b})).status,403);
});
test('same request and parallel different requests preserve one immutable event and original report time',async()=>{
 const{s,b,m}=await setup(),one=body(m),two=body(m);
 const results=await Promise.all([one,two].map(v=>s.handle(req('/api/qa-verifications','POST',v,browser),{BUCKET:b}).then(json)));
 assert.ok(results.every(r=>[200,201].includes(r.status)));const [a,c]=results.map(r=>r.value);
 assert.equal(a.verification.eventId,c.verification.eventId);assert.equal(a.verification.reportedUtc,c.verification.reportedUtc);
 assert.equal([...b.rows.keys()].filter(k=>k.includes('/events/')).length,1);
 const retry=await json(await s.handle(req('/api/qa-verifications','POST',one,browser),{BUCKET:b}));
 assert.equal(retry.value.duplicate,true);assert.equal(retry.value.verification.eventId,a.verification.eventId);
 assert.equal((await s.handle(req('/api/qa-verifications','POST',{...one,surfaceId:'other'},browser),{BUCKET:b})).status,409);
 const goals=await(await s.handle(req('/api/qa-goals','GET',undefined,browser),{BUCKET:b})).json();
 assert.equal(goals.goals[0].verification.state,'saved');assert.equal(goals.goals[0].delivery.state,'unavailable');
});
test('lost conditional-put response never replaces original proof, reservation or timestamp',async()=>{
 const{s,b,m}=await setup(),v=body(m);b.failAfterPut=k=>k.includes('/events/');
 const r=await json(await s.handle(req('/api/qa-verifications','POST',v,browser),{BUCKET:b}));assert.equal(r.status,201);
 const retry=await json(await s.handle(req('/api/qa-verifications','POST',v,browser),{BUCKET:b}));assert.deepEqual(retry.value.verification,r.value.verification);
});
test('old captured request can reconcile after manifest changes; new stale reports fail',async()=>{
 const{s,b,m}=await setup(),v=body(m);let block=true,originalPut=b.put.bind(b);
 b.put=async(k,...args)=>{if(k.includes('/events/')&&block)throw Error('network');return originalPut(k,...args);};
 assert.equal((await s.handle(req('/api/qa-verifications','POST',v,browser),{BUCKET:b})).status,503);
 const next=await manifest([goal('next')],'2026-11-09T05:01:00.000Z');
 assert.equal((await s.handle(req('/api/qa-goals','PUT',next),{BUCKET:b})).status,200);
 block=false;assert.equal((await s.handle(req('/api/qa-verifications','POST',v,browser),{BUCKET:b})).status,201);
 assert.equal((await s.handle(req('/api/qa-verifications','POST',body(m),browser),{BUCKET:b})).status,409);
});
test('historical human pass is read-only and never described as native delivery',async()=>{
 const prior={state:'pass',reportedUtc:'2026-11-08T07:00:00.000Z',proofId:'a'.repeat(64)};
 const historical=goal('history',prior);historical.surface.url=null;const{s,b,m}=await setup([historical]);
 const r=await(await s.handle(req('/api/qa-goals','GET',undefined,browser),{BUCKET:b})).json();
 assert.equal(r.goals[0].verification.state,'prior-pass');assert.equal(r.goals[0].delivery.state,'not-attempted');
 assert.equal((await s.handle(req('/api/qa-verifications','POST',body(m),browser),{BUCKET:b})).status,409);
 assert.equal((await s.handle(req('/api/qa-goals','PUT',await manifest([],'2026-11-09T05:01:00.000Z')),{BUCKET:b})).status,409);
});
test('only one service dispatch reservation wins; queued is not delivered; actual receipt and lease expire distinctly',async()=>{
 const{s,b,m}=await setup();const saved=await(await s.handle(req('/api/qa-verifications','POST',body(m),browser),{BUCKET:b})).json(),eventId=saved.verification.eventId;
 const out=await(await s.handle(req('/api/qa-outbox'),{BUCKET:b})).json();assert.equal(out.items.length,1);
 assert.equal(out.items[0].proofSha256,await qaDigest(out.items[0].event));
 const receipt={schemaVersion:1,kind:'owner-human-qa-delivery',worldId,eventId,attemptId:randomUUID(),state:'reserved',
 recordedUtc:new Date(clock()).toISOString(),queueReceiptId:null,receiptSha256:null};
 const two={...receipt,attemptId:randomUUID()};
 const claims=await Promise.all([receipt,two].map(v=>s.handle(req('/api/qa-delivery','PUT',v),{BUCKET:b}).then(r=>r.json())));
 assert.equal(claims.filter(r=>r.applied).length,1);
 let r=await(await s.handle(req('/api/qa-goals','GET',undefined,browser),{BUCKET:b})).json();
 assert.equal(r.goals[0].delivery.state,'unknown');
 const winner=[receipt,two][claims.findIndex(claim=>claim.applied)];
 const queued={...winner,state:'queued',queueReceiptId:randomUUID()};
 assert.equal((await s.handle(req('/api/qa-delivery','PUT',queued),{BUCKET:b})).status,200);
 r=await(await s.handle(req('/api/qa-goals'),{BUCKET:b})).json();assert.equal(r.goals[0].delivery.state,'queued');
 const delivered={...queued,state:'delivered',receiptSha256:'b'.repeat(64)};
 assert.equal((await s.handle(req('/api/qa-delivery','PUT',delivered),{BUCKET:b})).status,200);
 r=await(await s.handle(req('/api/qa-goals'),{BUCKET:b})).json();assert.equal(r.goals[0].delivery.state,'delivered');
 assert.equal((await s.handle(req('/api/qa-delivery','PUT',{...delivered,receiptSha256:'c'.repeat(64)}),{BUCKET:b})).status,409);
 assert.equal((await s.handle(req('/api/qa-outbox'),{BUCKET:b})).status,200);
 assert.equal((await s.handle(req('/api/qa-outbox','GET',undefined,browser),{BUCKET:b})).status,403);
 const lease={schemaVersion:1,kind:'owner-human-qa-transport',worldId,recordedUtc:new Date(clock()).toISOString(),
 expiresUtc:new Date(clock()+45000).toISOString(),qualificationSha256:'d'.repeat(64)};
 assert.equal((await s.handle(req('/api/qa-transport','PUT',lease),{BUCKET:b})).status,200);
 r=await(await s.handle(req('/api/qa-goals'),{BUCKET:b})).json();assert.equal(r.transport.state,'ready');
 const later=createHumanQaService({worldId,ownerOrigin:origin,ownerPrivate:true,now:()=>clock()+60000});
 r=await(await later.handle(req('/api/qa-goals'),{BUCKET:b})).json();assert.equal(r.transport.state,'unavailable');
});
test('malformed or corrupted stored proof fails closed and imposes body and origin bounds',async()=>{
 const{s,b,m}=await setup(),v=body(m);
 assert.equal((await s.handle(new Request('https://wrong.example/api/qa-goals'),{BUCKET:b})).status,403);
 assert.equal((await s.handle(req('/api/qa-verifications','POST',{...v,unexpected:true},browser),{BUCKET:b})).status,400);
 await s.handle(req('/api/qa-verifications','POST',v,browser),{BUCKET:b});
 const key=[...b.rows.keys()].find(k=>k.includes('/requests/')),row=b.rows.get(key),r=JSON.parse(row.text);r.goal.taskIds=['changed'];row.text=JSON.stringify(r);
 const verification=await s.handle(req('/api/qa-verifications?requestId='+v.requestId,'GET',undefined,browser),{BUCKET:b});
 // The request payload/event bindings must not accept tampered goal data as a genuine proof.
 assert.equal(verification.status,503);
});
