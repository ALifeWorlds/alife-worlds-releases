import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,copyFile,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {collectPackageInputs,CORE_PACKAGE_ROLES} from '../lib/plugin-version.mjs';
import {checkAllRuleDocuments} from '../lib/agent-rules.mjs';
const source=fileURLToPath(new URL('../',import.meta.url)),scratch=path.join(source,'runtime/test-fixtures');
const expected=['roles/SHARED.md','roles/director.md','roles/support.md','roles/world-requests.md'].sort();
async function fixture(fn){
 await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'core-packet-'));
 try{for(const rel of await collectPackageInputs(source)){const target=path.join(root,rel);await mkdir(path.dirname(target),{recursive:true});await copyFile(path.join(source,rel),target);}await fn(root);}
 finally{assert.ok(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));await rm(root,{recursive:true,force:true});}
}
test('distributed defaults and collected packets contain exactly the selected three core roles',async()=>{
 const roles=JSON.parse(await readFile(path.join(source,'data/roles.json'),'utf8'));
 assert.deepEqual(roles.map(r=>r.id).sort(),[...CORE_PACKAGE_ROLES].sort());
 const files=await collectPackageInputs(source);assert.deepEqual(files.filter(f=>f.startsWith('roles/')).sort(),expected);
 for(const name of ['mcp.json','.mcp.json','lib/world-launcher.mjs','scripts/world-launcher.mjs','web/world-launcher.html'])assert.ok(files.includes(name),name);
 assert.equal(await checkAllRuleDocuments(source),true);
 const doc=await readFile(path.join(source,'docs/AGENT_RULES.md'),'utf8');
 assert.deepEqual([...doc.matchAll(/^## [^\n]+ \(([a-z][a-z0-9-]*)\)$/gm)].map(m=>m[1]).sort(),[...CORE_PACKAGE_ROLES].sort());
});
test('extra source templates and private overrides are preserved but never collected',async()=>fixture(async root=>{
 await writeFile(path.join(root,'roles/technical-support.md'),'Owned extra role recovery; do not ship or delete.\n');
 await mkdir(path.join(root,'roles/optional'),{recursive:true});await writeFile(path.join(root,'roles/optional/specialist.md'),'Optional historical template.\n');
 await mkdir(path.join(root,'runtime/private'),{recursive:true});await writeFile(path.join(root,'runtime/private/roles.json'),'{"private":"custom project registry fixture"}\n');
 const files=await collectPackageInputs(root);assert.deepEqual(files.filter(f=>f.startsWith('roles/')).sort(),expected);assert.ok(!files.some(f=>f.startsWith('runtime/')));
 assert.match(await readFile(path.join(root,'roles/technical-support.md'),'utf8'),/do not ship or delete/);
 assert.match(await readFile(path.join(root,'roles/optional/specialist.md'),'utf8'),/historical/);
 const staged=path.join(root,'runtime/staged');for(const rel of files){const to=path.join(staged,rel);await mkdir(path.dirname(to),{recursive:true});await copyFile(path.join(root,rel),to);}
 assert.deepEqual((await collectPackageInputs(staged)).filter(f=>f.startsWith('roles/')).sort(),expected);assert.equal(await checkAllRuleDocuments(staged),true);
}));
test('packaging rejects a missing, duplicated or extra default role instead of trimming the catalogue',async()=>fixture(async root=>{
 const file=path.join(root,'data/roles.json'),original=JSON.parse(await readFile(file,'utf8'));
 for(const roles of [original.slice(0,2),[...original,{...original[0],id:'worker1'}],[original[0],original[0],original[2]],[original[0],original[1],{...original[2],id:'foreign'}]]){
  await writeFile(file,JSON.stringify(roles));await assert.rejects(collectPackageInputs(root),/three core roles/);
 }
 await writeFile(file,JSON.stringify(original));assert.deepEqual((await collectPackageInputs(root)).filter(f=>f.startsWith('roles/')).sort(),expected);
}));
test('missing core packets and stale generated agent views remain hard failures',async()=>fixture(async root=>{
 const support=path.join(root,'roles/support.md'),contents=await readFile(support);
 await rm(support);await assert.rejects(collectPackageInputs(root),{code:'ENOENT'});await writeFile(support,contents);
 const file=path.join(root,'docs/AGENT_RULES.md');await writeFile(file,(await readFile(file,'utf8'))+'\n## Unselected specialist (worker1)\n');
 await assert.rejects(checkAllRuleDocuments(root),/out of date/);
}));

test('only create-world is advertised while the full building workflow and maintenance guidance remain packaged',async()=>{
 const files=await collectPackageInputs(source);assert.deepEqual(files.filter(f=>f.startsWith('skills/')&&f.endsWith('/SKILL.md')),['skills/create-world/SKILL.md']);
 const guide='skills/create-world/references/world-guide.md';assert.ok(files.includes(guide));
 const body=await readFile(path.join(source,guide),'utf8');
 for(const phrase of ['/world','/plugin','/rule','/universal','First invocation with image references','Open ALife Worlds in the host','Task tabs and computer handback'])assert.ok(body.includes(phrase),phrase);
 const skill=await readFile(path.join(source,'skills/create-world/SKILL.md'),'utf8');assert.ok(skill.includes('references/world-guide.md'));
 assert.match(skill,/^name: create-world$/m);assert.ok(skill.includes('references/building-world.md'));assert.ok(files.includes('skills/create-world/references/building-world.md'));
 const builder=await readFile(path.join(source,'skills/create-world/references/building-world.md'),'utf8');for(const command of ['begin','reserve','record-created','await-binding','reserve-continuation','record-continuation','start-world','register-launcher'])assert.ok(builder.includes(command),command);
 const manifest=JSON.parse(await readFile(path.join(source,'plugin.json'),'utf8')),compat=JSON.parse(await readFile(path.join(source,'.codex-plugin/plugin.json'),'utf8'));
 assert.equal(manifest.extensions['com.openai'].onboardingSkill,'./skills/create-world/SKILL.md');assert.equal(compat.onboardingSkill,'./skills/create-world/SKILL.md');
 assert.ok(manifest.extensions['com.openai'].interface.defaultPrompt.includes('$alife-worlds:create-world'));assert.ok(compat.interface.defaultPrompt.includes('$alife-worlds:create-world'));
});
