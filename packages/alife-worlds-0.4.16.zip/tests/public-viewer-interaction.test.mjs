import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const source=(await readFile(new URL('../web/world-view.mjs',import.meta.url),'utf8')).replace(/^import .*;\r?$/gm,'').replace(/^await import.*;\r?$/gm,'');
function harness({embedded=false,expected='public-world',operatorPresentation=false}={}){
 const elements=new Map(),listeners=new Map(),calls={mount:[],modes:[],fetch:[],renders:[],feeds:[],audio:[],ticks:[],ready:[],preferenceKeys:[],removed:0,fullscreen:0,destroyed:0};
 const node=()=>({dataset:{},attributes:{},textContent:'',setAttribute(k,v){this.attributes[k]=v;},addEventListener(){}});
 for(const id of ['world-showcase','world-anchor'])elements.set(id,node());
 const range={disabled:false,value:'100',dispatchEvent(){}};let paused=false;
 const pause={getAttribute:()=>String(paused),click(){paused=!paused;}};
 const controls={children:[],append(x){this.children.push(x);},querySelector:q=>q==='input[type=range]'?range:pause,addEventListener(){}};
 const main=elements.get('world-showcase');main.dataset.source='/api/world-view';if(operatorPresentation)main.dataset.operatorPresentation='true';main.querySelectorAll=()=>Array.from({length:4},()=>({remove(){calls.removed++;}}));
 const document={baseURI:'https://world.test/world/view',hidden:false,getElementById:id=>elements.get(id),referrer:'https://host.test/landing',addEventListener(){}};
 const window={addEventListener(k,v){listeners.set(k,v);}},parent={postMessage:(...args)=>calls.ready.push(args)};
 const farm={host:{dataset:{renderBuild:'fixture-executed-build',mode:'view'},addEventListener(){},querySelector:q=>{assert.equal(q,'.ag-controls');return controls;}},setAudioPreferenceKey:x=>calls.preferenceKeys.push(x),render:(...x)=>calls.renders.push(x),receiveFeed:f=>calls.feeds.push(f),setPresentationMode:x=>calls.modes.push(x),toggleFullscreen:()=>calls.fullscreen++,destroy:()=>calls.destroyed++,audio:{state:()=>({enabled:false}),setExternalEnabled:x=>calls.audio.push(x)}};
 const summary={percent:50,accepted:1,tasks:2},snapshot={kind:'read-only-world',world:{id:expected},model:{marker:'canonical'},feed:{marker:'observed',observedUtc:'2026-11-09T12:00:00.000Z'},summary:{current:summary,epic:summary,represented:20}};let fail=false;
 const context={window,parent,document,location:{origin:'https://world.test',search:'?project='+expected+(embedded?'&embedded=planet&soundHost=https%3A%2F%2Fhost.test':'')},URL,URLSearchParams,setInterval(fn){calls.ticks.push(fn);return 1;},clearInterval(){},queueMicrotask,innerHeight:720,Date,console,AgentOutpost:{mount:(anchor,opts)=>{calls.mount.push(opts);return farm;}},fetch:async(url,opts)=>{calls.fetch.push({url:String(url),opts});return{ok:!fail,json:async()=>snapshot};}};
 context.globalThis=context;vm.runInNewContext(source,context);
 return{calls,controls,main,listeners,window,parent,snapshot,setFailure:v=>{fail=v;},pause};
}
const settle=()=>new Promise(setImmediate);
test('public website stays fixed cosmetic View with no mode toggle, command host or operational captions',async()=>{
 const h=harness();await settle();const opts=h.calls.mount[0];assert.equal(opts.presentationMode,'view');assert.equal(opts.cosmeticOnly,true);assert.equal(opts.modelKey,false);assert.equal(opts.operatorPresentation,false);assert.equal(opts.farmCommandHost,undefined);assert.equal(opts.productPrivacyHost,undefined);
 assert.equal(h.controls.children.length,0);assert.equal(h.calls.removed,4);assert.equal(h.main.dataset.interactions,'true');h.listeners.get('message')({source:h.parent,origin:'https://host.test',data:{type:'alife-world-mode',worldId:'public-world',mode:'private'}});assert.deepEqual(h.calls.modes,['view']);
 const before=JSON.stringify(h.snapshot);await h.calls.ticks[0]();await settle();assert.equal(JSON.stringify(h.snapshot),before);assert.equal(h.calls.preferenceKeys.length,2);assert.equal(h.calls.ready[0][0].renderBuild,'fixture-executed-build');assert.equal(h.calls.ready[0][0].worldId,'public-world');assert.equal(h.calls.fetch[0].url,'https://world.test/api/world-view?project=public-world');assert.equal(h.calls.fetch[0].opts.credentials,'omit');assert.equal(h.calls.fetch[0].opts.method,undefined);
});
test('public control messages require exact parent origin/world and expose only closed cosmetic actions',async()=>{
 const h=harness();await settle();const message=h.listeners.get('message'),data={type:'alife-world-control',worldId:'public-world',action:'pause',paused:true};for(const event of [{source:{},origin:'https://host.test',data},{source:h.parent,origin:'https://wrong.test',data},{source:h.parent,origin:'https://host.test',data:{...data,worldId:'other'}}])message(event);
 assert.equal(h.pause.getAttribute('aria-pressed'),'false');message({source:h.parent,origin:'https://host.test',data});assert.equal(h.pause.getAttribute('aria-pressed'),'true');message({source:h.parent,origin:'https://host.test',data:{...data,action:'fullscreen'}});assert.equal(h.calls.fullscreen,1);
 for(const action of ['wake','retire','unblock','change-model'])message({source:h.parent,origin:'https://host.test',data:{...data,action}});assert.equal(h.calls.fetch.length,1);assert.equal(h.calls.fullscreen,1);assert.equal(h.calls.audio.length,0);
});
test('unavailable refresh retains original observation time and wrong-world input cannot replace the last exact scene',async()=>{
 const h=harness();await settle();h.setFailure(true);await h.calls.ticks[0]();await settle();assert.equal(h.main.dataset.sourceState,'unavailable');assert.equal(h.calls.feeds[0].observedUtc,h.snapshot.feed.observedUtc);assert.match(h.calls.feeds[0].error,/unavailable/);h.setFailure(false);h.snapshot.world.id='foreign';await h.calls.ticks[0]();await settle();assert.equal(h.calls.renders.length,1);assert.equal(h.main.dataset.sourceState,'unavailable');assert.equal(h.calls.feeds[1].observedUtc,'2026-11-09T12:00:00.000Z');h.listeners.get('pagehide')();await h.calls.ticks[0]();assert.equal(h.calls.destroyed,1);assert.equal(h.calls.fetch.length,3);
});
test('planet previews remain fixed View and only the exact registered parent can control bridged sound',async()=>{
 const h=harness({embedded:true});await settle();assert.equal(h.controls.children.length,0);assert.equal(h.calls.mount[0].presentationMode,'view');assert.equal(h.calls.mount[0].cosmeticOnly,true);const message=h.listeners.get('message'),data={type:'alife-sound-state',worldId:'public-world',enabled:true};message({source:{},origin:'https://host.test',data});message({source:h.parent,origin:'https://wrong.test',data});message({source:h.parent,origin:'https://host.test',data:{...data,worldId:'another-world'}});assert.equal(h.calls.audio.length,0);message({source:h.parent,origin:'https://host.test',data});assert.deepEqual(h.calls.audio,[true]);assert.equal(h.calls.modes.length,0);
});
