import test from 'node:test';
import assert from 'node:assert/strict';
import {createLocalOwnerFrameProvider} from '../lib/owner-frame-local.mjs';
import {createHash} from 'node:crypto';
import {createProjection} from '../lib/projection.mjs';
import {createDemo} from '../lib/demo.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {publicWorldSnapshot} from '../lib/public-world.mjs';
import {createLocalAppearance} from '../lib/local-world-appearance.mjs';
import '../web/launcher-world113/renderer.js';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),origin='http://127.0.0.1:7499',worldId='world-fixture';
const descriptor={schemaVersion:1,bundleId:'fixture-scene',worldVersion:'1.3.6',artifactSha256:'a'.repeat(64)};
async function createFixture(){
 const bytes=new TextEncoder().encode('/* fixture qualified renderer */'),row={path:'web/agent-outpost/agent-outpost.js',sha256:sha(bytes),bytes:bytes.length};
 let qualified=true,reads=0;const state=await createProjection(registry,createDemo(registry,'working'));state.feed.observedUtc=new Date().toISOString();for(const agent of state.model.agents){agent.model=null;agent.modelSpeed=null;agent.reasoningEffort=null;}
 const snapshot=publicWorldSnapshot(state,registry,{worldId});snapshot.model.visualWorldKey='scene-1234567890abcd';
 const appearance=createLocalAppearance(state,registry,snapshot,descriptor,{oracle:globalThis.AgentOutpost,digestJSON:sha});
 const value={schemaVersion:3,kind:'owner-world-preview',worldId,renderer:descriptor,snapshot,appearance,names:snapshot.model.agents.map(agent=>({id:agent.threadId,name:agent.roleId,source:'registry-fallback',observedUtc:null,state:'unknown'})),metadata:{revision:0,contentHash:'d'.repeat(64),agents:snapshot.model.agents.map(agent=>({id:agent.threadId,modelState:'unknown',modelSource:null,modelObservedUtc:null,selectedState:'unknown',selectedSource:null,selectedObservedUtc:null,presentationSource:'unknown',appliedToken:null}))}};
 const provider=createLocalOwnerFrameProvider({worldId,websiteVersion:'1.1.5',getOrigin:()=>origin,descriptor,readProfile:async()=>({status:'ready',source:'project',worldVersion:'1.0.2',resourceIdentity:'e'.repeat(64),selection:{files:[row]}}),qualifyProfile:async()=>qualified,readAsset:async()=>bytes,readSnapshot:async()=>{reads++;return value;}});
 return {provider,refuse:()=>{qualified=false;},reads:()=>reads};
}
test('default provider returns the same exact owner service and selected release without a second feed reader',async()=>{
 const f=await createFixture(),service=f.provider();assert.equal(f.provider(),service);
 const response=await service.ownerFrameResponse(new Request(origin+'/api/owner-world-release?project='+worldId),{ownerAuthorized:true});assert.equal(response.status,200);const offer=await response.json();assert.deepEqual(offer.current.renderer,descriptor);assert.equal(offer.previous,null);assert.equal(f.reads(),1);
 const asset=await service.ownerFrameResponse(new Request(origin+offer.current.resourceBase+'agent-outpost/agent-outpost.js'),{ownerAuthorized:true});assert.equal(asset.status,200);
 f.refuse();assert.equal((await service.ownerFrameResponse(new Request(origin+'/api/owner-world-release?project='+worldId),{ownerAuthorized:true})).status,503);assert.equal(f.reads(),1);
});
