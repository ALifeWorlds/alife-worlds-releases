import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import '../web/agent-outpost/agent-outpost.js';

const F=globalThis.AgentOutpost;
const source=await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8');
function productionLine(name){
 const line=source.split('\n').find(row=>row.trimStart().startsWith('function '+name+'('));
 assert.ok(line,'production function '+name+' exists');
 return line;
}

test('distance gait keeps two alternating tripods and grounded outdoor routes through both hill directions',()=>{
 const start=F.sideWalkingLegs(Math.PI*.4),half=F.sideWalkingLegs(Math.PI*1.4);
 assert.equal(start.length,6);assert.equal(half.length,6);
 for(let side=0;side<2;side++)for(let leg=0;leg<3;leg++){
  const i=side*3+leg,opposite=(1-side)*3+leg;
  assert.notEqual(start[i].stance,half[i].stance);
  assert.notEqual(start[i].stance,start[opposite].stance);
 }
 assert.deepEqual(F.sideWalkingLegs(0,true),F.sideWalkingLegs(7,true));
 for(const width of [900,1600,3200])for(const [from,to]of [[width*.1,width*.9],[width*.9,width*.1]]){
  const route=F.outdoorGroundRoute(width,{x:from},{x:to});assert.ok(route.length>2);
  assert.equal(route[0].x,from);assert.equal(route.at(-1).x,to);
  for(const p of route){assert.equal(p.outside,true);assert.equal(p.y,F.outdoorSurface(width,p.x).y-11);}
 }
});

test('fresh delivery pacing follows recorded progress and remains separate from the visual Fast multiplier',()=>{
 const now=Date.parse('2026-11-09T12:00:00Z'),delivery={observedUtc:new Date(now).toISOString(),startedUtc:new Date(now-60000).toISOString(),progress:.1,status:'running'};
 const early=F.deliveryPacing(delivery,1900,95,now),late=F.deliveryPacing({...delivery,progress:.98},1900,95,now);
 assert.ok(early.speed<95);assert.ok(late.speed>95*1.5);assert.equal(late.maxProgress,.98);assert.equal(late.completed,false);
 assert.equal(F.deliveryPacing(delivery,1900,95,now+120001).speed,0);
 const done=F.deliveryPacing({...delivery,status:'completed',progress:1,completedUtc:new Date(now).toISOString()},1900,95,now);
 assert.equal(done.completed,true);assert.equal(done.maxProgress,1);
 assert.equal(F.deliveryPacing({...delivery,status:'completed',progress:1},1900,95,now).completed,false);
});

test('production footprints reject airborne movement and teleport gaps and only mark short grounded displacement',()=>{
 const marks=[],steps=[],x={clock:1,snapshot:{stations:[{key:'agent'}]},sceneSurface:()=>({hill:true,y:200}),speedMode:()=>false,carveMovement:(...args)=>marks.push(args),sandFootstep:p=>steps.push(p)};
 vm.createContext(x);vm.runInContext(productionLine('footprint'),x);
 const actor={key:'agent',foot:{x:10,y:300},grassFoot:{x:10,y:200},outdoorFall:{}};
 x.footprint(actor,{x:20,y:300});assert.equal(marks.length,0);assert.equal(actor.foot,null);
 actor.outdoorFall=null;x.footprint(actor,{x:20,y:300});x.footprint(actor,{x:23,y:300});assert.equal(marks.length,0);
 x.footprint(actor,{x:28,y:300});assert.equal(marks.length,1);assert.equal(steps.length,1);
 x.footprint(actor,{x:300,y:300});assert.equal(marks.length,1,'a long relocation may not draw a trail bridge');
 actor.jumpStarted=.8;x.footprint(actor,{x:308,y:195,outside:true});assert.equal(marks.length,1);assert.equal(actor.foot,null);
});

test('production gravity lands on the current shared surface before replanning and never overshoots it',()=>{
 const landings=[],sounds=[],x={groundPosition:(_s,p)=>({...p,y:187,outside:true}),beginGroundedReturn:(s,a,p)=>landings.push({s,a,p}),feedbackSound:(...args)=>sounds.push(args)};
 vm.createContext(x);vm.runInContext(productionLine('stepOutdoorGravity'),x);
 const actor={outdoorFall:{x:80,y:20,velocity:0,outside:true},walking:true,foot:{x:1,y:2}};
 for(let n=0;n<200&&actor.outdoorFall;n++){x.stepOutdoorGravity({key:'agent'},actor,.05);if(actor.outdoorFall)assert.ok(actor.outdoorFall.y<=187);assert.equal(actor.walking,false);assert.equal(actor.foot,null);}
 assert.equal(actor.outdoorFall,null);assert.equal(landings.length,1);assert.equal(landings[0].p.y,187);assert.equal(landings[0].p.x,80);assert.equal(sounds.length,1);
});

test('summit dirt emits on an allowed outward crossing only and caps the shared burst collection',()=>{
 const x={sceneHill:()=>({cx:800,peak:207}),layout:{bodyRadius:29},feedbackClock:0,summitPuffs:[],summitPuffSerial:0};vm.createContext(x);vm.runInContext(productionLine('trackSummitCrossing'),x);
 const actor={},inside={x:800,y:207,outside:false},outside={x:800,y:207,outside:true};
 x.trackSummitCrossing(actor,outside);assert.equal(x.summitPuffs.length,0,'an initial exterior observation is not an exit');
 x.trackSummitCrossing(actor,inside);x.trackSummitCrossing(actor,outside);assert.equal(x.summitPuffs.length,1);
 x.trackSummitCrossing(actor,inside);assert.equal(x.summitPuffs.length,1,'entry is silent');
 x.feedbackClock=1;x.trackSummitCrossing(actor,outside,false);assert.equal(x.summitPuffs.length,1,'paused or held transitions suppress effects');
 const distant={summitOutside:false};x.trackSummitCrossing(distant,{x:100,y:207,outside:true});assert.equal(x.summitPuffs.length,1);
 for(let i=0;i<40;i++){x.feedbackClock++;x.trackSummitCrossing({summitOutside:false},outside);}
 assert.equal(x.summitPuffs.length,24);assert.ok(x.summitPuffs.every(p=>p.direction==='out'&&p.x===800&&p.y===207));
});

test('decorative clock uses 180-second days, 360-second seasons and 45-second weather with explicit snow',()=>{
 for(const [n,season]of ['spring','summer','autumn','winter'].entries()){
  const start=n*360;assert.equal(F.outdoorEnvironment(start).season,season);assert.equal(F.outdoorEnvironment(start+359).season,season);
  const wet=F.outdoorEnvironment(start+45),painter=F.woodlandWeather(wet);
  assert.equal(wet.weather,season==='winter'?'snow':'rain');assert.equal(painter.snowing,season==='winter');assert.equal(painter.raining,season!=='winter');
  assert.equal(F.outdoorEnvironment(start+90).weather,'breeze');assert.equal(F.outdoorEnvironment(start+135).weather,'clear');
 }
 assert.equal(F.outdoorEnvironment(0).day,F.outdoorEnvironment(180).day);assert.equal(F.outdoorEnvironment(90).light,0);assert.equal(F.outdoorEnvironment(0).source,'visual cycle');
});

test('exit dust covers the full ant at the angle change, follows its actor and expires',()=>{
 const actor={summitOutside:false},puffs=[],ovals=[],ctx={globalAlpha:1,save(){},restore(){},fillRect(){}};
 const x={sceneHill:()=>({cx:800,peak:207}),layout:{bodyRadius:29},feedbackClock:0,summitPuffs:puffs,summitPuffSerial:0,stopped:()=>false,host:{dataset:{fitScale:'1'}},summitPuffMetrics:F.summitPuffMetrics,ctx,oval:(...args)=>ovals.push({args,alpha:ctx.globalAlpha})};
 vm.createContext(x);vm.runInContext(productionLine('trackSummitCrossing')+'\n'+productionLine('drawSummitPuffs'),x);
 x.trackSummitCrossing(actor,{x:810,y:195,outside:true},true,65);x.drawSummitPuffs();assert.deepEqual(ovals[0].args.slice(0,2),[810,195]);assert.equal(ovals[0].alpha,1);assert.ok(ovals[0].args[2]>=65*1.15);assert.ok(ovals[0].args[3]>=65*1.15);
 x.feedbackClock=.1;x.trackSummitCrossing(actor,{x:808,y:209,outside:true},true,65);assert.equal(puffs.length,1);assert.equal(puffs[0].x,808);assert.equal(puffs[0].y,209);
 x.feedbackClock=.7;x.drawSummitPuffs();assert.equal(puffs.length,0);
});

test('both main scene and magnifier put original grass behind ants and exit dust above them',()=>{
 const main=source.slice(source.indexOf(' function draw(){'),source.indexOf(' function frame(ms)'));
 assert.ok(main.indexOf('actorPaint(outdoorForeground)')<main.indexOf('actorPaint(()=>{drawFastTrail'));
 assert.ok(main.indexOf('drawSummitPuffs();')>main.indexOf('actorPaint(()=>{drawFastTrail'));
 const lens=source.slice(source.indexOf(' function drawMagnifier('),source.indexOf(' function actorPaint('));
 assert.ok(lens.indexOf('   outdoorForeground();')<lens.indexOf('drawFastTrail(s,a)'));
 assert.ok(lens.indexOf('drawSummitPuffs();')>lens.indexOf('drawFastTrail(s,a)'));
});

test('moving labels read layout once and only write changed pixel positions', () => {
 const reads = [], writes = [], nodes = new Map();
 const world = {};
 for (const [key, value] of Object.entries({offsetLeft: 5, offsetTop: 12, clientWidth: 1000})) {
  Object.defineProperty(world, key, {get() { reads.push(key); return value; }});
 }
 const context = {
  world, stage: {style: {left: '3px'}}, nativeLabelMetrics: () => ({font: 9.5}),
  nativeFrameLayout: null, floatingNameNodes: nodes, floatingNameSeen: new Set(),
  pendingNativeNames: new Map(), floatingNames: {append() {}},
  el() { return {dataset: {}, textContent: '', style: new Proxy({}, {
   set(styles, key, value) { writes.push(key); styles[key] = value; return true; }
  })}; }
 };
 vm.createContext(context);
 const start = source.indexOf(' function readNativeFrameLayout(');
 const end = source.indexOf(' function appearanceOf(', start);
 vm.runInContext(source.slice(start, end), context);
 context.nativeFrameLayout = context.readNativeFrameLayout();
 const box = {x: 20, y: 30, w: 60, h: 12};
 const queue = () => {
  context.nativeName('first', 'First agent', box, .5);
  context.nativeName('second', 'Second agent', box, .5);
 };
 queue();
 assert.equal(writes.length, 0);
 context.finishNativeNames();
 assert.deepEqual(reads, ['offsetLeft', 'offsetTop', 'clientWidth']);
 assert.equal(nodes.get('first').style.left, '18px');
 assert.equal(nodes.get('first').style.top, '27px');
 assert.equal(nodes.get('first').style.fontSize, '9.5px');
 const initialWrites = writes.length;
 queue();
 context.finishNativeNames();
 assert.equal(writes.length, initialWrites);
});
