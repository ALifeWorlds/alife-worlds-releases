import test from 'node:test';import assert from 'node:assert/strict';
import {mkdtemp,open,writeFile,readFile,appendFile,stat,rm} from 'node:fs/promises';import os from 'node:os';import path from 'node:path';
import {createNativeMetadataStore,recoverNativeMetadata,metadataFileKey,nativeMetadataProjection,safeNativeName} from '../lib/native-agent-metadata.mjs';
import {applyNativeProgress} from '../lib/native-progress.mjs';
const stamp='2026-11-09T10:00:00.000Z',id='20000000-0000-0000-0000-000000000001',projectId='10000000-0000-0000-0000-000000000001',row=(type,payload,timestamp=stamp)=>JSON.stringify({type,payload,timestamp})+'\n';
async function fixture(fn){const root=await mkdtemp(path.join(os.tmpdir(),'alife-metadata-')),file=path.join(root,'native.jsonl'),binding={id:'director',threadId:id,sessionPath:file};let time=Date.parse(stamp);const store=createNativeMetadataStore({root,projectId,now:()=>time});await writeFile(file,row('session_meta',{id,cwd:root}));const recover=async(previous=null,opts={})=>{const h=await open(file,'r');try{const s=await h.stat();return await recoverNativeMetadata(h,{size:s.size,binding,root,previous,fileKey:metadataFileKey(binding,s),...opts});}finally{await h.close();}};try{await fn({root,file,binding,store,recover,time:t=>time=t});}finally{assert(root.startsWith(os.tmpdir()+path.sep));await rm(root,{recursive:true,force:true});}}
test('cold metadata recovery exceeds activity window without interpreting private message content',async()=>fixture(async f=>{
 await appendFile(f.file,row('event_msg',{type:'thread_settings_applied',thread_id:id,thread_settings:{cwd:f.root,model:'gpt-6-astra',reasoning_effort:'xhigh',service_tier:'default',private:'SECRET'}}));
 const padding=row('response_item',{type:'message',role:'user',content:'PRIVATE-'.repeat(20000)});for(let n=0;n<24;n++)await appendFile(f.file,padding);
 const recovered=await f.recover();assert.equal(recovered.metadata.model.value,'gpt-6-astra');assert.equal(recovered.metadata.model.observedUtc,stamp);assert.equal(recovered.coverage,'current');assert(recovered.bytesRead>2*1024*1024);assert(!JSON.stringify(recovered).includes('PRIVATE'));assert(!JSON.stringify(recovered).includes('SECRET'));
}));
test('warm gap and restart retain verified metadata, stable revision and original observation time',async()=>fixture(async f=>{
 await appendFile(f.file,row('turn_context',{cwd:f.root,model:'gpt-6.1-sol',effort:'xhigh'}));let recovery=await f.recover();await f.store.update(f.binding,{recovery,index:{name:'Director 1.0',archived:false}});
 const file=path.join(f.root,'.alife-worlds/native-agent-metadata-v2.json'),before=await readFile(file,'utf8'),rev=f.store.status().revision;
 f.time(Date.parse(stamp)+600000);recovery=await f.recover(await f.store.get(f.binding));await f.store.update(f.binding,{recovery,index:{name:'Director 1.0',archived:false}});assert.equal(await readFile(file,'utf8'),before);assert.equal(f.store.status().revision,rev);
 const cold=createNativeMetadataStore({root:f.root,projectId});const prior=await cold.get(f.binding);assert.equal(prior.metadata.model.value,'gpt-6.1-sol');assert.equal(nativeMetadataProjection(prior).modelState,'stale');assert.equal(nativeMetadataProjection(prior).modelObservedUtc,stamp);
 const changed={...f.binding,threadId:'30000000-0000-0000-0000-000000000001'};assert.equal(await cold.get(changed),null);
}));
test('explicit null invalidates model; partial omissions preserve metadata; full tier omission clears tier',async()=>fixture(async f=>{
 await appendFile(f.file,row('event_msg',{type:'thread_settings_applied',thread_settings:{model:'gpt-6-astra',service_tier:'priority'}}));await f.store.update(f.binding,{recovery:await f.recover()});
 await appendFile(f.file,row('turn_context',{cwd:f.root,effort:'high'}));let r=await f.recover(await f.store.get(f.binding));assert.equal(r.metadata.model.value,'gpt-6-astra');assert.equal(r.metadata.serviceTier.value,'priority');await f.store.update(f.binding,{recovery:r});
 await appendFile(f.file,row('event_msg',{type:'thread_settings_applied',thread_settings:{model:null}}));r=await f.recover(await f.store.get(f.binding));assert.equal(r.metadata.model.value,null);assert.equal(r.metadata.serviceTier.value,null);
}));
test('native cwd mismatch refuses metadata and file truncation never reuses old applied settings',async()=>fixture(async f=>{
 await appendFile(f.file,row('turn_context',{cwd:path.dirname(f.root),model:'foreign'}));await assert.rejects(f.recover());
 await writeFile(f.file,row('session_meta',{id,cwd:f.root})+row('turn_context',{cwd:f.root,model:'gpt-6-astra'}));const old=await f.recover();await writeFile(f.file,row('session_meta',{id,cwd:f.root}));const fresh=await f.recover(old);assert.equal(fresh.metadata.model,null);
}));
test('pending metadata line is not lost at read boundary and bounded exhaustion is explicit',async()=>fixture(async f=>{
 const text=row('turn_context',{cwd:f.root,model:'gpt-6-astra'});await appendFile(f.file,text.slice(0,60));const first=await f.recover();assert.equal(first.metadata.model,null);await appendFile(f.file,text.slice(60));const next=await f.recover(first);assert.equal(next.metadata.model.value,'gpt-6-astra');
 const limited=await f.recover(null,{budget:10});assert.equal(limited.coverage,'bounded');assert.equal(limited.metadata.model,null);const repeated=await f.recover(limited);assert.equal(repeated.bytesRead,0);assert.equal(repeated.coverage,'bounded');
}));
test('unsafe names, title/request fallback, malformed/foreign cache cannot enter a durable projection',async()=>fixture(async f=>{
 assert.equal(safeNativeName('Piper 1.0.5'),'Piper 1.0.5');for(const name of ['C:\\Users\\private','name\nsecret','https://private.test','api_key=secret'])assert.equal(safeNativeName(name),null);
 await f.store.update(f.binding,{index:{title:'SECRET-REQUEST',name:'Piper 1.0.5',archived:true}});const a=await f.store.get(f.binding);assert.equal(a.name.value,'Piper 1.0.5');assert.equal(a.archived.value,true);assert(!JSON.stringify(a).includes('SECRET'));assert(!JSON.stringify(a).includes(f.file.replaceAll('\\','\\\\')));
 await writeFile(path.join(f.root,'.alife-worlds/native-agent-metadata-v2.json'),'{invalid}');const cold=createNativeMetadataStore({root:f.root,projectId});assert.equal(await cold.get(f.binding),null);assert.equal(cold.status().persistence,'unavailable');
}));
test('deliberate progress protocol accepts only same-agent commentary, never reasoning or normal prose',()=>{
 const s={},context={threadId:id},event={type:'response_item',timestamp:stamp,payload:{type:'message',role:'assistant',channel:'commentary',content:[{type:'output_text',text:'[ALife activity] Locating workspace.js occurrence | Reading the room label renderer'}]}};
 applyNativeProgress(s,event,context);assert.equal(s.progressUpdate.headline,'Locating workspace.js occurrence');const good=structuredClone(s.progressUpdate);const nativePhase={...event.payload,phase:'commentary'};delete nativePhase.channel;applyNativeProgress(s,{...event,payload:nativePhase},context);assert.deepEqual(s.progressUpdate,good);
 for(const payload of [{...event.payload,channel:'analysis'},{...event.payload,role:'user'},{...event.payload,content:[{type:'output_text',text:'Normal assistant commentary'}]},{...event.payload,thread_id:'foreign'},{...event.payload,content:[{type:'output_text',text:'[ALife activity] Reading C:\\Users\\private'}]}]){applyNativeProgress(s,{...event,payload},context);assert.deepEqual(s.progressUpdate,good);}
 applyNativeProgress(s,{type:'event_msg',payload:{type:'turn_started'}},context);assert.equal(s.progressUpdate,null);
});
