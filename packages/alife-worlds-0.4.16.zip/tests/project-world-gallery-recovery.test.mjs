import test from 'node:test';
import assert from 'node:assert/strict';
import {createProjectWorldGallery} from '../web/project-world-gallery.mjs';

const renderer={schemaVersion:1,bundleId:'colony-world113',worldVersion:'1.3.0',artifactSha256:'a'.repeat(64)},worldId='world-fixture';
globalThis.OWNER_SITE_CONTEXT={renderer};
const {createExistingWorldFramePreview}=await import('../web/owner-site/project-frame-adapter.mjs');

// A small DOM contract fixture, not a physical browser or human visual check.
class Node{
 constructor(tag='div'){this.tagName=tag;this.children=[];this.parentElement=null;this.dataset={};this.style={setProperty(){},removeProperty(){}};this.attributes=new Map();this.listeners=new Map();this.className='';this.hidden=false;this.disabled=false;this.textContent='';this.classList={add:(...names)=>this.className=[...new Set([...this.className.split(' ').filter(Boolean),...names])].join(' '),remove:(...names)=>this.className=this.className.split(' ').filter(n=>!names.includes(n)).join(' ')};}
 get childNodes(){return this.children;}get firstChild(){return this.children[0]||null;}
 get isConnected(){return this.root===true||!!this.parentElement?.isConnected;}
 get nextSibling(){if(!this.parentElement)return null;return this.parentElement.children[this.parentElement.children.indexOf(this)+1]||null;}
 append(...nodes){for(const n of nodes){if(n.parentElement){const rows=n.parentElement.children;rows.splice(rows.indexOf(n),1);}this.children.push(n);n.parentElement=this;}}
 moveBefore(n,reference){if(this.failMove)throw Error('Original return failed');if(n.parentElement){const rows=n.parentElement.children;rows.splice(rows.indexOf(n),1);}const at=reference?this.children.indexOf(reference):-1;if(at<0)this.children.push(n);else this.children.splice(at,0,n);n.parentElement=this;}
 remove(){if(this.failRemove)throw Error('Removal failed');if(this.parentElement){const rows=this.parentElement.children;rows.splice(rows.indexOf(this),1);this.parentElement=null;}}
 replaceChildren(...nodes){for(const n of [...this.children])n.remove();this.append(...nodes);}
 contains(n){return n===this||this.children.some(c=>c.contains(n));}
 setAttribute(k,v){this.attributes.set(k,v);}
 addEventListener(k,fn){if(!this.listeners.has(k))this.listeners.set(k,new Set());this.listeners.get(k).add(fn);}
 removeEventListener(k,fn){this.listeners.get(k)?.delete(fn);}
 click(){if(this.disabled)return;for(const fn of this.listeners.get('click')||[])fn({preventDefault(){},stopPropagation(){}});}
}
function fixture({mode='normal'}={}){
 const root=new Node();root.root=true;const original=new Node(),container=new Node(),scene=new Node(),frame=new Node('iframe'),next=new Node();root.append(original,container);original.append(scene,next);scene.append(frame);
 const doc={hidden:false,createElement:tag=>new Node(tag),addEventListener(){},removeEventListener(){},defaultView:{matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}})}};
 const project={id:worldId,name:'Fixture world',connection:{state:'ready',target:{url:'https://fixture.invalid/'}}},snapshot={world:{id:worldId}},preview={schemaVersion:3,kind:'owner-world-preview',worldId,renderer,snapshot},joined={snapshot,metadataMarker:{worldId,artifactSha256:renderer.artifactSha256}};
 let current={catalogResponse:{state:'current',catalog:{schemaVersion:1,kind:'owner-world-catalog',worldId,currentId:worldId,sourceState:'current',worlds:[project]}},preview,joined},behavior=mode,resolve,reject,originalAPI,lastStatus;
 const calls={create:0,dispose:0,motion:[]},getCurrentInput=()=>current;
 const gallery=createProjectWorldGallery({document:doc,container,expectedWorldId:worldId,ownerOrigin:'https://fixture.invalid',approvedRenderer:renderer,assertCatalogResponse:value=>{if(value.catalog&&value.catalog.worldId!==worldId)throw Error('Foreign catalog');return value;},getCurrentInput,createPreview:({host,project,renderer,onStatus})=>{
  calls.create++;lastStatus=onStatus;originalAPI=createExistingWorldFramePreview({host,project,renderer,scene,frame,worldId,currentId:worldId,getCurrentInput,syncVisibility(){},onStatus});
  if(behavior==='creation-throws')throw Error('Creation failed after moving the scene');
  return{...originalAPI,setMotion:value=>{calls.motion.push(value);originalAPI.setMotion(value);},dispose(){calls.dispose++;if(behavior==='throws')throw Error('Dispose failed');if(behavior==='false')return false;if(behavior==='left-content')return;if(behavior==='pending')return new Promise((r,j)=>{resolve=()=>{originalAPI.dispose();r();};reject=j;});return originalAPI.dispose();}};
 }});
 gallery.setActive(true);assert.equal(calls.create,1);assert(scene.isConnected);
 const entry=()=>gallery.element.children.find(n=>n.dataset.projectId===worldId),host=()=>entry()?.children[0]?.children[1]?.children[1]?.children[0];
 // Shell details are located by their class rather than copied renderer logic.
 const find=(node,cls)=>node.className.split(' ').includes(cls)?node:node.children.map(n=>find(n,cls)).find(Boolean);
 return{root,original,container,scene,frame,next,gallery,calls,entry,host:()=>find(gallery.element,'pw-preview'),recovery:()=>find(gallery.element,'pw-recover'),get current(){return current;},setCurrent:value=>current=value,setMode:value=>behavior=value,resolve:()=>resolve(),reject:()=>reject(Error('Original async return failed')),externalReturn:()=>originalAPI.dispose(),lateReady:()=>lastStatus({state:'ready',token:1})};
}
function assertRetained(f){assert(f.scene.isConnected);assert(f.gallery.element.isConnected);assert(f.host().contains(f.scene));assert.equal(f.gallery.getDiagnostics().pendingRecoveries,1);assert.equal(f.gallery.getDiagnostics().disposed,false);assert.equal(f.entry().dataset.preview,'unavailable');assert.equal(f.entry().dataset.motion,'paused');assert(f.recovery());}

test('renderer rebinding refuses a failed return and preserves its original recovery operation',()=>{
 const f=fixture({mode:'false'}),next={schemaVersion:1,bundleId:'colony-world999',worldVersion:'1.3.1',artifactSha256:'c'.repeat(64)};
 assert.equal(f.gallery.setApprovedRenderer(next),false);assertRetained(f);assert.equal(f.calls.dispose,1);
 assert.equal(f.gallery.setApprovedRenderer(next),false);assert.equal(f.calls.dispose,1,'Rebinding must not replay failed cleanup');
 f.setMode('normal');assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.scene.parentElement,f.original);
 assert.equal(f.gallery.setApprovedRenderer(next),true);assert.equal(f.gallery.getDiagnostics().pendingRecoveries,0);assert.equal(f.gallery.dispose(),true);
});

test('failed invalidation retains the sole scene/API and pauses it without automatic retries',()=>{
 const f=fixture();const beforeArt=f.entry().children[0].children[1].children[0].innerHTML;f.original.remove();f.current.catalogResponse.state='stale';f.gallery.update();assertRetained(f);assert.equal(f.calls.dispose,1);assert.equal(f.entry().children[0].children[1].children[0].innerHTML===beforeArt,true,'Retained scene keeps its matching sphere art');assert.deepEqual(f.calls.motion.at(-1),{running:false,visible:false});
 for(let i=0;i<3;i++){f.gallery.update();f.gallery.setMotion({running:true,visible:true});f.lateReady();}assert.equal(f.calls.dispose,1);assert.equal(f.calls.create,1);assertRetained(f);
 f.root.append(f.original);assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.scene.parentElement,f.original);assert.equal(f.gallery.getDiagnostics().pendingRecoveries,0);
});
test('outer clear on an unavailable catalog cannot clear or detach a failed-return host',()=>{
 const f=fixture();f.original.remove();f.setCurrent({...f.current,catalogResponse:{state:'unavailable',catalog:null}});assert.equal(f.gallery.update(),false);assertRetained(f);assert.equal(f.calls.dispose,1);
 f.gallery.update();assert.equal(f.calls.dispose,1);assertRetained(f);f.root.append(f.original);assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.scene.parentElement,f.original);assert.equal(f.gallery.getDiagnostics().previewInstances,0);assert.equal(f.entry(),undefined);
});
test('removing a project from the catalog retains its failed-return entry until explicit recovery',()=>{
 const f=fixture();f.original.remove();f.current.catalogResponse.catalog.worlds=[];f.gallery.update();assertRetained(f);assert.equal(f.calls.create,1);
 f.root.append(f.original);assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.entry(),undefined);assert.equal(f.scene.parentElement,f.original);
});
test('outer dispose reports incomplete and keeps the gallery attached until the original return succeeds',()=>{
 const f=fixture();f.original.remove();assert.equal(f.gallery.dispose(),false);assertRetained(f);assert.equal(f.gallery.getDiagnostics().disposing,true);
 assert.equal(f.gallery.dispose(),false);assert.equal(f.calls.dispose,1);assert.equal(f.gallery.update(),false);f.lateReady();assertRetained(f);
 f.root.append(f.original);f.recovery().click();assert.equal(f.gallery.getDiagnostics().disposed,true);assert.equal(f.gallery.element.isConnected,false);assert.equal(f.scene.parentElement,f.original);assert.equal(f.scene.isConnected,true);assert.equal(f.scene.nextSibling,f.next);
});
test('explicit false and non-returning successful callbacks retain content instead of clearing it',()=>{
 for(const mode of ['false','left-content']){const f=fixture({mode});f.current.catalogResponse.state='stale';f.gallery.update();assertRetained(f);assert.equal(f.calls.dispose,1);f.setMode('normal');assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.scene.parentElement,f.original);}
});
test('an in-flight async return is not replayed; rejection retains the original scene and recovery handle',async()=>{
 const f=fixture({mode:'pending'});assert.equal(f.gallery.dispose(),false);assertRetained(f);assert.equal(f.gallery.getDiagnostics().pendingTeardowns,1);assert.equal(f.recovery().disabled,true);assert.equal(f.gallery.retryCleanup(),false);assert.equal(f.calls.dispose,1);
 f.reject();await Promise.resolve();await Promise.resolve();assertRetained(f);assert.equal(f.gallery.getDiagnostics().pendingTeardowns,0);assert.equal(f.recovery().disabled,false);f.setMode('normal');assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.scene.parentElement,f.original);assert.equal(f.gallery.getDiagnostics().disposed,true);
});
test('async success settles the original operation and explicit completion does not dispose twice',async()=>{
 const f=fixture({mode:'pending'});assert.equal(f.gallery.dispose(),false);f.resolve();await Promise.resolve();await Promise.resolve();assert.equal(f.scene.parentElement,f.original);assert.equal(f.gallery.getDiagnostics().disposed,false);assert.equal(f.calls.dispose,1);assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.calls.dispose,1);assert.equal(f.gallery.getDiagnostics().disposed,true);
});
test('creation failure after moving the scene cannot erase an unknown original creation effect',()=>{
 const f=fixture({mode:'creation-throws'});assertRetained(f);assert.equal(f.calls.dispose,0);assert.equal(f.gallery.retryCleanup(),false);assert.equal(f.calls.create,1);assert(f.host().contains(f.scene));
 f.externalReturn();assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.scene.parentElement,f.original);assert.equal(f.gallery.getDiagnostics().pendingRecoveries,0);
});
test('normal teardown returns the same scene, removes only its empty gallery and reports disposed',()=>{
 const f=fixture();assert.equal(f.gallery.dispose(),true);assert.equal(f.scene.parentElement,f.original);assert.equal(f.frame.parentElement,f.scene);assert.equal(f.scene.nextSibling,f.next);assert.equal(f.gallery.element.isConnected,false);assert.equal(f.calls.dispose,1);assert.equal(f.gallery.dispose(),true);assert.equal(f.calls.dispose,1);assert.equal(f.gallery.getDiagnostics().cleanupFailures,0);
});
test('failed shell removal cannot make outer disposal detach retained content or claim completion',()=>{
 const f=fixture();f.entry().failRemove=true;assert.equal(f.gallery.dispose(),false);assert(f.gallery.element.isConnected);assert.equal(f.scene.parentElement,f.original);assert.equal(f.gallery.getDiagnostics().disposed,false);assert.equal(f.gallery.getDiagnostics().pendingRecoveries,1);
 f.entry().failRemove=false;assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.calls.dispose,1);assert.equal(f.gallery.getDiagnostics().disposed,true);
});
test('unknown outer content is retained rather than swept away during gallery disposal',()=>{
 const f=fixture(),unknown=new Node('section');f.gallery.element.append(unknown);assert.equal(f.gallery.dispose(),false);assert(unknown.isConnected);assert.equal(f.scene.parentElement,f.original);assert.equal(f.gallery.getDiagnostics().pendingRecoveries,1);assert.equal(f.gallery.getDiagnostics().disposed,false);
 unknown.remove();assert.equal(f.gallery.retryCleanup(),true);assert.equal(f.gallery.getDiagnostics().disposed,true);
});
