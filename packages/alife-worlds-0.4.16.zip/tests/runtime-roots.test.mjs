import {writeTestConfig} from './test-config.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdir,mkdtemp,writeFile,readFile,rm,symlink} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createAdapter} from '../adapters/native-session-adapter.mjs';
import {loadRegistry,createProjection} from '../lib/projection.mjs';
import {createApp} from '../server.mjs';
const registry=await loadRegistry(),scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));
const projectId='10000000-0000-0000-0000-000000000000',threadId='20000000-0000-0000-0000-000000000000',stamp=new Date().toISOString();
const row=(type,payload)=>JSON.stringify({type,payload,timestamp:stamp})+'\n';
async function fixture(fn){
 await mkdir(scratch,{recursive:true});const base=await mkdtemp(path.join(scratch,'roots-test-')),native=path.join(base,'native'),planning=path.join(base,'planning');
 await mkdir(path.join(native,'Agent'),{recursive:true});await mkdir(planning);
 const config={projectId,bindingsFile:'bindings.json',stateFile:'state.json'},session=path.join(native,'session.jsonl');
 const bindings={schemaVersion:1,projectId,projectRoot:native,agents:[{id:'world-requests',home:'Agent',threadId,hostId:'local',sessionPath:session}]};
 const state={schemaVersion:1,projectId,projectRoot:planning,projectName:'Source plan',observedUtc:stamp,agents:[],tasks:[],events:[]};
 const write=async(file,data)=>writeFile(file,JSON.stringify(data));
 await write(path.join(native,'bindings.json'),bindings);await write(path.join(planning,'state.json'),state);
 await write(path.join(native,'state.json'),{...state,projectName:'Wrong native planning file',projectId:'foreign'});
 await writeFile(session,row('session_meta',{id:threadId,cwd:native})+row('turn_context',{cwd:native,model:'gpt-6.1-sol',effort:'xhigh'})+row('event_msg',{type:'task_started',turn_id:'one'}));
 const identity={schemaVersion:1,roleId:'world-requests',threadId,projectId,workspacePath:native,homePath:path.join(native,'Agent')};
 await write(path.join(native,'Agent','receipt.json'),{...identity,accessVerified:true,contractsFullRead:true,retirementVersion:1});
 await write(path.join(native,'Agent','checkpoint.json'),{...identity,status:'working',taskIds:[],fullInstructions:'PRIVATE-CONTRACT'});
 const adapter=createAdapter({root:native,planningRoot:planning,config,registry});
 try{await fn({base,native,planning,session,config,bindings,state,write,adapter});}
 finally{assert.ok(path.resolve(base).startsWith(path.resolve(scratch)+path.sep));await rm(base,{recursive:true,force:true});}
}
test('separate source planning and exact native workspace retain identity, cwd and receipt',async()=>fixture(async f=>{
 const s=await f.adapter.readSnapshot(),a=s.agents.find(a=>a.roleId==='world-requests');assert.equal(s.projectName,'Source plan');assert.equal(a.instanceId,threadId);assert.equal(a.connected,true);assert.equal(a.onboarded,true);assert.equal(a.activityState,'working');assert.equal(a.observedUtc,stamp);
 f.state.projectName='Updated source plan';f.state.tasks=[{id:'new-source-task',ownerRoleId:'world-requests',title:'Source edit',stage:'Ready',steps:[]}];await f.write(path.join(f.planning,'state.json'),f.state);
 const next=await f.adapter.readSnapshot();assert.equal(next.projectName,'Updated source plan');assert.equal(next.tasks.length,1);assert.equal(next.agents.find(a=>a.roleId==='world-requests').observedUtc,stamp);
}));
test('native session cwd must remain coordination cwd rather than the source directory',async()=>fixture(async f=>{
 await writeFile(f.session,row('session_meta',{id:threadId,cwd:f.planning})+row('event_msg',{type:'task_started'}));const a=(await f.adapter.readSnapshot()).agents.find(a=>a.roleId==='world-requests');assert.equal(a.connected,false);assert.equal(a.connectionState,'refused');
}));
test('foreign canonical IDs/roots and native binding roots fail closed after the split',async()=>{
 for(const kind of ['snapshot-id','snapshot-root','binding-id','binding-root'])await fixture(async f=>{
  if(kind==='snapshot-id')f.state.projectId='foreign';if(kind==='snapshot-root')f.state.projectRoot=f.native;if(kind==='binding-id')f.bindings.projectId='foreign';if(kind==='binding-root')f.bindings.projectRoot=f.planning;
  await f.write(path.join(f.planning,'state.json'),f.state);await f.write(path.join(f.native,'bindings.json'),f.bindings);await assert.rejects(f.adapter.readSnapshot());
 });
});
test('relative roots and traversal in roots/state/bindings/homes are refused',async()=>{
 for(const kind of ['relative-native','relative-planning','root-traversal','state-traversal','binding-traversal','home-traversal'])await fixture(async f=>{
  let root=f.native,planningRoot=f.planning;const config={...f.config};
  if(kind==='relative-native')root='native';if(kind==='relative-planning')planningRoot='planning';if(kind==='root-traversal')planningRoot=f.planning+'/../planning';if(kind==='state-traversal')config.stateFile='../native/state.json';if(kind==='binding-traversal')config.bindingsFile='../planning/state.json';if(kind==='home-traversal'){f.bindings.agents[0].home='../planning';await f.write(path.join(f.native,'bindings.json'),f.bindings);}
  await assert.rejects(createAdapter({root,planningRoot,config,registry}).readSnapshot());
 });
});
test('redirected native/planning roots and redirected planning input are refused',async()=>{
 for(const kind of ['native-root','planning-root','state-file'])await fixture(async f=>{
  const alias=path.join(f.base,'alias');await symlink(kind==='native-root'?f.native:f.planning,alias,process.platform==='win32'?'junction':'dir');
  const options={root:f.native,planningRoot:f.planning,config:f.config,registry};
  if(kind==='native-root')options.root=alias;else if(kind==='planning-root')options.planningRoot=alias;else{await symlink(f.native,path.join(f.planning,'redirect'),process.platform==='win32'?'junction':'dir');options.config={...f.config,stateFile:'redirect/state.json'};}
  await assert.rejects(createAdapter(options).readSnapshot());
 });
});
test('split-root HTTP excludes private paths, keeps source assets and blocks supplied transport',async()=>fixture(async f=>{
 let calls=0;const app=await createApp({configFile:await writeTestConfig(f.base),mode:'live',nativeReadOnly:true,nativeWorkspaceRoot:f.native,commandsEnabled:true,commandAdapter:{dispatch:async()=>{calls++;}},adapter:f.adapter,journalPath:path.join(f.base,'journal.json')});
 try{const url=await app.listen(0),data=await(await fetch(url+'/api/dashboard')).json(),serialized=JSON.stringify(data);
  for(const root of [f.native,f.planning])assert.ok(!serialized.includes(JSON.stringify(root).slice(1,-1)));assert.ok(!serialized.includes('PRIVATE-CONTRACT'));assert.ok(!serialized.includes('nativeWorkspaceRoot'));assert.equal(data.feed.farmFacts.commands.transportEnabled,false);
  const actual=await readFile(new URL('../web/boot.js',import.meta.url),'utf8');assert.equal(await(await fetch(url+'/boot.js')).text(),actual);
  for(const route of ['/antfarm.config.json','/bindings.json','/Agent/receipt.json','/data/project-state.json','/api/config','/api/native-workspace','/%2e%2e/bindings.json'])assert.equal((await fetch(url+route)).status,404);
  assert.equal((await fetch(url+'/api/ant-farm-command',{method:'POST',body:JSON.stringify({agentId:threadId,action:'wake'})})).status,503);assert.equal(calls,0);
 }finally{await new Promise(resolve=>app.server.close(resolve));}
}));
test('nativeWorkspaceRoot is unavailable outside native read-only configuration',async()=>fixture(async f=>{
 await assert.rejects(createApp({configFile:await writeTestConfig(f.base),mode:'live',nativeReadOnly:false,nativeWorkspaceRoot:scratch}),/requires nativeReadOnly/);
}));
