import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdir,mkdtemp,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import {createOwnerRuleLibrary} from '../lib/owner-rule-library.mjs';
import {assertOwnerRuleLibraryResponse,selectRuleLibraryPacket,mountOwnerRuleLibrary} from '../web/owner-rule-library.mjs';
import {portableClipboard,parsePortableImport} from '../lib/portable-definitions.mjs';
import {parsePortableImport as browserParse} from '../web/portable-definitions.mjs';
import {createOwnerRuleLibraryClient} from '../web/owner-site/rule-library-client.mjs';
import {createApp} from '../server.mjs';
import {publicWorldId} from '../lib/public-world.mjs';
const worldId='world-rule-fixture';
function catalogs(){return Object.fromEntries(['plugin','world'].map(scope=>[scope,{scope,revision:2,requests:[{text:'PRIVATE REQUEST'}],groups:[{id:'safe-group',title:'Safe group',properties:[{id:'safe-rule',title:'Readable human label',description:'Short human explanation.',text:'Follow this detailed AI instruction.',active:true,history:[{text:'PRIVATE HISTORY'}]},{id:'retired-rule',title:'Retired',text:'PRIVATE INACTIVE',active:false}]}]}]));}
const fixture=()=>createOwnerRuleLibrary(catalogs(),{worldId});

test('active effective rule library round-trips whole scopes, groups and properties through Node and browser portable v2',()=>{
 const input=catalogs(),before=JSON.stringify(input),library=createOwnerRuleLibrary(input,{worldId});assert.equal(JSON.stringify(input),before);assert.equal(library.scopes.length,2);
 for(const scope of ['plugin','world'])for(const selection of [{scope},{scope,groupId:'safe-group'},{scope,groupId:'safe-group',propertyId:'safe-rule'}]){const packet=selectRuleLibraryPacket(library,selection),copy=portableClipboard(packet);assert.equal(packet.schemaVersion,2);assert.deepEqual(parsePortableImport(copy),packet);assert.deepEqual(browserParse(copy),packet);assert.equal(packet[scope].groups[0].properties[0].description,'Short human explanation.');assert.equal(packet[scope].groups[0].properties[0].text,'Follow this detailed AI instruction.');assert.equal(JSON.stringify(packet).includes('PRIVATE'),false);assert.equal(packet[scope].groups[0].properties.length,1);}
});

test('rule library rejects foreign identity, extra/private data, legacy packets and invalid modular selections',()=>{
 const base=fixture();for(const mutate of [v=>v.worldId='world-foreign',v=>v.extra='PRIVATE',v=>v.scopes.push(v.scopes[0]),v=>v.scopes[0].scope='agent',v=>v.scopes[0].revision=-1,v=>v.scopes[0].packet.schemaVersion=1,v=>v.scopes[0].packet.plugin.prompt='Extra prompt',v=>v.scopes[0].packet.plugin.groups[0].properties[0].history=[],v=>delete v.scopes[0].packet.plugin.groups[0].properties[0].description]){const value=structuredClone(base);mutate(value);assert.throws(()=>assertOwnerRuleLibraryResponse(value,{worldId}));}
 for(const selection of [{scope:'agent'},{scope:'plugin',propertyId:'safe-rule'},{scope:'world',groupId:'missing'},{scope:'plugin',groupId:'safe-group',propertyId:'missing'},{scope:'plugin',groupId:'../other'}])assert.throws(()=>selectRuleLibraryPacket(base,selection));
});

class Node{
 constructor(tag,doc){this.tagName=tag;this.ownerDocument=doc;this.dataset={};this.attributes={};this.children=[];this.listeners=new Map();this._text='';}
 set textContent(v){this._text=String(v);this.children=[];}get textContent(){return this._text+this.children.map(n=>n.textContent).join('');}
 append(...nodes){for(const node of nodes){if(node.tagName==='#fragment')this.append(...node.children);else{node.parentNode=this;this.children.push(node);}}}
 replaceChildren(...nodes){this.children=[];this._text='';this.append(...nodes);}
 setAttribute(k,v){this.attributes[k]=String(v);}addEventListener(k,v){this.listeners.set(k,v);}removeEventListener(k){this.listeners.delete(k);}
 querySelectorAll(selector){return descendants(this).filter(n=>selector==='details[data-rule-key]'&&n.tagName==='details'&&n.dataset.ruleKey);}
}
function descendants(root){return root.children.flatMap(n=>[n,...descendants(n)]);}
function dom(){const doc={createElement:tag=>new Node(tag,doc),createDocumentFragment:()=>new Node('#fragment',doc),hidden:false,listeners:new Map(),addEventListener(k,v){this.listeners.set(k,v);},removeEventListener(k){this.listeners.delete(k);}};doc.body=new Node('body',doc);return{doc,container:new Node('div',doc)};}

test('actual rule UI separates human labels and AI instructions and copy/clone only export the selected definition',async()=>{
 const {doc,container}=dom(),copies=[],clones=[],library=mountOwnerRuleLibrary(container,{worldId,documentRef:doc,clipboard:text=>copies.push(text),download:(text,name)=>clones.push({text,name})});library.update(fixture());
 assert.equal(container.children[0].open,undefined);assert.equal(descendants(container).filter(n=>n.className==='wf-rule-scope').length,2);assert(descendants(container).filter(n=>n.className==='wf-rule-scope').every(n=>n.open===false));
 const article=descendants(container).find(n=>n.className==='wf-rule-property');assert.equal(article.children[0].textContent,'Readable human label');assert.equal(article.children[1].textContent,'Short human explanation.');assert.equal(article.children[2].children[0].textContent,'AI instructions');assert.equal(article.children[2].children[1].textContent,'Follow this detailed AI instruction.');
 article.children[2].open=true;library.update(fixture());assert.equal(descendants(container).find(n=>n.className==='wf-rule-property'),article);const newer=fixture();newer.scopes[0].revision++;library.update(newer);assert.equal(descendants(container).find(n=>n.className==='wf-rule-instruction').open,true);
 const buttons=descendants(article).filter(n=>n.tagName==='button');await buttons[0].onclick();await buttons[1].onclick();assert.equal(copies.length,1);assert.equal(clones.length,1);const packet=parsePortableImport(copies[0]);assert.deepEqual(JSON.parse(clones[0].text),packet);assert.equal(packet.kind,'plugin');assert.equal(packet.plugin.groups.length,1);assert.equal(packet.plugin.groups[0].properties.length,1);assert.equal(clones[0].name,'plugin-safe-group-safe-rule.json');
 library.unavailable();assert.equal(descendants(container).filter(n=>n.className==='wf-rule-property').length,0);await buttons[0].onclick();assert.equal(copies.length,1);library.dispose();assert.equal(container.children.length,0);
});

test('unavailable/disposed library invalidates pending reads and never injects markup from a human label',async()=>{
 const {doc,container}=dom();let finish;const library=mountOwnerRuleLibrary(container,{worldId,documentRef:doc,request:()=>new Promise(resolve=>{finish=resolve;})}),pending=library.refresh();library.unavailable();finish(fixture());await pending;assert.equal(descendants(container).some(n=>n.className==='wf-rule-property'),false);
 const value=fixture();value.scopes[0].packet.plugin.groups[0].properties[0].title='<img onerror=alert(1)>';library.update(value);const heading=descendants(container).find(n=>n.tagName==='h4');assert.equal(heading.textContent,'<img onerror=alert(1)>');assert.equal(heading.children.length,0);library.dispose();assert.throws(()=>assertOwnerRuleLibraryResponse({...value,worldId:'world-other'},{worldId}));
});

test('owner rule client uses existing refresh notifications, bounded exact-origin reads and clears on presentation changes',async()=>{
 const {doc,container}=dom(),root=new Node('main',doc);root.dataset={workspaceAudience:'owner',operatorMode:'public'};root.querySelector=()=>container;const events=new Map();let reads=0,observerCallback;const win={location:{href:'https://owner.test/',origin:'https://owner.test'},setTimeout,clearTimeout,addEventListener:(k,v)=>events.set(k,v),removeEventListener:k=>events.delete(k),MutationObserver:class{constructor(fn){observerCallback=fn;}observe(){}disconnect(){}}};
 const client=createOwnerRuleLibraryClient({root,worldId,documentRef:doc,windowRef:win,fetcher:async(url,options)=>{reads++;assert.equal(url,'https://owner.test/api/rule-library?project='+worldId);assert.equal(options.credentials,'same-origin');assert.equal(options.redirect,'error');return Response.json(fixture());}});
 assert.equal(reads,0);const details=container.children[0];details.open=true;details.listeners.get('toggle')();await new Promise(setImmediate);assert.equal(reads,1);assert(descendants(container).some(n=>n.className==='wf-rule-property'));
 root.listeners.get('alife-workspace-refresh')({detail:{available:true}});await new Promise(setImmediate);assert.equal(reads,2);root.dataset.operatorMode='view';observerCallback();assert.equal(descendants(container).some(n=>n.className==='wf-rule-property'),false);client.dispose();assert.equal(events.has('pagehide'),false);
});

test('owner rule reads clear old exports on auth loss, reject oversized bodies and refuse an alternate source before fetch',async()=>{
 const {doc,container}=dom(),root=new Node('main',doc);root.dataset={workspaceAudience:'owner',operatorMode:'public'};root.querySelector=()=>container;let mode='good',reads=0;
 const win={location:{href:'https://owner.test/',origin:'https://owner.test'},setTimeout,clearTimeout,addEventListener(){},removeEventListener(){}};
 const client=createOwnerRuleLibraryClient({root,worldId,documentRef:doc,windowRef:win,fetcher:async()=>{reads++;return mode==='auth'?new Response(null,{status:403}):mode==='large'?new Response('x',{headers:{'Content-Type':'application/json','Content-Length':String(3*1024*1024)}}):Response.json(fixture());}});
 container.children[0].open=true;const refresh=async()=>{client.refresh();await new Promise(setImmediate);};await refresh();assert(descendants(container).some(n=>n.className==='wf-rule-property'));
 mode='auth';await refresh();assert.equal(descendants(container).some(n=>n.className==='wf-rule-property'),false);mode='large';await refresh();assert.equal(descendants(container).some(n=>n.className==='wf-rule-property'),false);assert.equal(reads,3);
 container.dataset.ruleLibrarySource='https://foreign.test/api/rule-library';await refresh();assert.equal(reads,3);client.dispose();
});

test('owner rule endpoint resolves the selected effective override, refuses foreign requests and compiles the portable UI',async()=>{
 const source=fileURLToPath(new URL('../',import.meta.url)),scratch=path.join(source,'runtime/test-fixtures');await mkdir(scratch,{recursive:true});const project=await mkdtemp(path.join(scratch,'rule-library-')),projectId='rule-library-isolated';let app;
 try{
  await mkdir(path.join(project,'data'));await writeFile(path.join(project,'data/agent-bindings.json'),JSON.stringify({schemaVersion:1,projectId,projectRoot:project,agents:[]}));await mkdir(path.join(project,'.alife-worlds/imports'),{recursive:true});await writeFile(path.join(project,'.alife-worlds/imports/rules-overlay.json'),JSON.stringify({schemaVersion:1,projectId,projectRoot:project,revision:1,scopeRevisions:{plugin:1,world:0},operationId:'fixture',planSha256:'0'.repeat(64),overrides:[{scope:'plugin',groupId:'fixture-library',groupTitle:'Fixture library',propertyId:'selected',property:{id:'selected',title:'Selected override',description:'Selected project only.',text:'Use the selected project fixture.'},basePropertySha256:null}]}));
  const configFile=path.join(project,'config.json');await writeFile(configFile,JSON.stringify({mode:'live',nativeReadOnly:true,nativeWorkspaceRoot:project,projectId,projectName:'Fixture',commandsEnabled:false}));const profile=path.join(project,'profile.json');await writeFile(profile,JSON.stringify({schemaVersion:1,worlds:[]}));let nativeReads=0;app=await createApp({configFile,worldProjectsProfilePath:profile,adapter:{readSnapshot:async()=>{nativeReads++;throw Error('Not needed for rule reads');}}});const url=await app.listen(0),selectedWorld=publicWorldId(projectId);
  for(const suffix of ['?project=foreign','?project='+selectedWorld+'&project='+selectedWorld,'?extra=1'])assert.equal((await fetch(url+'/api/rule-library'+suffix)).status,404);assert.equal((await fetch(url+'/api/rule-library',{method:'POST'})).status,405);assert.equal((await fetch(url+'/api/rule-library',{headers:{Origin:'https://foreign.test'}})).status,403);assert.equal(nativeReads,0);
  const response=await fetch(url+'/api/rule-library?project='+selectedWorld);assert.equal(response.status,200);assert.equal(response.headers.get('cache-control'),'no-store');const value=assertOwnerRuleLibraryResponse(await response.json(),{worldId:selectedWorld});assert.equal(value.scopes[0].packet.plugin.groups.find(g=>g.id==='fixture-library').properties[0].title,'Selected override');assert.equal(nativeReads,0);
  const page=await(await fetch(url)).text(),client=await(await fetch(url+'/workspace.js')).text();assert(page.indexOf('id="wf-rule-library"')>page.indexOf('id="wf-sprint-list"'));assert(page.indexOf('id="wf-rule-library"')>page.indexOf('id="wf-agents"'));assert(page.indexOf('id="wf-rule-library"')<page.indexOf('</main>'));new vm.Script(client);assert(client.includes('mountOwnerRuleLibrary'));assert(client.includes('selectRuleLibraryPacket'));assert(!client.includes('node:crypto'));assert(!client.includes('Buffer.byteLength'));
  await rm(path.join(project,'data/agent-bindings.json'));assert.equal((await fetch(url+'/api/rule-library')).status,503);
 }finally{if(app){app.server.closeAllConnections();await new Promise(resolve=>app.server.close(resolve));}assert(path.resolve(project).startsWith(path.resolve(scratch)+path.sep));await rm(project,{recursive:true,force:true});}
});
