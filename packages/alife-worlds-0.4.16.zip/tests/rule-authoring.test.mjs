import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {emptyCatalog,readRuleCatalogs,validateCatalog,assertShareableCatalog,registryMarkdown,exportRulePrompt,applyRuleChange} from '../lib/rules.mjs';
import {createRuleProposal,proposeRuleChange,decideRuleProposal,applyAcceptedRuleProposal,reconcileRuleProposal} from '../lib/rule-authoring.mjs';
import {portablePacketFromCatalog,validatePortablePacket} from '../lib/portable-definitions.mjs';
import * as browser from '../web/portable-definitions.mjs';

const source=fileURLToPath(new URL('../',import.meta.url));
const input=(extra={})=>({change:{command:'/plugin refresh the site after approved changes',requestId:'rule-fixture-one',expectedRevision:0,groupId:'delivery',groupTitle:'Delivery',properties:[{id:'refresh',title:'Refresh approved sites',description:'Refresh existing approved destinations after qualified changes.',text:'When a qualified change affects an approved Site, use its saved destination consent and retain the original release identity. Confirm actual deployment separately from source publication.'}],...extra},analysis:{intent:'Refresh existing approved sites after qualified updates',weaknesses:['A refresh can be mistaken for permission to change audience.'],safeguards:['Keep the existing destination and owner boundary.'],conflicts:[],openQuestions:[]}});
async function fixture(fn){const parent=path.join(source,'runtime/test-fixtures');await mkdir(parent,{recursive:true});const root=await mkdtemp(path.join(parent,'rule-authoring-'));try{
 for(const dir of ['rules','data','roles'])await mkdir(path.join(root,dir));
 for(const s of ['plugin','world'])await writeFile(path.join(root,'rules',s+'.json'),JSON.stringify(emptyCatalog(s)));
 const roles=[{id:'director',title:'Director'}];await writeFile(path.join(root,'data/roles.json'),JSON.stringify(roles));
 await writeFile(path.join(root,'roles/SHARED.md'),'# Shared\nPreserve the actual human authority and original effects.\n');await writeFile(path.join(root,'roles/director.md'),'# Director\nOwn this explicit fixture scope.\n');await fn(root);
 }finally{assert(path.resolve(root).startsWith(path.resolve(parent)+path.sep));await rm(root,{recursive:true,force:true});}}
const decision=p=>({proposalId:p.id,proposalSha256:p.sha256,decision:'accept',sourceReference:'user-message:fixture-decision'});
const target=p=>({proposalId:p.id,proposalSha256:p.sha256});

test('proposal is read-only for rules; missing/rejected decisions cannot apply; accepted retry preserves original receipt',()=>fixture(async root=>{
 await assert.rejects(applyAcceptedRuleProposal(root,input().change),/Use propose/);
 const p=await proposeRuleChange(root,input());assert.equal((await readRuleCatalogs(root)).plugin.revision,0);
 assert.equal((await proposeRuleChange(root,input())).sha256,p.sha256);
 await assert.rejects(applyAcceptedRuleProposal(root,target(p)),/not been accepted/);
 await decideRuleProposal(root,{...decision(p),decision:'reject'});await assert.rejects(applyAcceptedRuleProposal(root,target(p)),/not been accepted/);
 await decideRuleProposal(root,decision(p));const first=await applyAcceptedRuleProposal(root,target(p)),again=await applyAcceptedRuleProposal(root,target(p));
 assert.deepEqual(again,first);assert.equal(first.state,'applied');const c=(await readRuleCatalogs(root)).plugin;assert.equal(c.revision,1);assert.equal(c.ruleFormatVersion,2);assert.equal(c.groups[0].properties[0].implementation,'documented');
 await assert.rejects(proposeRuleChange(root,input()),/revision changed/);
 assert.equal((await readFile(path.join(root,'docs/PLUGIN_RULES.md'),'utf8')).includes('**AI instructions**'),true);
}));
test('edited digests, open choices and a stale reviewed revision require renewed review',()=>fixture(async root=>{
 const p=await proposeRuleChange(root,input());await decideRuleProposal(root,decision(p));await assert.rejects(applyAcceptedRuleProposal(root,{...target(p),proposalSha256:'a'.repeat(64)}),/identity|digest/);
 const c=applyRuleChange(emptyCatalog('plugin'),{...input().change,requestId:'independent-change',properties:[{id:'independent',title:'Independent',description:'Preserve another owner change.',text:'Preserve the independent current requirement.'}]});await writeFile(path.join(root,'rules/plugin.json'),JSON.stringify(c));
 await assert.rejects(applyAcceptedRuleProposal(root,target(p)),/revision changed/);assert.equal((await readRuleCatalogs(root)).plugin.groups[0].properties[0].id,'independent');
 const next=input({expectedRevision:1,requestId:'rule-fixture-next'});next.analysis.openQuestions=['Which existing destination is selected?'];const q=await proposeRuleChange(root,next);await decideRuleProposal(root,decision(q));await assert.rejects(applyAcceptedRuleProposal(root,target(q)),/open questions/);
 const exact=await proposeRuleChange(root,input({expectedRevision:1,requestId:'same-revision-content'}));await decideRuleProposal(root,decision(exact));c.groups[0].title='Concurrent same-revision edit';await writeFile(path.join(root,'rules/plugin.json'),JSON.stringify(c));await assert.rejects(applyAcceptedRuleProposal(root,target(exact)),/source content changed/);
}));
test('unknown original outcomes are inspected without replay; a matching saved request reconciles original source time',()=>fixture(async root=>{
 const p=await proposeRuleChange(root,input()),dir=path.join(root,'runtime/RuleAuthoring'),record={schemaVersion:1,proposalId:p.id,proposalSha256:p.sha256,requestId:p.change.requestId,state:'unknown',reservedUtc:'2026-11-09T00:00:00.000Z'};await decideRuleProposal(root,decision(p));await writeFile(path.join(dir,p.id+'.application.json'),JSON.stringify(record));
 assert.equal((await applyAcceptedRuleProposal(root,target(p))).state,'unknown');assert.equal((await readRuleCatalogs(root)).plugin.revision,0);
 const when='2026-11-09T00:01:00.000Z',c=applyRuleChange(emptyCatalog('plugin'),p.change,when);await writeFile(path.join(root,'rules/plugin.json'),JSON.stringify(c));const result=await reconcileRuleProposal(root,target(p));assert.equal(result.state,'applied');assert.equal(result.appliedUtc,when);assert.equal((await readRuleCatalogs(root)).plugin.revision,1);
}));
test('new rules need human descriptions, unsupported fields are refused, and review is supplied rather than invented',()=>{
 const c=emptyCatalog('plugin'),bad=input();delete bad.change.properties[0].description;assert.throws(()=>createRuleProposal(c,bad),/description/);
 assert.throws(()=>createRuleProposal(c,{...input(),analysis:{intent:'Unreviewed'}}),/Review|review/);
 assert.throws(()=>createRuleProposal(c,{...input(),selfApproved:true}),/review|change/);
 const v=createRuleProposal(c,input());assert(!JSON.stringify(v).includes('refresh the site after approved changes'));assert.equal(v.sourceCommandSha256.length,64);assert.equal(v.analysis.weaknesses.length,1);
 assert.equal(v.preview.properties[0].before,null);assert.equal(v.preview.properties[0].after.description,input().change.properties[0].description);
 const current=applyRuleChange(c,input().change),disable=input({command:'/plugin disable the selected refresh rule',requestId:'disable-request',expectedRevision:1,properties:[{id:'refresh',operation:'disable'}]});const proposed=createRuleProposal(current,disable);
 assert.equal(proposed.preview.properties[0].before.active,true);assert.equal(proposed.preview.properties[0].after.active,false);assert.equal(proposed.preview.properties[0].after.text,current.groups[0].properties[0].text);
});
test('human/AI formats and versioned Node/browser portable round trips retain descriptions and long instructions',()=>{
 const c=applyRuleChange(emptyCatalog('plugin'),input().change),p=c.groups[0].properties[0];p.text+='\n'+('Keep this bounded detailed instruction. '.repeat(120));
 validateCatalog(c);const md=registryMarkdown(c),prompt=exportRulePrompt(c);for(const s of ['### Refresh approved sites','**For people**','**AI instructions**',p.description,p.text])assert(md.includes(s)&&prompt.includes(s));
 const packet=portablePacketFromCatalog('plugin','Fixture rules',c);assert.equal(packet.schemaVersion,2);assert.equal(packet.plugin.groups[0].properties[0].description,p.description);assert.deepEqual(validatePortablePacket(packet),browser.validatePortablePacket(packet));
 const legacy={format:'alife-portable',schemaVersion:1,kind:'plugin',title:'Legacy',plugin:{groups:[{id:'old',title:'Old',properties:[{id:'one',title:'Old label',text:'Preserve original legacy instructions.'}]}]}};assert.equal(validatePortablePacket(legacy).schemaVersion,1);
});
test('privacy checks include history/request metadata, and invalid auxiliary members cannot enter packets',()=>{
 const c=applyRuleChange(emptyCatalog('plugin'),input().change);const marker='API_KEY=DEMO-NOT-A-REAL-SECRET-123456789';
 const request=structuredClone(c);request.requests[0].id=marker;assert.throws(()=>assertShareableCatalog(request),/private/);
 const history=structuredClone(c);history.groups[0].properties[0].history=[{text:marker,active:true,supersededAt:new Date().toISOString()}];assert.throws(()=>assertShareableCatalog(history),/private/);
 const extra=structuredClone(c);extra.groups[0].properties[0].history=[{text:'Old safe text',active:true,supersededAt:new Date().toISOString(),hidden:'unreviewed'}];assert.throws(()=>validateCatalog(extra),/history/);
});

test('a CLI-sized request cannot create an oversized unreadable before/after proposal record',()=>{
 const properties=Array.from({length:65},(_,i)=>({id:'entry-'+i,title:'Entry '+i,description:'Preserve the bounded entry '+i+'.',text:'Current entry '+i+' '+('a'.repeat(11900))}));
 const current=applyRuleChange(emptyCatalog('plugin'),{...input().change,requestId:'prepare-large-current',properties});
 const request=input({expectedRevision:1,requestId:'replace-large-current',properties:properties.map(p=>({...p,text:'Updated '+p.id+' '+('b'.repeat(11900))}))});
 assert(Buffer.byteLength(JSON.stringify(request))<1024*1024);assert.throws(()=>createRuleProposal(current,request),/record bound/);
});
