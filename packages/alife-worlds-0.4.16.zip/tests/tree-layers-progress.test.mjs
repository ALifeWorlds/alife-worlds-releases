import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import {readFile} from 'node:fs/promises';
import {dashboardProgress} from '../web/dashboard-model.mjs';
const renderer=await readFile(new URL('../web/agent-outpost/agent-outpost.js',import.meta.url),'utf8'),art=await readFile(new URL('../web/agent-outpost/colony-art.js',import.meta.url),'utf8'),manifest=JSON.parse(await readFile(new URL('../web/agent-outpost/assets/midnight-colony-reference-20261107/sprites.json',import.meta.url),'utf8'));
function api(source,extra={}){const module={exports:{}};vm.runInNewContext(source,{module,require:()=>({}),URL,...extra});return module.exports;}
const rendererApi=api(renderer),artApi=api(art);
function canvasLog(){let x=0,y=0,scale=1;const stack=[],events=[];const ctx=new Proxy({events,save(){stack.push([x,y,scale]);},restore(){[x,y,scale]=stack.pop();},translate(dx,dy){x+=dx*scale;y+=dy*scale;},scale(s){scale*=s;},transform(){},createLinearGradient:()=>({addColorStop(){}}),fillRect(a,b,w,h){if(w>0&&h===310)events.push({type:'base',left:x+a*scale,right:x+(a+w)*scale});},drawImage(image,...args){if(['pines','trees'].includes(image.key))events.push({type:'near',left:x+args[4]*scale,right:x+(args[4]+args[6])*scale});}},{get:(o,k)=>k in o?o[k]:()=>{},set:(o,k,v)=>{o[k]=v;return true;}});return ctx;}
function painter(source){class Image{constructor(key){this.key=key;this.complete=true;this.naturalWidth=1536;this.naturalHeight=1024;}}const a=api(source,{Image});assert.equal(a.provideReferenceAssets({manifest,images:Object.fromEntries(['trees','pines','scenery','props'].map(k=>[k,new Image(k)])),fontReady:true}).state,'ready');return a;}
function functionChunk(source,start){let depth=0,quote=null,escaped=false;for(let i=source.indexOf('{',start);i<source.length;i++){const c=source[i];if(quote){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c===quote)quote=null;continue;}if(c==='"'||c==="'"||c==='`'){quote=c;continue;}if(c==='{')depth++;else if(c==='}'&&--depth===0)return source.slice(start,i+1);}throw Error('Incomplete focused painter function');}
function paintPanels(renderSource,artSource,width,{foreground=false}={}){const a=painter(artSource),ctx=canvasLog(),woodland=a.create(),environment={light:.8,day:true,u:.4,raining:false,season:'summer',ambientSeed:'fixture'};
 const context={ctx,W:width,SURFACE_Y:a.geometry(width).surface,sceneHill:()=>a.geometry(width),sceneSurface:x=>a.surface(width,x),artApi:a,model:{visualWorldKey:'scene-fixture'},placementSeed:rendererApi.placementSeed,woodland,woodlandActive:()=>true,woodlandEnvironment:()=>environment,clock:1,visualSeconds:()=>1,humanMotion:{x:width/2,waitUntil:Infinity},feedbackClock:0,drawHuman(){},wallpaperTarget(){}};
 const groundStart=renderSource.indexOf('const groundRefinement='),groundEnd=renderSource.indexOf('})();',groundStart)+5,ambientStart=renderSource.indexOf('function makeAmbientFrame('),ambientEnd=renderSource.indexOf('\n',ambientStart);assert(groundStart>=0&&groundEnd>groundStart&&ambientStart>=0);vm.runInNewContext(renderSource.slice(groundStart,groundEnd)+'\nglobalThis.groundRefinement=groundRefinement;\n'+renderSource.slice(ambientStart,ambientEnd),context);
 context.visualSeconds=()=>context.clock;context.grassLayer={draw:(g,spec)=>context.groundRefinement.paintBackgroundGrass(g,spec)};
 const begin=renderSource.indexOf('function paintWoodlandLayer('),end=renderSource.indexOf('function outdoorForeground()',begin);assert(begin>=0&&end>begin);vm.runInNewContext(renderSource.slice(begin,end),context);context.outdoorBackground();
 if(foreground){for(const [name,type]of [['paintTree','planted-tree'],['paintForeground','foreground']]){const original=woodland[name];woodland[name]=(...args)=>{ctx.events.push({type});return original(...args);};}const grass=context.groundRefinement.paintSurfaceGrass;context.groundRefinement.paintSurfaceGrass=(...args)=>{ctx.events.push({type:'surface-grass'});return grass(...args);};Object.assign(context,{colonyTree:()=>rendererApi.sprintTreeSite(width,a.geometry(width).artScale),canonicalProgress:{sprint:{percent:50,tasks:2,accepted:1}},feed:{observedUtc:new Date().toISOString()},privateMode:false,options:{},treeProgressPresentation:rendererApi.treeProgressPresentation});vm.runInNewContext(functionChunk(renderSource,end),context);context.outdoorForeground();}
 return ctx.events;
}

test('opaque tiled scenery finishes before any near-tree overhang at both normal and wide fitted widths',()=>{
 for(const width of [1600,2720,4200,6000]){const events=paintPanels(renderer,art,width),firstNear=events.findIndex(e=>e.type==='near');assert(firstNear>=0);assert(events.some(e=>e.type==='base'));assert(!events.slice(firstNear).some(e=>e.type==='base'));}
});

test('splitting the real painter preserves all selected near-tree sprite draws and the planted site',()=>{
 const a=painter(art),p=a.create(),e={day:true,light:.8,u:.5,season:'summer',hideTree:true};
 const oldOrder=canvasLog();p.paintBackdrop(oldOrder,e,1,{x:0,y:0},null);
 const split=canvasLog();p.paintBackdrop(split,{...e,deferNearTrees:true},1,{x:0,y:0},null);assert.equal(split.events.filter(e=>e.type==='near').length,0);p.paintNearTrees(split,e,1);
 assert.deepEqual(split.events.filter(e=>e.type==='near'),oldOrder.events.filter(e=>e.type==='near'));
 for(const width of [1600,2720,4200]){const events=paintPanels(renderer,art,width,{foreground:true}),tree=events.findIndex(e=>e.type==='planted-tree'),grass=events.findIndex(e=>e.type==='surface-grass'),foreground=events.findIndex(e=>e.type==='foreground');assert(tree>=0&&grass>tree&&foreground>grass);assert(!events.slice(tree).some(e=>e.type==='base'));}
 for(const width of [1600,2720,4200]){const site=rendererApi.sprintTreeSite(width,a.geometry(width).artScale);assert(Math.abs(site.y-298*a.geometry(width).artScale)<1e-9);assert.equal(site.bounds.w,144*site.scale);}
});

test('tree growth and independent Epic annotation use accepted canonical dashboard counts',()=>{
 const tasks=[{id:'done',stage:'Done',milestone:{delivered:true,acceptanceEvidence:'Recorded goal acceptance'}},{id:'review',stage:'QA',milestone:{steps:[{complete:true}],delivered:false}}],model={tasks,cfg:{},presentation:{id:'current',title:'Current sprint',taskIds:['done','review']},roadmap:{epic:{id:'epic',title:'Release'},sprints:[{id:'prior',taskIds:['done']},{id:'current',taskIds:['review']}]}};
 const canonical=dashboardProgress(model),feed={observedUtc:new Date().toISOString()},p=rendererApi.treeProgressPresentation(canonical,feed);
 assert.equal(canonical.sprint.percent,50);assert.equal(canonical.epic.percent,50);assert.equal(p.percent,50);assert.equal(p.epicPercent,50);assert.equal(p.badge,'Sprint 50% · Epic 50%');assert.equal(artApi.treeState(p.percent).id,'young');
 const missing=rendererApi.treeProgressPresentation({sprint:canonical.sprint},feed);assert.equal(missing.percent,50);assert.equal(missing.epicPercent,null);assert(missing.badge.endsWith('Epic unavailable'));
});

test('six growth states stay tied to real progress and unavailable/stale progress never creates zero or completion',()=>{
 const stamp=Date.now(),feed={observedUtc:new Date(stamp).toISOString()};
 for(const [percent,id]of [[0,'seed'],[1,'sprout'],[25,'sapling'],[50,'young'],[75,'mature'],[100,'complete']]){const p=rendererApi.treeProgressPresentation({sprint:{percent,tasks:2,accepted:percent===100?2:0}},feed,false,false,stamp);assert.equal(artApi.treeState(p.percent).id,id);}
 for(const value of [null,{percent:100,tasks:2,accepted:1},{percent:0,tasks:0},{percent:NaN,tasks:2}]){const p=rendererApi.treeProgressPresentation({sprint:value},feed,false,false,stamp);assert.equal(p.percent,null);assert.equal(artApi.treeState(p.percent).id,null);}
 const canonical={sprint:{percent:50,tasks:2,accepted:1},epic:{percent:25,tasks:4,accepted:1}};
 for(const f of [{...feed,error:'Unavailable'},{observedUtc:new Date(stamp-120001).toISOString()}]){const p=rendererApi.treeProgressPresentation(canonical,f,false,false,stamp);assert.equal(p.percent,null);assert.equal(p.epicPercent,null);}
 assert.equal(rendererApi.treeProgressPresentation(canonical,feed,true,false,stamp).badge,'');assert.equal(rendererApi.treeProgressPresentation(canonical,feed,true,true,stamp).badge,'Sprint 50% · Epic 25%');
});

test('the actual viewer forwards its already-sanitized percentages after world identity validation',async()=>{
 const source=await readFile(new URL('../web/world-view.mjs',import.meta.url),'utf8'),app=await readFile(new URL('../web/app.mjs',import.meta.url),'utf8');
 assert(source.includes('farm.render(next.model,next.feed,{sprint:next.summary?.current,epic:next.summary?.epic})'));assert(source.indexOf("throw Error('World identity mismatch');last=next;")<source.indexOf('farm.render(next.model,next.feed,'));
 assert(app.includes('farm.render(displayInput?.model??current.model,'));assert(app.includes('farm.render(held?.model??current.model,'));
 assert.equal((app.match(/:dashboardProgress\(current.model\)/g)||[]).length,2);
 assert(app.includes('sprint:displayInput.snapshot.summary?.current,epic:displayInput.snapshot.summary?.epic'));
 assert(app.includes('sprint:held.snapshot.summary?.current,epic:held.snapshot.summary?.epic'));
 const css=await readFile(new URL('../web/agent-outpost/agent-outpost.css',import.meta.url),'utf8');assert(!css.includes("content:'Sprint tree"));assert(css.includes('content:attr(data-progress)'));assert(css.includes('data-mode=view'));assert(renderer.includes('treeAnnotationGeometry(treeSite,treeState.height,'));
});


test('the compact wood sign stays beside the actual far-left sprint root and clears canonical text in View',()=>{
 const lo=renderer.indexOf('const groundRefinement='),hi=renderer.indexOf('// Display permissions',lo),context={};vm.runInNewContext(renderer.slice(lo,hi)+';this.ground=groundRefinement;',context);
 const ground=context.ground,progress={badge:'Sprint 50% · Epic 25%',percent:50,epicPercent:25,label:'Accepted current work'};
 assert.deepEqual(JSON.parse(JSON.stringify(ground.woodSignModel(progress,'public').rows)),[{name:'Epic',value:'25%'},{name:'Sprint',value:'50%'}]);assert.equal(ground.woodSignModel(progress,'view').visible,false);assert.equal(ground.woodSignModel({...progress,badge:''},'private').visible,false);
 for(const [width,fit]of [[1000,.304],[1600,.45],[1600,1],[3200,.6]]){const site=rendererApi.sprintTreeSite(width,artApi.geometry(width).artScale),box=ground.woodSignGeometry(site,width,fit,5);assert.equal(box.width,68);assert.equal(box.height,48);assert(box.left>=7&&box.left+box.width<=5+width*fit-2);assert(Math.abs(box.top+box.height-site.y*fit)<=4);assert(Math.abs(box.left+box.width/2-(5+site.x*fit))<=120);assert(box.left+box.width<5+width*fit*.5);}
});

test('real woodland and fallback pool painters use blue water while retaining seasonal material and pool geometry',()=>{
 const colors=new Set(),ctx=new Proxy({createLinearGradient:()=>({addColorStop(_,color){colors.add(color);}})},{get:(o,k)=>o[k]??(()=>{}),set:(o,k,v)=>(o[k]=v,(k==='fillStyle'||k==='strokeStyle')&&colors.add(v),true)});
 const pool={x:100,y:280,rx:23,ry:10};artApi.create().paintPool(ctx,pool,1,{day:true,light:1,season:'summer'});assert(colors.has('#478eae'));assert(colors.has('#285b70'));assert(!colors.has('#479847'));
 const i=renderer.indexOf('function drawSupplyPiles(){'),source=functionChunk(renderer,i),fallback=[];const context={woodlandActive:()=>false,supplies:[{id:'water',x:100,y:280,waterScale:1}],wallpaperPaint:(id,kind,box,paint)=>{assert.equal(kind,'water');assert.equal(box.w,48);assert.equal(box.h,20);paint();},ctx,clock:1,visualSeconds:()=>1,palette:{deep:'#000000',muted:'#fff'},oval:(x,y,rx,ry,color)=>fallback.push(color),text(){},host:{dataset:{fitScale:'1'}}};vm.runInNewContext(source,context);context.drawSupplyPiles();assert(fallback.includes('#478eae'));assert(fallback.includes('#285b70'));assert(!fallback.includes('#479847'));
});
