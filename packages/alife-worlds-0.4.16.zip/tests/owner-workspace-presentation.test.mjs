import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {createOwnerWorkspaceContract} from '../lib/owner-workspace-contract.mjs';
import {configureScrollableList,preserveListPositions} from '../web/list-presentation.mjs';

const source=await readFile(new URL('../web/owner-site/workspace-client.js',import.meta.url),'utf8');
const roles=[{id:'director',title:'Director',role:'director'},{id:'world-requests',title:'World Requests',role:'world-requests'}],worldId='world-fixture';
const walk=node=>[node,...node.children.flatMap(walk)];
function harness(audience='owner'){
 function node(tag){return {tag,dataset:{},children:[],attributes:{},style:{setProperty(){},removeProperty(){}},_text:'',get textContent(){return this._text+this.children.map(c=>c.textContent).join('');},set textContent(v){this._text=v;this.children=[];},append(...children){this.children.push(...children);},replaceChildren(...children){this.children=children;this._text='';},setAttribute(k,v){this.attributes[k]=v;},addEventListener(){},removeAttribute(k){delete this.attributes[k];}};}
 const root=node('main'),nodes=new Map();root.dataset.workspaceAudience=audience;root.querySelector=selector=>{const id=selector.slice(1);if(!nodes.has(id))nodes.set(id,node('div'));return nodes.get(id);};
 const context={configureScrollableList,preserveListPositions,OWNER_SITE_CONTEXT:{worldId,roles,publicOrigin:'https://public.invalid'},createOwnerWorkspaceContract,document:{getElementById:()=>root,createElement:node,createDocumentFragment:()=>node('fragment')},localStorage:{getItem:()=>null,setItem(){}}};
 const anchor="disclosure($('wf-current-work'),'section:current-work');";assert(source.includes(anchor));
 vm.runInNewContext(source.replace(anchor,"globalThis.presentation={taskCard,renderAgents,recordObservations,renderObservations,activityRows,setSnapshot(value){snapshot=value;envelope={state:'current',receivedUtc:value.observedUtc};}};return;\n"+anchor),context);
 return {api:context.presentation,nodes};
}
const time=offset=>new Date(Date.now()+offset).toISOString();
function agent(alias='role-director'){return {alias,name:alias==='role-director'?'Director':'World Requests',state:'working',connected:true,terminalIdle:false,observedUtc:time(-10000),workSummary:null,nativeActivity:null,nativeEvents:[],progressUpdate:null};}
function task(id='task-example'){return {id,title:'Actual task '+id,description:'PRIVATE_SCOPE_ONLY',goal:'Deliver the actual outcome',stage:'QA',done:false,known:true,assignedOwners:['role-director'],actingOwner:null,condition:'blocked',reference:'INTERNAL_REFERENCE_ONLY',progress:{percent:70,basis:'subtasks',completedSteps:7,totalSteps:10},steps:[{title:'INTERNAL_STEP_ONLY'}],details:{source:'canonical-task',current:'TASK_CONTEXT_IS_NOT_WORK',next:'Run the agreed check',blocker:'Waiting for the supplied input',sourceUpdatedUtc:time(-20000),qaRequired:true,qaRequirements:'Check the actual result'}};}
function snapshot(agents=[agent()],tasks=[]){return {kind:'owner-workspace',schemaVersion:5,worldId,sourceState:'current',observedUtc:time(0),tasks,agents};}

test('every task-card context contains only the task name and requested planning fields',()=>{
 const {api}=harness(),value=task(),before=JSON.stringify(value);
 for(const context of ['board','current-work','sprint:actual','agent:role-director']){
  const card=api.taskCard(value,context),all=walk(card);assert.equal(card.open,false);assert.equal(all.find(n=>n.tag==='summary').textContent,'›Actual task task-example');
  assert.deepEqual(all.filter(n=>n.className==='wf-field-label').map(n=>n.textContent),['Goal','QA needed','What QA entails','Blockers','Next']);
  assert.match(card.textContent,/Deliver the actual outcome/);assert.match(card.textContent,/Check the actual result/);assert.match(card.textContent,/Waiting for the supplied input/);assert.match(card.textContent,/Run the agreed check/);
  for(const excluded of ['PRIVATE_SCOPE_ONLY','INTERNAL_REFERENCE_ONLY','INTERNAL_STEP_ONLY','TASK_CONTEXT_IS_NOT_WORK','Owner:','Task progress','Task record updated','QA70%'])assert.equal(card.textContent.includes(excluded),false,excluded);
  assert.equal(all.some(n=>['progress','input','code'].includes(n.tag)),false);assert.equal(all.some(n=>n.className==='wf-badge'),false);
 }
 assert.equal(JSON.stringify(value),before);
 for(const required of [true,false,null]){value.details.qaRequired=required;const labels=walk(api.taskCard(value));const qa=labels.find(n=>n.className==='wf-task-field'&&n.children[0].textContent==='QA needed');assert.equal(qa.children[1].textContent,required===true?'Yes':required===false?'No':'Not recorded.');}
 delete value.details.qaRequired;delete value.details.qaRequirements;assert.match(api.taskCard(value).textContent,/Not recorded\./);
});

test('agent cards replace two latest entries and collapse full recorded assignment membership',()=>{
 const {api,nodes}=harness(),a=agent(),original=time(-8000),newer=time(-2000),tasks=Array.from({length:120},(_,i)=>task('task-'+i));
 a.workSummary={id:'activity-report-old',text:'Earlier reported result',recordedUtc:original};a.progressUpdate={id:'activity-report-new',headline:'Latest reported result',detail:'One concise detail',recordedUtc:newer};
 a.nativeActivity={id:'activity-native-old',kind:'tool',phase:'started',recordedUtc:original};a.nativeEvents=[a.nativeActivity,{id:'activity-native-new',kind:'file',phase:'completed',recordedUtc:newer}];
 const state=snapshot([a],tasks);api.setSnapshot(state);api.renderAgents();
 const host=nodes.get('wf-agent-list'),all=walk(host),fields=all.filter(n=>n.className==='wf-task-field'),observed=fields.filter(n=>n.children[0].textContent==='Observed activity'),reported=fields.filter(n=>n.children[0].textContent==='Last reported work');
 assert.equal(observed.length,1);assert.equal(reported.length,1);assert.match(observed[0].textContent,/File operation · completed/);assert.match(reported[0].textContent,/Latest reported result/);assert.equal(host.textContent.includes('Earlier reported result'),false);assert.equal(host.textContent.includes('TASK_CONTEXT_IS_NOT_WORK'),false);
 const assignments=all.find(n=>n.className==='wf-agent-assignments');assert.equal(assignments.tag,'details');assert.equal(assignments.open,false);assert.equal(assignments.children[0].textContent,'Recorded assignments (120)');const cards=walk(assignments).filter(n=>n.className==='wf-read-task');assert.equal(cards.length,120);assert.ok(cards.every(n=>n.open===false));assert.equal(new Set(cards.map(n=>n.dataset.taskId)).size,120);
 const scrolling=walk(assignments).find(n=>n.className==='wf-agent-task-list');assert.equal(scrolling.dataset.longList,'true');assert.equal(scrolling.dataset.listCount,'120');assignments.open=true;scrolling.scrollTop=250;
 a.workSummary={id:'activity-report-newest',text:'Replacement reported result',recordedUtc:time(-1000)};a.nativeEvents.push({id:'activity-native-newest',kind:'research',phase:'started',recordedUtc:time(-1000)});api.renderAgents();
 assert.match(host.textContent,/Replacement reported result/);assert.equal(host.textContent.includes('Latest reported result'),false);assert.match(host.textContent,/Research · started/);assert.equal(host.textContent.includes('File operation · completed'),false);
 assert.equal(walk(host).filter(n=>n.className==='wf-task-field'&&n.children[0].textContent==='Last reported work').length,1);
 assert.equal(walk(host).find(n=>n.className==='wf-agent-assignments'),assignments);assert.equal(assignments.open,true);assert.equal(scrolling.scrollTop,250);
 tasks[0].goal='Changed actual goal';api.renderAgents();assert.notEqual(walk(host).find(n=>n.className==='wf-agent-assignments'),assignments);assert.match(host.textContent,/Changed actual goal/);
});

test('activity retains three original events per agent, deduplicates polls and ignores task edits',()=>{
 const {api,nodes}=harness(),a=agent(),b=agent('role-world-requests');
 const event=(i)=>({id:'activity-'+i,kind:i%2?'tool':'command',phase:i%2?'started':'completed',recordedUtc:time(-12000+i*1000)});
 a.nativeEvents=Array.from({length:6},(_,i)=>event(i));a.nativeActivity=a.nativeEvents.at(-1);b.nativeEvents=Array.from({length:5},(_,i)=>event(20+i));b.nativeActivity=b.nativeEvents.at(-1);
 // Use actual past clocks for every actor, independent of their task records.
 b.nativeEvents.forEach((e,i)=>e.recordedUtc=time(-10000+i*1000));b.observedUtc=b.nativeActivity.recordedUtc;a.observedUtc=a.nativeActivity.recordedUtc;
 const state=snapshot([a,b],[task()]);api.setSnapshot(state);api.recordObservations();let rows=api.activityRows();assert.equal(rows.length,6);for(const value of [a,b])assert.equal(rows.filter(r=>r.alias===value.alias).length,3);
 const first=JSON.stringify(rows);api.recordObservations();assert.equal(JSON.stringify(api.activityRows()),first);
 state.tasks[0].details.current='UPDATED TASK CONTEXT';state.tasks[0].details.sourceUpdatedUtc=time(0);state.tasks[0].progress.percent=99;state.observedUtc=time(0);api.setSnapshot(state);api.recordObservations();assert.equal(JSON.stringify(api.activityRows()),first);
 const newest={id:'activity-last',kind:'file',phase:'completed',recordedUtc:time(-500)};a.nativeEvents.push(newest);a.nativeActivity=newest;a.observedUtc=newest.recordedUtc;api.recordObservations();rows=api.activityRows();assert.equal(rows.filter(r=>r.alias===a.alias).length,3);assert.equal(rows.some(r=>r.eventId==='activity-last'),true);assert.equal(rows.some(r=>r.eventId==='activity-3'),false);
 api.renderObservations();const rendered=walk(nodes.get('wf-activity-list')),times=rendered.filter(n=>n.tag==='time');assert.equal(times.length,6);assert.ok(times.some(n=>n.dateTime===newest.recordedUtc));assert.equal(rendered.some(n=>n.textContent.includes('UPDATED TASK CONTEXT')),false);
});

test('native, authored progress and checkpoint reports share the same three-entry window with original clocks',()=>{
 const {api,nodes}=harness(),a=agent(),at=[time(-9000),time(-7000),time(-5000),time(-3000)];
 a.nativeEvents=[{id:'activity-first',kind:'tool',phase:'completed',recordedUtc:at[0]},{id:'activity-second',kind:'file',phase:'completed',recordedUtc:at[1]}];a.nativeActivity=a.nativeEvents.at(-1);a.observedUtc=at[1];
 a.workSummary={id:'activity-report',text:'Actual checkpoint report',source:'agent-checkpoint',recordedUtc:at[2]};a.progressUpdate={id:'activity-progress',headline:'Actual authored progress',detail:'Recorded concise work',source:'agent-progress',recordedUtc:at[3]};
 api.setSnapshot(snapshot([a]));api.recordObservations();const rows=api.activityRows();assert.deepEqual(Array.from(rows,r=>r.kind),['progress','work','native']);assert.deepEqual(Array.from(rows,r=>r.observedUtc),[at[3],at[2],at[1]]);assert.equal(rows.some(r=>r.eventId==='activity-first'),false);api.recordObservations();assert.equal(api.activityRows().length,3);
 api.renderObservations();const text=nodes.get('wf-activity-list').textContent;assert.match(text,/Actual checkpoint report/);assert.match(text,/Actual authored progress/);
 const publicUI=harness('public');publicUI.api.setSnapshot({...snapshot([a]),kind:'public-workspace',schemaVersion:1});publicUI.api.renderAgents();publicUI.api.recordObservations();assert.equal(publicUI.nodes.get('wf-agent-list').textContent.includes('Actual checkpoint report'),false);assert.equal(publicUI.nodes.get('wf-agent-list').textContent.includes('Actual authored progress'),false);assert.equal(publicUI.api.activityRows().some(r=>['progress','work','native'].includes(r.kind)),false);
});
