import {customProjectRegistry} from './custom-project-registry.mjs';
import test from 'node:test';import assert from 'node:assert/strict';
import {readFile,mkdir,mkdtemp,copyFile,rm,lstat,realpath} from 'node:fs/promises';import path from 'node:path';import {fileURLToPath,pathToFileURL} from 'node:url';
import {assertPublicWorldSnapshot} from '../lib/public-world-contract.mjs';
import {createDemo} from '../lib/demo.mjs';import {createProjection,loadRegistry} from '../lib/projection.mjs';import {publicWorldSnapshot} from '../lib/public-world.mjs';import {dashboardProgress} from '../web/dashboard-model.mjs';import {createApp} from '../server.mjs';import {writeTestConfig} from './test-config.mjs';
import {collectPackageInputs,packageFingerprint,sealVersion} from '../lib/plugin-version.mjs';
const sourceRoot=fileURLToPath(new URL('../',import.meta.url)),scratchRoot=path.join(sourceRoot,'runtime','test-fixtures');
const registry=customProjectRegistry,coreRegistry=await loadRegistry();
test('world transport carries selected sprint props without duplicating the private full roadmap',async()=>{
 const input=createDemo(registry,'working'),stamp=input.observedUtc;
 input.tasks=Array.from({length:88},(_,i)=>({id:'bounded-task-'+i,title:'Private roadmap work '+i,ownerRoleId:registry[i%registry.length].id,dependencies:[],goal:'Private roadmap goal',scope:'Private scope',acceptance:[],stage:i<5?'Done':'In Progress',condition:'working',current:'Private current work',next:'Private next work',accepted:i<5,acceptanceEvidence:i<5?'Private recorded acceptance':null,activelyAssigned:true,updatedUtc:stamp,steps:Array.from({length:12},(_,j)=>({id:'part-'+j,title:'Private implementation detail',complete:false}))}));
 input.events=[];input.criticalTaskIds=[];input.roadmap=null;input.sprint={id:'selected-sprint',title:'Selected sprint',taskIds:input.tasks.slice(0,26).map(t=>t.id)};
 const source=await createProjection(registry,input),before=JSON.stringify(source),value=publicWorldSnapshot(source,registry,{worldId:'bounded-current-world'});
 assertPublicWorldSnapshot(value);assert.equal(source.model.tasks.length,88);assert.equal(value.model.tasks.length,26);assert.equal(Object.keys(value.model.cfg.cards).length,26);assert.equal(value.summary.current.tasks,26);assert.equal(value.summary.current.accepted,5);assert.ok(Buffer.byteLength(JSON.stringify(value))<=262144);
 const emitted=new Set(value.model.tasks.map(t=>t.id));for(const a of value.model.agents)assert.ok(a.owned.every(t=>emitted.has(t.id)));for(const row of value.feed.items)assert.ok(row.taskIds.every(id=>emitted.has(id)));
 assert.equal(JSON.stringify(source),before);assert.ok(!JSON.stringify(value).includes('Private roadmap'));
});
async function qualifiedFixtureApp(directory){
 const packet=path.join(directory,'packet');
 for(const relative of await collectPackageInputs(sourceRoot)){const target=path.join(packet,relative);await mkdir(path.dirname(target),{recursive:true});await copyFile(path.join(sourceRoot,relative),target);}
 const fingerprint=await packageFingerprint(packet,await collectPackageInputs(packet));assert.equal((await sealVersion(packet,fingerprint)).releaseState,'released');
 return (await import(pathToFileURL(path.join(packet,'server.mjs')).href)).createApp;
}
async function removePublicFixture(directory){
 const absolute=path.resolve(directory);assert.ok(absolute.startsWith(path.resolve(scratchRoot)+path.sep));assert.equal((await lstat(absolute)).isSymbolicLink(),false);assert.equal(await realpath(absolute),absolute);await rm(absolute,{recursive:true,force:true});
}
test('public projection keeps real credit/role counts while excluding private text, IDs, paths and models',async()=>{
 const input=createDemo(registry,'retirement'),uuid='20000000-0000-4000-8000-000000000001',secret='PRIVATE-PROJECT-REPORT';input.projectName='C:/Users/private/'+secret;input.agents[0].instanceId=uuid;for(const a of input.agents){a.report=secret;a.latestUpdate=secret;a.model='gpt-'+secret;}for(const t of input.tasks){t.title=secret;t.current=secret;t.goal=secret;t.acceptance=[secret];}input.agents.find(a=>a.roleId==='worker1').retirementAlert.reason=secret;
 const state=await createProjection(registry,input),original=JSON.stringify(state),pub=publicWorldSnapshot(state,registry,{worldId:'public-world'}),text=JSON.stringify(pub),p=dashboardProgress(state.model);
 assert.equal(pub.summary.represented,20);assert.equal(pub.summary.connected,20);assert.equal(pub.summary.current.percent,p.sprint.percent);assert.equal(pub.summary.epic.percent,p.epic.percent);assert.ok(!text.includes(secret));assert.ok(!text.includes(uuid));assert.ok(!text.includes('C:/Users'));assert.ok(!text.includes('codex://'));assert.ok(pub.model.agents.every(a=>a.model===null&&a.reasoningEffort===null));assert.equal(JSON.stringify(state),original);assert.equal(pub.feed.farmFacts.commands.transportEnabled,false);assert.ok(pub.model.tasks.every(t=>t.title==='Recorded work'));assert.equal(pub.feed.agentHealth.find(h=>h.threadId==='role-worker1').retirementNeeded,true);
});
test('public routes have no operator bootstrap, reject mutation/mismatched worlds before reading and serve exact safe data',async()=>{
 await mkdir(scratchRoot,{recursive:true});const dir=await mkdtemp(path.join(scratchRoot,'public-view-qualified-'));let reads=0,app;
 try{const createFixtureApp=await qualifiedFixtureApp(dir);app=await createFixtureApp({configFile:await writeTestConfig(dir),nativeReadOnly:false,mode:'live',adapter:{readSnapshot:async()=>{reads++;return createDemo(coreRegistry,'working');}}});const url=await app.listen(0);assert.equal((await fetch(url+'/api/world-view?project=another-world')).status,404);assert.equal(reads,0);for(const route of ['/world/view','/watch?embed=1']){const r=await fetch(url+route),html=await r.text();assert.equal(r.status,200);assert.ok(r.headers.get('content-security-policy').includes('frame-ancestors *'));assert.ok(html.includes('world-view.mjs'));assert.ok(!html.includes('FARM_COMMAND_CONTEXT'));assert.ok(!html.includes('task-board'));assert.ok(!html.includes('app.mjs'));}const r=await fetch(url+'/api/world-view'),data=await r.json();assert.equal(r.status,200);assertPublicWorldSnapshot(data);assert.equal(data.kind,'read-only-world');assert.equal(data.summary.connected,coreRegistry.length);const local=await(await fetch(url+'/api/dashboard')).json();assert.equal(data.model.visualWorldKey,local.model.visualWorldKey);for(const t of data.model.tasks)assert.ok(local.model.tasks.some(v=>v.visualKey===t.visualKey));assert.ok(data.model.agents.every(a=>a.model===null));assert.equal(data.feed.farmFacts.commands.transportEnabled,false);assert.equal((await fetch(url+'/api/world-view',{method:'POST'})).status,405);assert.equal((await fetch(url+'/world/view',{method:'POST'})).status,405);assert.equal((await fetch(url+'/api/ant-farm-command',{method:'POST'})).status,503);}
 finally{if(app?.server.listening)await new Promise(resolve=>app.server.close(resolve));await removePublicFixture(dir);}
});

test('unqualified source default stays unavailable while mismatches and mutations refuse before adapter reads',async()=>{
 await mkdir(scratchRoot,{recursive:true});const dir=await mkdtemp(path.join(scratchRoot,'public-view-unqualified-'));let reads=0,app;
 try{app=await createApp({configFile:await writeTestConfig(dir),nativeReadOnly:false,mode:'live',adapter:{readSnapshot:async()=>{reads++;return createDemo(coreRegistry,'working');}}});const url=await app.listen(0);assert.equal((await fetch(url+'/api/world-view?project=another-world')).status,404);assert.equal(reads,0);for(const route of ['/api/world-view','/world/view'])assert.equal((await fetch(url+route,{method:'POST'})).status,405);assert.equal((await fetch(url+'/api/ant-farm-command',{method:'POST'})).status,503);assert.equal(reads,0);const response=await fetch(url+'/api/world-view');assert.equal(response.status,503);assert.deepEqual(await response.json(),{error:'World display unavailable'});assert.equal(reads,1);assert.equal((await fetch(url+'/api/world-view?project=another-world')).status,404);assert.equal(reads,1);}
 finally{if(app?.server.listening)await new Promise(resolve=>app.server.close(resolve));await removePublicFixture(dir);}
});

test('viewer client uses only the public source and keeps explicit View; standalone styling blends without a card',async()=>{
 const js=await readFile(new URL('../web/world-view.mjs',import.meta.url),'utf8'),css=await readFile(new URL('../web/world-view.css',import.meta.url),'utf8');assert.ok(js.includes("presentationMode:'view'"));assert.ok(js.includes('source.origin!==location.origin'));assert.ok(!js.includes('sendAction'));assert.ok(!js.includes('command-exchange'));assert.ok(css.includes('background:transparent'));assert.ok(css.includes('border:0!important'));assert.ok(css.includes('overflow:hidden'));assert.ok(css.includes('prefers-reduced-motion'));
});

test('public display contract refuses private extensions, model settings, enabled commands and role identity drift',async()=>{const value=publicWorldSnapshot(await createProjection(registry,createDemo(registry,'working')),registry,{worldId:'public-world'});assertPublicWorldSnapshot(value,{expectedWorldId:'public-world'});assertPublicWorldSnapshot(publicWorldSnapshot(await createProjection(coreRegistry,createDemo(coreRegistry,'working')),coreRegistry,{worldId:'core-world'}),{expectedWorldId:'core-world'});for(const mutate of [s=>s.secret='private',s=>s.model.agents[0].model='private-model',s=>s.feed.farmFacts.commands.transportEnabled=true,s=>s.model.agents[0].threadId='role-worker1',s=>s.feed.agentHealth.push(s.feed.agentHealth[0]),s=>s.feed.agentHealth.pop(),s=>s.feed.agentHealth[0].threadId='role-foreign-member',s=>s.feed.agentHealth[0]=s.feed.agentHealth[1]]){const changed=structuredClone(value);mutate(changed);assert.throws(()=>assertPublicWorldSnapshot(changed,{expectedWorldId:'public-world'}));}assert.throws(()=>assertPublicWorldSnapshot(value,{expectedWorldId:'another-world'}));});

test('sanitizing identities preserves the same role-based world layout',async()=>{const state=await createProjection(registry,createDemo(registry,'working')),pub=publicWorldSnapshot(state,registry,{worldId:'shared-world'}),api=globalThis.AgentOutpost,local=api.project(state.model,state.feed),viewer=api.project(pub.model,pub.feed),a=api.gardenLayout(1600,local.stations),b=api.gardenLayout(1600,viewer.stations);assert.deepEqual(local.stations.map(s=>s.key),viewer.stations.map(s=>s.key));for(const [key,p]of a.places)assert.deepEqual(p.room,b.places.get(key).room);assert.equal(JSON.stringify(pub).includes('needsHumanInput'),false);});


test('opaque visual identities survive local/public/private aliases without changing authority or private omissions',async()=>{
 const {privateOperatorSnapshot}=await import('../lib/operator-projection.mjs'),{assertOperatorSnapshot}=await import('../lib/operator-contract.mjs'),input=createDemo(registry,'blocked');input.tasks[0].visualKey='PRIVATE-INPUT-IGNORED';const state=await createProjection(registry,input,Date.now(),{worldId:'parity-fixture-world'}),before=JSON.stringify(state),pub=publicWorldSnapshot(state,registry,{worldId:'parity-fixture-world'}),owner=privateOperatorSnapshot(state,registry,{projectId:'parity-owner',projectName:'Fixture',revision:'a'.repeat(64)});
 assert.match(state.model.visualWorldKey,/^scene-[a-f0-9]{14}$/);assert.equal(pub.model.visualWorldKey,state.model.visualWorldKey);assert.equal(owner.model.visualWorldKey,state.model.visualWorldKey);assertPublicWorldSnapshot(pub);assertOperatorSnapshot(owner,{projectId:owner.project.id});
 for(const t of state.model.tasks){assert.match(t.visualKey,/^visual-[a-f0-9]{14}$/);const safe=pub.model.tasks.find(v=>v.visualKey===t.visualKey),privateTask=owner.model.tasks.find(v=>v.visualKey===t.visualKey);assert.ok(safe&&privateTask);assert.notEqual(safe.id,t.id);assert.equal(safe.id,privateTask.id);assert.equal(pub.model.cfg.cards[safe.id].visualKey,t.visualKey);assert.equal(safe.milestone.delivered,t.milestone.delivered);assert.ok(!JSON.stringify(pub).includes(t.id));}
 assert.equal(JSON.stringify(state),before);assert.equal(JSON.stringify(pub).includes('PRIVATE-INPUT-IGNORED'),false);const a=globalThis.AgentOutpost.project(state.model,state.feed),b=globalThis.AgentOutpost.project(pub.model,pub.feed),c=globalThis.AgentOutpost.project(owner.model,owner.feed);assert.deepEqual(a.blockedPackages.map(t=>t.visualKey),b.blockedPackages.map(t=>t.visualKey));assert.deepEqual(a.blockedPackages.map(t=>t.visualKey),c.blockedPackages.map(t=>t.visualKey));
 const other=await createProjection(registry,input,Date.now(),{worldId:'other-parity-world'});assert.notEqual(other.model.visualWorldKey,state.model.visualWorldKey);assert.notEqual(other.model.tasks[0].visualKey,state.model.tasks[0].visualKey);
});
test('optional visual DTO fields remain closed, mapped and backward compatible',async()=>{
 const value=publicWorldSnapshot(await createProjection(registry,createDemo(registry,'working')),registry,{worldId:'parity-world'});for(const mutate of [s=>s.model.visualWorldKey='private/path',s=>s.model.tasks[0].visualKey='raw-task-id',s=>s.model.cfg.cards[s.model.tasks[0].id].visualKey='visual-00000000000000',s=>s.model.visualWorldKey={path:'private'}]){const v=structuredClone(value);mutate(v);assert.throws(()=>assertPublicWorldSnapshot(v));}
 const legacy=structuredClone(value);delete legacy.model.visualWorldKey;for(const t of [...legacy.model.tasks,...Object.values(legacy.model.cfg.cards),...legacy.model.agents.flatMap(a=>a.owned),...legacy.feed.roster.flatMap(a=>a.owned)])delete t.visualKey;assertPublicWorldSnapshot(legacy);
 const {privateOperatorSnapshot}=await import('../lib/operator-projection.mjs'),{assertOperatorSnapshot}=await import('../lib/operator-contract.mjs'),owner=privateOperatorSnapshot(await createProjection(registry,createDemo(registry,'working')),registry,{projectId:'parity-owner',projectName:'Fixture',revision:'a'.repeat(64)});for(const mutate of [s=>s.model.visualWorldKey='private',s=>s.model.tasks[0].visualKey='raw-task-id',s=>s.model.cfg.cards[s.model.tasks[0].id].visualKey='visual-00000000000000']){const v=structuredClone(owner);mutate(v);assert.throws(()=>assertOperatorSnapshot(v,{projectId:owner.project.id}));}
});

test('public projection names approved website and QA roles while withholding arbitrary private titles',async()=>{
 const extra=[{id:'web-developer',title:'PRIVATE-WEBSITE-TITLE',role:'worker'},{id:'qa-verification',title:'PRIVATE-QA-TITLE',role:'worker'},{id:'custom-private-role',title:'PRIVATE-UNKNOWN-TITLE',role:'worker'}].map(r=>({...registry.find(r=>r.id==='worker1'),...r}));
 const roster=[...registry,...extra],value=publicWorldSnapshot(await createProjection(roster,createDemo(roster,'working')),roster,{worldId:'public-role-names'});
 assertPublicWorldSnapshot(value);
 for(const [id,title]of [['web-developer','Web Dev 1.0.2'],['qa-verification','QA'],['custom-private-role','ALife Agent']]){
  for(const rows of [value.model.agents,value.feed.roster]){const row=rows.find(a=>a.roleId===id);assert.equal(row.title,title);assert.equal(row.role,'worker');}
  for(const task of value.model.tasks.filter(t=>t.ownerRoleId===id))assert.equal(task.owners[0],title);
 }
 assert.ok(!JSON.stringify(value).includes('PRIVATE-'));assert.equal(value.summary.represented,roster.length);
});
test('public role name cutover accepts only the two exact previous generic worker tuples',async()=>{
 const extra=[{id:'web-developer',title:'Private website title',role:'worker'},{id:'qa-verification',title:'Private QA title',role:'worker'}].map(r=>({...registry.find(r=>r.id==='worker1'),...r}));
 const roster=[...registry,...extra],value=publicWorldSnapshot(await createProjection(roster,createDemo(roster,'working')),roster,{worldId:'public-role-transition'});
 const legacy=JSON.parse(JSON.stringify(value),(key,v)=>(key==='title'||key==='visualHelperName')&&['Web Dev 1.0.2','QA'].includes(v)?'ALife Agent':key==='owners'&&Array.isArray(v)?v.map(name=>['Web Dev 1.0.2','QA'].includes(name)?'ALife Agent':name):v);
 assertPublicWorldSnapshot(legacy);
 for(const roleId of ['web-developer','qa-verification']){
  const privateTitle=structuredClone(value);privateTitle.model.agents.find(a=>a.roleId===roleId).title='Private custom title';assert.throws(()=>assertPublicWorldSnapshot(privateTitle));
  const wrongRole=structuredClone(legacy);wrongRole.model.agents.find(a=>a.roleId===roleId).role='director';assert.throws(()=>assertPublicWorldSnapshot(wrongRole));
 }
 const unrelated=structuredClone(value);unrelated.model.agents.find(a=>a.roleId==='director').title='ALife Agent';assert.throws(()=>assertPublicWorldSnapshot(unrelated));
 const swapped=structuredClone(value);swapped.model.agents.find(a=>a.roleId==='web-developer').title='QA';assert.throws(()=>assertPublicWorldSnapshot(swapped));
});

test('versioned Web Dev public label uses only its verified roster title and keeps safe references',async()=>{
 const extra=[{id:'web-developer',title:'Web Dev 1.0.3',role:'worker'},{id:'qa-verification',title:'PRIVATE-QA-TITLE',role:'worker'},{id:'custom-private-role',title:'Web Dev 2.3.4',role:'worker'}].map(r=>({...registry.find(r=>r.id==='worker1'),...r}));
 const roster=[...registry,...extra],state=await createProjection(roster,createDemo(roster,'working'));
 state.model.agents.find(a=>a.roleId==='web-developer').title='Web Dev 9.9.9';
 const card=Object.values(state.model.cfg.cards)[0];card.visualHelperName='Web Dev 1.0.3';
 const value=publicWorldSnapshot(state,roster,{worldId:'versioned-public-roles'});assertPublicWorldSnapshot(value);
 for(const [id,title]of [['web-developer','Web Dev 1.0.3'],['qa-verification','QA'],['custom-private-role','ALife Agent']]){
  for(const rows of [value.model.agents,value.feed.roster]){const a=rows.find(a=>a.roleId===id);assert.equal(a.title,title);assert.equal(a.role,'worker');}
  for(const task of value.model.tasks.filter(t=>t.ownerRoleId===id))assert.equal(task.owners[0],title);
 }
 assert.equal(Object.values(value.model.cfg.cards)[0].visualHelperName,'Web Dev 1.0.3');
 assert.ok(!JSON.stringify(value).includes('PRIVATE-QA-TITLE'));assert.ok(!JSON.stringify(value).includes('9.9.9'));assert.ok(!JSON.stringify(value).includes('2.3.4'));
});
test('versioned Web Dev receiver accepts bounded versions and old labels without widening other identities',async()=>{
 const extra=[{id:'web-developer',title:'Web Dev 1.0.3',role:'worker'},{id:'qa-verification',title:'QA',role:'worker'},{id:'custom-private-role',title:'Private custom role',role:'worker'}].map(r=>({...registry.find(r=>r.id==='worker1'),...r}));
 const roster=[...registry,...extra],value=publicWorldSnapshot(await createProjection(roster,createDemo(roster,'working')),roster,{worldId:'versioned-public-transition'});
 const replace=title=>JSON.parse(JSON.stringify(value),(key,v)=>v==='Web Dev 1.0.3'?title:v);
 for(const title of ['Web Dev 0.0.0','Web Dev 1.0.2','Web Dev 123456.999999.1','ALife Agent'])assertPublicWorldSnapshot(replace(title));
 for(const title of ['Web Dev 01.0.3','Web Dev 1.0.3-beta','Web Dev 1.0.3 private note','Web Dev 1000000.0.0','Web Dev 1.0','Web Dev -1.0.3','Web Dev 1.0.3\n'])assert.throws(()=>assertPublicWorldSnapshot(replace(title)));
 for(const id of ['qa-verification','custom-private-role','director']){const changed=structuredClone(value);changed.model.agents.find(a=>a.roleId===id).title='Web Dev 1.0.3';assert.throws(()=>assertPublicWorldSnapshot(changed));}
 const wrongRole=structuredClone(value);wrongRole.model.agents.find(a=>a.roleId==='web-developer').role='director';assert.throws(()=>assertPublicWorldSnapshot(wrongRole));
 const wrongOwner=structuredClone(value);wrongOwner.model.tasks.find(t=>t.ownerRoleId==='web-developer').owners[0]='Web Dev 1.0.2';assert.throws(()=>assertPublicWorldSnapshot(wrongOwner));
});
test('versioned Web Dev producer withholds unapproved raw roster labels',async()=>{
 for(const title of ['Web Developer private notes','Web Dev 1.0.3-beta','Web Dev 01.0.3','Web Dev 1.0.3\n']){
  const roster=[...registry,{...registry.find(r=>r.id==='worker1'),id:'web-developer',title,role:'worker'}];
  const value=publicWorldSnapshot(await createProjection(roster,createDemo(roster,'working')),roster,{worldId:'versioned-public-fallback'});assertPublicWorldSnapshot(value);
  assert.equal(value.model.agents.find(a=>a.roleId==='web-developer').title,'Web Dev 1.0.2');
 }
});
