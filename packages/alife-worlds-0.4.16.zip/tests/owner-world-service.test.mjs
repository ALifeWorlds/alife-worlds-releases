import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createOwnerWorldService} from '../lib/owner-world-service.mjs';
import {createOwnerPreviewHandler} from '../lib/owner-preview-handler.mjs';
import {createProjection} from '../lib/projection.mjs';
import {createDemo} from '../lib/demo.mjs';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {publicWorldSnapshot} from '../lib/public-world.mjs';
import {createLocalAppearance,LOCAL_PALETTE} from '../lib/local-world-appearance.mjs';
import {assertPublicWorldSnapshot} from '../lib/public-world-contract.mjs';
import '../web/launcher-world113/renderer.js';
const renderer=Object.freeze({schemaVersion:1,bundleId:'fixture-scene',worldVersion:'1.3.0',artifactSha256:'a'.repeat(64)});
const digestJSON=text=>createHash('sha256').update(text).digest('hex');
async function fixture(worldId='world-fixture',descriptor=renderer,{observedUtc=new Date().toISOString(),revision=1,contentHash='b'.repeat(64)}={}){
 const state=await createProjection(registry,createDemo(registry,'working'));
 state.feed.observedUtc=observedUtc;
 for(const agent of state.model.agents){agent.model=null;agent.modelSpeed=null;agent.reasoningEffort=null;}
 const snapshot=publicWorldSnapshot(state,registry,{worldId});
 const appearance=createLocalAppearance(state,registry,snapshot,descriptor,{oracle:globalThis.AgentOutpost,digestJSON});
 const names=snapshot.model.agents.map(a=>({id:a.threadId,name:'Fixture agent',source:'registry-fallback',observedUtc:null,state:'unknown'}));
 const agents=names.map(a=>({id:a.id,modelState:'unknown',modelSource:null,modelObservedUtc:null,selectedState:'unknown',selectedSource:null,selectedObservedUtc:null,presentationSource:'unknown',appliedToken:null}));
 return{schemaVersion:3,kind:'owner-world-preview',worldId,renderer:descriptor,snapshot,appearance,names,metadata:{revision,contentHash,agents}};
}
// Conditional evaluation and the write are one synchronous commit after the
// optional scheduling hook, matching R2's atomic precondition contract.
function bucket({beforePut,afterPut}={}){
 const rows=new Map([['owner-world-preview/current-v3.json','legacy recovery bytes']]),puts=[];
 const object=(key,text)=>({key,size:Buffer.byteLength(text),etag:digestJSON(text),httpEtag:JSON.stringify(digestJSON(text))});
 const store={rows,puts,async get(key){const text=rows.get(key);return text===undefined?null:{...object(key,text),text:async()=>text};},async put(key,text,options){
  assert(options?.onlyIf instanceof Headers,'Receiver writes must have a real R2 conditional header');
  const headers=options.onlyIf,match=headers.get('If-Match'),absent=headers.get('If-None-Match');
  assert(match!==null&&absent===null||match===null&&absent==='*','Exactly one atomic compare/create precondition is required');
  const call={key,text,match,absent,applied:false};puts.push(call);await beforePut?.(call,store);
  const current=rows.get(key);
  if(absent==='*'&&current!==undefined||match!==null&&(current===undefined||object(key,current).httpEtag!==match))return null;
  rows.set(key,text);call.applied=true;const result=object(key,text);await afterPut?.(call,store);return result;
 }};return store;
}
const request=(method='GET',value,extra={})=>new Request('https://fixture.invalid/api/owner-world-preview',{method,...(value?{body:JSON.stringify(value),headers:{'content-type':'application/json',...(extra.headers||{})}}:{}),...extra});
test('qualified owner storage isolates world and artifact, preserves legacy bytes, and rejects regression',async()=>{
 const store=bucket(),service=createOwnerWorldService({worldId:'world-fixture',renderer}),value=await fixture();
 assert.equal((await service.ownerWorldResponse(request(),{BUCKET:store})).status,503);
 assert.equal((await service.ownerWorldResponse(request('PUT',value),{BUCKET:store})).status,200);
 assert.deepEqual(await(await service.ownerWorldResponse(request(),{BUCKET:store})).json(),value);
 assert.equal(store.rows.get('owner-world-preview/current-v3.json'),'legacy recovery bytes');
 const key='owner-world-preview/world-fixture/'+renderer.artifactSha256+'/current-v3.json';assert.ok(store.rows.has(key));
 const before=store.rows.get(key),regression=structuredClone(value);regression.metadata.revision=0;
 assert.equal((await service.ownerWorldResponse(request('PUT',regression),{BUCKET:store})).status,409);assert.equal(store.rows.get(key),before);
 const other=createOwnerWorldService({worldId:'world-other',renderer});assert.equal((await other.ownerWorldResponse(request(),{BUCKET:store})).status,503);
 const nextRenderer={...renderer,artifactSha256:'c'.repeat(64)},next=createOwnerWorldService({worldId:'world-fixture',renderer:nextRenderer});
 assert.equal((await next.ownerWorldResponse(request(),{BUCKET:store})).status,503);
 assert.equal((await next.ownerWorldResponse(request('PUT',await fixture('world-fixture',nextRenderer)),{BUCKET:store})).status,200);assert.equal(store.rows.get(key),before);
});
test('owner receiver retains strict source, alias, freshness, browser-write and method guards',async()=>{
 const store=bucket(),service=createOwnerWorldService({worldId:'world-fixture',renderer}),value=await fixture(),env={BUCKET:store};
 for(const change of [v=>v.worldId='world-other',v=>v.renderer={...renderer,artifactSha256:'d'.repeat(64)},v=>v.names.pop(),v=>v.names[0].name='C:/private/secret',v=>v.metadata.agents[0].appliedToken=0,v=>v.extra='unapproved']){const bad=structuredClone(value);change(bad);assert.equal((await service.ownerWorldResponse(request('PUT',bad),env)).status,400);}
 assert.equal((await service.ownerWorldResponse(request('PUT',value,{headers:{'content-type':'application/json',Origin:'https://fixture.invalid'}}),env)).status,403);
 assert.equal((await service.ownerWorldResponse(request('POST'),env)).status,405);
 assert.equal((await service.ownerWorldResponse(new Request('https://fixture.invalid/api/owner-world-preview?project=world-other'),env)).status,404);
 assert.equal(await service.ownerWorldResponse(new Request('https://fixture.invalid/unrelated'),env),null);
 assert.throws(()=>createOwnerWorldService({worldId:'world-fixture',renderer:{...renderer,unapproved:true}}));
 await service.ownerWorldResponse(request('PUT',value),env);
 const key='owner-world-preview/world-fixture/'+renderer.artifactSha256+'/current-v3.json',stored=JSON.parse(store.rows.get(key));stored.receivedUtc=new Date(Date.now()-45001).toISOString();store.rows.set(key,JSON.stringify(stored));
 assert.equal((await service.ownerWorldResponse(request(),env)).status,503);
});
test('portable local producer and receiver agree without native settings or raw identities',async()=>{
 const state=await createProjection(registry,createDemo(registry,'working'));
 state.feed.observedUtc=new Date().toISOString();state.model.nativeMetadata={persistence:'available',revision:1,contentHash:'b'.repeat(64)};
 for(const agent of state.model.agents){agent.model=null;agent.appliedModel=null;agent.modelSpeed=null;agent.reasoningEffort=null;agent.modelPresentationSource='unknown';}
 const origin='http://127.0.0.1:12345',worldId='world-fixture',handler=createOwnerPreviewHandler({readCurrentState:async()=>state,registry,worldId,getOrigin:()=>origin,publicWorldSnapshot,assertPublicWorldSnapshot,createLocalAppearance,oracle:globalThis.AgentOutpost,descriptor:renderer,includeMetadata:true,palette:LOCAL_PALETTE});
 async function call(patch={}){const response={status:null,body:null,writeHead(status){this.status=status;},end(body){this.body=JSON.parse(body);}};await handler({url:'/api/owner-world-preview?project='+worldId,method:'GET',headers:{host:'127.0.0.1:12345'},socket:{remoteAddress:'127.0.0.1'},...patch},response);return response;}
 const accepted=await call();assert.equal(accepted.status,200);await createOwnerWorldService({worldId,renderer}).assertOwnerWorld(accepted.body);
 assert.equal((await call({socket:{remoteAddress:'192.0.2.1'}})).status,403);
 assert.equal((await call({headers:{host:'127.0.0.1:12345',origin:'https://foreign.invalid'}})).status,403);
 assert.equal((await call({method:'PUT'})).status,405);
 assert.equal((await call({url:'/api/owner-world-preview?project=world-other'})).status,404);
 state.model.nativeMetadata=null;assert.equal((await call()).status,503);
});

test('delayed older create cannot overwrite the newer observation and metadata',async()=>{
 const now=Date.now(),old=await fixture('world-fixture',renderer,{observedUtc:new Date(now-2000).toISOString()}),fresh=await fixture('world-fixture',renderer,{observedUtc:new Date(now-1000).toISOString(),revision:2,contentHash:'c'.repeat(64)});
 let release,entered;const paused=new Promise(resolve=>release=resolve),started=new Promise(resolve=>entered=resolve);
 const store=bucket({beforePut:async call=>{if(JSON.parse(call.text).envelope.metadata.revision===1){entered();await paused;}}}),service=createOwnerWorldService({worldId:'world-fixture',renderer}),env={BUCKET:store};
 const slow=service.ownerWorldResponse(request('PUT',old),env);await started;
 const fast=await service.ownerWorldResponse(request('PUT',fresh),env);assert.equal(fast.status,200);assert.equal((await fast.json()).applied,true);release();
 const late=await slow;assert.equal(late.status,409);const saved=await(await service.ownerWorldResponse(request(),env)).json();assert.equal(saved.metadata.revision,2);assert.equal(saved.snapshot.observedUtc,fresh.snapshot.observedUtc);
 assert.equal(store.puts.filter(p=>p.applied).length,1);assert(store.puts.every(p=>p.absent==='*'));
});

test('delayed older replacement loses its ETag comparison rather than replacing a newer head',async()=>{
 const now=Date.now(),base=await fixture('world-fixture',renderer,{observedUtc:new Date(now-3000).toISOString(),revision:0,contentHash:'a'.repeat(64)}),old=await fixture('world-fixture',renderer,{observedUtc:new Date(now-2000).toISOString()}),fresh=await fixture('world-fixture',renderer,{observedUtc:new Date(now-1000).toISOString(),revision:2,contentHash:'c'.repeat(64)});
 let release,entered;const paused=new Promise(resolve=>release=resolve),started=new Promise(resolve=>entered=resolve);
 const store=bucket({beforePut:async call=>{if(JSON.parse(call.text).envelope.metadata.revision===1){entered();await paused;}}}),service=createOwnerWorldService({worldId:'world-fixture',renderer}),env={BUCKET:store};
 assert.equal((await service.ownerWorldResponse(request('PUT',base),env)).status,200);
 const slow=service.ownerWorldResponse(request('PUT',old),env);await started;assert.equal((await service.ownerWorldResponse(request('PUT',fresh),env)).status,200);release();assert.equal((await slow).status,409);
 const saved=await(await service.ownerWorldResponse(request(),env)).json();assert.equal(saved.metadata.revision,2);assert.equal(saved.snapshot.observedUtc,fresh.snapshot.observedUtc);
 assert.equal(store.puts.filter(p=>p.applied).length,2);assert(store.puts.slice(1).every(p=>p.match!==null&&p.absent===null));
});

test('identical accepted retry keeps its original receipt after expiry without refreshing data',async()=>{
 const store=bucket(),service=createOwnerWorldService({worldId:'world-fixture',renderer}),env={BUCKET:store},value=await fixture(),first=await(await service.ownerWorldResponse(request('PUT',value),env)).json();
 assert.equal(first.applied,true);assert.equal(first.duplicate,false);const key=[...store.rows.keys()].find(k=>k.endsWith('/current-v3.json')&&k.includes('/world-fixture/')),saved=store.rows.get(key),writes=store.puts.length,realNow=Date.now;
 Date.now=()=>realNow()+60000;
 try{
  const response=await service.ownerWorldResponse(request('PUT',value),env);assert.equal(response.status,200);const retry=await response.json();assert.equal(retry.applied,false);assert.equal(retry.duplicate,true);assert.equal(retry.receivedUtc,first.receivedUtc);assert.equal(retry.deliverySha256,first.deliverySha256);
  assert.equal(store.puts.length,writes);assert.equal(store.rows.get(key),saved);assert.equal((await service.ownerWorldResponse(request(),env)).status,503);
 }finally{Date.now=realNow;}
});

test('same observation with different content is a conflict, and unknown expired input is refused',async()=>{
 const store=bucket(),service=createOwnerWorldService({worldId:'world-fixture',renderer}),env={BUCKET:store},value=await fixture();assert.equal((await service.ownerWorldResponse(request('PUT',value),env)).status,200);const writes=store.puts.length,changed=structuredClone(value);changed.names[0].name='Different safe fixture label';
 const mismatch=await service.ownerWorldResponse(request('PUT',changed),env);assert.equal(mismatch.status,409);assert.match((await mismatch.json()).error,/identity conflict/);assert.equal(store.puts.length,writes);
 const unknown=await fixture('world-fixture',renderer,{observedUtc:new Date(Date.now()-60000).toISOString()}),empty=bucket();assert.equal((await service.ownerWorldResponse(request('PUT',unknown),{BUCKET:empty})).status,409);assert.equal(empty.puts.length,0);
});

test('lost reply after a committed conditional write reconciles the original accepted delivery',async()=>{
 let lost=false;const store=bucket({afterPut:()=>{if(!lost){lost=true;throw Error('Fixture lost response');}}}),service=createOwnerWorldService({worldId:'world-fixture',renderer}),value=await fixture();
 const response=await service.ownerWorldResponse(request('PUT',value),{BUCKET:store});assert.equal(response.status,200);const receipt=await response.json();assert.equal(receipt.duplicate,true);assert.equal(receipt.applied,false);assert.equal(store.puts.length,1);
 const retry=await(await service.ownerWorldResponse(request('PUT',value),{BUCKET:store})).json();assert.equal(retry.receivedUtc,receipt.receivedUtc);assert.equal(retry.deliverySha256,receipt.deliverySha256);assert.equal(store.puts.length,1);
});

test('a proven accepted write keeps its receipt when a newer head wins before readback',async()=>{
 const now=Date.now(),old=await fixture('world-fixture',renderer,{observedUtc:new Date(now-2000).toISOString()}),fresh=await fixture('world-fixture',renderer,{observedUtc:new Date(now-1000).toISOString(),revision:2,contentHash:'c'.repeat(64)});
 let release,entered;const paused=new Promise(resolve=>release=resolve),started=new Promise(resolve=>entered=resolve);
 const store=bucket({afterPut:async call=>{if(JSON.parse(call.text).envelope.metadata.revision===1){entered();await paused;}}}),service=createOwnerWorldService({worldId:'world-fixture',renderer}),env={BUCKET:store};
 const original=service.ownerWorldResponse(request('PUT',old),env);await started;const firstReceived=JSON.parse(store.puts[0].text).receivedUtc;
 assert.equal((await service.ownerWorldResponse(request('PUT',fresh),env)).status,200);release();const receipt=await(await original).json();assert.equal(receipt.applied,true);assert.equal(receipt.receivedUtc,firstReceived);
 assert.equal((await(await service.ownerWorldResponse(request(),env)).json()).metadata.revision,2);assert.equal(store.puts.length,2);
 // A superseded delivery has no historical receipt ledger; it is not replayed.
 assert.equal((await service.ownerWorldResponse(request('PUT',old),env)).status,409);assert.equal(store.puts.length,2);
});

test('unsupported conditional storage, missing ETags and absent write receipts never enable an unconditional fallback',async()=>{
 const service=createOwnerWorldService({worldId:'world-fixture',renderer}),value=await fixture();let calls=0;
 const unsupported={async get(){return null;},async put(key,text,options){calls++;assert(options.onlyIf instanceof Headers);throw Error('Conditional writes unsupported');}};
 assert.equal((await service.ownerWorldResponse(request('PUT',value),{BUCKET:unsupported})).status,503);assert.equal(calls,1);
 const accepted=bucket();await service.ownerWorldResponse(request('PUT',value),{BUCKET:accepted});const key=[...accepted.rows.keys()].find(k=>k.includes('/world-fixture/'));
 const missing={async get(){const text=accepted.rows.get(key);return{size:Buffer.byteLength(text),text:async()=>text};},async put(){throw Error('Must not write without an ETag');}};
 assert.equal((await service.ownerWorldResponse(request('PUT',value),{BUCKET:missing})).status,503);
 let undefinedCalls=0;const undefinedReceipt={async get(){return null;},async put(key,text,options){undefinedCalls++;assert(options.onlyIf instanceof Headers);return undefined;}};
 assert.equal((await service.ownerWorldResponse(request('PUT',value),{BUCKET:undefinedReceipt})).status,503);assert.equal(undefinedCalls,1);
});

test('conditional contention is bounded and successful-write/readback mismatch remains unconfirmed',async()=>{
 const service=createOwnerWorldService({worldId:'world-fixture',renderer}),value=await fixture();let attempts=0;
 const contended={async get(){return null;},async put(key,text,options){attempts++;assert(options.onlyIf instanceof Headers);return null;}};
 assert.equal((await service.ownerWorldResponse(request('PUT',value),{BUCKET:contended})).status,409);assert.equal(attempts,4);
 let mismatchCalls=0;const mismatch={async get(){return null;},async put(){mismatchCalls++;return{etag:'fixture-etag',httpEtag:'"fixture-etag"'};}};
 assert.equal((await service.ownerWorldResponse(request('PUT',value),{BUCKET:mismatch})).status,503);assert.equal(mismatchCalls,1);
});
