import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdir,mkdtemp,writeFile,rm,readFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {customProjectRegistry as registry} from './custom-project-registry.mjs';
import {siteBundleFixture,projectId,ownerOrigin,configuration} from './site-sync-fixture.mjs';
import {createSiteBundleContract} from '../lib/site-sync-bundle.mjs';
import {PREVIEW_DESCRIPTOR} from '../lib/world-preview.mjs';
import {createSiteBundleSource} from '../lib/site-sync-source.mjs';
const script=fileURLToPath(new URL('../scripts/produce-site-bundle.mjs',import.meta.url)),scratch=fileURLToPath(new URL('../runtime/test-fixtures/',import.meta.url));
async function fixture(run){
 await mkdir(scratch,{recursive:true});const root=await mkdtemp(path.join(scratch,'site-producer-')),runtime=path.join(root,'.alife-worlds','runtime');await mkdir(path.join(runtime,'data'),{recursive:true});
 const f=await siteBundleFixture();f.plan.observedUtc=new Date(Date.now()-10800000).toISOString();f.bundle.ownerPreview.renderer={...PREVIEW_DESCRIPTOR};f.bundle.ownerPreview.appearance.renderer={...PREVIEW_DESCRIPTOR};f.dashboard.ownerPreview=f.bundle.ownerPreview;
 const config={nativeReadOnly:true,nativeWorkspaceRoot:root,projectId},configFile=path.join(runtime,'antfarm.config.json'),planFile=path.join(runtime,'data','project-state.json'),rolesFile=path.join(runtime,'data','roles.json');
 await writeFile(configFile,JSON.stringify(config));await writeFile(planFile,JSON.stringify(f.plan));await writeFile(rolesFile,JSON.stringify(registry));
 const reads=[],hooks={};const server=http.createServer(async(request,response)=>{reads.push(request.url);try{await hooks.onRead?.();response.writeHead(200,{'Content-Type':'application/json'});response.end(JSON.stringify(f.dashboard));}catch{response.writeHead(503);response.end();}});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin='http://127.0.0.1:'+server.address().port;
 async function command(args=[]){return new Promise((resolve,reject)=>{const child=spawn(process.execPath,[script,'--dashboard-origin',origin,'--owner-origin',ownerOrigin,'--revision','7','--catalog-profile',path.join(root,'absent-launcher-profile.json'),...args],{cwd:root,stdio:['ignore','pipe','pipe']});let stdout='',stderr='';const timer=setTimeout(()=>{child.kill();reject(Error('Producer did not terminate'));},10000);child.stdout.on('data',chunk=>{stdout+=chunk;});child.stderr.on('data',chunk=>{stderr+=chunk;});child.on('error',reject);child.on('close',code=>{clearTimeout(timer);resolve({code,stdout,stderr});});});}
 try{await run({root,runtime,f,config,configFile,planFile,rolesFile,reads,hooks,command,origin});}finally{await new Promise(resolve=>server.close(resolve));assert.ok(path.resolve(root).startsWith(path.resolve(scratch)+path.sep));await rm(root,{recursive:true,force:true});}
}
test('one-shot producer reads exactly one actual dashboard and original plan/registry without writes or native identities',async()=>fixture(async f=>{
 const before=await Promise.all([f.configFile,f.planFile,f.rolesFile].map(file=>readFile(file,'utf8'))),result=await f.command();assert.equal(result.code,0,result.stderr);
 const bundle=JSON.parse(result.stdout);await createSiteBundleContract({...configuration,renderer:PREVIEW_DESCRIPTOR}).assertBundle(bundle);assert.equal(bundle.revision,7);assert.ok(bundle.workspace.agents.length>3);assert.equal(bundle.catalog.sourceState,'unavailable');assert.deepEqual(f.reads,['/api/dashboard']);assert.equal(result.stdout.includes(projectId),false);assert.equal(result.stdout.includes(f.root),false);
 assert.equal(bundle.workspace.planningObservedUtc,bundle.observedUtc);assert.notEqual(bundle.workspace.planningObservedUtc,f.f.plan.observedUtc);assert.equal(bundle.workspace.tasks[0].details.sourceUpdatedUtc,f.f.plan.tasks[0].updatedUtc??null);assert.deepEqual(bundle.agentMetadata.agents.map(agent=>agent.activity.observedUtc),f.f.bundle.agentMetadata.agents.map(agent=>agent.activity.observedUtc));
 assert.deepEqual(await Promise.all([f.configFile,f.planFile,f.rolesFile].map(file=>readFile(file,'utf8'))),before);
}));
test('one-shot refuses a plan changed during dashboard read rather than merging two source observations',async()=>fixture(async f=>{
 f.hooks.onRead=async()=>{await writeFile(f.planFile,JSON.stringify({...f.f.plan,projectName:'Changed during dashboard read'}));};
 const result=await f.command();assert.notEqual(result.code,0);assert.equal(result.stdout,'');assert.match(result.stderr,/plan changed during dashboard observation/);assert.deepEqual(f.reads,['/api/dashboard']);
}));
test('stable file with task membership inconsistent with the captured dashboard is unavailable',async()=>fixture(async f=>{
 const plan={...f.f.plan,tasks:[...f.f.plan.tasks,{...f.f.plan.tasks[0],id:'fixture-new-task'}]};await writeFile(f.planFile,JSON.stringify(plan));const result=await f.command();assert.notEqual(result.code,0);assert.equal(result.stdout,'');assert.match(result.stderr,/membership changed/);assert.deepEqual(f.reads,['/api/dashboard']);
}));
test('foreign bootstrap binding refuses before any dashboard read and source script rejects duplicate arguments',async()=>fixture(async f=>{
 await writeFile(f.configFile,JSON.stringify({...f.config,nativeWorkspaceRoot:path.dirname(f.root)}));const result=await f.command();assert.notEqual(result.code,0);assert.equal(result.stdout,'');assert.deepEqual(f.reads,[]);
 const duplicate=await f.command(['--revision','8']);assert.notEqual(duplicate.code,0);assert.equal(duplicate.stdout,'');assert.deepEqual(f.reads,[]);
}));
test('reusable in-process reader observes twice without a child process or a renewed agent work clock',async()=>fixture(async f=>{
 const source=await createSiteBundleSource({projectRoot:f.root,dashboardOrigin:f.origin,ownerOrigin,catalogProfile:path.join(f.root,'absent-launcher-profile.json')});
 const first=await source.observe(8),second=await source.observe(9);assert.deepEqual(f.reads,['/api/dashboard','/api/dashboard']);assert.equal(source.roles.length,registry.length);assert.equal(first.revision,8);assert.equal(second.revision,9);assert.deepEqual(first.agentMetadata.agents.map(agent=>agent.activity.observedUtc),second.agentMetadata.agents.map(agent=>agent.activity.observedUtc));
 const cancelled=new AbortController();cancelled.abort();await assert.rejects(source.observe(10,{signal:cancelled.signal}));assert.equal(f.reads.length,2);
}));

test('an absent or explicitly unavailable qualified source preview never publishes a default substitute',async()=>fixture(async f=>{
 const source=await createSiteBundleSource({projectRoot:f.root,dashboardOrigin:f.origin,ownerOrigin,catalogProfile:path.join(f.root,'absent-launcher-profile.json')});
 f.f.dashboard.ownerPreview=null;await assert.rejects(source.observe(8),/no qualified owner preview/);
 delete f.f.dashboard.ownerPreview;await assert.rejects(source.observe(9),/no qualified owner preview/);
}));
