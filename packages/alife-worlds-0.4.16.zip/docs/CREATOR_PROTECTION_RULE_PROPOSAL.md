# Proposed creator-protection rule

Status: exact proposal accepted by the human on 10 November 2026 and applied to plugin catalogue revision 64. The human subsequently explicitly authorized main publication and the latest packet/Codex update; 0.4.5 records that approval. The exact AI instruction below is unchanged.

Human label: **
Preserve creator credit and contributor rights
**

Human description:
Protect verified creator recognition and legitimate notices while keeping MIT permissions, contributor rights, governance access and independent forks distinct.

## AI instructions

When this applies
When maintaining, modifying, packaging or releasing ALife Worlds or its plugin rules, documentation, dependencies, assets or branding.

Required behavior
Read current repository instructions, LICENSE, contribution/governance documents and relevant provenance before editing. Preserve the verified original-creator credit for Itzel Juarez and the owner-designated official repository, while distinguishing historical creator recognition, copyright holders, repository owners/administrators, maintainers, contributors and independent forks. Preserve all legitimate copyright, permission, contributor and third-party notices. Keep MIT unchanged unless the owner explicitly approves a change and the necessary rights/permissions are established; do not imply that a policy edit revokes existing MIT grants. Contributors retain applicable rights unless a valid written agreement provides otherwise. Acceptance of code, Git authorship or repository access does not automatically assign copyright or grant founder status, project-wide ownership, governance or release authority.

Safety and failure behavior
Follow adopted CONTRIBUTING.md, CONTRIBUTORS.md, GOVERNANCE.md and BRANDING.md; unadopted review drafts confer no authority. Never invent holders, assignments, agreements, registered trademarks, governing entities or administrator/maintainer appointments. Do not stamp the creator's name on code, assets or destination-world content they do not own. Keep lawful MIT copying, modification, redistribution, sublicensing and commercial use intact. Require the applicable explicit approval for official branding changes, policy publication/adoption, default-branch merges, contributor agreements, licensing changes and access grants. Flag uncertain claims and rights for human or appropriate legal review rather than filling gaps. Do not introduce paid legal platforms or change unrelated APIs, animation, agents, settings, private access or connection behavior for governance work.

Evidence
Run the attribution check and affected build/tests; inspect the final scoped diff and preserve reviewable source/provenance. Package the governance and notice files with the plugin. Record verified facts, manual-review items and separate source, Git, package, installation and policy-adoption results. A passing check is not a legal ownership opinion or automatic official endorsement.

## Review analysis

- Weakness: Creator credit and Git authorship do not prove ownership of every contribution or establish copyright assignment.
- Weakness: Collective holders, prior agreements, repository administrators and art-reference rights remain partly unverified.
- Weakness: MIT does not automatically establish registered trademark rights or a contributor agreement; mechanical checks cannot decide legal rights.
- Safeguard: Keep LICENSE and asset notices intact; package all governance/notice documents and check their accessibility.
- Safeguard: Distinguish adopted policies from review drafts and explicit role grants from contribution credit.
- Safeguard: Use a dedicated review branch; require policy/adoption approval, preserve MIT freedoms, and surface uncertain facts for review.
- Ownership: Complements existing source custody, semantic rule ownership, portable exports and release approval; those rules retain their owning facets.
- Ownership: Does not grant repository access, make an independent build official, restrict lawful MIT forks or alter current runtime/private connections.

Exact proposal SHA256:
22e1a055c7f468255a0061c95e9e9e9aaeee5dd9bdf08bd99a852fbc3301dc20
