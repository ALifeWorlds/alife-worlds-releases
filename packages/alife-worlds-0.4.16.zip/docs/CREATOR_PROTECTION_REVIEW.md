# Creator protection and open-source governance review

Status: **the human authorized official-main publication of the approved bundle and rule on 10 November 2026; 0.4.5 records that publication approval.** No role appointment, copyright assignment or legal clearance follows. Git publication and packet/installation results are recorded separately.

## Verified records

- The project owner confirmed **Itzel Juarez as ALife Worlds' original creator** on 10 November 2026. Existing plugin author/developer metadata and Git history also carry that name. This verifies the intended project credit, not ownership of every contribution.
- The owner selected **https://github.com/ALifeWorlds/alife-worlds** as the official review destination. Its Git `main` was read-verified at `773d14a486df5cb6eb1e25ac7d5c138f76d30075`, the 0.3.6 baseline already integrated into the independent source.
- The pre-change independent release is 0.4.3, commit `21be067343894735992e11fe2cc10ef650100c1a`. Its history begins with an imported source snapshot; the local author list is not a complete upstream contributor roster.
- LICENSE remains MIT with **Copyright (c) 2026 Ant Farm package contributors**. No notice is replaced, no assignment is inferred and no new per-file copyright is added.
- Font/audio license files and artwork provenance are retained. [The notice index](../THIRD_PARTY_NOTICES.md) links the records.

## Approved framework

[CONTRIBUTING](../CONTRIBUTING.md), [CONTRIBUTORS](../CONTRIBUTORS.md), [GOVERNANCE](../GOVERNANCE.md) and [BRANDING](../BRANDING.md) separate historical credit, per-work rights, platform access, maintenance, official release authority and independent distributions. Contribution acceptance supplies none of the other roles automatically. No CLA, copyright-assignment instrument, DCO requirement, registered trademark claim, legal entity or administrator roster is invented.

The attribution checker is a local, dependency-free review aid. It protects known notices, checks document links, and reports new notice/license/dependency inputs. It tolerates whitespace/line-ending differences. Passing it does not prove copyright ownership, permission, compatibility or an enforceable trademark right; maintainers can change checks, so human review/platform controls remain necessary.

## Facts requiring review

1. Identify the individual holders behind the existing collective notice and any applicable employment, assignment or earlier contribution agreements. None were found in the inspected source; absence is not proof none exist.
2. Verify official repository administrator/maintainer accounts, governing legal entity if any, steward appointment and private security-report route. The connected GitHub app cannot access this repository, although configured Git access can read it. Do not infer an access grant from creator credit or a Git author name.
3. Confirm rights to supplied art references and generated derivatives for intended distribution; provenance is not a complete rights clearance.
4. Seek appropriate legal review before adopting separate trademark restrictions, registering marks, requiring a contributor agreement/assignment, or changing licensing. Existing MIT permissions remain intact.
5. The human approved the exact new plugin rule and this governance bundle on 10 November 2026, reaffirming Itzel Juarez as original creator, and subsequently explicitly authorized pushing all completed changes to main and updating the packet/Codex. The rule is applied at plugin catalogue revision 64; its AI wording is unchanged by publication. No site/runtime behavior, private audience change or legal agreement follows.

## Reference principles

Use the [OSI MIT text](https://opensource.org/license/mit) for the permission/notice baseline. [Blender's licensing material](https://www.blender.org/about/license/) and [OpenClaw's contribution guide](https://github.com/openclaw/openclaw/blob/main/CONTRIBUTING.md) are organizational references, not licenses or governance instruments imported into this project. No affiliation or equivalent legal protection is claimed.
