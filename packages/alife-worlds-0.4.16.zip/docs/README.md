# ALife World documentation

An **ALife Agent** is the represented member of your agent team. An **ALife World** is the shared environment and the plugin that presents it.

Start with the [product overview and quick start](../README.md).

| Learn about | Document |
| --- | --- |
| Installing the local Codex packet | [Codex setup](CODEX.md) |
| Authoring /world, /plugin, /rule and /universal | [Rule commands](COMMANDS.md) |
| Data, identity, privacy, freshness and commands | [Integration](INTEGRATION.md) |
| Rooms, ALife Agents, motion and controls | [Visuals](VISUALS.md) |
| Safe maintenance and human-selected settings | [Operations](OPERATIONS.md) |
| Implemented baseline, release checks and requested world work | [Release readiness](OPERATIONS.md#release-readiness-and-remaining-world-work) |
| World versions, per-surface evidence and rollback | [World releases](WORLD_RELEASES.md) |
| Input shape | [Snapshot schema](project-state.schema.json) |
| Artwork and reuse | [Assets](ASSETS.md) |
| Core role contracts and current catalogue | [Shared contract](../roles/SHARED.md), [Director](../roles/director.md), [Agent Support](../roles/support.md) and [World Requests](../roles/world-requests.md) |
| Contributor scope and custody | [Agent instructions](../AGENTS.md) |
| Original creator, contributions and project authority | [Creator credit](../README.md#original-creator), [Contributing](../CONTRIBUTING.md), [Contributors](../CONTRIBUTORS.md), [Governance](../GOVERNANCE.md), [Branding](../BRANDING.md) |
| Notices, automated attribution checks and unresolved rights | [Third-party notices](../THIRD_PARTY_NOTICES.md), [Governance review record](CREATOR_PROTECTION_REVIEW.md), [Attribution maintenance](OPERATIONS.md#creator-credit-and-attribution-checks) |

## Plugin Rules

[Plugin Rules](PLUGIN_RULES.md) groups project isolation, identity, human-selected settings, delivery, safety and portability. Use `/plugin` for this scope.

For another project, copy the self-contained [plugin-only prompt](../prompts/PLUGIN_RULES_PROMPT.md), or print the current active export from the source root:

```powershell
node scripts/rules.mjs export plugin
```

## World Rules

[World Rules](WORLD_RULES.md) groups appearance, ALife Agent behavior, movement, controls and **Sound**. Each rule stays in its owning group. Use `/world` for this scope.

Copy the self-contained [world-only prompt](../world/WORLD_PROMPT.md), or print it:

```powershell
node scripts/rules.mjs export world
```

Each export includes only its selected scope's active rules. It carries no private sprint, task history, native identity, credentials or source-project permission. Apply it against the destination project's own authority; documented instructions do not prove runtime implementation.

## Universal agent rules

[Universal Agent Rules](UNIVERSAL_AGENT_RULES.md) shows the current shared and retirement contract plus active /universal additions. These are inherited by incoming agents and successors, not automatically written into every existing home. The owning creation property includes the selected one-time Director first-Support bootstrap; acknowledged Support then owns normal staffing. The implemented source-backed workflow uses the host supported native tools; documented rules, exported contracts and generated homes alone do not prove actual provisioning.

## Core package and explicit startup

The package default is only Director, Agent Support and World Requests with complete shared/universal and retirement inheritance. Support prepares other contracts for concrete authorized needs. Existing projects keep their own explicitly configured private rosters; package membership changes no native home, chat, task, setting or active owner.

Use the single create-world entry and [submitted new-project setup workflow](COMMANDS.md#user-invoked-new-project-setup). It verifies the invoking context and approved settings, reuses healthy cores or reserves only missing ones, records native results and requires each role own complete access/reading/custody receipt. The host performs the supported native actions; a missing capability remains explicit. File-only setup and export create no team. Fresh-project, reuse, title, launcher and visible-world acceptance remain separate from source implementation.

## Rules by agent

[Rules by Agent](AGENT_RULES.md) lists each logical role's existing contract and additional /rule entries. /rule uses the verified role of the chat where it was invoked; there is no implicit Director/global fallback and no cross-role mutation. Export a complete selected creation contract with node scripts/rules.mjs contract director (substitute the approved role).

## Private project records

The active project plan, sprint membership, task results, native identities and machine recovery evidence remain local. They are not repository documentation or plugin inputs. Setup uses an empty example and never copies the current team's private state.

## Reference contracts

The [portable master contract](MASTER-PROMPT.md) summarizes the three-role boundary and source precedence. The [visual-rule comparison](VISUAL_RULES_COMPARISON.md) retains reference differences. Neither creates live tasks, native staffing, permissions or feature acceptance.

Current human instructions and owning source contracts take priority. Compare older material read-only and obtain the human's selection before importing a rule, hook, setting, asset or feature.

The [reusable public Site guide](../world/public-site-guide/README.md) supplies the shared setup prompt and fictional sprint example without project data or credentials.
