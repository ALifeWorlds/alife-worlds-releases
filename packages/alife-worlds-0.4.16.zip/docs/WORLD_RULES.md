# World rules

Generated from rules/world.json. Edit through /world; regenerate rather than keeping a second active rule copy.

These rules describe the world and its represented agent behavior. They confer no native execution, staffing, publication or plugin authority.

## Appearance & Layout (appearance)

### Preserve the selected world art style

Rule ID: `appearance.style` · active · documented

**For people**
Selected Midnight Colony art remains coherent; references choose appearance only.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
The human-selected default Midnight Colony uses the approved woodland pixel-art language: warm brown dirt and muted sage/olive foliage with deep undersides, controlled highlights and blue-teal water beneath coherent navy/blue terrain and sky layers. Use faithful separately drawable selected assets or an equally faithful authored renderer, consistent pixel density, intentional transparent edges, pivots and ground anchors; do not substitute generic triangle tiers, random floating rectangles or a flattened static reference board. Keep the complete scene coherent during asset loading and pause/reduced motion, and keep native room/ant text sharp. Preserve current ant anatomy, bodies, gait, role costumes, model colors/scale, props, controls, Sound and legitimate live-state effects. Default-art replacement is limited to the selected colony; all custom-world artwork/configuration and compatible prior materials remain. References select appearance only, never example identities, staged progress, board captions, screenshot chat content or new operational authority.

Additional constraints
mark the default skin's applicability and identify its approved asset manifest.

Safety and failure behavior
Preserve custom art, readable text, motion guards and all real identities/settings/progress.

### Render complete, recognizable agent bodies

Rule ID: `appearance.agents` · active · documented

**For people**
Visible articulated six-legged bodies match labels, roles and observed models.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Render the same six-legged articulated ALife Agents and role costumes. Actual observed model identity controls the maintained family colors, relative visual body sizes and trail shapes. Preserve real model, reasoning effort, speed, status and anatomy; these appearance sizes do not alter native settings or navigation. Keep each represented living ant visibly drawn at the position associated with its floating name; retain appropriate visible ghost, rescue-driver and recovery poses. Name tags must not substitute for missing character art. Keep transient appearance effects behind the character body so they do not obscure it, preserve six-limb anatomy and existing cosmetic squad/recovery semantics, and verify actual body/layer/label behavior instead of hiding names to mask a defect.

Additional constraints
Define a complete fallback silhouette and changed-scene body/layer evidence.

Safety and failure behavior
Never hide names to mask missing art or change settings/navigation to match appearance.

### Keep rooms readable and safely connected

Rule ID: `appearance.rooms` · active · documented

**For people**
Irregular separated rooms with consistent labels, access-aware actions and safe exits.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
The selected default colony uses open overhead organic dirt-patch rooms, nests, trees and role props matching the human-selected Midnight Colony presentation. Place rooms irregularly rather than in a row-and-column matrix. Keep a visible dirt gap between full feathered room-floor boundaries; rooms never touch. Preserve actual role ownership, safe exits, entrance/shaft clearance and connected walking gaps. Place compact single-line warm-white regular-weight room names on muted plaques centered on the TOP contour edge of their own stable rooms, half inside and half outside. Keep the entire plaque within the width of its own room. Put the appropriate primary Wake Up, Unblock or Retire TEXT button immediately beside the name; do not substitute an icon for the selected text-button design. Match the selected in-room reference letterforms, weight, spacing and quiet scale with sharp licensed bundled glyphs and a restrained soil-readable shadow; the reference raster alone does not prove an exact font family. Keep one common 14 CSS-pixel regular-weight room-name scale, line height and padding across all roles, independent of body/model size; never shrink individual long names. Use the human-selected balanced muted soil/olive plaque backing at opacity0.62, a restrained muted-green text-action fill, no heavy border and no underlined or bold names. Shift role props down from the top UI and keep nests and their actual resting-ant anchors aligned, preserving floor silhouettes, room gaps, route safety, task identities and native state. Truncate long names with literal ... inside the reserved width, retaining the complete accessible name. Hovering the plaque or its name shows the full agent name at the pointer; keep permitted keyboard/touch access and exact action-disabled reasons. Align responsive labels and hit targets with room geometry. Preserve pending/disabled feedback and exact reasons; mode and access restrictions still govern controls. Keep one selected-room inspector with detailed actions below the room and its existing dropdowns. Preserve moving/outside names, real identities and compatible room/route rules. Custom worlds retain their own art and configuration.

Additional constraints
specify measured text bounds, accessible full names and shared hit-target transforms.

Safety and failure behavior
No per-name shrinking, room movement that breaks routes, or enabled unsupported controls.

### Show observed model appearance honestly

Rule ID: `appearance.model-loot-colors` · active · documented

**For people**
Exact observed model selection drives approved body/key/trail palette and sizes.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Use the approved muted model palette and strictly descending relative body size at the same pose: Astra largest, warm muted orange (#ce946f) with star-like trails; Sol 6.1 second largest, pale gray-green (#a0aaa3), with diamond-like trails; Sol 6 medium, blue with dotted trails; Terra second smallest, green with leafy trails; Luna smallest, pale gold with ring-like trails. Match the Ant key. Derive appearance from actual observed model identity; unknown metadata stays distinct neutral gray (#7c8088). This replaces the earlier loot palette and Sol 6.1 yellow/gold appearance. Never change real model selection, reasoning effort, speed, status or custom-world overrides. For genuine known-model walking, use the same verified body/trail/key color and star/diamond/dot/leaf/ring glyph at a readable bounded screen size, independently of the separately observed fast-speed aura. Unknown models have no invented model trail. Preserve actual walking/air/drag, source freshness, bounded trail history/lifetime, Pause, hidden-page and reduced-motion guards. This trail facet belongs to the current selected sprint; it does not advance unrelated future scope. Current selected-model presentation may use verified native-index selection immediately with explicit provenance; it does not claim that selection is applied to the running turn. Preserve the separate applied model/effort/speed evidence. Reconcile received body/key/room accent and ant/courier trail style on a valid snapshot even when paused or stationary, without advancing movement clocks. Unchanged style preserves original trail ages; changed or unavailable eligibility clears stale marks. Retain actual state, navigation, privacy and motion guards.

Additional constraints
Specify a versioned family mapping and visible selected/applied provenance; reuse owner metadata policy.

Safety and failure behavior
Unknown stays neutral; preserve original trail ages and real model/effort/speed settings.

### Keep the model guide collapsed and private

Rule ID: `appearance.ant-key` · active · documented

**For people**
Collapsed generic model appearance guide, omitted publicly.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Provide a compact, initially collapsed Ant key near the world controls. Use the same production ant silhouettes to explain each model family color and relative body size. It is a generic appearance guide, not a roster or a claim about running models. Keep it within existing metadata privacy boundaries and omit it from the sanitized public viewer. Do not restore the old bottom speed strip, weather caption or gem-click text.

Additional constraints
Keep a fixed generic legend with explicit guide labeling and audience gating.

Safety and failure behavior
No live model count inference, public model legend or restored deprecated bottom strips.

### Shared base ant visual scale

Rule ID: `appearance.base-ant-scale` · active · documented

**For people**
Draw default colony ants at a common larger base size while preserving model-relative differences.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Use a common 1.5 base ant drawing multiplier for the selected default colony, 20% larger than the previous 1.25 base. Keep the relative observed-model size, palette and trail mapping under appearance.model-loot-colors unchanged, including the neutral unknown fallback. Use the same base for the existing body poses, cosmetic soldier/courier and ghost representations and Ant key; keep context modifiers/layout caps and derive grounded feet and head/name offsets through the existing shared size helper. The diagnostic must report the same base constant. This is visual size only: preserve actual model/effort/speed/state, role/world anchors, navigation/hit behavior, custom-world overrides and existing art/motion/audio/privacy contracts.


## Activity & Progress (activity)

### Show work only from fresh native activity

Rule ID: `activity.working` · active · documented

**For people**
Fresh same-project native work drives appearance even without a canonical task.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Fresh verified activity from every bound same-project native chat drives the working appearance, including research, coordination and handoffs with no canonical task. A missing, finished or unavailable task must not suppress actual work; task ownership or stage alone never proves activity. Preserve original evidence timestamps, stale/unknown states, exact project isolation and separate canonical task/progress credit. Never force a target busy count or invent tasks to animate an ant.

Additional constraints
consume exact actor/lifecycle evidence independent of assignment and accepted progress.

Safety and failure behavior
No invented tasks, target busy counts or polling-based activity timestamps.

### Rest after confirmed nonworking activity

Rule ID: `activity.idle` · active · documented

**For people**
Confirmed nonworking/ordinary waiting rests; stale remains unknown.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Confirmed native idle or ordinary waiting without active work is shown resting for every agent, even when retained or eligible queued work exists. A task association does not prove current work. Keep actual native activity distinct from this represented sleep pose; explicit human-input, real blockers and recovery retain their own cues. Missing/stale/unconfirmed activity stays unknown and never implies retirement.

Additional constraints
Define one explicit state precedence shared by all renderers and inspectors.

Safety and failure behavior
Queued work alone does not prove busy; missing data cannot mean retired or idle.

### Show unavailable activity as unknown

Rule ID: `activity.unavailable` · active · documented

**For people**
Missing/stale observations stop busy routines.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Stop busy-work routines for missing/stale activity. Do not fabricate fresh work through polling.

Additional constraints
Reference a shared freshness evaluator and retain last verified metadata separately.

Safety and failure behavior
No busy animation from heartbeat; an unavailable source does not erase identity or prove failure.

### Tie blocker alarms to actual unresolved issues

Rule ID: `activity.blockers` · active · documented

**For people**
A real unresolved blocker has persistent fire/exclamation cues until resolution.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
A real unresolved blocker shows fire and an exclamation mark. Wake a blocked sleeper and circle its burning bed; a travelling blocked ALife Agent stops with fire ahead. Keep the incident until canonical resolution.

Additional constraints
Bind the incident to its canonical ID/revision and define precedence over resting poses.

Safety and failure behavior
Only recorded resolution clears it; visual extinguishing/clicks never resolve the issue.

### Show sleep only for confirmed resting states

Rule ID: `activity.sleeping` · active · documented

**For people**
Confirmed idle/waiting uses gray tucked pose and gentle Zzz with higher-priority exceptions.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Every confirmed nonworking idle or ordinary waiting ALife Agent rests gray in its tucked pose with closed eyes and visible animated Zzz, consistently across roles and model sizes. Queued or eligible work alone does not suppress sleep. Keep the Zzz legible at the current world fit, using staggered gentle motion. Genuine human-input attention, blockers/fire, failure and retirement/recovery retain their distinct higher-priority visuals. Preserve Pause, hidden-page, reduced-motion, stale-state and actual return-to-bed guards.

Additional constraints
Keep sleeping as pose owner and reference idle classification plus the shared precedence table.

Safety and failure behavior
Honor motion/stale guards; no queued-work inference or decorative failure state.

### Tie retirement visuals to recorded state

Rule ID: `activity.retirement` · active · documented

**For people**
Genuine recorded retirement need shows ghost/body/recovery scene.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
A genuine recorded retirement need shows a clearly visible translucent floating ant ghost with a gentle hover, recognizable antennae/six-limb ant identity, current model-relative scale, an exclamation mark and wandering within its own room. Keep the gravestone at the body location, gray corpse and flies, and assigned Support ambulance/CPR until verified recovery. Idle, old timestamps or missing data alone never mean dead.

Additional constraints
Define the verified lifecycle incident required and label recovery visuals as representation.

Safety and failure behavior
No native retirement from age/idle/missing data; no invented Support dispatch.

### Request work through authorized Wake Up actions

Rule ID: `activity.wake-task-search` · active · documented

**For people**
Wake is contextual and disabled until verified capability/eligibility.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Show the contextual Wake Up button for a sleeping ALife Agent in modes/access permitting operational controls. Keep it visible but disabled with the exact current reason when command verification/connection or eligibility is unavailable. Through the existing verified enabled connector, search for work the agent can actually tackle; if none exists, request useful next work from the current Director. Keep it resting if no assignment results. Do not fabricate a send, task or enabled transport.

Additional constraints
Reference the dispatch reservation/receipt contract and show pending/unknown states.

Safety and failure behavior
No automatic enablement, fabricated work, recipient substitution or settings change.

### Send only authorized unblock requests

Rule ID: `activity.unblock-request` · active · documented

**For people**
Unblock requests real help through verified Support transport; click does not resolve.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Show the contextual Unblock button for a real blocked agent/task in modes/access permitting operational controls. Retain it disabled with the exact current reason when connection, verification or eligibility is unavailable. A verified enabled request tells current Agent Support that this exact assignment needs help; clicking or animation does not resolve the blocker.

Additional constraints
Reserve exact assignment, recipient and request identity; reject changed context before dispatch.

Safety and failure behavior
Keep unavailable controls disabled; no duplicate send or local resolution from animation.

### Request retirement for the selected agent

Rule ID: `activity.retire-request` · active · documented

**For people**
Retire asks verified Support for genuine retirement help, preserving continuity.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Show the contextual Retire button for a genuine recorded retirement need in modes/access permitting operational controls. Retain it disabled with the exact current reason when connection, verification or eligibility is unavailable. A verified enabled request tells current Agent Support that this agent needs retirement help, preserving continuity; animation or an unavailable connector never performs retirement.

Additional constraints
Specify request semantics, eligibility and original request reconciliation before any lifecycle action.

Safety and failure behavior
No archival, successor creation or identity transfer from a decorative click alone.

### Explain why an action is unavailable

Rule ID: `activity.disabled-tooltips` · active · documented

**For people**
Exact disabled reason is accessible only where operational details are allowed.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
When a name-plaque action is gray or disabled, hovering its control or surrounding plaque shows the exact current reason in a native cursor tooltip. Keep the reason available to keyboard/touch accessibility too, including unavailable connection, current agent/task eligibility and pending request state. This operational reason is available only where the current mode/access permit operational details. In View, hide these task/agent/connection reason tooltips and their accessibility-only operational labels under site.view-mode.

Additional constraints
Use one access-filtered reason model for visible text, title, focus and touch.

Safety and failure behavior
Remove unauthorized tooltip/ARIA/DOM values rather than merely hiding them with CSS.

### Grow the sprint tree from accepted progress

Rule ID: `activity.sprint-tree` · active · documented

**For people**
Six-stage selected tree follows canonical accepted sprint progress; watering grants nothing.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Place the selected real sprint tree at its established exterior foreground-LEFT planted root. Use one coherent broadleaf pixel-art family matching the selected clean master across SIX distinct states: seed, sprout, sapling, young, mature and complete, with inherited connected trunk/branches, grounded roots and layered sage/olive canopy silhouettes. Select the visual state only from the existing actual canonical accepted sprint progress, preserving its calculation, denominator, rounding and acceptance requirement; full growth requires accepted100percent. A changed sprint updates this same representation, not a new world. Missing, stale or invalid progress remains unavailable/stale; permitted last-known art or a neutral planted site cannot fabricate zero or completion. Working ants collecting water bring it to THIS actual tree and visibly pour at its roots through preserved safe shore/travel routes. Watering, clicks, mining, combat, elapsed time and animation earn no progress or growth. Preserve role-tree exceptions, the acceptance ledger, current motion/timing guards and exact tree/site collision footprint. Remove the generic Sprint tree location heading; retain only compact permitted canonical Sprint and Epic percentages and inspection details. Use the existing canonical Epic summary independently of sprint growth, never a guessed value. Place the percentage annotation above the actual current canopy, not an oversized fixed empty frame. Keep the planted tree root under the foreground grass so it sits naturally in the terrain. Complete all opaque tiled landscape panels before painting near-tree overhangs so no panel cuts trunks/roots into hard rectangular blocks. Preserve the exact selected raster art, palette, crops/pivots and independent navigation/interaction rules.

Additional constraints
Keep art, growth, rooting, accepted-progress selection, epic independence, routes and collision here. Percentage visibility, audience, accessible inspection and the no-stage-heading/progress-bar restriction are owned by activity.tree-inspection; apply that owner without a competing disclosure policy.

Safety and failure behavior
Preserve exact canopy placement, privacy, unavailable/stale behavior, accepted-growth gate, history and independent epic value.

### Show permitted tree progress accessibly

Rule ID: `activity.tree-inspection` · active · documented

**For people**
Permitted percentage stays above the tree; accessible inspection reveals permitted details.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Keep the selected sprint completion percentage visibly ABOVE the actual sprint tree at all times, including at rest, whenever that value is permitted by the selected audience, existing Private concealment and public sanitization. Hover, keyboard focus and brief accessible touch reveal the permitted sprint name and additional details; they are not prerequisites for the permitted percentage. Show truthful no-active-sprint, unavailable, stale or concealed feedback when appropriate rather than inventing or exposing a value. This saved target supersedes hover-only percentage behavior; runtime implementation and applicable acceptance remain separate. Do not add a stage heading or progress bar. Anchor the permitted percentage above the actual current canopy with complete audience concealment and touch/keyboard access.

Additional constraints
Own percentage visibility and inspection disclosure for activity.sprint-tree. Preserve no-active-sprint, unavailable, stale and concealed states; no cosmetic effect earns progress.

Safety and failure behavior
View/concealed values never reach tooltip/ARIA; no stale/empty scope interpreted as zero or completion.

### Show human-input requests without exposing private text

Rule ID: `activity.human-input-attention` · active · documented

**For people**
Fresh verified human-input request uses attention pose; public receives a generic flag only.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
A fresh verified native human-input or approval request makes the affected living ant face the viewer, stand on its two rear legs, wave both front legs and make small attention jumps, with a yellow triangle and black exclamation above its head. Ordinary waiting, pause, blockers, idle and stale activity alone never trigger it. Clear it on actual resume/completion. Carry the minimal generic needs-input flag to local, authenticated private and sanitized public views; never expose request text, prompts, transcripts, private native identities, tool arguments or operational controls publicly. Preserve six-limb anatomy, real settings/status/progress and View restrictions. Pause, hidden-page, reduced-motion and stale-data guards stop autonomous attention motion.

Additional constraints
Define exact event identity, expiry and clear-on-resume semantics in the lifecycle adapter.

Safety and failure behavior
No request text/private IDs publicly; honor motion guards and higher-priority real incidents.


## Movement & Interaction (movement)

### Route ants around real obstacles

Rule ID: `movement.routes` · active · documented

**For people**
Grounded safe routes avoid obstacles/water and reserve reachable dry shore points.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Use grounded six-leg distance gait, real shaft/mound routes and safe paths around rocks, intact gems, WATER/POND FOOTPRINTS and unintended rooms. Reserve reachable dry shore pickup points outside water plus the full ant-body clearance; pond placement must preserve room/shaft travel corridors and all existing pond-shore reachability. Ants collect from the shore and walk around water instead of through it. Broken gem debris stays walkable; wait when no safe route exists. Reflow preserves real agent/task state.

Additional constraints
Maintain one geometry transform and bounded route invalidation/replan with a safe waiting result.

Safety and failure behavior
No walking through water/unintended rooms or changing real task state to resolve a route failure.

### Carry supplies only for the agent own work

Rule ID: `movement.supplies` · active · documented

**For people**
Only fresh own-work makes random resource trips; addressed traffic wins.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Fresh confirmed own-work randomly collects water, gems or outdoor grass. Plucked grass visibly disappears and regrows over time; collecting a gem spawns a replacement in a safe random underground position. Recorded addressed traffic has priority and resource trips earn no task credit.

Additional constraints
Keep an explicit cosmetic activity label and stable bounded pickup/regrowth state.

Safety and failure behavior
No progress credit or generated assignment; stale work immediately loses autonomous eligibility.

### Create sand wear only from eligible walking

Rule ID: `movement.trails` · active · documented

**For people**
Only genuine eligible underground walking creates fixed-width sand wear.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Only actual eligible underground walking strengthens fixed-width sand wear. Clicks, dragging, falling and teleports do not carve progress or trails.

Additional constraints
Centralize grounded-walking eligibility and bound permanent/trailing storage.

Safety and failure behavior
Cosmetic marks never affect task progress; no marks from paused/stale or airborne motion.

### Preserve accessible cosmetic world controls

Rule ID: `movement.controls` · active · documented

**For people**
Mode-safe details and cosmetic hop/drag remain; no magnifier or native authority.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Keep room-anchored plaque details, local hop and safe pointer-captured drag/drop in interactive modes. Remove the separate magnifying-glass button. View keeps passive safe ant name tags and hides operational plaques/details while permitting the existing cosmetic mining, drag, hop and scenery interactions under site.view-mode; no actual task or agent command is granted.

Additional constraints
Specify cancel/lost-capture cleanup and use the same transformed coordinates as drawing.

Safety and failure behavior
No native effect; View exposes only permitted safe labels and cosmetic controls.

### Deliver only recorded addressed messages

Rule ID: `movement.mail` · active · documented

**For people**
Recorded addressed messages have matching visible envelopes; arrival is not a receipt.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
An actual recorded addressed message is carried as an envelope visibly marked M to its real recipient. Never fabricate messages or count visual delivery as native receipt/task completion.

Additional constraints
Bind visual traffic to the stable event/recipient and actual transport state.

Safety and failure behavior
No fabricated messages, duplicate dispatch or task completion from travel time.

### Keep diagonal walking grounded

Rule ID: `movement.diagonal` · active · documented

**For people**
Diagonal gait follows real travel direction with grounded distance-driven steps.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Walking diagonally keeps the ant facing its actual travel direction with the same forward fore/aft tripod foot cycle, natural foot lift/plant and distance-driven stride as other directions. Avoid lateral sliding, sideways foot shuffles and abrupt perspective flips.

Additional constraints
define consistent facing interpolation and stationary/airborne gait behavior.

Safety and failure behavior
No sliding workaround that teleports or changes real activity/settings.

### Use bounded, progress-paced travel

Rule ID: `movement.speed` · active · documented

**For people**
Baseline versus 1.5x walking is separate from evidence-based delivery catch-up.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Keep regular baseline walking/research speed and a separate 1.5× walking mode that is always faster than the regular baseline. Message/activity travel pacing is separate: use actual recorded progress, status and timing to slow a long-running transfer, accelerate with faster real progress, and move very quickly toward its intended endpoint as actual delivery/completion approaches or is observed. This pacing may exceed 1.5×. Never change real agent settings or manufacture native progress/completion from animation time. Retain existing speed-streak and distinct dirt-footprint presentation for eligible faster walking.

Additional constraints
Label it visual locomotion; route delivery pacing only from real operation status/progress.

Safety and failure behavior
No synthetic delivery progress, native speed change or unsupported throughput claim.

### Show dangling legs while dragging

Rule ID: `movement.drag` · active · documented

**For people**
Held ants dangle without grounded trails and resume safe travel.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Held ALife Agents dangle and animate their legs with no grounded steps/trails; resume safe travel after release.

Additional constraints
Use bounded release coordinates and deterministic safe landing/replan.

Safety and failure behavior
No trail/task credit or changed message identity while held.

### Keep dragging and deliveries distance-aware

Rule ID: `movement.delivery-distance` · active · documented

**For people**
Dragged delivery keeps original event/recipient and replans remaining route.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Dragging away preserves the same recorded message/activity identity, recipient and intended destination. After any required landing, replan the remaining safe route from the released position and pace travel from that same operation’s actual progress/status. Near or completed operations use very fast non-teleporting catch-up to the endpoint, independent of the regular 1.5× walking mode. Visual catch-up grants no extra native delivery, work or task acceptance.

Additional constraints
Keep visual catch-up non-teleporting and bounded to the original operation's status.

Safety and failure behavior
No second receipt/send, changed recipient or extra acceptance from visual arrival.

### Anchor agent details to the correct room

Rule ID: `movement.room-details` · active · documented

**For people**
Room popup shows current permitted work/model/state/blocker only.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Clicking an ALife Agent name plaque opens a small popup anchored at its own room, with relevant current work, observed model/state and blocker details, respecting Private view. Show this operational popup only where current mode and access permit it. In View, keep permitted safe world labels but do not open or expose work/model/state/blocker details; site.view-mode owns that visibility.

Additional constraints
Clear/access-filter popup models on mode, project and binding changes.

Safety and failure behavior
No operational data in public/View DOM, native tooltips or accessibility labels.

### Land airborne ants before resuming routes

Rule ID: `movement.gravity` · active · documented

**For people**
Released airborne ants land on real ground before safe routing.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Dragged/released ALife Agents above outdoor ground fall with gravity, land on the actual mound or grass surface, then resume safe routing. Airborne and held motion creates no footprints or progress.

Additional constraints
Use capped/substepped physics and the shared actual surface geometry.

Safety and failure behavior
Airborne motion creates no footprints or task credit; no identity/state reset.

### Keep background human legs grounded

Rule ID: `movement.big-legs` · active · documented

**For people**
Background people use grounded feet and correct near/far occlusion.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Keep scenery people/legs at a believable background scale with alternating planted/swing feet on the actual far-road ground baseline. Draw them BEHIND the nearer grouped trio pine trees, hill and nearer foreground details; never overlay those trees or float between depth layers. Preserve grounded proportions and the selected art style. Tapping may make the person jump/run away; scenery never changes real agent tasks.

Additional constraints
Tie the road baseline and depth order to the selected scene profile.

Safety and failure behavior
Scenery taps remain cosmetic; preserve custom-world scale and all agent routes.

### Update speed appearance from fresh metadata

Rule ID: `movement.speed-metadata-freshness` · active · documented

**For people**
One verified setting/time drives Fast aura, eligibility and inspector; expired is unknown.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
The 1.5x/Fast aura, fast-only streaks, visual speed eligibility and inspector must use the same current verified per-agent speed observation, with its actual source and observation time. Refresh from a supported exact-agent settings notification or read through the existing shared bounded observation path; opening or selecting the agent chat in Codex, clicking the ant, sending a dummy turn or waking an idle agent must not be required. A verified return to normal clears the Fast appearance automatically within the normal shared refresh cycle and invalidates cached fast trails. Poll/heartbeat/activity timestamps never freshen an older speed setting. Complete applied-setting snapshots with omitted, null or unsupported speed are unknown; a partial omission is not a new confirmation. Missing, expired or unavailable speed evidence clears the Fast-only appearance and shows speed as unknown instead of assuming Standard or preserving an old Fast value. Re-evaluate freshness while motion is paused and keep visible aura/inspector state consistent on resume and across local/private/public presentations under their approved metadata privacy. If the host cannot supply a current supported settings observation without chat selection, report that capability limit and use the unknown fallback. Preserve actual model, speed and reasoning settings, model appearance and the independent delivery/progress pacing rule; do not introduce per-agent pollers, model requests per poll or new host processes.

Additional constraints
Use the same shared freshness evaluator for style and inspector, evaluated even when motion is paused.

Safety and failure behavior
No dummy turn/chat selection requirement, invented Standard fallback or separate per-agent poller.

### Change perspective at the actual summit

Rule ID: `movement.summit-transition` · active · documented

**For people**
Ants/couriers traverse the true summit before perspective change; exit-only puff.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Autonomous ants and cosmetic soldier/courier representations must visibly traverse the hill entrance/shaft all the way to the true anthill summit before leaving or changing from overhead to side view. Never switch perspective halfway along the climb or project an interior ant onto the exterior ground early. Anchor the inside/outside transition at the summit in both directions, with brief bounded soil particles rising upward on a real summit EXIT only. Entry has no particle puff. Keep the continuous true-peak route and perspective transition in both directions. Keep pose/ground offsets inside that summit transition rather than teleporting an ant out mid-climb. Preserve safe obstacle-aware routes, distance/progress and real message/task identities, and the existing manual drag/drop/gravity behavior. The poof is local cosmetic feedback with no sound/model invocation, task credit or native effect; respect Pause, hidden-page and reduced-motion guards.

Additional constraints
Make one bidirectional summit transition anchor and validate changed scene geometry.

Safety and failure behavior
No teleport, native effect, sound/model invocation or progress credit; preserve drag/gravity guards.


## Site Structure & Modes (site)

### Keep the world first with fitted controls

Rule ID: `site.order` · active · documented

**For people**
World fit/control layout references plugin owners; mode controls disclosure.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
The full operator site's section order remains owned by plugin site-presentation.four-section-layout, subject to the selected presentation mode and later explicit human/project direction. Fit the complete first-page world to its available desktop/mobile viewport without unintended non-world whitespace/gutters while preserving the complete world, all rooms and sprite proportions, using the existing responsive layout/fit and common coordinate-transform contracts under plugin mobile-layout.horizontal-fit and camera.zoom-pan rather than stretching anatomy or adding Pan/Fit/Zoom controls. In the full operator presentation, keep the world-title/project dropdown and necessary mode, Pause and single Sound controls within that viewport, with the world's pixel/monospaced style and extra sprint/ant/status information initially collapsed. Keep collapsed team details inside the agents section. View's world-only disclosure is owned by site.view-mode; the public split landing and its restricted world controls are owned by site.public-viewer. Preserve independent Private/Public scrolling, privacy and access contracts.

Additional constraints
Keep as a world placement reference and use typed owner IDs for fit/order contracts.

Safety and failure behavior
No stretched anatomy, extra camera controls or public operator dropdowns.

### Show canonical progress without invented credit

Rule ID: `site.progress` · active · documented

**For people**
World/site use canonical whole-count progress; View conceals every progress annotation.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Use the same canonical epic and current-sprint counts and percentages under plugin delivery.progress-accounting and delivery.goal-completion. Where operational information is permitted, keep their compact adjacent pair at the top of the collapsible bottom epic/sprint plan, including narrow screens; page-level overview placement follows plugin site-presentation.four-section-layout. View, including the fixed public website View, shows none of those counts, percentages, bars or progress/freshness captions in or outside the world viewport. Hiding presentation never edits the canonical records or changes whole-task/sprint accounting. Never infer completion from animation, mining, watering, combat or elapsed time.

Additional constraints
Use access-filtered progress DTOs and reference the delivery arithmetic owner.

Safety and failure behavior
No private values in View DOM/tooltips; hiding never edits canonical progress.

### Conceal operational information in Private mode

Rule ID: `site.privacy` · active · documented

**For people**
Private presentation fits one screen and removes operational layout/scroll space.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Private locks the world to one fitted screen and removes operational sections from layout instead of retaining masked scroll space. Block page scrolling until Public is restored.

Additional constraints
Resolve clearer presentation labeling and explicitly reference links-and-access for real authorization.

Safety and failure behavior
No audience change; preserve existing concealment, accessible controls and saved mode choice.

### Hide operational information in View

Rule ID: `site.view-mode` · active · documented

**For people**
World-only fitted View removes operational data while preserving permitted cosmetic interactions.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
View is a world-only presentation, fitted to one available screen with page scrolling locked. Hide all sprint, epic, task and operational data both inside the world viewport and elsewhere on the page: no sprint/epic/task labels, counts, percentages, progress bars or numeric or tooltip annotations, operational plaques, action lists, version/information footers or later operational sections. Do not retain operational values in hover/native tooltips or accessibility-only labels. Remove those sections from layout rather than leaving masked or collapsed space. Preserve the actual world art and permitted non-operational labels. Existing page-local cosmetic world interactions remain available, including the existing scenery, drag/hop, mining and wasp-hit feedback where supported, under the existing Pause, hidden-page and reduced-motion guards. These interactions never edit canonical tasks/sprints, control real agents, invoke native commands or models, or grant access. Keep appropriate viewing/audio controls; public-website control visibility is owned by site.public-viewer. Presentation mode never changes an audience.

Additional constraints
Define one allowlisted View data/control model before render and clear prior mode state.

Safety and failure behavior
No canonical writes, model calls or native commands from cosmetic interactions.

### Fit public worlds and permit page scrolling

Rule ID: `site.public-mode` · active · documented

**For people**
Public presentation fits the world and permits document scrolling below it.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Public keeps the COMPLETE WORLD fitted into one available screen using the same world-fit policy as Private, with uniform sprite proportions and readable native labels. The DOCUMENT/PAGE scrolls below the fitted farm to reach the sprint board and later sections, including wheel/touch scrolling with the pointer inside the farm. Do not use a tall natural-height world, nested world scrolling or an independent farm scrollbar. Preserve browser zoom, existing Private/View page locks, actual identities and audience/privacy boundaries. This supersedes the earlier tall Public-world proposal.

Additional constraints
Label presentation-only semantics and define wheel/touch behavior at the farm boundary.

Safety and failure behavior
No nested farm scrollbar, distorted scene or automatic publishing.

### Keep team details collapsed by default

Rule ID: `site.team-details` · active · documented

**For people**
Team details default collapsed and open by choice.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Team responsibilities/details start collapsed and open only when the viewer chooses.

Additional constraints
Persist disclosure per world/surface and keep it presentation-only.

Safety and failure behavior
Never expose private role details in a public surface or treat expansion as authorization.

### Remove obsolete bottom sand progress art

Rule ID: `site.sand-mountains` · active · documented

**For people**
Remove obsolete bottom sand art; true progress remains in meters.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Remove the bottom sand mountain/chamber artwork. Retain truthful evidence-backed sprint/epic progress in the site meters without decorative sand credit.

Additional constraints
Keep this as the current visual decision and label prior versions historical.

Safety and failure behavior
Do not remove current soil/route geometry or grant decorative sand progress.

### Offer a bounded read-only public world

Rule ID: `site.public-viewer` · active · documented

**For people**
Authorized public split landing reuses qualified world in fixed sanitized View with restricted controls.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
For the selected authorized public website, restore its approved split landing composition: slogan/text on the left and the actual maintained ALife World on the right, with a responsive mobile arrangement and a correctly fitted world area without unused whitespace or distorted anatomy. Use the same actual qualified world renderer/art and delivered world version as the selected local world; a planned version label is not parity proof. Keep the public world fixed/default in site.view-mode, with its permitted cosmetic interactions and no mode/Interact toggle, project/world selector, model/Ant key or other world buttons/selectors. Its only world controls are the single audio toggle, the adjacent volume slider only while audio is on, fullscreen with an accessible exit/fallback, and pause/resume motion. Audio behavior remains owned by sound-and-motion.one-toggle, muted-start, immediate-mute and suppression. Do not render sprint/task/operational data or a progress/freshness information caption inside or below this View world; remove the hidden caption's space. Preserve true source timestamps and honest missing/stale world availability without fabricating activity. The public surface stays sanitized and cannot edit tasks/data, command real agents, invoke models or trigger agent work. Preserve custom art, approved branding, sound isolation, current consent/audience and native browser accessibility; verify actual hosting/version delivery separately.

Additional constraints
Build from a separate closed public DTO, explicit control allowlist and recorded renderer/artifact identity.

Safety and failure behavior
No private progress/captions/model key/dropdown/commands; respect consent, mute and accessibility.

### World version engraved into dirt

Rule ID: `site.ground-version-label` · active · documented

**For people**
Engrave the actual selected world release into the ground and keep separate website versions outside the scene.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Replace the world surface Website/World version badge with the actual selected/served world release engraved subtly into the bottom-center dirt. Use restrained soil tones, faint inset shading and the existing pixel font; keep it faded but readable, centered and scaled through the existing responsive scene fit. Paint this ground art beneath room floors, footprints, ants, cargo and shadows so agents can cross it normally. It has no obstacle, collision, hit target, route change, model call or task/progress effect. Take the canonical major.minor.patch value only from the existing verified selected-world authority: validated OwnerSiteContext.worldVersion in local/private owned frames or a ready project-sourced worldProfile.worldVersion in the full operator. Missing, invalid or cleared identity leaves the number absent; never substitute a Website/plugin/build/renderer compatibility version, native title or planned release. This nonoperational terrain mark may remain in world-only presentations while operational View footers and task/sprint/Epic metadata stay hidden. Preserve custom-world art, existing world layout, model-relative scale/palette/trails, actual identities/settings, navigation, Sound/motion and audience boundaries. Keep independent Website/plugin/release records outside the world and preserve completed release, audit and title operations.


## Sound (sound-and-motion)

### Start all world audio muted

Rule ID: `sound-and-motion.muted-start` · active · documented

**For people**
Every load starts muted; only Sound explicitly enables audio.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Start every page load muted regardless of remembered privacy. Only the single Sound toggle enables/resumes audio; Wake, dragging, magnifying and other gestures never unmute it.

Additional constraints
initialize one master audio gate before loading any cue or music.

Safety and failure behavior
No remembered privacy/volume setting or Wake/drag gesture unmutes.

### Suppress autonomous motion and audio together

Rule ID: `sound-and-motion.suppression` · active · documented

**For people**
Pause, hidden page and reduced motion suppress autonomous motion/effects/audio.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Pause, hidden pages and reduced motion suppress autonomous movement/effects/audio. Motion controls do not pause real agents.

Additional constraints
Centralize suppression eligibility and drop accumulated autonomous cue triggers.

Safety and failure behavior
Motion control never pauses real agents; no catch-up audio burst.

### Use one Sound control for all world audio

Rule ID: `sound-and-motion.one-toggle` · active · documented

**For people**
One Sound toggle and conditional slider share master volume, saved per world.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Use one Sound toggle with an adjacent volume slider in the same control group. Show the slider only while Sound is enabled and hide it when muted. Apply volume to the existing shared master for world music and effects, including parent-owned planet cues; changing or restoring volume never enables audio. Retain a separate level per world while every load still starts muted. Keep the existing muted-start, immediate-mute, suppression, licensed-assets and custom-world protections under their owning properties; add no second Sound/ASMR toggle, native command or model request.

Additional constraints
Use the owning muted-start, immediate-mute, suppression and licensed-assets requirements. Share one master/control and preserve separate per-world volume; these references do not remove any unique audio protection.

Safety and failure behavior
No behavior removal, second toggle, implicit unmute or loss of per-world level/history.

### Keep sound cues short and spatial

Rule ID: `sound-and-motion.short-spatial-cues` · active · documented

**For people**
Soft panned cues have short envelopes and roughly 65ms trigger cap.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Use soft filtered/panned movement, water and prop cues with short gain envelopes and an approximately 65ms trigger cap.

Additional constraints
Define shared voice/trigger limits and safe master headroom with graceful cue dropping.

Safety and failure behavior
No loud resume burst; opt-in, immediate mute and suppression always win.

### Silence every world sound immediately

Rule ID: `sound-and-motion.immediate-mute` · active · documented

**For people**
Mute silences all loops/cues and blocks new playback immediately.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
The one Mute/Sound control immediately silences every active cue, ambience and music loop and prevents new playback. Every load starts muted; no other gesture or remembered privacy choice unmutes.

Additional constraints
Route all child/parent audio through the same master gate and cancel scheduled output on mute.

Safety and failure behavior
No alternate gesture unmutes; every load starts muted regardless of stored preferences.

### Use only licensed bundled audio

Rule ID: `sound-and-motion.licensed-assets` · active · documented

**For people**
All audible samples are locally bundled verified CC0 Freesound assets with manifest.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Every audible world/space/UI sample, including music, is bundled locally from Freesound with a verified CC0 license and author/source/license/hash manifest. Replace procedural audible synthesis; no runtime CDN fetch is needed.

Additional constraints
Validate selected asset hashes against source/license provenance during packaging.

Safety and failure behavior
No runtime CDN, procedural audible substitution, missing attribution evidence or custom-music overwrite.

### Require listening evidence for audio claims

Rule ID: `sound-and-motion.listening-evidence` · active · documented

**For people**
Actual listening is distinct from code/transport checks.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Verify physical listening separately from transport, code or gain checks; do not claim audible quality from a source test.

Additional constraints
Record exact candidate, output device and whether listening occurred.

Safety and failure behavior
Keep unlistened work NOT TESTED; no invented listening or new blanket checklist.

### Never replay old completion sound cues

Rule ID: `sound-and-motion.no-replayed-cues` · active · documented

**For people**
Unchanged snapshots/reloads do not replay old completion cues.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Do not replay old completion-pour cues on refresh or unchanged observations.

Additional constraints
Deduplicate against stable original event IDs and explicit per-world cue eligibility.

Safety and failure behavior
Do not rewrite native receipts/times; old completion never becomes a fresh cue.

### Play mining cues only for permitted interactions

Rule ID: `sound-and-motion.mining-cues` · active · documented

**For people**
Distinct opt-in chip/break sounds follow mute/motion/trigger guards.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Play soft distinct click/chip/break mining cues sourced from Freesound.org for gem interaction, only after the single Sound toggle enables audio. Keep immediate mute, motion guards and bounded cue triggering.

Additional constraints
Send all cues through the same master budget and selected licensed asset manifest.

Safety and failure behavior
No sound before opt-in or task/progress effect from mining.

### Preserve selected music and all Sound guards

Rule ID: `sound-and-motion.music` · active · documented

**For people**
Default bundled selected lo-fi loop; preserve custom music and all Sound guards.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Use the previously bundled CC0 Freesound Lofi Beat Loop Schmoop as the DEFAULT world background music, with the existing optional UI, water, grass and mining cues. The world music loop is the lo-fi beat; the separate galaxy ambience is not a replacement for it. Do not replace custom-world music. Every load starts muted, only the single Sound control enables audio, mute immediately silences everything, and Pause/hidden-page/reduced-motion guards remain active. Preserve the bundled author/source/license/hash manifest; no runtime online audio fetch is required.

Additional constraints
Reference the immutable manifest entry and explicit default/custom override precedence.

Safety and failure behavior
No online fetch, ambient substitution, unlicensed file or automatic unmute.


## Agent Support & Rescue (rescue)

### Keep Agent Support in its first-responder room

Rule ID: `rescue.clinic` · active · documented

**For people**
Support has first-responder room/cross/alarm for genuine incidents; no CLINIC label.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Agent Support has a first-responder medical/garage room, medical cross and alarms for genuine help incidents. Do not write CLINIC in the room.

Additional constraints
Keep room art separate from incident/dispatch evidence.

Safety and failure behavior
No invented incident, native send or default new responder role.

### Animate rescue from verified retirement incidents

Rule ID: `rescue.ambulance` · active · documented

**For people**
Verified retirement incident has ambulance/CPR representation until verified recovery.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
For a genuine retirement incident, Agent Support uses an ambulance with flashing lights to reach the room, lifts the corpse from its grave and animates CPR beside it until verified recovery. The visual response does not itself revive or retire a native agent.

Additional constraints
Require exact incident plus assigned/observed Support response for autonomous dispatch, matching firetruck semantics.

Safety and failure behavior
No fake recovery, retirement, busy Support or new native responder from animation.

### Tie fire response to actual Support work

Rule ID: `rescue.firetruck` · active · documented

**For people**
Actual assigned/observed Support work drives hose response; only resolution clears fire.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
For a genuine fire/blocker incident, Agent Support drives a firefighter truck to the affected ALife Agent and animates a water hose. Only actual issue resolution extinguishes the fire. Response movement requires actual assigned/observed Support work; an alert alone does not invent a real dispatch.

Additional constraints
Bind response to incident ID/current lifecycle and clear on verified resolution.

Safety and failure behavior
No alert-only dispatch or animation-based blocker resolution.


## Mining & Underground Materials (mining)

### Preserve safe routes around mining materials

Rule ID: `mining.obstacles` · active · documented

**For people**
Abundant intact minerals block walking while preserving routes; debris is walkable.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Place abundant mining rocks/gems throughout the hill while reserving safe paths between real room exits, the entrance/shaft, pools and active deliveries. Intact materials block walking; broken debris is walkable. Do not create artificial task work or completion credit.

Additional constraints
Use bounded placement attempts, validated clear corridors and deterministic fallback.

Safety and failure behavior
No forced task completion, real workload or unreachable pickup goals.

### Keep mining hits and damage stable

Rule ID: `mining.clicks` · active · documented

**For people**
Each mineral has stable 2-8 hit requirement; gems keep size until final break.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Each decorative rock or gem receives one stable random requirement of 2–8 hits. Every hit adds visible branching chip/crack lines. Gems KEEP THEIR FULL SIZE while being chipped; only their final hit breaks them into low walkable debris. Rocks retain progressive chipping/shrink toward their final break. Never change a task or its progress. This replaces both the earlier 1–8 requirement and the earlier instruction to shrink gems on intermediate clicks.

Additional constraints
Keep stable per-object cosmetic IDs and bounded debris lifecycle.

Safety and failure behavior
No canonical progress change; don't restore superseded hit ranges or intermediate gem shrink.

### Keep dirt and tree feedback cosmetic

Rule ID: `mining.cursor` · active · documented

**For people**
Local dirt/leaf/chip feedback respects View and motion guards.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Clicks/touches on hill dirt create bounded dirt puffs; cursor dirt remains local. Tree taps release leaves. Mineral taps make chips/cracks. Respect motion guards. View permits these existing page-local cosmetic interactions under site.view-mode; they grant no canonical task/progress or native effect.

Additional constraints
Use shared input/effect bounds and a cosmetic-only action dispatch path.

Safety and failure behavior
No network/native/model/task effect; respect suppression and accessible inputs.


## Projects & Galaxy (projects)

### Switch only to the selected authorized world

Rule ID: `projects.dropdown` · active · documented

**For people**
Registered project folder names select exact worlds; mismatch fails.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Replace the site/world title with a dropdown of actual registered projects using this plugin. Use each project folder name as its displayed world name. Selecting a project resolves that exact world; unknown or mismatched IDs fail instead of falling back to another project.

Additional constraints
Scope inventory to authorized projects and keep cross-world navigation an explicit capability.

Safety and failure behavior
No fallback root, imported binding or automatic inclusion from discovery.

### Show authorized worlds as rope-hung spheres

Rule ID: `projects.show-all` · active · documented

**For people**
Show each permitted registered world in its own rope-hung sphere with truthful readiness and style.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Put Show all last in the project dropdown. Show one rounded handmade sphere, suspended by a rope, for each actual registered world permitted in the current audience. Populate the overview dynamically within the existing bounded catalog; never impose a fixed five-project limit. Retain stable randomly varied placement and center the sphere when only one world exists. Decorate each shell and frame from that world's validated saved art style or its actual qualified scene theme; identify the latter as qualified-scene rather than fabricating a saved-style record. Missing or unsupported style stays neutral. Place readable project labels outside the busy central window. Clip the actual own-world view and its art/hit areas wholly inside the sphere's framed central window, with no rectangular webpage chrome or unintended bleed. Intentional ropes, rim decoration and outside labels belong to the shell. A Live window requires its own qualified renderer, fresh validated input, ready connection/target and actual matching render acknowledgment; queued rendering stays Loading. Missing, stale, foreign or unavailable connections remain honestly Unconfirmed/Unavailable and never borrow the current world's feed or art. Selection uses the existing exact-world routing under projects.dropdown. Retain each world's existing privacy, audio and interaction permissions.

Additional constraints
Use a bounded dynamic authorized catalog, stable per-world identity, supported-style descriptors and fresh own-world input. Live requires an actual matching render acknowledgment. Retain the sole original scene and recovery handle if preview return or disposal fails.

Safety and failure behavior
No fabricated worlds, credential reuse or unauthorized background service startup.

### Keep world-overview ambience bounded

Rule ID: `projects.space` · active · documented

**For people**
Keep space and suspension cosmetic, bounded and governed by shared motion and Sound controls.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Keep a coherent, softly lit semi-realistic space atmosphere around the handmade rope-hung worlds, accommodating their different actual art styles without replacing custom-world art or inventing saved styles. Use bounded decorative space motion and gentle suspension sway. Preserve the existing Pause, hidden-page, overview-visibility and reduced-motion guards, opt-in ASMR and permitted cosmetic interactions. Sound remains governed by sound-and-motion, including its single control/master, muted start and immediate silence; the overview grants no new audio or interaction permission. Decorative atmosphere and motion never fabricate projects, agents, work, messages, progress, acceptance or model calls. Keep operational/private information subject to the existing audience and mode rules.

Additional constraints
Use one bounded scheduler and an explicit qualified-style mapping. Unsupported custom styles remain neutral or unavailable; do not fabricate saved art profiles.

Safety and failure behavior
No project creation, AI calls, invented work or automatic audio.


## Exterior & Terrain (exterior)

### Keep fly interactions cosmetic and bounded

Rule ID: `exterior.flies` · active · documented

**For people**
Bounded decorative flies have stable 1-5 hit targets and usable touch areas.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Bounded decorative flies approach the exterior hill with visibly larger bodies and usable click/touch targets. Each fly receives one stable random target of 1–5 hits; only that same fly leaves when its target is met. Preserve motion guards. View permits the existing cosmetic click/touch effects under site.view-mode. This has no task/progress effect.

Additional constraints
Keep stable cosmetic IDs, actor caps and cleanup on world exit.

Safety and failure behavior
No task effect or confusion with genuine pending-request indicators.

### Keep day and night purely decorative

Rule ID: `exterior.day-night` · active · documented

**For people**
Bounded day cycle preserves round sun/moon and motion guards.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Cycle through daylight, sunset, night and sunrise with a round properly proportioned moon/sun independent of horizontal viewport expansion. Keep bounded ambient effects and honor Pause, hidden-page and reduced-motion guards.

Additional constraints
Use one bounded world ambience clock with explicit pause/resume behavior.

Safety and failure behavior
No claim of live location/time, task progress or native work from ambience.

### Bound night fireflies and pointer reactions

Rule ID: `exterior.night-fireflies` · active · documented

**For people**
Night fireflies flee with bounded cosmetic glow under guards.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
At night, bounded exterior fireflies appear and leave over time. Clicking a firefly makes it flee quickly away from the cursor with a fading glow. Respect motion guards and View interaction restrictions; do not confuse decorative fireflies with real pending-request indicators.

Additional constraints
Keep distinct shapes/colors/placement from operational request cues and cap actors.

Safety and failure behavior
No fake request state, model call or canonical effect.

### Keep parallax clouds behind the world

Rule ID: `exterior.clouds` · active · documented

**For people**
Layered clouds drift with restrained opacity and motion guards.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Move clouds of different sizes in separate depth/parallax layers, with coherent gentle drift, restrained opacity and motion guards.

Additional constraints
Bound actors/overdraw and use the shared scene scheduler/depth contract.

Safety and failure behavior
Preserve readable text, hit targets and reduced-motion static composition.

### Preserve selected dirt depth and palette

Rule ID: `exterior.soil-depth` · active · documented

**For people**
Darkening soil remains connected; seam correction preserves real geometry.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Give the dirt layer a readable depth gradient that becomes darker toward the bottom, preserving artwork, white text and agent/prop contrast. Keep the mound and interior visually connected: remove only the artificial straight horizontal divider or soil-texture/material discontinuity while preserving the true hill silhouette, walkable dirt surface, feathered room floors, navigation/route geometry and above-hill perspective transition. Do not replace the seam with a blurred strip, black border or newly painted wall; no soil-art correction relocates agents, beds, props, ponds, roots or collision footprints.

Additional constraints
Treat material/edge changes as visual-only unless geometry is explicitly selected.

Safety and failure behavior
No blurred divider workaround, relocation or erased current terrain art.

### Keep the grass-to-dirt transition natural

Rule ID: `exterior.surface-band` · active · documented

**For people**
Continuous grass-to-soil transition with coherent roots.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Add a thicker continuous transition layer between exterior grass and underground dirt, connecting the visible hill into the ground with coherent edge texture and roots.

Additional constraints
Specify this as a textured natural transition within the existing terrain envelope.

Safety and failure behavior
No straight divider, navigation change or new occlusion of roots/agents.

### Preserve selected landscape depth layers

Rule ID: `exterior.foreground` · active · documented

**For people**
Selected layered woodland art has grounded near/far occlusion and coherent weather variants.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Preserve distinct grounded depth layers rather than placing all exterior art on one flat plane. Carry the selected woodland style through navy night sky/stepped clouds/cream crescent, muted blue-teal mountains, layered distant forest, small warm-window houses, road/cars/people, blue-teal lake/ripples/shoreline reeds/rocks and sparse foreground grass/soil. Use the selected connected near/far pine silhouettes with irregular overlapping bough tiers, deep green undersides, sage/olive midtones and restrained highlights, grounded brown trunks and controlled distant contrast; no disconnected foliage tiles, repeated triangle bars or mixed default art. Keep distant feet/legs, road traffic and houses behind nearer pines and the hill; retain the hill and real agents in their grounded middle plane with a separate nearer foreground detail layer, readable travel silhouettes and proper occlusion/parallax bounds. Rainy night is a reference condition, not permission to freeze time: preserve real day/night sun/moon motion, weather/seasons and permitted leaf/rain motion using coherent variants and complete base art during pause/hidden/reduced motion. Snow is deliberate accent, never corrupt white foliage; rain needs visible precipitation with permitted companion effects. Preserve existing mound, pond footprints, navigation, shore pickup, stable tree root, role rooms, composition, custom-world overrides and actual privacy/live-state rules; change selected art treatment, not gameplay positions.

Additional constraints
Keep scene behavior here and identify skin-specific visual tokens/assets in the saved profile.

Safety and failure behavior
No changed gameplay positions, frozen day/night, corrupted white foliage or forced custom reskin.

### Keep seasons and weather decorative

Rule ID: `exterior.weather-seasons` · active · documented

**For people**
Page-local decorative seasons/weather/day use specified bounded timing.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Use a bounded decorative seasonal cycle with spring, summer, autumn and winter lighting/foliage, clear weather, rain, breeze and winter snow. Carry the explicit precipitation kind through the renderer so snow is painted in winter rather than discarded by a rain-only guard. Current visual timing is 360 seconds per season, 45 seconds per weather step and 180 seconds per day. This is page-local ambience with pause, hidden-page and reduced-motion guards, never live weather, task activity or progress.

Additional constraints
Label ambience explicitly and place overridable timing in a versioned world profile.

Safety and failure behavior
No live-location inference, task progress, new service or motion while suppressed.


## Special Forces Exterior Defense (defense)

### Show a three-soldier cosmetic defense unit

Rule ID: `defense.unit` · active · documented

**For people**
Actual Special Forces work may show three cosmetic soldiers, not extra agents.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Fresh verified actual Special Forces work sends three soldier-costumed visual ants from its real room to the exterior hill, including real research/handoff work without an eligible canonical task. Bind an eligible actual task when present; otherwise retain only a page-local visual work episode, never a fabricated task. Space soldiers individually during travel and combat with distinct Special Forces 1/2/3 names. These are the existing role avatar and cosmetic companions, never extra native agents, chats or task credit.

Additional constraints
Mark applicability conditional on that authorized bound role and exact fresh work episode.

Safety and failure behavior
No new native agents/tasks, target busy count or default specialist creation.

### Keep wasp combat aimed and bounded

Rule ID: `defense.wasps` · active · documented

**For people**
Bounded cosmetic combat has minimum enemy count, health and one-damage hits.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Spawn at least FOUR thin-waisted animated wasps beyond the left/right screen boundaries before the soldier unit arrives. They fly toward the hill and wander smoothly around it while the actual unresolved issue and fresh work continue. Each wasp starts with at least 4 health (currently 4); each soldier starts with 6 health. Each hit deals one damage. Soldiers auto-aim an attached shoulder/mid-body laser blaster at a wasp and fire from its barrel; wasps attack back. In interactive modes, clicks/taps damage wasps with visible feedback. View permits the same page-local cosmetic hit feedback under site.view-mode; it cannot resolve or edit the actual issue, task or real agent work. Keep bounded actors/projectiles and readable spacing.

Additional constraints
Define hard actor/projectile caps and bounded replacement/attack rates in the cosmetic engine.

Safety and failure behavior
Hits never resolve a real issue; no native command, task credit or unsuppressed autonomous attacks.

### Keep cosmetic casualties separate from native agents

Rule ID: `defense.casualties` · active · documented

**For people**
Cosmetic defeats/replacements are bounded and never kill native agents.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
A defeated soldier rolls over with X eyes, lingers, then scales down and disappears; wasps have distinct animated defeats. Immediately create the cosmetic replacement: soldier reinforcements travel from the real room, wasps enter from offscreen. Bound the populations, projectiles and lingering corpses. Cosmetic casualties never retire/kill a native agent, change identities or grant task credit.

Additional constraints
Use explicit population/corpse budgets and episode-aware spawn cooldowns.

Safety and failure behavior
No native retirement, new chats, identity changes or progress from cosmetic casualties.

### Resolve defense from actual agent state

Rule ID: `defense.resolution` · active · documented

**For people**
Actual completion/idle ends defense; stale/wait/mail pauses without invented victory.

**AI instructions**

When this applies
Apply this requirement during authorized creation, maintenance or rendering of this world and its represented behavior.

Required behavior
Actual completion of the bound task/issue or verified native return to idle ends its represented defense: stop spawning wasps, clear remaining enemies and return the unit to its real room. A still-working role may begin another actual-work episode without a canonical task; a completed retained task must not suppress it. Missing/stale activity, waiting and outgoing addressed mail pause combat without inventing victory. Pause, hidden-page and reduced-motion guards stop autonomous motion and attacks; View follows site.view-mode: existing cosmetic wasp interaction remains available without changing actual task/issue state or granting commands.

Additional constraints
Model defense by stable work episode and distinct active/paused/resolved states.

Safety and failure behavior
Only verified completion/idle resolves; preserve canonical tasks and motion/View guards.


## Status and removal

Documented means saved, not proof of runtime implementation. Implemented is recorded only after its applicable change/checks. Disable one group/property through the command workflow; reverse any runtime effect and check it before claiming removal is applied. Historical values are inactive registry history, never a second active directive.
