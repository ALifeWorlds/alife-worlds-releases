# Use ALife World in Codex

## Install the 0.4.3 release candidate

Build this exact qualified source with `node scripts/build-plugin.mjs`. This checkout's `.agents/plugins/marketplace.json` points only at its generated `.plugin-build/alife-worlds` packet. Preserve the existing marketplace registration and installed packet before an authorized switch. Use `codex plugin marketplace add <this-checkout>` and `codex plugin add alife-worlds@alife-worlds-local --json`; if that marketplace name is already registered at a different root, remove only that registration through `codex plugin marketplace remove alife-worlds-local --json` first, then register this checkout. Do not write directly into the plugin cache or change other marketplace registrations.

Verify the supported plugin list reports installed/enabled version 0.4.3 and this exact local source; compare the installed manifests and skill bytes with the qualified packet. The RC marker is the Git branch/tag and release documentation; the three package manifests retain the host-compatible version 0.4.3. Installation does not automatically update another world's private state or Site. Already running chats can retain an earlier loaded plugin until the host reloads it; registration readback alone does not prove a native panel invocation or visible world acceptance. Restore the preserved previous source registration and reinstall it through the same supported commands if rollback is needed.

The package identity remains `alife-worlds`; its display name is **ALife Worlds**. The plugin exposes only `create-world`. It handles project startup and dispatches rule/world/open maintenance to its bundled world-guide reference without provisioning for those maintenance requests.

## Enable private Windows reconnect

For explicitly approved unattended connection recovery, copy [the credential-free configuration example](../scripts/windows/connection.config.example.json) into that destination's private `.alife-worlds/connection-supervisor/connection.json` and replace every placeholder with its own qualified packet, original planning/configuration roots and existing registered Director. Run `scripts/windows/setup-connection-credential.ps1 -ConfigFile <absolute-private-config>` to enter pairing privately; approved automation can use `-FromStdin` without putting secrets in arguments. The script uses CurrentUser DPAPI and restrictive ACLs. Then run `scripts/windows/register-connection-supervisor.ps1 -ConfigFile <absolute-private-config> -Install -StartNow`. Registration is an explicit opt-in; it creates one limited current-user interactive-logon task with hidden execution and bounded self-restart. It performs no agent setup or settings change.

The private supervisor owns exact child PID generations and their recovery, including the original publisher lock and pending journal. A repair hold survives restarts. Re-pair through the supported setup script; `-ResetRepairHold` is an explicit repair choice after reconciling the original state, never permission to discard an unknown request. Preserve the prior configuration, encrypted pairing and task XML when replacing them. A cloned plugin includes only these scripts, never a configured task or somebody else's credentials. See [connection limits and custody](INTEGRATION.md#optional-windows-connection-recovery).

Trusted local Windows helpers use process-local `RemoteSigned`, preserving machine/user execution policy and Group Policy. They do not use Bypass, change persistent policy or remove downloaded-file trust marks. A blocked or unsigned downloaded script requires the owner's supported signing/trust flow. Each PowerShell process loads its own runtime's security/CIM module, avoiding incompatible module inheritance from a different PowerShell edition. Native dummy-credential checks cover actual CurrentUser encryption, restrictive ACLs and same-user decryption; they make no Site requests or task registrations.

## Connection status

This development packet can be installed through an explicitly requested, qualified local source cutover. Preserve the previous registration and installed packet first, validate a frozen source snapshot, and verify the listed source/version plus skill discovery after refresh. Installation, native startup, world rendering and native message transport have separate acceptance. The commands below describe the supported flow; invoking a skill alone does not authorize installation.

## Build and register this source

Before replacing the marketplace packet, follow [Plugin versions and release guard](#plugin-versions-and-release-guard) to qualify and seal the current version.

From your authorized source checkout:

```powershell
npm run build:plugin
codex plugin marketplace add . --json
codex plugin add alife-worlds@alife-worlds-local --json
codex plugin list --marketplace alife-worlds-local --json
```

Use the installed CLI's help if its supported options differ. The local marketplace must resolve this checkout, and its plugin entry must resolve the generated packet under `.plugin-build/alife-worlds`. The installer manages the cache; edit source and rebuild/reinstall rather than editing cached files.

The packet contains an explicit allowlist of runtime, documentation, role contracts, tests and the empty example. It excludes this team's actual plan, homes, native bindings, local configuration, journals and checkpoints. The previous generated packet is retained locally for recovery.

If the marketplace name is already registered to another source, the supported add command refuses the switch. After the human authorizes connection, preserve the previous source information, inspect `codex plugin marketplace list`, then use `codex plugin marketplace remove alife-worlds-local` before adding this checkout. This changes the registration; it does not authorize deleting old source folders or manually editing the cache.

## Verify the connection

Check the listed plugin ID, source path, version, installed state and enabled state. Compare the installed manifest and skill with the generated packet. Reload the app or open a fresh chat when required to expose the changed skill; an already-open chat may retain the earlier tool/skill list.

For explicitly requested first setup, invoke the create-world skill in the actual selected project's Codex chat. It uses supported native project/chat tools to create missing core chats under the guarded workflow below. Opening the read-only launcher alone creates no agents or service. Native message transport and deprecated feature imports are separate.

## Setup scope

The existing npm run setup command initializes missing files in an explicitly authorized source copy; it is not the Codex native startup workflow. Never run it in an installed cache.

The [create-world setup workflow](COMMANDS.md#user-invoked-new-project-setup) derives the actual cwd/thread and unique local saved-project mapping automatically, including a null thread projectId when the path mapping is exact. The invoking project chat becomes Director for a fresh world, preserving its settings. The explicit setup supplies the core destination rather than requiring an Agent Dump exception question. The helper loads the approved private creation profile automatically; Director then reserves and creates Agent Support once through supported native create_thread. Only the acknowledged Agent Support then creates missing World Requests. Each role must read its complete generated contracts and write its own exact-home/custody receipt from its actual native session.

The helper scripts/bootstrap-world.mjs begin verifies native session ID/cwd and current saved-project metadata, then keeps the episode, homes, bindings, runtime snapshot and effects under the actual project's ignored .alife-worlds directory. Its finite binding handshake and durable same-child continuation preserve unknown sends and keep the effectful startup chain moving without duplicate launches. It supplies no hidden native transport. A host without the required native tools reports the missing capability. Existing ALife teams/configurations are preserved for their existing connection workflow, never replaced by a new default team.

Before first creation reservation, the helper reconciles the incoming role's complete current project/master/shared/retirement/role/universal/own-rule contract from the current invoked qualified packet. It updates only uncreated/unreserved generated drafts, preserves durable preimages and refuses an edited draft; existing or pending native custody is never rewritten or replayed. Native project IDs remain opaque and must match the actual local project/root/host mapping.

Existing same-folder agents and explicitly selected other-folder agents are recorded as protected read-only membership intended for private visual display. Their actual display requires the world adapter's combined-roster integration. Reset-plan proposes only plugin-created core targets; it performs no archive, delete or filesystem reset. Reused and pre-existing agents remain protected.

A newly created setup episode captures the actual invoking title and reuses that same chat as Director. After its own full onboarding receipt, the [first setup chat title workflow](COMMANDS.md#first-setup-chat-title) reserves the exact target, compares a fresh native preflight, performs the supported set_thread_title action once and records the real result/readback. There is no hidden native RPC, replacement chat or model/settings change. Existing episodes and later human title changes remain intact; unknown operations are reconciled without replay. Title status and original core/world readiness are reported separately.

World Requests starts only the explicitly requested private loopback service after all three core receipts. Register-launcher verifies its exact identity and preserves unrelated profile entries. This local link alone does not provide authenticated phone/remote access, public hosting or native-message controls.

Source fixtures do not establish a completed live Codex startup/rendering acceptance. Check the actual target-bound private acceptance separately; neither these instructions nor generated folders prove native readiness.

## Private world release and display

The [private world record commands](COMMANDS.md#private-world-release-records) initialize only this exact onboarded project's neutral definition and preserve existing custom art, preferences, surface opt-outs and records. Immutable world/design snapshots and the append-only private ledger provide readable JSON/Markdown history; source definition, prepared artifact, actual per-surface deployment and actual acceptance remain separate. These filesystem helpers perform no native or hosting calls.

For a new episode, World Requests is the logical role and World 1.0 is its requested native display from world definition 1.0.0. Existing episodes are not relabeled or reset by this change. Bootstrap status exposes requested display separately from unknown observed display; later authorized native title changes require the exact original target reservation, supported result and readback. Plugin and world versions remain independent.

## Native team and local server

Plugin installation and the existing local world's service are separate connections. Preserve native homes, project/chat identity, session cwd and the existing local server's owner. Configure only the current project's authorized read-only adapter, as described in [Integration](INTEGRATION.md).

A missing or stale observation remains unknown. Source and package tests do not prove native messaging, hosted deployment, physical-phone layout or listening acceptance.

## Documentation

The product overview follows the approachable purpose, quick-start, capabilities and usage organization seen in [Image Blaster](https://github.com/neilsonnn/image-blaster/blob/main/README.md) and [OpenClaw](https://github.com/openclaw/openclaw/blob/main/README.md), using this plugin's own content.

Local marketplace and cache behavior is documented in the [official OpenAI plugin guide](https://developers.openai.com/plugins/build/plugins).

## Planet icon and Open ALife Worlds

The package keeps the original transparent 1254×1254 colored planet PNG unchanged, with the existing Itzel Juarez author and developer credits preserved. It remains the guarded recovery asset. Current server/tool discovery uses 64x64 native-theme monochrome SVG variants, refreshed in 0.2.17 to retain more of the original planet; actual host color/shape observation remains separate. The logo and composerIcon reference `./assets/icon-monochrome.svg`, with logoDark and composerIconDark at `./assets/icon-monochrome-dark.svg`; `./assets/icon.png` remains the unchanged recovery asset. The display name is **ALife Worlds**, and the sidebar tool remains **Open ALife Worlds** for accessing configured worlds. The onboarding prompt requests project setup with Director, Agent Support and World Requests.

A name, icon or launch prompt is presentation metadata; it does not prove that the action ran. When the host exposes the supported `open_in_codex` website opener, the skill can resolve and verify the current authorized project/site URL, then open that existing site in the right-hand Codex browser panel with a browser target and right placement. Discover the available host tool first. A host without it returns the supported URL or an honest unavailable result; do not invent a route or bypass a rejected action.

Opening an ordinary website panel does not install, register, enable or refresh the plugin. A custom embedded MCP App is a separate integration. The scoped foundation refresh is accepted under [Verified foundation refresh](#verified-foundation-refresh); later refreshes need explicit authorization and qualification. The requested native-panel action remains **NOT TESTED** until actually exercised with the correct project/site. A simulated viewport is separate evidence; physical-phone checks also remain independent.

The [official plugin format](https://developers.openai.com/plugins/build/plugins) owns logo, composer-icon and onboarding-skill fields. A custom embedded view uses the [supported MCP Apps resource and render-tool path](https://developers.openai.com/plugins/build/chatgpt-ui); do not invent a native host route or bypass a failed connection.

## First use with an image folder

A full prose style description is optional when the human supplies reference images. Read the [complete image-reference workflow](ASSETS.md#first-use-with-an-image-folder), inspect every supplied image, derive one coherent art direction, and generate the required project assets using the actual available image tool. Preserve the original references and their provenance.

No reference folder was supplied for this source-presentation change. The workflow is available guidance, not evidence that a reference batch was inspected, assets were generated, or a new world was accepted.


## Verified foundation refresh

A qualified local refresh installed version 0.1.0-foundation.1 from this Git source using the existing alife-worlds@alife-worlds-local identity. All 112 authored packet files plus provenance matched the frozen candidate. A fresh turn in an existing native chat advertised the new alife-world skill and successfully performed its read-only grouped rule discovery: 42 Plugin Rules and 64 World Rules. Installation and skill discovery are accepted independently of native command transport.

The old source and a full recoverable installed-packet checkpoint were retained. The supported installer replaced its managed cache. Exact before/after verification found only the ALife marketplace source path changed in the global configuration; model, reasoning, speed and other installed plugin settings were preserved. No native chat, home, binding or session cwd was recreated or moved.

The installed packet is a frozen snapshot. Keep the marketplace packet unchanged while another owner has unfinished source edits; build new candidates in an isolated qualification copy and activate only a qualified refresh. That historical refresh predates the building-world source workflow. Live startup acceptance, additional specialist staffing and native message/Wake/Unblock/Retire transport remain separate. A queued website-panel request is not proof that a native panel was observed.

## Plugin versions and release guard

The canonical version is package.json; plugin.json and .codex-plugin/plugin.json must match it. Releases use normal X.Y.Z numbers. Version 0.1.3 adds the selected read-only world launcher and three-core/bootstrap contracts. Earlier releases remain immutable historical checkpoints.

For a later plugin update, make the content changes and explicitly choose its version increment:

```powershell
npm run version:bump -- patch
# Or use minor / major for the intended release scope.
npm run version:check
```

The bump synchronizes all three manifests and never commits, pushes, installs or deploys. Repeating an unchanged build does not bump. Do not use npm version by itself: it would leave the plugin manifests out of sync. A version-write lock prevents overlapping bump/seal commands. If interrupted, preserve the runtime/versioning reservation and reconcile the owner and all three manifests before retry; packaging fails closed on a mismatch.

Qualify in an isolated source copy while preserving the current marketplace packet. Do not bump an already prepared candidate again merely to run these checks:

```powershell
npm run rules:check
npm test
npm run build:plugin -- --candidate
```

The candidate build prints contentFingerprint and writes a distinct candidate directory, leaving .plugin-build/alife-worlds intact. Only after the exact frozen candidate passes its required checks, the release owner records that same fingerprint in plugin-releases.json:

```powershell
npm run version:seal -- QUALIFIED_SHA256
npm run version:check
```

Replace QUALIFIED_SHA256 with the full contentFingerprint from the qualified build. Run seal in the frozen source being activated, including its existing release history. It rejects a fingerprint that no longer matches. Carry the reviewed ledger entry with the matching source; do not copy an installed packet back as authoring source. Sealing records a qualified release identity, not a Git push, Codex refresh, native connection or hosted publication.

Normal npm run build:plugin requires a sealed version before updating the marketplace packet. Both normal and --candidate builds reject changed content under an already recorded version; choose a new patch/minor/major and requalify. Preserve previous ledger entries. An identical seal is harmless and writes nothing; an existing release fingerprint cannot be replaced by the command.

The fingerprint covers the sorted authored packet file paths and content, including manifests, code, art, rules, tests and documentation. UTF-8 text uses canonical LF newlines so Windows CRLF checkout conversion alone does not create a release change; binary assets remain byte-exact. The ledger itself and derived package-provenance.json are excluded to avoid self-reference. Local runtime, private plans and build outputs remain outside the package allowlist. This is a checked source release ledger, not a tamper-proof service or remote publication registry; deleting or editing its history would remove that protection and is not part of the supported workflow.

After final qualification and ledger review, the coordinator builds the matching marketplace packet and uses the supported Codex refresh flow above. Verify the installed identity/version, actual skill discovery and selected launcher entrypoints; source text alone does not change Codex. Keep the previous source registration and installed packet for rollback. Rollback must use that exact preserved packet/source and its own version, rather than rewriting released history or relabeling changed files. Native message transport, settings, private worlds and hosted websites remain separate.

All seven focused versioning regressions passed in an isolated current-source copy, covering version mismatch, unchanged qualification, same-version changed-content refusal, explicit synchronized patching, immutable seal/retry behavior, private-state exclusion and text/binary fingerprint boundaries. The active marketplace and installed cache are not test targets.

The sealed0.1.1 checkpoint was not activated as an installed plugin: the final Windows Git export exposed the inherited-contract newline issue. Its fingerprint remains in release history. The corrected0.1.2 release pins the full role inputs and passed the clean Windows-export rule/build checks; the earlier seal was not rewritten. Later releases retain those strict checks.


On Windows, package publication retries only sharing-related EPERM/EBUSY/EACCES failures for a bounded total delay of 1.55 seconds. Each attempt verifies the same original regular directory, absent destination and exact common .plugin-build parent. The machine result records publicationRetries. A persistent failure stops publication and retains existing/recovery directories for reconciliation. Two real Windows directory-lock cases verify temporary-release success with sealed history preserved and permanent-lock failure with the active packet and recovery stage preserved. This source correction changes no release ledger, installed cache or running service.

## Read-only sidebar world launcher (F01)

The local open_world entrypoint retains the explicit picker and verified full-dashboard destination in selected.viewerUrl. Its current MCP App resource is ui://alife-worlds/launcher/v4.html. read_world_preview is a separate app-only read tool without a render-resource attachment; it supplies bounded snapshots and bundled sounds to this one component. It performs no AI/model call, native chat/action, Git operation, service startup or task edit. The stdio configuration and original plugin identity remain unchanged.

### Private connection profile

The configuration owner maintains the bounded external launcher-profile.json selected by ALIFE_WORLD_PROFILE or the existing default. Profile schema 1 remains supported for full operator launch. Optional schema 2 permits a closed renderer descriptor on an existing world row. The exact existing alias, label, opaque canonical projectId, public worldId, normal projectRoot and literal http://127.0.0.1:PORT origin remain required; no URL/path arrives from a tool caller. Preserve unrelated worlds and existing choices. Normal-file/realpath guards,64 KiB/32-world limits and duplicate identity/root/origin refusals remain in force. Missing/unsupported renderer configuration never selects another world.

A renderer descriptor has bundleId colony-world113, worldVersion 1.1.3 and its exact artifactSha256. Descriptor schema 1 supports only an explicitly selected sanitized spectator component. The separately configured owner-local form has schemaVersion 2 and appearance owner-local-v1. Only Root/configuration custody may add that private attestation after verifying the actual service/artifact. This source update does not write a live profile. Unknown custom renderer descriptors retain their full-dashboard link with an explicit unsupported-inline result; there is no default skin fallback.

### Direct original-world rendering and isolation

The v4 component draws the pinned original World 1.1.3 scene directly in its own document. It requests no subframe, browser network or external resource permissions: frameDomains, connectDomains and resourceDomains are all empty. The assembly verifies a contained regular-file hash manifest and stays within 512 KiB UTF8. It reuses the exact qualified 026 procedural art/CSS and the original renderer with only an audited lifecycle/local-appearance adapter. The different general source renderer is not substituted or overwritten. The original world rules, positions, accepted mechanics, muted audio behavior and stable visualWorldKey/task visualKey are retained. This is not the later world-visual backlog implementation.

Every selected read rechecks the existing bounded /api/world-launcher identity against the private profile's exact project/root/world/origin. An owner-local snapshot then uses only GET /api/owner-world-preview?project=VERIFIED_PUBLIC_WORLD_ID; a deliberately configured descriptor-schema 1 spectator component uses the existing public endpoint. There is no silent fallback between those contracts. Read bodies are capped at 320 KiB combined,256 KiB public DTO and32 KiB minimized appearance, with a4s total deadline including a2s health read. Reject redirects, non-JSON/compressed/oversized/malformed data, foreign identity and closed-schema violations. MCP cancellation aborts the bounded Node HTTP read. A host that cannot forward UI cancellation still has the backend hard deadline; actual forwarding needs native qualification.

The owner-only envelope derives the unchanged public DTO and local minimized appearance from ONE existing app.readCurrentState() result. The appearance is bound to that DTO's canonical JSON SHA256, exact world/artifact and observation UTC, with exactly the same unique sanitized role aliases. It forwards only fixed color/scale/shape/effort-size tokens, booleans and genuine allowed speed-observation timestamps. Model names, raw effort/service-tier settings, native IDs and private work prose stay out. The source observer supplies no model-applied timestamp, so modelAppliedUtc remains null; neither a poll nor a lifecycle event substitutes one. Existing120s fast/trail admission and expiry rules remain authoritative. General public DTOs/routes, publisher and website receive no sideband or behavior change.

One serialized visible-only snapshot poll runs5s after its preceding request settles. Selection, Refresh and visibility-resume share that path. Hidden panels stop polling and motion; switch/refusal/teardown invalidates generations and cancels pending work. The variant destroy method releases its animation frames, global listeners, ResizeObserver, privacy adapter and audio context. Late replies cannot restore a previous world. Real activity timestamps are preserved; failures retain a clearly unavailable last snapshot, and repeated polling creates no work/progress evidence.

### Audio and full dashboard

All nine existing hash-pinned CC0 samples and their author/source/license manifest are retained. A trusted Sound enable lazily requests package-owned64 KiB compressed chunks through the same app-only tool, with96 KiB replies,2s health admission and a4 MiB compressed file/cache bound. Verify final hashes before WebAudio decode. The4 MiB bound is not a decoded PCM memory claim. Every mount starts muted, the existing volume slider remains beside Sound, and mute immediately stops sources and invalidates pending loads. Switching/disposal closes audio. No browser fetch or remote audio URL is used.

Open full dashboard remains an explicit separate action. It freshly verifies selected.viewerUrl and uses the supported ui/open-link only when the host advertises openLinks. An acknowledgment is a request acknowledgment, not visible navigation. Unsupported openLinks disables that action with a reason without adding a popup. The full operator keeps its original controls and frame-ancestors none. For an explicitly requested Codex browser panel, discover the supported model-side open_in_codex tool and pass only the verified operator URL with placement right; the widget invents no such RPC. Queued requests still need actual visible acceptance.

### Native icon and qualification boundary

The original 1254x1254 colored PNG remains byte-identical. The 0.2.17 64x64 square code-native SVGs replace the thin outline with a substantial stepped planet body. Negative-space cuts retain the upper, middle and lower bands, stepped highlight and separate sparkle; the tilted orbit and two satellite pixels follow the original master. Monochrome retains this geometry rather than the original yellow, pink and mint hues or raster shading. Both variants share the same geometry and use CanvasText/color-scheme semantic theme colors rather than a guessed Codex hex. Server and tool discovery share bounded, hash-verified light/dark descriptors. A malformed SVG is never emitted; the contained original PNG remains the guarded fallback. Root owns logo/composer manifest wiring, version, packaging and installation. SVG support and optional theme variants follow the [official icon requirements](https://developers.openai.com/plugins/deploy/submission); native color/shape rendering requires actual host observation.

For the 0.2.17 icon source change, World Requests reviewed an offline light/dark contact sheet at actual 16, 20, 24, 32 and 64 pixel sizes, with an enlarged view beside the unchanged colored master and previous outline. The smallest sizes reduce fine highlight detail. This is a simulated-theme source preview, not an installed Codex screenshot. The single existing monochrome containment/fallback test passed (1 test, 0 failures, cancellations or skips); the launcher edit changes only the two SVG hash pins. That source handoff preceded Root’s qualified 0.2.17 private publication, supported installation and subsequent human-visible icon acceptance. The 0.2.18 source preserves both accepted SVGs; its new package/world qualification and runtime activation remain separate.

Historical v2 replaced the world area with an opening-acknowledgment message. Version013/v3's source checks passed, but the human's actual native screenshot and Codex log showed ERR_BLOCKED_BY_CSP under both HTTP-excluding frame-src and frame-src none policies. Those failures remain recorded. Adding another URI, alias-only CSP metadata or weakening the operator guard is not accepted as a correction. The v4 source/candidate wrapper and profile activation remain separate gates; focused fixtures do not prove an installed native world, all 20 visible ants, audio listening or native-theme icon acceptance.

World Requests completed 29 focused checks with zero failures, cancellations or skips against the final source slice: protocol/profile isolation, direct module bridge, closed public/local projections, actual frozen-source reversal, command-path containment, lifecycle/audio cancellation and private candidate route rejection. Initial fixture deficiencies were corrected in the test harness; the final bounded regression passed. These source results do not establish native or runtime activation acceptance. Root separately qualifies clean Windows export, packet/version integration and the exact private guard/profile. The private candidate wrapper is source-only until its exact Root-supplied runtime guard, profile attestation and activation are qualified. No fixed listener, existing service, publisher, proof, settings, model or native agent is changed by authoring. Keep the native result NOT TESTED until actual qualified activation and observation; retain source PASS independently of the original native FAIL.

## Three-core package membership

The distributed default catalogue contains exactly Director, Agent Support and World Requests (stable IDs director, support and world-requests). Package collection rejects an extra, missing, duplicated or substituted default role; it does not silently trim an invalid catalogue.

Only roles/SHARED.md, roles/director.md, roles/support.md and roles/world-requests.md enter the packet. Other local/source templates are excluded without being deleted by the collector. The existing strict rule-document check still regenerates its expectations from the selected catalogue, so stale or extra role sections in the generated agent manual fail qualification.

A project's explicit private registry override remains project configuration, outside the packet. It can retain that project's existing roster and work while the plugin ships three defaults; packet membership never archives chats, rewrites homes or transfers native identity. Do not copy a private override into data/roles.json to bypass the default-catalogue guard.

All 11 focused cases passed against the actual isolated three-core source: four membership/document checks and seven affected version/packaging checks. They cover exact membership, preserved extra local templates, private override exclusion, invalid catalogue refusal and stale/missing core documents. Run them together with the affected version/packaging regressions:

```powershell
node --test tests/core-package.test.mjs tests/plugin-version.test.mjs
```

This package slice is separate from renderer/runtime checks and actual global/thread launcher acceptance. The release owner must combine the settled slices, complete clean Git-export qualification and use a new version before activating changed content over an existing sealed packet.

## Reviewed startup source qualification

The completed 0.1.5 baseline passed 36 focused cases: 14 bootstrap, nine launcher/profile, four core-package and nine version/publication regressions. The automatic-start correction passes 68 affected source cases with the approved private profile, exact invoking context, one advertised entry, healthy service reuse and durable continuation covered. Native target-bound acceptance remains separate. It covers opaque native project IDs, exact service identity, current complete incoming inheritance with durable recovery, preserved edited/established/reserved custody, and protected existing/linked membership. The bundled skill validator passes. Test identities and onboarding receipts are synthetic; this is not a live Codex startup or extra-agent rendering acceptance. Whole-candidate policy/adapter integration, a new qualified version, Git publication and installed refresh remain the release owner's separate steps.


### Full local dashboard destination

The startup and local sidebar launcher open the verified full dashboard at operatorUrl = origin + "/?project=" + the encoded actual projectId. New local worlds use Public presentation by default and retain the existing Public/Private/View modes, project dropdowns and cosmetic Interact controls; an existing world's choice is preserved. Native actions remain guarded by their real supported capability.

The bootstrap records operatorUrl separately from its sanitized spectator viewerUrl. Reading or reusing a healthy older bootstrap derives the missing operatorUrl without rewriting its journal, changing its PID, restarting its runtime or altering settings. Registration returns both links and preserves unrelated entries. The private MCP launcher keeps the selected.viewerUrl field for compatibility while returning the operator target there. Public/hosted spectator routes keep their public world ID and existing privacy contract.

The regression was caused by startup metadata, the CLI reuse/registration path and local launcher all selecting the spectator URL even though the full root dashboard already existed. The helper now supplies the operator target; the launcher validates the original exact project/root/world/origin before constructing it. Source checks and actual host navigation/rendering remain separate acceptance.

The bounded 0.1.7 source correction passes 91 focused cases with zero failures or skips: bootstrap/healthy legacy reuse, launcher identity and host bridge, full local HTML/project refusal, separate sanitized spectator routes, packaging/version and complete rule inheritance. Generated-rule consistency and the building-world skill validator also pass. The fixtures use synthetic native metadata and disposable local services. Actual host navigation, full dashboard rendering and installed refresh remain the release owner’s separate acceptance.

### Create-world invocation and running status

The advertised skill and onboarding/default prompt use alife-worlds:create-world before submission. Its full building-world workflow remains packaged as a reference, with the original context, approval, receipt and effect guards intact. Only an actual submitted setup that has begun receives the Building world / alife-worlds:building-world progress status. Maintenance and read-only opening do not provision agents. The host owns the original selected/submitted skill chip; the plugin does not claim a supported conditional rewrite of that earlier chip. Native pre-submission display and actual post-submission progress remain separate host observations.

### Registered-project views and count labels

The 0.2.18 local/private picker shares the bounded external connection profile and verified folder names; its explicit switch opens only the chosen project's own world. Show all loads each visible planet's verified read-only viewer inside a full circular clip, with captions and accessible selection outside it. Missing or unsupported worlds remain truthful. This is a read-only presentation path, without a model call or operational action.

The native sidebar's Show all catalogue keeps one explicitly selected, supported inline renderer. Switching reveals that selected card, and its task/sprint counts flow below its planet. Other entries retain unconfirmed/unsupported state until explicitly selected. The existing tools, closed DTO/appearance binding, deadlines, frame/network CSP and audio bounds remain unchanged; no custom-world farm substitution is introduced.

Sprint percentages count whole completed member tasks, including required linked goals/amendments once; epic percentages count whole completed sprints. The pure dashboard helper and external labels identify completed/total task or sprint denominators. This launcher-only assembly keeps colony-world113 and its original manifest, descriptor, art, audio and renderer hashes. The separately saved count-canvas1.1.5 candidate and native-context proposal remain deferred; neither is a gate for the three registered-picker/switch/circular-view goals. See [the current integration contract](INTEGRATION.md#registered-worlds-and-count-progress--8-november-2026).

## Current local-site entry and sidebar website ownership

When a human authorizes a Web Developer specialist, that role maintains the Codex plugin/sidebar site entry, frontend wrapper, links and safe display composition alongside the selected local/private/public websites. World Requests retains renderer/modes/art/interactions. Root retains registration/backend, canonical Git, qualified package and actual service/installation activation. A source/frontend edit is not proof of native panel rendering or an agent connection.

Open current local site uses the existing supported tool selection, rechecks the same selected project/world/origin, and submits the exact selected.viewerUrl operator target through the host’s advertised ui/open-link capability. The UI shows the supplied local origin, without hardcoded ports, filesystem paths, cached Site fallbacks, arbitrary URLs or direct localhost fetches. Unsupported opening stays disabled with a truthful reason; acknowledgment is not visible navigation. This preserves the current full local website as the entry instead of substituting an older static page.

The inline component consumes only the actual package-pinned qualified renderer and supported current preview DTO. Its World version label comes from the validated renderer descriptor, never a website version guess. Fixed View retains cosmetic world interaction and actual muted-by-default Sound/conditional volume, Pause and Fullscreen while omitting the old Interact toggle, sprint/progress footer, metadata note and their layout space. Selection/overview, identity/hash validation, visible-only polling, lifecycle cancellation and trusted audio remain in their original boundaries. The earlier1.1.3 qualification details above are historical; Root’s actual selected artifact and installed source determine current preview support.

This two-file frontend candidate is authored against Root-confirmed41eefb55 and the explicit unsealed0.2.21 guard. Necessary extracted-module syntax is checked; no browser/native/render/audio acceptance is claimed. Root separately qualifies backend100-role compatibility, actual local data recovery, package version/registration/cache identity and installation. New QA message features and later agent-card refinements are independent of this P0 entry/site delivery.

The qualified public-name update uses launcher resource v7 so the app can obtain the matching explicit-name validator. The selected World1.2.2 scene/art and private appearance contract remain unchanged; host refresh and visible rendering remain separate from installation.

### Reference-art transport and mapped release context

The reference-art inline entry uses resource v8 and a separate app-only read_world_art tool for package-pinned image/font chunks. It verifies the complete selected family and loaded font before mounting; failed loading remains unavailable rather than claiming the procedural fallback is the chosen art. The tool opens no service, sends no chat message and changes no native settings. Installation and an already-open host loading the new resource remain separate results.

For a verified project whose canonical root differs from its recorded execution cwd, world-release supports an explicit private pinned context provider and --project-root. It reuses the existing native authority and compares native title evidence against the actual saved native project namespace. Ordinary exact-project guards remain unchanged. See [Integration](INTEGRATION.md#explicit-native-context-for-world-release-records) for the contract and limits.

## Updating an existing copy

A plugin code update and a portable definition import are separate operations. The qualified plugin packet contains reusable renderer assets, website components, defaults, rules and implementation code. The chat /import workflow accepts only its validated portable definition format; it does not execute a ZIP, update installed code, replace an existing world or copy this development team's identities, approvals, work or settings.

For an authorized update, preserve the destination's current source, native team, selected world/profile, local configuration and recovery packet first. The destination Git owner reads the current instructions, checks the approved remote and integrates with fast-forward-only synchronization where possible; unresolved local changes or conflicts require review rather than reset. Build and verify the qualified packet from that source using the existing build/register workflow above. Reinstall or refresh only through the destination's supported plugin connection after its human authorizes the cutover, then inspect the actual listed source/version and host discovery. A pushed source version does not automatically update another installed copy. Never edit the installed cache.

A saved custom world, audience, agent roster or human-selected model/speed remains local. Reusable website modules need the destination's own actual project data, qualified scene and existing site configuration. Preserve the site's App/project identifiers and audience. Configure and publish through its current owner; this source packet contains no ready-made account connection or hosting credential. Selected-world preparation and deployment have their own actual receipts and versions. The neutral new-world definition remains1.0.0; an example renderer release does not relabel another world's history.

The source archive and qualified plugin packet are different artifacts. To build/register an extracted source archive, use the unchanged local marketplace definition under .agents/plugins/marketplace.json and the existing build commands above. The installed CLI accepts a plugin selector from a configured marketplace; it does not accept a ZIP as the plugin selector. Keep the qualified packet immutable, and use the matching source checkout/archive for the supported local-marketplace workflow. A source archive has no Git history; use an authorized Git checkout for future fetch/integration.

An already running project's vendored runtime/site is also separate from the installed plugin. This update does not silently overwrite that runtime or its saved custom scene. Its owner must preserve the current files, profiles, identities, active effects and recovery evidence, review the exact reusable-code diff and record a separately authorized runtime cutover. There is no executable ZIP /import or blanket reset/update command in this release.
