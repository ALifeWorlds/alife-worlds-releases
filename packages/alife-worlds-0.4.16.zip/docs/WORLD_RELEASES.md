# ALife World release history

World versions, plugin versions and hosting saved/deployment versions are different records. The owning policy is plugin delivery.world-release-versioning; [Operations](OPERATIONS.md#world-releases-and-site-updates) describes the release workflow. This portable document contains neutral release facts and the record contract. The selected world actual history and private surface mapping live in its own private records.

## Source definition

| World version | Status | Display | Meaning |
| --- | --- | --- | --- |
| 1.0.0 | Definition / preparation | World 1.0 | Starting neutral world version; no surface is claimed deployed or verified by this row. |
| 1.1.0 | Qualified renderer baseline / recovery | World 1.1 | Prior Sound volume UI and visible-world corrections; actual selected-world delivery and acceptance remain in the private ledger. |
| 1.1.1 | Qualified renderer baseline / recovery | World 1.1.1 | Keyed initial placement and public/local visual-key consistency; actual selected-world delivery and acceptance remain in the private ledger. |
| 1.1.2 | Sealed source candidate / not activated | World 1.1.2 | Attention and shared moving-name correction in the private plugin 0.2.5 source checkpoint; no world deployment, runtime installation or native title change is claimed. |
| 1.1.3 | Retained correction / visual failure recorded | World 1.1.3 | Plugin 0.2.6 source/installation and actual selected-world delivery retain their separate private receipts; the reported room-name visual mismatch is not acceptance. |
| 1.1.4 | Source qualified / artifact preparation pending | World 1.1.4 | Plugin 0.2.7 retains the sealed privately published room-lettering and woodland/sprint-tree correction. Plugin 0.2.8 is the narrow snapshot-compatibility candidate for the same artwork; no prepared world artifact, installation, deployment or whole-release acceptance follows from this row. |
| Unversioned | Historical recovery | Previous display retained in actual history | Preserve the old working artifact and real hosting revisions; do not relabel them 1.0.0. |

The shipped world/world-release.json is a neutral definition. Its artifact digest is null and surfaces empty until real artifact qualification and destination receipts exist in the private producer contract. A plugin release version or Site save number is never substituted for a world version.

## Actual selected-world records

- .alife-worlds/world-release/ledger.json: canonical actual release, deployment and rollback events for the exact selected project/world.
- The qualified scripts/world-release.mjs report command reads that actual project ledger; report --format markdown gives its readable history. Invoke it from the selected project context using the qualified plugin script path as described in [Commands](COMMANDS.md). Preserve a private report copy with the ledger when handing off actual changes, per-surface versions, checks and rollback targets. A template is not a completed local history.
- .alife-worlds/world-profile.json: saved art direction, asset manifest, reference provenance, human preferences and scoped private surface mapping. Keep credentials outside it.
- Hash-verified immutable design/asset snapshots: retained recovery inputs, distinct from tasks, chats, runtime grants and native bindings.

Each real release records version/date, change summary, immutable world artifact identity and source reference, applicable check results/limits, selected art profile and retained recovery target. For each actual local, owner-private, public viewer or custom-domain destination, record requested, deployed and verified world versions separately, plus its real hosting/source revision and actual result. Missing facts stay Unknown; failed or pending updates never make a destination current. The readable report must expose this world actual rows and statuses.

## Visible delivery and corrections

Plugin 0.2.0 / world 1.1.0 are the retained prior renderer baseline. Plugin 0.2.1 adds acknowledged fresh-Director title support and release-title completion guards without changing that world artifact. Plugin 0.2.2 / world 1.1.1 are the qualified baseline for keyed same-version placement. Plugin 0.2.3 and 0.2.4 contain documentation corrections without a new world artifact. Plugin 0.2.5 is a sealed privately published source/packet checkpoint for the undeployed world 1.1.2 attention and shared moving-name candidate. Plugin 0.2.6 is a sealed privately published source/packet checkpoint and supported installation; actual selected-world local 1.1.3 delivery is recorded privately, with verification separate. Its room-name appearance received a human-reported visual failure against the selected reference; preserve valid source/installation/delivery evidence and recoverable history. Plugin 0.2.7 / World 1.1.4 is a sealed privately published source/packet correction. Plugin 0.2.8 is the current narrow snapshot-compatibility candidate for that unchanged renderer and artwork. These source checkpoints and allocations do not establish current hosted delivery or acceptance. This portable record claims no selected-world deployment, rendered acceptance or native title change. Keep the neutral new-world initialization definition separate from an existing world release history. The single Sound control and its conditional volume UI remain owned by world sound-and-motion.one-toggle; agent body/art visibility remains owned by appearance.agents.

### Retained attention correction scope

The first narrow correction keeps a genuine unresolved input or approval visible while the same bound source remains freshly verified. Preserve the original event and work timestamps; clear attention on actual resolution, completion or unavailable source. Route the existing agent to a safe clear-floor target instead of a bed or paused defense position. Reuse the existing Special Forces leader attention drawing without creating a second agent.

The original 0.2.5 attention allocation excluded room styling, soil, sprint-tree/woodland art and immersive fullscreen. Its exact source/private publication and later inherited local delivery receipts stay at their actual revisions and scope; they do not supply a new visual PASS. Each subsequent push, installation, runtime or hosted effect still needs its exact release-owner clearance and actual receipt. Do not promote a destination or acceptance from this historical scope.

### Retained 0.2.6 room-name iteration

The 0.2.6 iteration used lower-floor white room names without dark plaques and consistent role typography. The human rejected its appearance against the reference. That lower-floor interpretation and approximate numerical font recipe are historical, not current directives. Preserve the original source and actual per-surface outcomes; the newer selected image owns the upper-rim lettering correction.

Preserve the existing attention source, moving/outside names, ant bodies and art, props, beds, walkability, water/routes, drag/gravity, perspective, real identities/settings, task/progress, audio/motion and audience boundaries. Soil, woodland, pines, sprint-tree artwork, fullscreen, website styling and the plugin icon are outside this narrow source allocation.

The selected-world private ledger distinguishes prepared artifact, local deployment, verified status and any separately held hosted destination. A known local deployment is not an all-surfaces result; a source push/archive is not a cloud deployment. The 0.2.6 visual failure remains open under the same original task until its corrected outcome is demonstrated.

### Current 0.2.7 / World 1.1.4 source correction

Match the latest room-name reference with compact bold white/soft-white pixel-like native text centered at each own room upper rim, equal per-kind visible metrics across roles, restrained soil-readable shadow and no dark plaque or long-label shrinking. Preserve full accessible names, single-line ellipsis, current hit targets, one selected-room inspector and compatible room/route/custom-world contracts. The exact font family is unknown from the raster; record the actual matching licensed font chosen rather than claim an unverified family or numerical recipe is exact.

The same bounded source correction carries faithful selected near/far pines and complete woodland layering, a coherent six-state broadleaf sprint tree at the existing foreground-left root, and soil-material continuity. Preserve authored alpha/frame/pivot/grounding, all day/night/weather/season/motion behavior, navigation and existing canonical progress; water, time and art changes earn no credit. The art references provide no example native identities, staged progress or screenshot-chat content to import.

The 0.2.7 source/packet is sealed and privately published. One bounded preview observed the core room lettering, woodland/tree artwork, visible agents and pause/resume behavior with a scoped PASS. Preserve that evidence at its actual scope; it is not human approval, a forced check of all six growth states, all-surface acceptance or a complete plugin PASS.

The narrow 0.2.8 compatibility candidate addresses the snapshot filter rejecting the selected sprites.json, art-provenance.json and room-names.LICENSE.txt. Its scope allows only the named immutable artwork metadata and bounded asset legal notices within the existing permitted roots, while preserving private-path, traversal, link, size, context, revision and idempotence guards. Retain all 36 selected world files, including the font and its complete license; do not strip notices or bypass the supported writer. The renderer, artwork and W49 rules remain unchanged. Artifact preparation has not been attempted for this correction. After the complete exact candidate is ready, run only the focused metadata/license acceptance and private-file refusal regression plus the required package checks; reuse the unchanged bounded visual evidence. This record grants no installation, runtime/hosting cutover or native title effect; the release owner records those separately.

An actual human visual failure reopens the original criteria even when provider deployment and direct asset hashes passed. Preserve those valid receipts and the last deployed version; record the failed acceptance and keep the verified version unknown. Qualify the actual outer-page/frame/module-or-bundle/CSS/world-data/theme path before attributing the failure to cache or claiming a visible fix. A later correction uses a new authorized version/effect and preserves the prior artifact; it does not relabel or overwrite the failed iteration. See the owning [delivery procedure](OPERATIONS.md#world-releases-and-site-updates).

## Same-version placement evidence

Matching version labels and served files are supporting evidence. Record the actual selected world/artifact/profile/mode, safe keyed placement inputs, measured canvas/DPR and comparison phase. Reproducible initial anchors and opaque local/public visual keys must agree without exposing task/native identities; public aliases do not become a different layout seed. A frame budget that changes room packing must be distinguished from stale source. Source diagnostics are not observed browser bounds, and independently changed interaction history or real snapshots must not be forced into fake synchronization. The actual runtime owner verifies live producer reloads when projection code changes. Preserve earlier human proof at its real hosting revision and scope; a new wrapper revision is a new observation, even when the world artifact stays the same.

## Numeric versions and display

| Change | Example canonical version | World owner display |
| --- | --- | --- |
| Initial definition | 1.0.0 | World 1.0 |
| Compatible fix | 1.0.1 | World 1.0.1 |
| Compatible feature | 1.1.0 | World 1.1 |
| Breaking contract | 2.0.0 | World 2.0 |

Compare numeric components, not text order. The release owner reserves world/plugin versions before the next world source change. Display updates preserve the world-requests identity, home, work and settings and require actual supported native readback. Version text alone performs no rename.

## Recovery and rollback

Retain the exact old unversioned or numbered artifact/profile and verified hashes. A world artifact digest excludes mutable ledgers/receipts to avoid recursive identity; plugin packet fingerprints are independently qualified. Before a later requested rollback, resolve the concrete retained version and current project, inspect its diff/dependencies and preserve the current state. Restore only the selected world/design scope through its actual owner. Append the real file, runtime and each hosted result; a local restore does not prove a website changed. Preserve earlier history, unknown effects and all unrelated user work.

Never put private paths, site IDs/URLs, native identities, credentials, live project plans or copied task history in this portable record. Detailed evidence and actual surface mapping remain in the selected project private ledger/operator receipts.

## Shared base ant scale source update

Plugin 0.3.2 carries the World 1.3.1 renderer source correction: one common base drawing multiplier increases from 1.25 to 1.5 while preserving the observed-model relative size, palette, trails and unknown fallback. Its diagnostic uses the same constant. The paired production and inline renderer inputs and pinned asset manifest remain aligned. The owning appearance.base-ant-scale rule and generated world exports describe the visual-only change; existing context/layout modifiers, grounding helper, interaction/navigation, native settings, motion/audio and custom-world boundaries remain. See [Visuals](VISUALS.md#shared-base-ant-scale).

This row describes qualified source and a reproducible renderer reference, not an automatic update to another saved world or installed copy. Selected-world preparation, actual per-site deployment, native display naming and human visual acceptance retain their independent private receipts. The new-world definition stays neutral 1.0.0.

## Ground world-version engraving source update

Plugin 0.3.4 carries the World 1.3.2 source update: the default woodland paints its actual selected or served world release into the bottom-center dirt beneath room floors, footprints and ants. Existing validated owner context or a ready project-sourced profile supplies the value; unknown identity clears it, with no renderer, plugin, build, Website or planned-version fallback. The former in-world combined badge is removed; the independent Website record remains outside the world in the Site footer. Art, real identities/settings, layout, navigation, hit regions, audio and motion remain unchanged. See [Visuals](VISUALS.md#world-version-engraved-into-dirt).

Focused painter/context evidence, compiled viewport dependency validation, affected owner-site integration and preview pin checks qualify the source. Browser readability and human visual acceptance remain unconfirmed. This source record and reproducible reference do not update an installed packet, another saved world or any public surface; actual preparation and authorized local/private delivery retain separate private receipts. Earlier releases and recovery stay preserved.


## Qualified source candidate: World 1.3.7

Plugin 0.4.7 carries the ready-only owner frame protocol, actual artwork/font readiness and bounded cosmetic transfer. The selected woodland keeps blue shoreline water, compact two-row Epic/Sprint sign and contact shadows; the later approved top-contour 14px room-name plaques retain full-name hover and truthful text actions. Custom art, actual activity, original progress and human settings remain authoritative. The candidate has a complete exact-byte scene inventory preserved across Git exports. Immutable World preparation, selector changes, local/private deployment and human visual acceptance require their own actual private receipts; this source record does not claim any of those effects.

## Qualified source candidate: World 1.3.9

Plugin0.4.9 adds the reconciled role-room props on the current0.4.8 performance source. The new immutable candidate uses World1.3.9/colony-world139; intermediate upstream compatibility1.3.8 was not selected in the maintainer destination. No actual selected-world or native-title version is inferred from that source allocation. Preserve each destination selected label layout, custom art, real activity, prior resources and human settings. Exact artifact preparation, profile selection, local/private publication and human visual acceptance retain separate receipts.

### Bundled renderer 1.3.10 / plugin 0.4.10

The default renderer retains role-specific room props from 1.3.9, labels the blue ant aura as 1.5× movement speed, replaces the old decorative heading with ALife World, and makes sky clouds 35% taller and more opaque without adding cloud instances. These default changes do not overwrite an existing custom world's scene. The renderer compatibility descriptor and actual selected-world release remain separate. This portable row claims no selected-world deployment or physical frame-rate acceptance.

### Bundled optional presentation 1.3.11 / plugin 0.4.15

The current 1.3.10 default renderer receives only the World-owned reversible contextual Director-request operations; its newer clouds, heading and accepted rendering behavior are preserved. Both aliases have exact renderer SHA-256 8633b86273f1e104b047dabd837607d6a4701233f5e458b9452e132fc2bb965f. The default compatibility artifact is 8eaf71cbfe8865e36e979499c28586e28ba7549147b785e46966b51c872c74c9, with the raw source inventory pinned in the manifest. The optional facade is absent by default, so packaging grants no native send authority. Three affected current-base component groups and syntax passed; the exact-byte reverse proof preserves the original source.

This neutral portable compatibility identity does not select any destination world. The active custom 1.3.9 and separately prepared custom 1.3.10 retain their own complete inventories, profiles and receipts. No generic default art is copied into them, and no Wake Up activation or native title/selector change accompanies this release.
