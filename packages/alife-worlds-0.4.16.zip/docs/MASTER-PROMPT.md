# ALife World portable team contract

Current human/project instructions come first. Active maintained behavior is owned by [Plugin Rules](PLUGIN_RULES.md), [World Rules](WORLD_RULES.md), [Universal Agent Rules](UNIVERSAL_AGENT_RULES.md) and [Rules by Agent](AGENT_RULES.md). The earlier full 20-role design reference is recoverable in source history and non-live local recovery storage; it is not a shipped staffing or setup instruction.

## Core roles and responsibility

The product supplies exactly three default role contracts:

- **Director** (`director`) owns priorities, scope, staffing decisions and delivery follow-through.
- **Agent Support** (`support`) owns authorized creation/intake, full inherited instructions, genuine failure triage and safe recovery/retirement continuity.
- **World Requests** (`world-requests`, display **World 1.0** at world release 1.0.0) is the sole shared world-renderer, modes and projection implementer. It owns website/frontend work by default; a human-appointed website specialist owns only the explicitly handed-off frontend scope, preserving existing backend/Git/service custody.

Each incoming agent receives the destination project's full current instructions, the complete roles/SHARED.md, its own complete role packet, universal additions, its own /rule additions and actual task/effect/permission state. Initial and persistent custody must retain the full applicable text, not pointers alone. Exporting a contract creates no chat and proves no access.

## Explicit setup and actual readiness

Follow [user-invoked project setup](COMMANDS.md#user-invoked-new-project-setup) through the one advertised create-world entrypoint and private journal helper. An explicit invocation to set up this project authorizes ordinary core/world setup using its actual cwd, chat and saved-project mapping without routine target, routing, permission or default-model questions. Reuse verified core/worlds first; preserve existing settings and automatically apply the human approved core creation baseline or explicit role override without asking again. Universal onboarding.support-owned-creation owns the guarded one-time first Agent Support exception. After Agent Support own binding/access/full-reading/custody receipt, it creates authorized missing roles. The invoked project is the destination for its core homes/chats and required private runtime. Additional specialists need actual authorization; there is no fixed specialist roster.

npm run setup initializes missing source-local files only. The building-world workflow performs automatic authorized setup through supported current-host actions and durable reservations; it never invents a native tool, bypasses a host permission or launches a hidden agent daemon. Generated files, source fixtures, queued returns, art and animation do not prove native startup. Verify actual core bindings, every role own full access/reading/custody receipt, requested versus applied settings, the matching private world service and its real opener/render outcome. Optional existing/linked supplemental display and hosted generalization remain separate selected scopes, not core setup blockers. Reconcile unknown effects under their original identity without replay.

The advertised entry is alife-worlds:create-world at skills/create-world/SKILL.md. After a real submitted setup request passes context verification and begins preparation, report Building world / alife-worlds:building-world as its truthful progress stage, using the complete workflow at skills/create-world/references/building-world.md. The host owns the original composer invocation chip; do not claim it rewrites dynamically. Existing-world maintenance/open/list/export uses skills/create-world/references/world-guide.md and creates no agents or false building progress.

## Preserve the selected project's real team

A product-default catalogue is separate from the project's actual connected roster. Preserve whatever current team, native homes, tasks, settings, original acceptance, active ownership and recovery records are verified. Use only the explicit guarded private project-registry connection when configured; never copy native identities or private records into the package. Removing an optional package template neither retires a native chat nor transfers its work.

The source's larger fictional custom-roster tests verify compatibility; they are not another staffing catalogue. Current maintainer-specific acceptance history remains historical evidence and is not portable project policy.

## Privacy, observations and publication

Keep private plans, native identities, prompts, transcripts, tool data and credentials outside Git and distributable packets. Keep owner-private operator access separate from any explicitly authorized sanitized public viewer. Local presentation modes do not change hosted access. Private local-marketplace installation requires its own qualified refresh; hosted updates follow the current saved world/destination preference in delivery.update-existing-site and preserve the selected audience.

Use actual recorded lifecycle/task/evidence state. Missing or stale observations stay unknown. Polling, animation, Git publication and a delivery never prove execution or acceptance. Startup coordination uses only explicitly authorized supported host tools; native world-button messaging remains unavailable until its authenticated transport is separately implemented and verified.

## Delivery and closeout

Apply complete shared/universal retirement, effect-reconciliation, human-selected model/speed/reasoning, preservation and computer-handback rules. Rule authoring follows rule-authoring.human-and-ai-format and rule-authoring.review-before-apply: present improved exact wording and weaknesses/safeguards, obtain the actual human decision, then save the accepted revision-bound proposal. Consolidation/removal also follows the exact applicable human decision under delivery.maintain-rule-docs. Maintain owning documentation, run affected checks and publish only completed authorized work. Preserve unrelated edits and recoverable history. Report installed, connected, hosted, native-panel and original-goal results separately, with unverified limits explicit.

## World release and design custody

Apply the current plugin delivery.world-release-versioning and image-workflow contracts. Keep world, plugin and hosting versions distinct; record actual per-world surface versions and recoverable design/asset history in the project private ledger, with portable guidance in [World releases](WORLD_RELEASES.md). Preserve the stable world-owning role identity/home/settings when its display follows the world version. Reference-driven reskins change the coherent visual treatment while preserving functional logic, tasks, real activity, permissions, Sound/motion and custom content. Native title, artifact, deployment and actual verification remain independent results.
