> Historical initial inventory: some entries were selected/restored afterward. Use [STEP4_RULE_REVIEW.md](STEP4_RULE_REVIEW.md) for the current pinned review and unselected choices. Old totals are not current missing-feature counts.

# Visual and site rules comparison

> Read-only comparison: findings do not activate a rule. [Plugin Rules](PLUGIN_RULES.md) and [World Rules](WORLD_RULES.md) show the current maintained registries. An older candidate needs the human’s concrete selection before import.


Requested on 5 November 2026. This is an inventory/comparison, not an instruction to import old rules. The human’s requested dashboard ordering is implemented from current source; no deprecated plugin code, rules, hooks, settings or assets were imported. Preserve the human-selected model, speed and reasoning; historical reference execution-policy text is not current authorization.

## Reference and scope

The most recent preserved authoring reference reports **0.14.41** and owns the topic manuals for views, identity, phone, world art, pixel detail, routines, design, activity and connections, plus the generated world-design contract. The separate deprecated GitHub checkout reports **0.14.33** and has a monolithic PRODUCT_RULES.md. They are not byte-equivalent: for example Public Progress controls and later phone/site rules occur in the newer authoring manual. The table uses the newer authoring contract and calls out current differences; it does not silently blend the two versions or claim that old documentation proves old runtime acceptance.

This covers every visual/site rule group found in those owning topic contracts, including related feed, privacy, interaction, sound, phone and website-connection requirements. Agent staffing, Git delivery and nonvisual governance rules are outside this visual/site checklist.

**Included** means current source implements the rule group; **Partial** means only some details match; **Different** means current behavior conflicts or the human now chose another presentation; **Missing** means absent; **Deferred** means an optional/later integration is not active for this local dashboard; **Unverified** is an actual acceptance limit. Included is a source finding, not blanket browser, physical-phone or listening acceptance.

Current owning code: [ALife World engine](../web/agent-outpost/agent-outpost.js), [dashboard](../web/app.mjs), [progress/handoff view model](../web/dashboard-model.mjs), [projection](../lib/projection.mjs), [native adapter](../adapters/native-session-adapter.mjs), [server boundary](../server.mjs), [visual contract](VISUALS.md) and [integration contract](INTEGRATION.md).

## Totals

87 rule groups: 30 partial, 9 missing, 10 different, 29 included, 8 deferred, 1 unverified.

## World appearance

| # | Old visual/site rule | Current status | Evidence or remaining gap |
| --- | --- | --- | --- |
| 1 | Sharp brown pixel colony; sandstone/deep-brown soil, sage, brass, blue water and warm light | **Partial** | Current procedural canvas has a related soil/sand/water palette; it is not the old sharp pixel renderer. |
| 2 | Oak/spruce/birch, bushes, moon, sun, clouds and insect sprite atlases; hard alpha and nearest-neighbor sampling | **Missing** | Current optional PNG concepts are not the old live sprite/atlas system. |
| 3 | Three mountain planes, three cloud depths, pixel woodland, foreground occlusion, rooted trunks and moving canopies | **Partial** | Decorative exterior/weather exists; the exact old layered pixel/parallax composition is absent. |
| 4 | Day, sunset, night, seasons, rain, leaves, fireflies and night room/entrance lamp pools | **Partial** | Current outdoorEnvironment and scenery provide cycles/effects; exact pixel layers and lamp treatment differ. |
| 5 | Small shallow carved rooms blended into soil, overhead main-room furniture and no pasted floor/rim | **Different** | sceneRoomEnvelope/sceneDrawRoom use front-facing wall/floor rooms, following this clone’s existing contract. |
| 6 | Clear entrance shaft; ground contact and consistent camera/scale/contact/shadows | **Partial** | Hill/shaft and grounded route functions exist; the old assembled pixel perspective has not been adopted or visually qualified here. |
| 7 | One cute 64x64 pupil-eyed ALife Agent body with moving antennae; roles do not replace it or add costumes | **Different** | Current drawAnt and sceneCostume retain distinct role costumes. |
| 8 | Six articulated legs; distance-driven tripod gait; overhead underground and side-view outdoors | **Included** | walkingLegs, sideWalkingLegs and antPerspective are retained and covered by source tests. |
| 9 | Smooth diagonal/head facing, planted stance/recovery, fixed-length human knees and heel/toe roll | **Partial** | Distance gait, heading and human motion exist; exact old pixel-frame/head/foot treatment is not qualified. |
| 10 | Director has two large monitors | **Different** | sceneDrawRoom and sceneState currently specify three monitors. |
| 11 | Support has a first-responder clinic/garage, medical cross, alarms and no task tree | **Partial** | Medical props/alarm behavior exists; stationHasTree still gives Support a tree. |
| 12 | World Requests has a smaller sand-engraved name and readable plaque | **Partial** | The real World Requests plaque exists; the old smaller engraved treatment is absent. |
| 13 | Model-derived full-body colors, distinct model glyphs, actual effort labels and size scales | **Included** | modelIdentity/modelColor/modelTrailStyle/effortScale consume observed metadata; unavailable remains unknown. |
| 14 | Known non-default model gets a subtle model-colored aura; only observed faster tier gets denser speed marks | **Partial** | Actual-tier trails/fast aura exist; the old independent non-default-model aura rule is different. |
| 15 | Retirement ghost only for a genuine retirement alert; no work/cargo/trails or native replacement from the ghost | **Included** | Retirement Needed is driven by retained alert data, with a pale ghost; drawings have no native authority. |

## Movement, supplies and interaction

| # | Old visual/site rule | Current status | Evidence or remaining gap |
| --- | --- | --- | --- |
| 16 | Working is separate from task ownership/stage; no polling, tokens, decoration or time creates progress | **Included** | Exact-bound lifecycle health and evidence-based tasks remain separate. |
| 17 | Idle is awake; Sleeping requires explicit safe sleep, gray body/outfit, tucked rest pose and Zs | **Different** | Current native terminal Idle is rendered Sleeping; there is no explicit safe-sleep activity state. |
| 18 | Waiting, Blocked, Error, Paused and retirement remain distinct; clearing a blocker does not invent work | **Partial** | Current projection separates several states/blockers, but its native abort/error/state vocabulary differs from the old resolver. |
| 19 | Fresh own-work repeatedly alternates gestures and water/grass/mined-material trips to its own room | **Partial** | Water and grass/work routines exist; mined-material collection is absent. |
| 20 | Mail takes priority for sender and receiver, cancels supplies/releases reservations, then resumes only if fresh | **Partial** | Current addressed deliveries take priority; exact immediate two-sided cancellation/release semantics are not established. |
| 21 | Real Support incidents drive alarms; assigned recovery uses ambulance, assigned blocker help fire engine | **Included** | supportAlarmState and assigned response routines require genuine facts; unavailable assistance remains inactive. |
| 22 | No invented pickups, arrivals or motion through unreachable routes | **Included** | routePath/routeWithHill retain safe waiting and valid geometry; current routing tests remain passing. |
| 23 | Couriers visit sender pickup and current recipient; queue at most32, active at most5; one sender courier | **Included** | Retained bounded queue/pump and addressed courier route/replan logic. |
| 24 | Stable event IDs, first-load baseline and unchanged polls prevent replay; arrival never sends/accepts work | **Included** | changes/sequence and current transfer projection retain original event IDs and timestamps. |
| 25 | Opaque rocks/gems use shared drawing/hit geometry, take2–8 hits and show cracks, chips and strength | **Missing** | Current blocked-task repair rocks are not the old decorative mining system. |
| 26 | Mined drops can be reserved/collected, grass regrows, unavailable supplies fall back to water | **Partial** | Current grass/water routines exist; mining drops and their reservation/fallback system do not. |
| 27 | Routes avoid solid minerals/unrelated rooms, use intentional entrances, and decorations avoid live paths | **Partial** | Room/prop avoidance exists; mineral navigation and decoration-placement rules are absent. |
| 28 | Actual footfalls immediately carve fixed-width grains, sampled every3 pixels, including inside rooms | **Partial** | Current footprint raster is actual-travel driven, but uses its own6px/non-pixel treatment. |
| 29 | Repeated traffic strengthens without widening; preserve wear on resize; clear on refresh/project/style | **Included** | Fixed-width accumulated footprints and resize persistence are retained. |
| 30 | Idle/click/drag/fall/teleport/outdoor grass/paused frames do not carve trails | **Included** | Footprint and relocation guards separate actual underground steps from local interaction. |
| 31 | Model glyph trails fade separately from lasting sand wear | **Included** | Current modelTrailStyle/updateFastTrail remain separate from footprint raster. |
| 32 | Pointer capture, hop, drag/drop gravity and Escape/cancel/lost-capture/blur safety on touch and mouse | **Included** | Retained canvas pointer handlers, endAntDrag and outdoor drop/return physics. |
| 33 | Press plaque or room pocket to open focus; ALife Agent click hops without opening the room | **Partial** | Plaques and ALife Agent hop/inspector behavior exist; old room-pocket click behavior is not fully matched. |
| 34 | Focused room reads the same live actor each frame and shows no duplicate when it leaves | **Included** | drawRoomLens reads agentPosition and draws only when antInsideRoom is true. |
| 35 | Focused room has opaque sand, no hill/plaques/mountain, current state/summary/model, reachable Close/Escape | **Partial** | Current lens isolates the live room and supports closing; exact old side-view summary/model layout differs. |
| 36 | Tree taps/leaves, mineral chips, water rings, reactive insects and background-only fleeing legs | **Partial** | Current scenery feedback/ripples/leg reactions exist; old pixel/mining/atlas effects differ. |
| 37 | Delivery sand puffs are decorative; bottom completion mountain graph is removed | **Different** | Current ALife World retains the completion-sand chamber/mountain; old local puff-only presentation is not adopted. |

## Truth, progress and feed

| # | Old visual/site rule | Current status | Evidence or remaining gap |
| --- | --- | --- | --- |
| 38 | Checked steps plus explicit evidenced acceptance own progress;100% requires all scoped tasks accepted | **Included** | Existing gardenCredits remains the single credit engine; dashboardProgress reuses it for selected sprint and full epic. |
| 39 | Current sprint stays separate from full roadmap; future work cannot inflate current execution/progress | **Included** | inCurrentSprint, selected-sprint ALife World scoping and separate sprint/epic meters are tested. |
| 40 | Every plaque/room/count/motion uses one shared blocker/current-task/activity resolver | **Partial** | Current AgentOutpost projection is consistent internally; it is not the old farmState snapshot contract and semantics. |
| 41 | Freshness: self-reports120s, one-second visible refresh,8s transport timeout,25s feed expiry | **Partial** | Current native work expires after120s; browser refresh remains5s and stale feed expiry120s, without the old8s/25s controller. |
| 42 | Stale/missing/future evidence cannot renew Working; retain last-success data honestly | **Included** | Native lifecycle timestamps are not refreshed by polling; missing/stale work becomes unavailable. |
| 43 | Safe last-known Sleeping can retain a labeled Unconfirmed pose without action freshness | **Missing** | Current schema has terminal Idle, not the old explicit safe-sleep/lastRestSafe fields. |
| 44 | Mode/project switching rejects obsolete replies; reset camera only on real project change | **Deferred** | This dashboard has one selected local project and no multi-world selection controller. |
| 45 | Known queued Wake preparation is bounded and earns no work/progress; unknown/refused starts none | **Deferred** | Retained gateway/routines are dormant; native command transport is intentionally disabled. |
| 46 | Newest-first bounded current observations/handoffs use recorded source timestamps, no generated summaries | **Included** | New current-task cards and recentHandoffs display sanitized recorded transfers; no native transcript is decoded into summaries. |
| 47 | Numeric metrics are sourced and expire; absent FPS/resources/analytics stay n/a | **Included** | telemetryView/currentPiperAnalytics retain expiry/source guards; they do not invent missing live producers. |

## Site layout and controls

| # | Old visual/site rule | Current status | Evidence or remaining gap |
| --- | --- | --- | --- |
| 48 | World first; canonical current work/planning below; normal wheel scrolling reaches details | **Included** | Requested order is now world → sprint board → tasks/transfers → responsibilities → folded epic/sprints. |
| 49 | Project title is a dropdown with Show all last | **Missing** | Current site is intentionally a single-project dashboard; ALife World title is not the old project selector. |
| 50 | Show all uses saved-style live planet previews, scattered depth/stars/comets and centered single planet | **Missing** | No multi-world overview is implemented in the current source. |
| 51 | Upper-right Public/Private/View, Pause, Progress and Sound controls | **Partial** | Pause/Sound and remembered Private toggle exist; View and the old unified mode/progress toolbar do not. |
| 52 | No settings, room chooser, separate Room button or magnifier | **Different** | Current ALife World retains a magnifier and its own accessible inspector controls. |
| 53 | Compact plaque with accessible state/last-report tooltip, full name and separate action target | **Partial** | Current plaques preserve full native text/status, but their wrapping/status/target treatment differs. |
| 54 | Team details starts collapsed; no surrounding dashboard frame | **Different** | The human now explicitly requested the responsibilities/task dashboard; old world-only framing is not selected. |
| 55 | Public shows project goal, epic/sprint progress and task/check details below the world | **Included** | Current dashboard shows these canonical fields; folded plan has visible sprint/epic progress in its header. |
| 56 | Progress on/off control beside Sound and compact pixel sprint meter; no bottom percent/Fit toolbar | **Partial** | New header meters/folded plan satisfy the requested progress visibility, not the old toolbar/pixel-meter arrangement. |
| 57 | Private/View fit one screen and remove operational sections rather than keeping masked scroll space | **Different** | Current remembered privacy masks preserve section space and document scrolling. |
| 58 | View disables plaques, mining, drag, hop and other world interactions | **Missing** | No View mode exists in the current dashboard. |
| 59 | Private keeps the real project display name | **Different** | Current private browser/world title remains Department of Beautiful Chaos. |
| 60 | Current task/blocker/QA/next-step details stay readable, with status text rather than color alone | **Included** | New task cards expose current/next and fold steps/acceptance; board cards show titles and owners. |
| 61 | Reference status palette: green progress, blue backlog, orange blocked, lavender idle, pale-green accepted | **Partial** | Textual stages and existing theme colors exist; the five old reference colors are not applied uniformly in the new board. |

## Phone, identity and customization

| # | Old visual/site rule | Current status | Evidence or remaining gap |
| --- | --- | --- | --- |
| 62 | Deliberate portrait/full-height composition, safe areas, readable touch controls and separate landscape fit | **Partial** | Current responsive fit/name sizing exists; the old safe-area/full-height phone camera composition is not adopted. |
| 63 | 100–300% camera zoom/pan with shared canvas/plaque transform; native browser text/pinch zoom stays enabled | **Partial** | Browser zoom/drag and the magnifier exist; the old dedicated camera/zoom controller is absent. |
| 64 | Physical phone and native-panel checks are independent of simulated widths | **Unverified** | Source layout tests cover widths; this pass does not establish physical-phone or native-panel acceptance. |
| 65 | White ALife World text; readable contrast and available licensed UI fonts | **Included** | Current ALife World enforces white text and uses local/system fallbacks. |
| 66 | Bundled Inter headings and Pixelify Sans labels; no remote font/image request | **Partial** | No remote runtime font request is needed; the old bundled font pairing is not installed in this foundation. |
| 67 | Pixel planet listing/composer identity plus monochrome Open ALife World sidebar/MCP icon | **Deferred** | Current README branding exists; an installable replacement plugin/MCP entrypoint is a later packet-qualification stage. |
| 68 | Inspect real image references, make original licensed art, preserve explicit camera/style and verify assembled motion | **Partial** | This is an existing procedural world; the reference-led asset/custom-world creation workflow is not implemented as a connected product feature. |
| 69 | Saved custom palette/layout/actors/art/labels/trails and separate default overrides survive updates; reset reveals newest default | **Missing** | No equivalent multi-project DEFAULT_WORLD/custom-override upgrade/reset pipeline exists here. |

## Sound and suppression

| # | Old visual/site rule | Current status | Evidence or remaining gap |
| --- | --- | --- | --- |
| 70 | Every load starts muted; only the single Sound control enables audio | **Included** | Current AudioContext/gain toggle remains opt-in and independent of privacy/drag/wake. |
| 71 | All audible samples are bundled CC0 Freesound with author/source/license manifest | **Missing** | Current audio is procedural/synthesized, not the old Freesound sample package. |
| 72 | Lo-fi music24%, rain16%, sand/water/grass/mining/insect/UI samples | **Missing** | The old music/rain/sample channels are not present. |
| 73 | Decode once, spatial panning, short envelopes,75ms trigger cap and six-source limit | **Partial** | Current short filtered/panned cues have their own roughly65ms cap; the old decoded-sample/six-source pipeline is absent. |
| 74 | Mute immediately silences every channel; late resume/decode/play cannot undo newer mute/teardown | **Partial** | Current master gain mutes immediately; old asynchronous music/rain/decode race guarantees are not applicable or independently qualified. |
| 75 | Pause, hidden page and reduced motion freeze autonomous motion/effects/audio while factual state may refresh | **Included** | Retained stopped/visibility/reduced-motion and audio guards remain active. |
| 76 | No replay of old completion pours/sounds; listening quality is separate from transport tests | **Included** | Stable credit/event baselines prevent replay; this pass makes no physical-listening claim. |

## Privacy, connection and hosted-site boundaries

| # | Old visual/site rule | Current status | Evidence or remaining gap |
| --- | --- | --- | --- |
| 77 | Display modes do not change website audience or create publication | **Included** | Current controls are local presentation; no hosting/audience operation is exposed. |
| 78 | Private/View server payload aliases identities and strips native IDs, paths, task/message prose and private config | **Partial** | Current loopback projection excludes runtime roots/secrets but includes native IDs; Private is a presentation mask, not the old alias-filtered endpoint. |
| 79 | No prompts/reasoning/tool arguments/results/transcripts/secrets in public data; no model calls from viewing | **Included** | Current output projection is allowlisted and the browser only reads local state; native command transport stays off. |
| 80 | Metadata scanner skips decoding private bodies, not merely excluding them from output | **Different** | Current adapter JSON-parses bounded complete rows, then retains only allowlisted scalars; it is not the old structural skip parser. |
| 81 | Native actions require connected public host/current owner/task/freshness/real receipts and preserve Unknown | **Deferred** | Gateway guards have isolated tests, but production transport is deliberately disabled; open-chat protocol launch was browser-blocked. |
| 82 | Read-only website cannot execute native Wake/Retire or alter tasks; no mutation endpoint by page views | **Included** | nativeReadOnly blocks connector loading and transport, including accidentally supplied enable flags. |
| 83 | Homepage iframe is ALife World-only; public /watch is separate from authenticated owner /world | **Deferred** | Confirmed target is the existing local loopback dashboard; hosted routes/embed are not configured or imported. |
| 84 | Hosted Public text requires owner opt-in; Private/View stripping is enforced server-side | **Deferred** | No hosted viewer/publisher or Public-details publication boundary is active here. |
| 85 | 401/403/sign-in redirects produce accessible recovery notice and same-site sign-in/check access | **Deferred** | Current target has no hosted authentication flow. |
| 86 | Reuse one project-scoped authorized publisher, preserve audience/credentials, bounded retry/keepalive and25s offline truth | **Deferred** | There is no hosted relay/reconnection service in this current-source foundation. |
| 87 | Separate source/planning from unchanged native workspace; never copy homes/IDs or reset to repair connection | **Included** | New explicit nativeWorkspaceRoot plus source planningRoot keep the same20 identities/cwd/receipts. |

## Current human-selected UX

World first; current sprint board; up-to-date selected-sprint task cards and original recorded transfers; agent logic/responsibilities; then a collapsible epic/sprint plan with current-sprint and full-epic progress visible in the closed header. Future tasks remain outside current execution. No transfer event is inferred from animation or transcript content. Empty recorded traffic is shown honestly.

No additional rule in this comparison was adopted automatically. Source/API checks and actual browser acceptance are recorded separately in the existing coordination evidence.

## Later human-selected restoration

The original classifications above are the pre-restoration comparison baseline. The human subsequently selected the rescue/retirement, awake Idle/Sleeping, blocker fire, mining/cursor/SFX, own-work resources, obstacle awareness, room-local inspector, M-envelope, diagonal gait, observed-speed trail and dangling/distance-aware drag topics. Their active wording now belongs to World Rules, not a copied older prompt. The selected implementation and checks are described in Visuals and Integration. This selection imports no unrelated older feature or execution setting. Native Wake Up task search remains unavailable under the existing connection hold.

## Current selected restoration checkpoint

The original87-group table above is the read-only comparison baseline, not a blanket import. The current human-selected World Rules take precedence: decorative minerals are2–8hits; CLINIC lettering, magnifier and bottom sand piles are removed; idle/sleep/fire/recovery/mail/drag rules have source implementation and retained checks. The project-folder selector, real registered-world overview, one-screen Private/View, operational DOM removal, collapsed team, shared100–300% camera, leaves/dirt effects, muted local CC0 audio and default-world-only lofi now have source implementation. The existing public landing was separately accepted. Native task-command dispatch remains held; pointer Pan, physical-phone and listening acceptance remain distinct. See [current visual behavior](VISUALS.md) and the grouped [World Rules](WORLD_RULES.md) for current source/selection. No unselected old rule is activated by this checkpoint.
