> Selection update —6 November2026: the human selected **F01 sidebar world launcher** and **C04 new-project bootstrap rules**, then explicitly allowed Director a one-time first-missing-Support bootstrap. Support owns all further authorized creation after actual first-Support access/custody acknowledgement. Other candidates remain unselected. The full inventory below is the dated initial-review snapshot; current owning rules are [Plugin Rules](PLUGIN_RULES.md), [Universal Agent Rules](UNIVERSAL_AGENT_RULES.md) and [World Rules](WORLD_RULES.md). Selected rules do not prove native provisioning or launcher host acceptance.

# Step4: current rules and deprecated-plugin comparison

REFERENCE ONLY. Proposals below are not active instructions, approved imports, implementations or release authorization. The initial snapshot below records candidates before the later selections above. Current human corrections take priority.

Snapshot 2026-11-06T07:28:30.220Z. Current source HEAD b6749b37c7d58b1c117f95eb6231cf06cc8df61f plus saved authoring changes. Deprecated 0.14.41 reference a30378822a62912550992c782161a18fa0e615c0. No old rule/code was checked out or merged.

## What is currently installed and saved

Actual Codex UI: **Plugins → Installed → ALife Worlds**, version 0.1.0-foundation.1 at this review. One skill; no separate sidebar world app. F01 explains the missing entrypoint. A subsequent direct human request asks for a normal numbered release; version activation has separate evidence and cannot approve migration candidates.

Reviewed current source: **44 Plugin properties in 12 groups, revision15**; **68 World properties in 10 groups, revision28**. Installed review baseline: Plugin11/42 and World21/64. Full exact current registry text is below. Shared role contracts/manuals add execution instructions, so these are registry-property counts, not every instruction in the product.

Implementation labels are reproduced source declarations, not fresh independent acceptance. Saved, installed, local, hosted and physically tested states are separate. Recent local tree/key/input/art qualification does not install or publish those changes.

## Current command scopes and incoming-agent rules

Completed current-source command contract: /world changes represented world rules; /plugin changes plugin policy; /rule changes only the verified recipient agent role; /universal adds rules inherited by incoming agents and successors. The old /rule-means-plugin convention is superseded. Source authoring does not itself modify native identities, notify every current chat or create agents.

Universal revision1 has2 active additions; 0 role-specific addition catalogues. The existing 20 role packets still apply. Full shared/retirement contract and every role packet: [Universal Agent Rules](UNIVERSAL_AGENT_RULES.md), [Rules by Agent](AGENT_RULES.md), [Command guide](COMMANDS.md).

- **onboarding.support-owned-creation** [documented]: Route every new-agent request to the existing bound Agent Support. Support alone creates an authorized new agent or successor after verifying scope, reusable capacity and human-approved model/settings. A missing Support is an explicit dependency, not permission for another role to create agents.
- **onboarding.complete-inheritance** [documented]: Before launch, Agent Support includes the complete current shared and retirement contract, active universal additions, the selected role packet and that role own active rules, plus latest human/task/permission/effect custody. Preserve full persistent instructions and the current initial-prompt requirements; require the new agent actual exact-project/home access, complete reading and custody acknowledgement. A rule export creates no chat and /universal does not rewrite existing homes automatically.

This is newly human-selected current-source work, not an old-rule import. Support-only creation introduces an explicit first-Support bootstrap question in C04. Generic native creation is not implemented merely because command/contract assembly works.

## How to choose

Conflicting means the same property has incompatible values. Old-only/missing capability means an optional prior workflow or tool is absent. Partial means a current requirement exists but old detail or implementation differs. Complementary/context-dependent means the ideas can coexist with explicit triggers/audience/ownership. Duplicate/already-present needs no second policy copy. Obsolete means historical IDs/backend conventions. New-only identifies current selected rules without an exact old match.

Choose exact IDs: **keep new**, **adapt old**, **combine with specified contexts**, **defer**, or **drop old**. Example: C04 adapt; C05 combine; W04 keep new; F01 implement later. Policy selection does not automatically authorize copying old code, hooks, settings, assets, identities or data. Silence selects nothing.

## First decisions worth reviewing

| IDs | Topic | Current position / choice |
|---|---|---|
| P01/C01, P02/C02 | Model and speed | Your selected settings win. No old Standard reset or fixed Terra/Sol defaults. |
| P03 | Hosted publication | Your explicit publish-to-website gate wins; Git, installation, reconnect and hosted visual deployment are separate. |
| C04/C05/C07 | Generic3-core startup | Potential Director/Support/World Requests bootstrap and staffing intake; preserve current 20 agents. |
| W01 | Room perspective | Current front-facing registry versus latest approved overhead art; reconcile the single property. |
| W03/W04 | Ant representation | Family-size mapping versus old effort sizing; no-work sleep versus explicit safe sleep. |
| P19/P22/W09 | Contextual combinations | Separate updates from destructive reset; display modes from audience; private controls from view-only payloads. |
| F01 | Sidebar world app | Optional minimal current-world MCP launcher; no automatic old-tool import. |

## Current internal drift

- **I01 — Stale inherited Standard-only instructions:** No automatic Standard reset or upgrade. Explicit owner synchronization with recovery/readback is separate; do not edit existing homes in this comparison.
- **I02 — Installed/inherited automatic publication versus revision13:** The installed snapshot remains historical. Current COMMANDS/skill authoring was aligned to the explicit website publication gate during separately authorized command work; verify the installed refresh independently.
- **I03 — Latest private/public link instruction already covered:** Retain stable property IDs and distinct audiences; no duplicate rule, site creation or publication required.
- **I04 — Room registry versus latest selected art:** appearance.rooms still says front-facing while the latest selected muted art is top view. The qualified source records this known limit. See W01; no rule rewritten here.
- **I05 — Old manual comparison is historical:** The earlier87-row VISUAL_RULES_COMPARISON.md includes features since selected/restored. Its old totals are not current missing-feature counts.
- **I06 — Installed snapshot lags source:** Installed Plugin11/42 and World21/64 differ from the reviewed authoring input. The separate new human version-number request will receive its own qualified refresh; it does not select old rules.
- **I07 — Stale launcher hold wording:** launcher.open-worlds still mentions a connection/installation hold although the foundation is installed. Future refresh still requires qualification. Do not reinterpret stale wording as an instruction to disconnect.

The original installed snapshot contains old automatic-update guidance. Current command/skill authoring now expresses the explicit website publication gate; this current-source drift was corrected during the separately authorized command work. Some native homes retain historical Standard-only text; the human settings correction governs. This comparison rewrites neither active rules nor existing role homes.

## Already-covered shared contract

The new shared roles/manuals already require exact project/native custody, one task/acceptance store, one scoped owner, preserved original acceptance, focused checks, truthful effect/delivery receipts, protected user tools, full persistent inheritance/custody and authorized sequential succession with actual acknowledgement before archive. Generic native messaging, arbitrary-project provisioning and automatic staffing remain unavailable where owning docs say so. A role template is not a working tool.

## Plugin policy and workflow candidates

P and C views intentionally overlap; they are not additive imports or counts of unique atomic rules. Overlap: P01 ↔ C01; P02 ↔ C02; P33 ↔ C03; P08 ↔ C04; P10 ↔ C05; P09 ↔ C06; P11 ↔ C07; P12 ↔ C08; P07 ↔ C09; P29 ↔ C11; P04/P15 ↔ C12.

### P01 — Human-selected speed versus old Standard-only enforcement

**conflicting**. Old text makes Standard/default mandatory. The current direct human correction preserves the selected model, speed and effort and explicitly supersedes that baseline.

Current IDs: agent-settings.preserve-settings, agent-settings.approved-creation. Current policy exists; no running settings were probed or changed.

**Proposed choice:** Keep current human-selected settings. Never restore Standard-only enforcement or change settings when adopting another legacy workflow.

Current: docs/PLUGIN_RULES.md:16; docs/PLUGIN_RULES.md:17; AGENTS.md:33; docs/OPERATIONS.md:59. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L29), [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L8), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L188).

### P02 — Old fixed role models are not a creation baseline

**conflicting**. Old Terra-message/Sol-Extra-High defaults are historical selections and must not become settings for the new team.

Current IDs: agent-settings.approved-creation, agent-settings.observed-metadata. Desired defaults do not prove applied native metadata or switching capability.

**Proposed choice:** Use only the current human-approved role settings or explicit creation baseline; ask when missing. Never infer approval from old model names.

Current: docs/PLUGIN_RULES.md:17; docs/PLUGIN_RULES.md:18; AGENTS.md:33. Deprecated: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L142), [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L45).

### P03 — Explicit website publication versus automatic updates

**conflicting**. Authoring revision13 already records the human-selected explicit publish-to-website gate. Frozen revision11 and inherited source prose still say to update an authorized site after completed work. Old feed reconnection is distinct from deploying source.

Current IDs: delivery.sync-before-push, delivery.publish-completed-work, delivery.update-existing-site. Current/installed documentation drift; no permission to refresh, reconnect or deploy follows from this comparison.

**Proposed choice:** Keep the selected explicit publication gate. Align inherited delivery prose through its owner, distinguishing Git push, existing-feed reconnect, hosted deployment and installation.

Current: docs/PLUGIN_RULES.md:30; docs/PLUGIN_RULES.md:30; skills/alife-world/SKILL.md:44; docs/COMMANDS.md:22. Deprecated: [plugins/alife-worlds/skills/creating-world/references/web-view.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/web-view.md#L19), [plugins/alife-worlds/skills/creating-world/SKILL.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/SKILL.md#L46), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L232).

### P04 — Exact native privacy and truthful activity

**already-present**. Both prohibit private prompt/transcript access and work inferred from polling, animation, open chats or process liveness.

Current IDs: authority.exact-native-scope, authority.honest-results. Registry records implemented policy. No native probe or lifecycle acceptance was repeated.

**Proposed choice:** Keep the current single policy and exact project/chat/cwd checks; import no old bindings, reports or private data.

Current: docs/PLUGIN_RULES.md:11; docs/PLUGIN_RULES.md:10; AGENTS.md:25. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L5), [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L13).

### P05 — Optional independently versioned activity observer

**old-only**. The old product isolates a reviewed12-hook observer from changing art/UI. This optional component is not selected into the new foundation.

Current IDs: preservation.selected-imports, preservation.no-extra-effects. Old docs describe implementation and limits. No hook was executed, installed or trusted. The current hook-free reader is not a missing rule because this companion is absent.

**Proposed choice:** Only if separately selected, define immutable observer versions, human review of changed executable hooks and independent native acceptance. Preserve the hook-free default.

Current: docs/PLUGIN_RULES.md:23; docs/PLUGIN_RULES.md:24; AGENTS.md:29. Deprecated: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L104), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L112), [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L9).

### P06 — Canonical storage and reconnect continuity

**partial**. Current policy preserves one canonical plan, identities, exact private pairing and honest outages. The old marked-store reconciliation and persisted automatic reconnect workflow is more specific.

Current IDs: preservation.existing-custody, authority.canonical-records. Current operations explicitly say no autostart or persisted credential store is implemented; do not infer DPAPI/mutex reconnect from preservation guidance.

**Proposed choice:** Preserve exact store/project identity and overrides, reject ambiguity and reconcile before reconnect. Persisted automatic reconnect needs separate selection and credential/process custody.

Current: docs/PLUGIN_RULES.md:22; docs/PLUGIN_RULES.md:9; docs/OPERATIONS.md:70. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L11), [plugins/alife-worlds/shared/connection-rules.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/shared/connection-rules.mjs#L8).

### P07 — Synchronize rules to every existing recognized role

**partial**. Current full inheritance/readback covers onboarding and custody transfer. Old exact-home managed-block synchronization to all existing roles, with recoverable preimages, is a distinct workflow.

Current IDs: preservation.existing-custody, delivery.maintain-rule-docs. No existing home was synchronized. File delivery, native notification and actual acknowledgement are separate.

**Proposed choice:** After an explicitly authorized existing-team update, preview exact homes, preserve role text/recovery, refuse ambiguity/concurrent changes and distinguish saved delivery from actual readback. No automatic staffing or notices.

Current: roles/SHARED.md:3; AGENTS.md:21; docs/OPERATIONS.md:65; docs/PLUGIN_RULES.md:22. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L15), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L108), [plugins/alife-worlds/shared/connection-rules.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/shared/connection-rules.mjs#L12).

### P08 — Three-role startup versus preserved existing20

**partial**. Old startup provisions missing Director/Agent Support/World Requests. The new source marks that model as future scope and keeps this existing20-agent team intact.

Current IDs: preservation.no-extra-effects, preservation.existing-custody. Qualified automatic provisioning is absent; that feature gap is not approval to import setup code or restructure this team.

**Proposed choice:** For a later selected startup flow, reuse equivalent verified roles and create only authorized missing roles without moving homes/identities. Preserve the current20. Latest universal Support-only creation forbids the old Director bootstrap of missing Support. See C04; initial Support creation needs an explicit human choice.

Current: AGENTS.md:19; README.md:74; docs/PLUGIN_RULES.md:24. Deprecated: [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L6), [plugins/alife-worlds/skills/creating-world/references/connect-existing.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/connect-existing.md#L7).

### P09 — Folder-first Director title and real access confirmation

**old-only**. Old startup has an actual native Director rename/readback/confirmation transaction. Source/native custody separation does not implement that startup sequence.

Current IDs: . No title, native access receipt or chat was changed. Current source setup creates missing unconnected configuration only.

**Proposed choice:** If separately selected, verify actual project and existing Director; preserve identity, perform a required native rename/readback truthfully, then require exact-folder read/write and complete custody acknowledgement. The startup transaction is missing, but existing native homes must not move. A future new project may explicitly choose folder-first setup.

Current: AGENTS.md:7; AGENTS.md:21; skills/alife-world/SKILL.md:14. Deprecated: [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L3), [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L16).

### P10 — Single Agent Support staffing intake

**partial**. Latest universal onboarding.support-owned-creation already routes all staffing to bound Support. Old stable-request reservation/unknown-launch reconciliation adds optional implementation detail.

Current IDs: agent-settings.approved-creation, preservation.no-extra-effects. Ownership policy exists; old launch/intake tools are not current capabilities merely because the policy exists.

**Proposed choice:** Route authorized staffing to existing Support with the original request ID; reuse capacity, reconcile uncertain launches and finish only after actual access/full-rule acknowledgement.

Current: AGENTS.md:17; roles/SHARED.md:13; docs/PLUGIN_RULES.md:17. Deprecated: [plugins/alife-worlds/skills/creating-world/references/agent-intake.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/agent-intake.md#L3), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L170).

### P11 — Complete project-only roster and safe discovery

**partial**. Current source preserves configured bindings and explicit project registration. Old folder discovery, unverified-home state and recovery-tree exclusions are a separate capability.

Current IDs: authority.exact-native-scope, preservation.existing-custody. An explicit registry is not automatic scanning. Hiding never retires a role; current20 stay intact.

**Proposed choice:** If selected, discover bounded read-only project-owned candidates, exclude links/caches/recovery copies, verify native owners before connection and never execute discovered instructions or create replacements.

Current: docs/PLUGIN_RULES.md:11; docs/PLUGIN_RULES.md:22; AGENTS.md:19; docs/INTEGRATION.md:152. Deprecated: [plugins/alife-worlds/skills/creating-world/references/agent-intake.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/agent-intake.md#L11), [plugins/alife-worlds/shared/connection-rules.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/shared/connection-rules.mjs#L4).

### P12 — Full successor custody and truthful recovery

**already-present**. Both preserve full instructions, original tasks/checks/effects and one authorized successor with real custody acknowledgement before predecessor archive. Healthy waits/outages do not justify churn.

Current IDs: preservation.existing-custody. Policy present; no native retirement/transfer was executed or qualified.

**Proposed choice:** Keep the current contract. Reconcile unknown effects and never transfer old native identity, process registration, leases or grants.

Current: roles/SHARED.md:23; AGENTS.md:21; docs/PLUGIN_RULES.md:22. Deprecated: [plugins/alife-worlds/skills/creating-world/references/retirement.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/retirement.md#L3), [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L27).

### P13 — One revision-aware canonical ledger

**already-present**. Stable task/step IDs, original acceptance and version-aware canonical writes already exist as selected policy. Current private edits add a cooperative lock and final byte revision check.

Current IDs: authority.canonical-records. Owning docs record earlier edit acceptance; this audit did not rerun it.

**Proposed choice:** Retain one canonical ledger. Hosted snapshots are mirrors and queued intents are requests, never a second acceptance store.

Current: docs/PLUGIN_RULES.md:9; roles/SHARED.md:7; docs/INTEGRATION.md:175. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L21), [plugins/alife-worlds/shared/operating-rules.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/shared/operating-rules.mjs#L11).

### P14 — Focused checks and first whole-goal PASS

**already-present**. Current policy already distinguishes implementation, affected checks, authorized publication and actual candidate QA, returning one focused correction to the same owner and preserving companions.

Current IDs: authority.honest-results. Policy text establishes no new product/task PASS. No product tests repeated for this audit.

**Proposed choice:** Keep original checks and honest actual results; removed criteria are removed, not passed. Do not restore a blanket missing-evidence NOT TESTED phrase over the human correction.

Current: roles/SHARED.md:9; docs/OPERATIONS.md:37; docs/PLUGIN_RULES.md:10. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L23), [plugins/alife-worlds/shared/operating-rules.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/shared/operating-rules.mjs#L13).

### P15 — One interactive owner and protected authoring

**already-present**. User/reference state, unsaved tools/profiles and distinct persistence-test identities already have current protections and a bounded stop/return route.

Current IDs: preservation.existing-custody. Physical-window protection is a separate absent adapter; display privacy is not that protection.

**Proposed choice:** Retain current one-owner authority and protected-state rules. Old grants, board labels and planned actors never grant control.

Current: roles/SHARED.md:31; docs/PLUGIN_RULES.md:22; AGENTS.md:37. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L25).

### P16 — Stable effects and truthful delivery receipts

**already-present**. Both distinguish world events/queue receipts from real messages and preserve exact effect identities with no unknown replay.

Current IDs: links-and-access.private-messages, authority.disabled-native-transport. Private edit idempotency is documented as accepted; native messaging remains unavailable.

**Proposed choice:** Keep actor/project/request/body reconciliation and queued/delivered/failed/unknown states. A courier arrival or accepted intent never proves native delivery.

Current: roles/SHARED.md:13; docs/PLUGIN_RULES.md:79; docs/INTEGRATION.md:175. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L31), [plugins/alife-worlds/skills/creating-world/references/sprint-commands.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/sprint-commands.md#L9).

### P17 — Coalesced notifications and authorized follow-through

**complementary**. Current effects policy gates sends and unknown retries. Old detail adds coalesced notices, changed-evidence episodes and one existing authorized schedule rather than a watcher per role.

Current IDs: preservation.no-extra-effects. No message/reminder/schedule created. Optional workflow detail is not a runtime defect.

**Proposed choice:** If selected, coalesce by stable request/effect and use follow-through only under explicit authorization, keeping schedule/reminder scope and owner.

Current: roles/SHARED.md:13; docs/PLUGIN_RULES.md:24. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L31), [plugins/alife-worlds/shared/operating-rules.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/shared/operating-rules.mjs#L21).

### P18 — Epic and sprint command protocol

**old-only**. Canonical sprint planning exists. Old /new and command_request/save_epic/start_sprint conventions are not the new /world and /rule authoring workflow.

Current IDs: . Do not advertise old slash/MCP commands as installed features. No sprint changed.

**Proposed choice:** If selected later, require an explicit sprint goal, preserve history/current owners and original request IDs and keep planning distinct from staffing authority and actual acceptance.

Current: roles/SHARED.md:7; docs/COMMANDS.md:3; README.md:43. Deprecated: [plugins/alife-worlds/skills/creating-world/references/sprint-commands.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/sprint-commands.md#L3).

### P19 — Reset/delete is destructive and never an update

**context-dependent**. Old explicit reset/delete removes managed work/world/custom rules. Current upgrades preserve custom worlds/rules, and reconnecting must not invoke reset.

Current IDs: custom-worlds.preserve-worlds, custom-worlds.preserve-rules, preservation.existing-custody. No reset/delete tool imported or run. Destructive intent would be a separately reviewed scope.

**Proposed choice:** Keep updates non-destructive. Any later selected reset/delete requires explicit request, exact reviewed inventory, recovery and settled effects, protecting source/imported chats/history. Updates and reset/delete have different intent. Reset is an optional destructive workflow, not a reason to overwrite the non-destructive update rule.

Current: docs/PLUGIN_RULES.md:70; docs/PLUGIN_RULES.md:71; docs/PLUGIN_RULES.md:22; AGENTS.md:29. Deprecated: [plugins/alife-worlds/skills/creating-world/references/reset-project.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/reset-project.md#L3).

### P20 — Whole-team/world clone versus scope-only rule export

**partial**. New source already exports independent active plugin/world rules. Old full clone embeds a reviewed reusable roster/home/art/world inventory with hashes and destination reconstruction.

Current IDs: preservation.selected-imports. Rule export is not a full world/team clone. Old importer/validator/startup code is not selected.

**Proposed choice:** Preserve independent rule exports. If full recreation is selected, validate inventory/paths/bytes, keep destination rules first and use fresh identities with separate actual native-custody verification.

Current: docs/COMMANDS.md:30; docs/OPERATIONS.md:13; docs/PLUGIN_RULES.md:23. Deprecated: [plugins/alife-worlds/skills/creating-world/references/clone-project.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/clone-project.md#L5).

### P21 — Independent local project clone workflow

**old-only**. Old bounded goal-based copy creates fresh IDs and requires an opened independent destination. It is not sanitized public export or current source setup.

Current IDs: preservation.no-extra-effects. No folder/project/chat/approval copied. An optional absent command is not a missing preservation rule.

**Proposed choice:** Only if selected: review non-overwriting destination and exact exclusions; preserve original team, use fresh goals/IDs/checkpoints, transfer no credentials/grants/effects and review source before sharing.

Current: AGENTS.md:13; AGENTS.md:29; docs/PLUGIN_RULES.md:24. Deprecated: [plugins/alife-worlds/skills/creating-world/references/clone-project.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/clone-project.md#L23).

### P22 — Old Public-mode details versus private sprint boundary

**context-dependent**. Old Public display mode can show opted-in epic/sprint/task details; modes never change audience. Current public hosting excludes private sprint/task prose and actions while owner-private presentation may show them.

Current IDs: links-and-access.access-isolation, links-and-access.public-link, links-and-access.private-editing. Separate sanitized public and authorized private projections are documented. No live data fetched or republished.

**Proposed choice:** Keep maintained world art and sanitized progress public; keep sprint/task prose, editing and real messages owner-private. Never port old public-detail payloads or use a display toggle as access control. Public presentation mode and an anonymous public audience are different contexts. Private task details remain owner-only; a mode toggle never grants access.

Current: docs/PLUGIN_RULES.md:82; docs/PLUGIN_RULES.md:80; docs/INTEGRATION.md:171. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L37), [plugins/alife-worlds/skills/creating-world/references/web-view.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/web-view.md#L13), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L236).

### P23 — Private operator link and optional website/custom domain

**already-present**. The latest human /plugin statement is already explicit: a plugin-supplied private link for phone/computer and a separate optional public website/custom-domain link.

Current IDs: links-and-access.private-link, links-and-access.private-editing, links-and-access.private-messages, links-and-access.public-link, links-and-access.public-domain, links-and-access.access-isolation, links-and-access.public-fullscreen. Saved rules remain documented; owning docs record this project deployed edit/fullscreen acceptance. Native messaging remains unavailable; no automatic per-project hosting is implied.

**Proposed choice:** Keep private viewing/editing and supported authenticated messages distinct from optional read-only public website/domain viewing. Domain setup never exposes private data, changes audience or auto-publishes.

Current: docs/PLUGIN_RULES.md:77; docs/PLUGIN_RULES.md:78; docs/PLUGIN_RULES.md:81; docs/PLUGIN_RULES.md:83; docs/INTEGRATION.md:171. Deprecated: [plugins/alife-worlds/skills/creating-world/references/web-view.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/web-view.md#L5), [plugins/alife-worlds/skills/creating-world/references/web-view.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/web-view.md#L15), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L236).

### P24 — Custom-world preservation on default/plugin updates

**duplicate**. The active new group already expresses legacy preservation and adds recoverable conflict handling. Importing another copy would duplicate the authority.

Current IDs: custom-worlds.preserve-worlds, custom-worlds.preserve-rules, custom-worlds.update-defaults, custom-worlds.recoverable-merge. Setup preserves existing files and the builder stages defaults separately. No custom-world updater was run or newly qualified.

**Proposed choice:** Keep the single current group: update bundled defaults/shared code without losing custom content/rules/identity. An unresolved conflict keeps the existing world usable.

Current: docs/PLUGIN_RULES.md:70; docs/PLUGIN_RULES.md:71; docs/PLUGIN_RULES.md:72; docs/PLUGIN_RULES.md:73; docs/INTEGRATION.md:164. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L41), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L138).

### P25 — Actual image inspection, generation and integration

**already-present**. Both make a visual prose brief optional and derive original coherent sprites/world art from actual supplied references. New rules explicitly require every input/output inspection and real integration.

Current IDs: image-workflow.inspect-all, image-workflow.generate-integrate. No image folder supplied, artwork generated or image acceptance claimed for this audit.

**Proposed choice:** Retain current image workflow/provenance, useful alpha/scale/pivots and selected perspective. Never claim absent input inspection or tool output.

Current: docs/PLUGIN_RULES.md:65; docs/PLUGIN_RULES.md:66; skills/alife-world/SKILL.md:48. Deprecated: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L132), [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L10).

### P26 — Owning manuals and generated scope-only rule views

**already-present**. Current manuals and active contradiction/duplicate removal already exist. New registries own policy; grouped docs/prompts are generated views with separate plugin/world exports.

Current IDs: delivery.maintain-rule-docs. A view is not another editable authority. This audit regenerates no source or packet.

**Proposed choice:** Keep one owning registry per scope, update actual behavior/checks/limits and never equate saved guidance with implemented capability.

Current: docs/PLUGIN_RULES.md:31; docs/OPERATIONS.md:13; docs/COMMANDS.md:32. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L47), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L144).

### P27 — Scoped Git and cleanup protect unique work/recovery

**already-present**. Current policy already preserves concurrent/unique changes and actual remote/branch ownership. Cleanup needs inventory/dependency/recovery scope; no reset/clean/force shortcut.

Current IDs: delivery.sync-before-push, delivery.publish-completed-work, preservation.existing-custody. No fetch/checkout/commit/push/cleanup or source/index mutation in this audit.

**Proposed choice:** Keep current Git-owner and recovery policy. Authorized push never implies installation, hosted deployment, audience change or recovery deletion.

Current: docs/PLUGIN_RULES.md:28; docs/PLUGIN_RULES.md:29; roles/SHARED.md:33; AGENTS.md:37. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L29), [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L49).

### P28 — Absent metric/protection adapters remain unavailable

**complementary**. Current truthfulness prevents fabricated measurements. Old detail explicitly names unavailable window protection, performance, resource recovery and analytics.

Current IDs: authority.honest-results. Listing an absent adapter creates neither implementation scope nor real metrics/token savings. None were measured.

**Proposed choice:** If selected as clarification, label each absent adapter unavailable and require actual source/session/revision/time evidence for measurements.

Current: docs/PLUGIN_RULES.md:10; roles/SHARED.md:37; docs/OPERATIONS.md:55. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L37), [plugins/alife-worlds/shared/operating-rules.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/shared/operating-rules.mjs#L27).

### P29 — Legacy backend API and storage names

**obsolete**. Old start/connect/request_agent APIs and ALIFE_RULES.md/ALife-Agents.json belong to the reference backend, not the new foundation endpoints or rule stores.

Current IDs: preservation.selected-imports. Never call obsolete commands or rename current/native IDs to imitate the backend.

**Proposed choice:** Use current registries and supported host tools. Keep legacy names reference-only unless an exact compatibility migration is separately selected.

Current: AGENTS.md:29; skills/alife-world/SKILL.md:26; docs/COMMANDS.md:3. Deprecated: [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L12), [plugins/alife-worlds/skills/creating-world/references/agent-intake.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/agent-intake.md#L9), [plugins/alife-worlds/skills/creating-world/references/reset-project.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/reset-project.md#L11).

### P30 — Retained planet, new launcher wording and native navigation

**partial**. Human selected the existing planet icon and Open ALife Worlds. The old singular title/MCP serverInfo icon entrypoint and fixed embedded fonts are different host capabilities, not proof of a global MCP sidebar item in this skill packet.

Current IDs: launcher.planet-icon, launcher.open-worlds, typography.licensed-fonts, typography.white-text. Plugin/skill visibility and an actual native side panel are independent acceptance. No old server/icon/font was imported.

**Proposed choice:** Keep selected planet and plural wording, supported opener for verified URLs and honest unavailable state. New MCP navigation needs exact implementation/qualification; use white readable text and licensed fonts. The separate global/thread MCP App entrypoint is absent. See F01. Installation itself is verified.

Current: docs/PLUGIN_RULES.md:60; docs/PLUGIN_RULES.md:61; docs/PLUGIN_RULES.md:56; docs/PLUGIN_RULES.md:55; skills/alife-world/SKILL.md:52. Deprecated: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L222), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L227).

### P31 — Independent phone, landscape and camera/accessibility checks

**already-present**. Both preserve private access and existing connection with responsive phone presentation. New rules explicitly separate actual phone/native evidence from simulated widths and require100–300% shared camera/pan.

Current IDs: mobile-layout.portrait, mobile-layout.landscape, mobile-layout.browser-zoom, mobile-layout.physical-checks, camera.zoom-pan. Documented browser-width acceptance is not physical-phone acceptance. No browser/native/phone checks repeated.

**Proposed choice:** Keep full-height portrait safe areas, independent landscape fit, readable touch controls and shared art/plaque/hit transform while preserving browser text/pinch zoom. Record physical/native checks separately.

Current: docs/PLUGIN_RULES.md:44; docs/PLUGIN_RULES.md:45; docs/PLUGIN_RULES.md:46; docs/PLUGIN_RULES.md:47; docs/PLUGIN_RULES.md:51. Deprecated: [plugins/alife-worlds/skills/creating-world/references/web-view.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/web-view.md#L5), [plugins/alife-worlds/skills/creating-world/references/web-view.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/web-view.md#L21), [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L43).

### P32 — Red blocked supersedes legacy orange

**conflicting**. The old site palette says orange blocked. The current explicit human amendment selects red; green progress, blue backlog, lavender idle and pale-green accepted stay active.

Current IDs: site-presentation.blocked, site-presentation.progress, site-presentation.backlog, site-presentation.idle, site-presentation.accepted, site-presentation.semantics. Policy values compared; no renderer/pixel retest claimed.

**Proposed choice:** Keep current red blocked, readable contrast and text labels. Colors never change task state, freshness or acceptance.

Current: docs/PLUGIN_RULES.md:37; docs/PLUGIN_RULES.md:35; docs/PLUGIN_RULES.md:36; docs/PLUGIN_RULES.md:38; docs/PLUGIN_RULES.md:39; docs/PLUGIN_RULES.md:40. Deprecated: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L240).

### P33 — Concise helper launch versus full initial-prompt wording

**conflicting**. Both require full persistent inheritance and complete actual readback. Old clean-helper guidance uses concise file-loading prompts/no previews; current shared template says include the full contract in each initial role prompt and checkpoint.

Current IDs: . No launch prompt/home changed. Reconciling visible message format needs exact human selection without weakening custody.

**Proposed choice:** If selected, persist the full common/role/retirement/latest-human contracts, use one concise exact-folder file-loading launch and require complete readback/access/custody before work. Templates alone authorize no chat.

Current: roles/SHARED.md:3; AGENTS.md:21. Deprecated: [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L18), [plugins/alife-worlds/skills/creating-world/references/retirement.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/retirement.md#L11), [plugins/alife-worlds/skills/creating-world/SKILL.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/SKILL.md#L48).

## Core agents and staffing

Proposed generic core: **Director** for priorities/capacity/acceptance; **Agent Support** for authorized staffing/recovery; **World Requests** for world/UI/adapter. Other responsibilities can remain functions of these roles until real work justifies a specialist. Independent validation is still required when relevant; the implementer does not self-accept. This is a future baseline proposal, not retirement of current agents.

| Existing role | Future disposition proposal |
|---|---|
| Director | planned-core: Priorities, scope, capacity and independent acceptance; retains current custody. |
| Agent Support | planned-core: Authorized onboarding/recovery; optional future unified staffing intake if selected. |
| World Requests | planned-core: Sole world/UI/adapter implementation owner. |
| Request Intake | mergeable-responsibility-or-specialist: Director can own request intake; separate specialist only for real volume/scope. |
| Delivery Lead | mergeable-responsibility-or-specialist: Director can serialize assignments/results; separate role if actual coordination capacity warrants. |
| Release & Closeout | mergeable-responsibility-or-specialist: Owner/Director closeout function; optional release specialist for complex releases. |
| Agent Worker #1 | on-demand-specialist: Implementation capacity under a concrete authorized claim. |
| Agent Worker #2 | on-demand-specialist: Additional justified independent capacity. |
| Agent Worker #3 | on-demand-specialist: Additional justified independent capacity. |
| Agent Worker #4 | on-demand-specialist: Additional justified independent capacity; slot does not set concurrency. |
| QA Coordinator | mergeable-responsibility-or-specialist: Acceptance/run preparation; separate coordinator when shared environments require it. |
| QA Operator | on-demand-independent-validator: Independent actual-product acceptance; do not let the implementer self-accept. |
| Memory Clean | on-demand-specialist: Each owner cleans its finished outputs; measured broader cleanup needs explicit manifest/custody. |
| Technical Support | on-demand-specialist: Specific authorized tooling/dependency issue under current source ownership. |
| Product Design & Shaping | mergeable-responsibility-or-specialist: Director shaping function; optional specialist for substantial design. |
| Spinner Whip | mergeable-responsibility-or-specialist: Director changed-evidence follow-through; no implied timer or nudge authorization. |
| Git Merger | on-demand-specialist: Safe publication/synchronization under the actual Git owner. |
| Special Forces | on-demand-specialist: Bounded complex problem or critical bottleneck; current lead custody preserved. |
| Optimizer | on-demand-specialist: Measured performance work with a real metric/baseline. |
| Piper | on-demand-specialist: Evidence-based analysis when assigned; no standing monitor implied. |

All 20 existing chats/homes/tasks/settings/bindings remain. Deprecated rules do not require a fixed20-agent team. Inquiry is optional, not a fourth required core.

### C01 — Preserve human speed versus old Standard-only enforcement

**conflicting**.

**New:** Preserve the human's selected speed/model/reasoning; no automatic Standard reset.

**Deprecated:** Old portable contract mandates persistent Standard and disables faster modes.

**Possible contextual wording:** Preserve each existing agent's human-selected settings. Creation and replacement use only the human-approved settings for that role; missing choices require the human.

Recommendation: Keep current. Do not migrate the old global Standard requirement or rewrite historical observations.

Current: AGENTS.md:33; roles/SHARED.md:19. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L29), [plugins/alife-worlds/skills/creating-world/SKILL.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/SKILL.md#L36).

### C02 — Old Terra/Sol/Astra creation defaults

**conflicting**.

**New:** New roles require approved role settings or an explicit creation baseline; task difficulty does not authorize upgrades.

**Deprecated:** Old project declares Terra for messages, Sol Extra High otherwise and Astra Extra High only by selection.

**Possible contextual wording:** No model family or reasoning level is implied by a role catalogue or deprecated project; record the human's actual approved creation choice.

Recommendation: Exclude old model defaults. They are source-project choices, not portable operating rules.

Current: AGENTS.md:33; roles/SHARED.md:19. Deprecated: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L142), [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L45).

### C03 — Concise file-loading launch versus full pasted prompts

**conflicting**.

**New:** Current shared/role packets require full contracts in both initial prompt and checkpoint; a pointer alone is insufficient.

**Deprecated:** Old launch procedure keeps full contracts in files/checkpoint, uses concise launch text and requires complete readback/custody.

**Possible contextual wording:** Persist complete current contracts and custody before launch. A concise launch may point to them only if the actual helper fully reads and acknowledges those files, exact access and inherited effects.

Recommendation: Concise file loading is a reasonable selectable simplification; it is not adopted by this audit.

Current: roles/SHARED.md:3; roles/SHARED.md:23; roles/director.md:5. Deprecated: [plugins/alife-worlds/skills/creating-world/references/retirement.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/retirement.md#L3), [plugins/alife-worlds/skills/creating-world/references/retirement.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/retirement.md#L11).

### C04 — Real three-core bootstrap and readiness gates

**conflicting**.

**New:** Latest selected universal rule says only the existing bound Agent Support creates agents/successors; missing Support is a dependency, not permission for Director to create it. Generic3-core startup remains unimplemented.

**Deprecated:** Old folder-first startup bootstraps the missing core, reuses verified equivalents and waits for each real chat/access/custody receipt.

**Possible contextual wording:** Choose an explicit bootstrap rule before implementing fresh-project startup: human establishes the initial Support, or human approves one narrowly defined initial-Support exception. After that, Support alone handles authorized creation, full inheritance and actual receipts. Preserve existing 20 identities.

Recommendation: Do not import the old Director-creates-first-Support action under the current universal rule. This requires a human-selected exception or initial-Support setup path.

Current: AGENTS.md:19; README.md:37; README.md:74. Deprecated: [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L6), [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L9).

### C05 — All staffing requests through one Support intake

**partial**.

**New:** Latest universal onboarding.support-owned-creation already routes every staffing request to bound Agent Support. Director retains scope/priorities; the detailed stable-request reservation/reconciliation protocol is additional old detail.

**Deprecated:** Old requests preserve stable original request IDs, route every receiver to Support, reconcile pending/unknown launches and verify reuse receipts before provisioning.

**Possible contextual wording:** Director defines the authorized scope/capacity gap. Support owns one request and verifies existing capacity and unknown effects first; creation requires approved settings and the actual new helper receipt.

Recommendation: The ownership rule is already selected in new source. Review only the request/reservation/reconciliation detail, not another duplicate ownership rule.

Current: AGENTS.md:17; roles/director.md:11; docs/OPERATIONS.md:25. Deprecated: [plugins/alife-worlds/skills/creating-world/references/agent-intake.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/agent-intake.md#L3), [plugins/alife-worlds/skills/creating-world/references/agent-intake.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/agent-intake.md#L9), [plugins/alife-worlds/server/agent-intake.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/server/agent-intake.mjs#L19).

### C06 — Folder-first homes and automatic Director naming

**context-dependent**.

**New:** Source and native coordination homes/cwd remain separate; no identity transfer or current-team relocation follows a source change.

**Deprecated:** Old new-project invocation places new native homes/chats directly in the selected folder and normally renames the initiating chat Director.

**Possible contextual wording:** Verify the user-selected project and configured native coordination root. Existing identities/homes/cwd never move or rename implicitly. Future new homes/titles follow the user's explicit destination and supported host action.

Recommendation: Do not apply old folder/title actions to this existing 20-role team.

Current: AGENTS.md:7; AGENTS.md:7; README.md:39. Deprecated: [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L6), [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L7).

### C07 — Dynamic bounded inventory and optional visible subset

**old-only**.

**New:** Current exact bindings and all 20 existing identities are preserved; folders and catalogues authorize no new agents.

**Deprecated:** Old read-only inventory discovers recognized local homes, marks unverified entries Unconfirmed, excludes backups/caches and optionally filters visible actors without deleting chats/tasks.

**Possible contextual wording:** Discovery is read-only and bounded to the authorized native workspace. Unknown entries stay Unconfirmed until ownership is verified; backups are evidence, not agents. Hiding an actor never retires or deletes it.

Recommendation: Useful optional extension. Never infer that old 'outside homes' wording relocates or rejects the explicitly separate current native workspace.

Current: AGENTS.md:19; AGENTS.md:27. Deprecated: [plugins/alife-worlds/skills/creating-world/references/agent-intake.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/agent-intake.md#L11), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L180).

### C08 — Sequential safe retirement and real custody

**duplicate**.

**New:** Support creates one authorized sequential successor, carries full inheritance/effects and obtains actual receipt before predecessor archive; waits/outages are not failures.

**Deprecated:** Old retirement contract supplies the same safeguards and prepare/complete actions with request IDs, successor verification and actual archive/settlement evidence.

**Possible contextual wording:** Retirement preserves the same task/history and current permissions; one successor obtains full real custody before safe archive. Existing imported owners retain their process; unknown effects are reconciled.

Recommendation: No new policy copy is needed. Do not retire healthy idle roles or inherit old model settings.

Current: roles/SHARED.md:27; roles/SHARED.md:25; roles/support.md:11. Deprecated: [plugins/alife-worlds/skills/creating-world/references/retirement.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/retirement.md#L7), [plugins/alife-worlds/server/retirement.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/server/retirement.mjs#L18), [plugins/alife-worlds/server/retirement.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/server/retirement.mjs#L6).

### C09 — Approved contract propagation to existing role homes

**complementary**.

**New:** Current onboarding/handoffs preserve complete current rules and custody; each role owns its home.

**Deprecated:** Old procedure synchronizes an authorized current portable rule update into every recognized role, preserving role-specific instructions and preimages; saved delivery differs from readback.

**Possible contextual wording:** Only after an approved rule change and explicit role-home write custody, propagate the current contract without changing tasks/settings or treating a file write as an agent acknowledgement.

Recommendation: Potential complement to prevent stale homes. No automatic all-home edits are authorized now.

Current: AGENTS.md:21; roles/SHARED.md:23. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L15).

### C10 — Inquiry and specialist roles are optional

**old-only**.

**New:** Current project retains its 20 roles; a catalogue never authorizes additional staffing.

**Deprecated:** Old Inquiry is an optional question helper and explicitly not a fourth default core role; actual actions require scope authorization.

**Possible contextual wording:** Represent responsibilities independently of permanent headcount. Reuse existing roles before proposing an optional specialist, and obtain creation/settings approval if one is needed.

Recommendation: Optional, not a generic staffing requirement. No fourth core role or fixed 20-agent army.

Current: AGENTS.md:19; AGENTS.md:19. Deprecated: [plugins/alife-worlds/skills/creating-world/references/agent-intake.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/agent-intake.md#L13), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L182).

### C11 — Legacy keys and old roster-file conventions

**obsolete**.

**New:** Current native IDs/homes and canonical task authority are preserved; the new source does not import old records.

**Deprecated:** Old compatibility retains world-creator for World Requests and uses ALife-Agents.json/agent.json as part of its own state contract.

**Possible contextual wording:** Preserve the current project's established role/native/task identities. Prior source identifiers and roster-file names are reference schema, never live bindings or permissions.

Recommendation: Do not carry literal legacy IDs/paths/store conventions into this new baseline.

Current: AGENTS.md:7; AGENTS.md:25; docs/OPERATIONS.md:23. Deprecated: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L148), [plugins/alife-worlds/skills/creating-world/references/project-start.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/project-start.md#L6).

### C12 — Reuse, nonfabricated work and scope ownership

**duplicate**.

**New:** One owner per scope; reuse capable agents; no fabricated activity/acceptance or new-agent authority from templates; World Requests owns world implementation.

**Deprecated:** Old rules preserve the same ownership/isolation/actual-work boundaries and say the role catalogue itself authorizes no additional agents.

**Possible contextual wording:** Retain the current authority, truthful-state and preservation contract. A useful role description or animation never grants staffing, execution or acceptance.

Recommendation: No duplicate import is needed.

Current: roles/SHARED.md:7; roles/director.md:11; roles/world-requests.md:11; AGENTS.md:25. Deprecated: [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L17), [plugins/alife-worlds/skills/creating-world/references/operating-contract.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/skills/creating-world/references/operating-contract.md#L27).

## World, layout and state candidates

### W01 — Room perspective and the latest approved art

**conflicting**.

**New:** The registry still says front-facing rooms; the separately approved latest muted-art handoff selects overhead interior rooms. Qualified source records this unresolved wording explicitly.

**Deprecated:** Overhead ants/furniture in small open soil recesses, with a separate side-view room close-up.

**Choice/contextual combination:** Choose one current default perspective. Recommended: reconcile the registry to the already selected top-view interior, while keeping grounded exterior side-view travel. This is a current-source reconciliation, not blanket adoption of old art.

Current: rules/world.json#appearance.rooms; runtime/selected-world-20261106/qualified-source.json#knownLimits; docs/VISUALS.md. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L15).

### W02 — Role costumes versus one uncostumed ant body

**conflicting**.

**New:** Same six-legged articulated production ant anatomy with role costumes and accessories.

**Deprecated:** Same cute pixel body for every role, expressly excluding role-specific replacement bodies or costumes.

**Choice/contextual combination:** Keep current anatomy/accessories; if selected, limit costumes to removable accessories so the same base ant remains recognizable.

Current: rules/world.json#appearance.agents; docs/VISUALS.md. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L15).

### W03 — Model-family sizes versus effort-based sizes

**conflicting**.

**New:** Human-selected family ordering: Astra, Sol 6.1, Sol 6, Terra, Luna; current muted family colors/trails. No change to native settings.

**Deprecated:** Model colors plus reasoning-effort body sizing, non-default model aura and verified faster-tier trail accents.

**Choice/contextual combination:** Keep the current selected family size/color mapping. If desired, represent actual effort through a separate small indicator rather than changing family size order.

Current: rules/world.json#appearance.model-loot-colors; rules/plugin.json#agent-settings. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L15).

### W04 — Idle and safe sleep

**conflicting**.

**New:** Confirmed Idle with eligible work stays awake; Idle without eligible work sleeps.

**Deprecated:** Idle remains awake; Sleeping requires explicit safe-sleep/stop evidence, with stale activity kept unknown.

**Choice/contextual combination:** Choose whether no-work Idle may sleep, or whether only explicit safe-sleep evidence permits it. In either case, stale evidence must not become fresh sleep/work.

Current: rules/world.json#activity.idle; rules/world.json#activity.sleeping. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L58).

### W05 — Director monitors

**conflicting**.

**New:** Director has three monitors.

**Deprecated:** Director has two large monitors.

**Choice/contextual combination:** Keep current three-screen desk, or explicitly select two. This affects visual presentation only.

Current: roles/director.md:9; docs/VISUALS.md. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L19).

### W06 — Agent Support task tree

**conflicting**.

**New:** Support keeps its default task tree; current no-tree exceptions are Director, QA Operator, Technical Support and Optimizer.

**Deprecated:** Support's first-responder garage has no task tree.

**Choice/contextual combination:** Choose whether Support keeps a tree. Keep its incident-driven ambulance/firetruck behavior regardless; drawing cannot resolve actual recovery.

Current: roles/support.md:9; docs/VISUALS.md:18; docs/VISUALS.md:28. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L19).

### W07 — Room details and full side-view close-up

**partial**.

**New:** Small room-anchored popup with current work/model/state/blocker details; existing source also has room inspection.

**Deprecated:** A live side-view room close-up of the same actor, with an Away state and no exterior/progress content.

**Choice/contextual combination:** Optional combine: a compact popup by default, with an explicit expanded room view; both use the same real state and privacy rules.

Current: rules/world.json#movement.room-details; web/agent-outpost/agent-outpost.js. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L15).

### W08 — Mining drop reservation and strength feedback

**partial**.

**New:** Intact obstacles, walkable broken debris, 2–8 hits, proportional cracking/chipping and actual-work supply trips are already documented.

**Deprecated:** Same 2–8 hits, plus remaining-strength bar, one-drop reservations, collectible delivery and fallback to water when supplies are unavailable.

**Choice/contextual combination:** Do not import a second hit-count rule. Select only the missing feedback/reservation details if useful, preserving existing resource behavior and zero task credit.

Current: rules/world.json#mining; rules/world.json#movement.supplies. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L44).

### W09 — Private payload minimization

**complementary**.

**New:** Local Private is presentation concealment. Hosted public data is sanitized; owner-private access is authenticated. Needs-input metadata is local/owner-private only.

**Deprecated:** Private/View responses remove operational prose, native IDs and detailed model evidence at the server boundary.

**Choice/contextual combination:** Optional combine: retain authenticated owner operations while minimizing any view-only payload server-side. Define audience separately from the Public/Private/View presentation toggle. See P22 for public task-detail conflicts.

Current: roles/SHARED.md#Display contract; rules/plugin.json#links-and-access; lib/operator-contract.mjs. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L196).

### W10 — Structural privacy parsing and smaller read budgets

**partial**.

**New:** The native reader is scoped and bounded, publishes allowlisted scalars, but JSON.parse decodes bounded whole rows; prefix64KiB/window2MiB, freshness120s.

**Deprecated:** Skips ignored JSON bodies without decoding them; identity prefix16KiB/incremental256KiB; freshness120s.

**Choice/contextual combination:** Consider equivalent structural skipping and smaller measured budgets as a separate hardening change. Preserve supported lifecycle parsing and exact identity checks; no hook or old parser import until selected.

Current: adapters/native-session-adapter.mjs:5; adapters/native-session-adapter.mjs:68; adapters/native-session-adapter.mjs:79. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L92).

### W11 — Per-surface poll and freshness profiles

**partial**.

**New:** Current local poll is5s, native freshness120s; the separately hosted public/private transports have their own10/15s update cadences and45/60s stale budgets.

**Deprecated:** One-second visible refresh, bounded request timeouts and25s hosted-feed expiry; native activity still120s.

**Choice/contextual combination:** Define local, authenticated owner and public showcase profiles separately. Compare each transport's update period/expiry together before selecting faster polling; polling never renews work.

Current: docs/INTEGRATION.md; docs/OPERATIONS.md; adapters/native-session-adapter.mjs:5. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L58).

### W12 — Exact audio mix and cue limits

**partial**.

**New:** Muted start, one immediate Sound control, Pause/hidden/reduced-motion guards, local CC0 manifests and the selected lo-fi loop are already current; short cues use roughly65ms trigger cap.

**Deprecated:** Same general safeguards with additional historic voice/gain/timing mix details.

**Choice/contextual combination:** Keep the current selected beat and guards. Consider old mix parameters only after actual listening comparison; they are tuning choices, not proof of missing music or mute logic.

Current: rules/world.json#sound-and-motion; docs/ASSETS.md. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L120).

### W13 — Pixel atlases and exact embedded fonts

**complementary**.

**New:** Actual production six-legged ant/gait and licensed-font policy are current; the selected muted art uses the current renderer.

**Deprecated:** Explicit64x64 pixel frames, hard-alpha/nearest-neighbor grids and embedded licensed Inter/Pixelify Sans.

**Choice/contextual combination:** Optional style/asset choice only. Do not replace current ant anatomy, custom-world art, or fonts merely because the old packet bundled them.

Current: rules/world.json#appearance; rules/plugin.json#typography; docs/ASSETS.md. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L48).

### W14 — Layout, motion and interaction protections already restored

**duplicate**.

**New:** World-first order; collapsed details; camera100–300%; project dropdown/Show all; Private/View fit; normal Public wheel; no magnifier/bottom sand graph; mute/motion guards; safe travel, real messages and no decorative progress.

**Deprecated:** Most of these exact behaviors are in the deprecated display contract.

**Choice/contextual combination:** Keep current owning properties. These are already present as rules; verify implementation by feature when it changes rather than importing another copy. Documented status is not a fresh runtime PASS.

Current: rules/plugin.json#camera; rules/world.json#site; rules/world.json#movement; rules/world.json#projects. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L70).

### W15 — New-only world amendments

**new-only**.

**New:** Current Ant key, selected-sprint seed-to-tree/hover-only percentage, private needs-human-input attention pose and issue-driven Special Forces three-avatar/wasp defense have no exact matching old rule.

**Deprecated:** No equivalent exact contract found in the scoped deprecated owning sources.

**Choice/contextual combination:** Keep already selected current rules separate from migration choices. The defense rules remain documented and unimplemented; no new native agents are implied. Recent art/tree/key/input source checks do not establish hosted/installed acceptance.

Current: rules/world.json#appearance.ant-key; rules/world.json#activity.sprint-tree; rules/world.json#activity.human-input-attention; rules/world.json#defense. Deprecated starting point: [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L15).

## F01 — Codex sidebar world launcher

**Missing capability.** The installed0.1.0-foundation.1 packet is skills-only. Actual Codex UI shows ALife Worlds under Plugins → Installed, with one skill and no separate MCP world app.

Deprecated: Old open_world declares global and thread MCP App entrypoints.

Proposal: Optionally implement a minimal verified-current-world launcher through the supported global/thread MCP App entrypoint. Preserve access boundaries. Do not import old startup/reset/delete/spawn tools, hooks or data merely to restore the sidebar.

Verified prior implementation: [plugins/alife-worlds/server/index.mjs](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/plugins/alife-worlds/server/index.mjs#L71), [docs/PRODUCT_RULES.md](https://github.com/ALifeWorlds/alife-worlds/blob/a30378822a62912550992c782161a18fa0e615c0/docs/PRODUCT_RULES.md#L227). [Official sidebar entrypoint contract](https://developers.openai.com/plugins/build/extensions#sidebar-apps). Global app metadata needs ui.resourceUri and openai/ui.entrypoints with type global; type thread is the conversation-side entrypoint. The new packet has neither app registration.

## Duplicates and implementation gaps

No duplicate import is needed for project isolation, truthful activity/progress, canonical task/acceptance records, no unknown-effect replay, custody/retirement, scoped Git/recovery, muted opt-in audio/motion guards, custom-world preservation, image inspection, project/Show all selection, world-first layout, Public wheel scrolling, Private/View fit or private/public access separation. Documented requirements may still need implementation/acceptance; that is a feature backlog, not a missing rule.

## Installed-to-authoring text delta

These source changes were already selected by the human; this comparison does not adopt them from deprecated source.

- **plugin preservation.close-task-tabs (added):** Each agent tracks the exact browser tabs and temporary previews it creates. Once a task, request, handoff, cancellation or completed computer-use step no longer needs them, save the necessary result/evidence and close those owned temporary tabs through supported browser controls before reporting closeout. Verify the known tab IDs are absent from the accessible inventory. Keep user-owned tabs, another active agent's tabs, unsaved work and explicitly requested deliverables open. Ownership uncertainty or an unavailable close control stays an explicit unresolved item; do not bulk-close a browser or stop a shared service. On the next assignment, start from a fresh task-owned tab instead of accumulating old test/demo/duplicate previews.
- **plugin preservation.release-computer-control (added):** At the end of computer/browser work, or when returning control for a wait or handoff, settle outstanding input/capture and use the supported host end-session/completion action immediately after the final UI observation, before continuing non-UI work or reporting completion. For cua_repl, the next call is the completion_summary-only action exactly once; observe a user handoff's outcome before summarizing it. End the agent's own session so its blue computer-use tint/border/overlay clears and the human regains control. Keep any genuine other owner's active computer session intact. Do not disable safety indicators, change host security settings, kill helpers or claim the overlay disappeared without evidence. If the host cannot release it or its visible disappearance cannot be verified, report that exact remaining limitation and preserve the real session/effect state.
- **plugin delivery.update-existing-site (changed):** Prepare and check local website changes, but do not deploy, upload, replace or update the hosted website until the human explicitly instructs publish to website. Completion of local work, a Git push, a /world or /rule edit, prior website authorization or a prepared handoff does not trigger deployment. This supersedes the earlier automatic website-update rule. After an explicit publish instruction, use the existing authorized site owner, destination and audience, then verify the actual hosted result. Keep public/private access boundaries and separate installation permissions.
- **plugin delivery.maintain-rule-docs (changed):** After every /world, /plugin, /rule, /universal or other command that adds or changes rules, update the owning manuals and regenerate the grouped views and prompts. Review meanings for duplicate, superseded, old, deprecated or conflicting active instructions; consolidate compatible facets by subject/property and retain required inactive history only as clearly non-authoritative evidence. Current human intent wins; ask for a genuinely missing decision instead of silently adopting a conflict. Record actual behavior, checks and limits; saving documentation alone is not implementation, publication or installation.
- **plugin links-and-access.public-link (changed):** When the owner has authorized a public website viewer, use the same maintained world renderer/art and current canonical progress as the local world. Prepare and verify matching qualified world source for the website, while keeping its sanitized display distinct from private operator data. Public visitors cannot alter sprints, tasks, real agent work or invoke native commands. Any later operational access requires the human explicit authorization and the actual supported authenticated capability; a display toggle or decorative interaction never grants it. Private creation alone does not publish a world. Website deployment follows the explicit publish-to-website gate.
- **world appearance.agents (changed):** Render the same six-legged articulated ALife Agents and role costumes. Actual observed model identity controls the maintained family colors, relative visual body sizes and trail shapes. Preserve real model, reasoning effort, speed, status and anatomy; these appearance sizes do not alter native settings or navigation.
- **world appearance.model-loot-colors (changed):** Use the approved muted model palette and strictly descending relative body size at the same pose: Astra largest, lavender/purple with star-like trails; Sol 6.1 second largest, orange/gold with diamond-like trails; Sol 6 medium, blue with dotted trails; Terra second smallest, green with leafy trails; Luna smallest, pale gold with ring-like trails. Derive appearance from actual observed model identity. Unrecognized or unavailable model metadata stays unknown with a neutral gray fallback. This replaces the earlier legendary-orange/epic-purple/rare-blue loot palette. Never change real model selection, reasoning effort, speed, status or custom-world overrides.
- **world appearance.ant-key (added):** Provide a compact, initially collapsed Ant key near the world controls. Use the same production ant silhouettes to explain each model family color and relative body size. It is a generic appearance guide, not a roster or a claim about running models. Keep it within existing metadata privacy boundaries and omit it from the sanitized public viewer. Do not restore the old bottom speed strip, weather caption or gem-click text.
- **world activity.sprint-tree (added):** A side tree represents the currently selected real sprint. Grow from a seed at 0 percent toward a full tree at 100 percent using only the canonical sprint progress already used by the world. Selecting another sprint updates this same representation. No active sprint or valid progress shows unavailable feedback rather than fabricated zero or completion. Preserve role trees, their existing exceptions, the acceptance ledger and resource behavior; mining and elapsed animation time grant no growth.
- **world activity.tree-inspection (added):** Show the selected sprint name and completion percentage only on hover, keyboard focus or a brief accessible touch inspection. Keep scene percentages hidden at rest, respect existing Private concealment and public sanitization, and show truthful no-active-sprint or unavailable feedback when appropriate.
- **world activity.human-input-attention (added):** When current verified lifecycle evidence explicitly requests human input or approval, the affected living ant faces the viewer, stands upright on its two rear legs, waves both front legs and makes small attention jumps like a character asking the viewer for help. Show a yellow triangle with a black exclamation mark above its head. Ordinary waiting, an intentional pause, a blocker, idle or stale activity alone must not trigger this pose. Preserve the existing ant anatomy, real task state, model/speed, blocker/recovery semantics and privacy; expose a bounded needs-input flag only to the local and authenticated owner-private world, never the public showcase or private request content. A resumed/completed request clears it. Pause, hidden-page, reduced-motion and stale-data guards stop autonomous attention motion; View remains noninteractive.
- **world sound-and-motion.music (changed):** Use the previously bundled CC0 Freesound Lofi Beat Loop Schmoop as the DEFAULT world background music, with the existing optional UI, water, grass and mining cues. The world music loop is the lo-fi beat; the separate galaxy ambience is not a replacement for it. Do not replace custom-world music. Every load starts muted, only the single Sound control enables audio, mute immediately silences everything, and Pause/hidden-page/reduced-motion guards remain active. Preserve the bundled author/source/license/hash manifest; no runtime online audio fetch is required.

## Complete reviewed Plugin Rules

### Project Isolation, Identity & Evidence (authority)

- **authority.canonical-records — Canonical records** [implemented]: Use one authoritative task, roster and acceptance store. Native activity and task acceptance remain separate.
- **authority.honest-results — Honest results** [implemented]: Never infer execution, progress or acceptance from animation, polling, messages, tokens or Git publication.
- **authority.exact-native-scope — Exact native scope** [implemented]: Read only exact authorized native identities and cwd using bounded observations; publish no prompts, reasoning, transcripts, tool arguments/results or credentials.
- **authority.disabled-native-transport — Native transport** [implemented]: Keep native messaging transport disabled until separately implemented and verified. Rule authoring does not enable native commands.

### Human-selected Settings (agent-settings)

- **agent-settings.preserve-settings — Existing agents** [implemented]: Preserve the human-selected model, speed and reasoning. Do not reset or upgrade them to finish work.
- **agent-settings.approved-creation — New agents** [implemented]: Use only a human-approved role model/settings or explicit creation baseline. Never inherit a higher-model helper or create/replace/fork a higher-model workaround without approval. Ask when an approved creation choice is missing.
- **agent-settings.observed-metadata — Observed metadata** [implemented]: Show actual applied model/effort/tier when available. Missing metadata remains unknown; saved preference is not running-request proof.

### Safety, Recovery & Portability (preservation)

- **preservation.existing-custody — Existing custody** [implemented]: Preserve existing source, native homes, bindings, identity, service owners, unique edits and unknown effects. Do not reset or replace a world to disguise a connection problem.
- **preservation.selected-imports — Selected imports** [implemented]: Treat deprecated code, rules, settings, hooks and assets as read-only reference until the human selects an exact import.
- **preservation.no-extra-effects — Bounded effects** [implemented]: Rules do not automatically authorize new agents, monitors, unrelated cleanup, installation, hosting, audience changes or public release.
- **preservation.close-task-tabs — Close finished task tabs** [documented]: Each agent tracks the exact browser tabs and temporary previews it creates. Once a task, request, handoff, cancellation or completed computer-use step no longer needs them, save the necessary result/evidence and close those owned temporary tabs through supported browser controls before reporting closeout. Verify the known tab IDs are absent from the accessible inventory. Keep user-owned tabs, another active agent's tabs, unsaved work and explicitly requested deliverables open. Ownership uncertainty or an unavailable close control stays an explicit unresolved item; do not bulk-close a browser or stop a shared service. On the next assignment, start from a fresh task-owned tab instead of accumulating old test/demo/duplicate previews.
- **preservation.release-computer-control — Return computer control and clear the blue effect** [documented]: At the end of computer/browser work, or when returning control for a wait or handoff, settle outstanding input/capture and use the supported host end-session/completion action immediately after the final UI observation, before continuing non-UI work or reporting completion. For cua_repl, the next call is the completion_summary-only action exactly once; observe a user handoff's outcome before summarizing it. End the agent's own session so its blue computer-use tint/border/overlay clears and the human regains control. Keep any genuine other owner's active computer session intact. Do not disable safety indicators, change host security settings, kill helpers or claim the overlay disappeared without evidence. If the host cannot release it or its visible disappearance cannot be verified, report that exact remaining limitation and preserve the real session/effect state.

### Delivery & Acceptance (delivery)

- **delivery.sync-before-push — Sync before pushing** [documented]: Fetch and integrate the latest changes from the approved Git remote before pushing completed work. Preserve concurrent edits; never force-push or discard unique work to make publication easier.
- **delivery.publish-completed-work — Publish completed work** [documented]: After authorized changes are finished and their affected checks pass, commit and push the scoped changes to the approved Git remote. Respect any later explicit human hold or changed publication scope.
- **delivery.update-existing-site — Explicit website publication** [documented]: Prepare and check local website changes, but do not deploy, upload, replace or update the hosted website until the human explicitly instructs publish to website. Completion of local work, a Git push, a /world or /rule edit, prior website authorization or a prepared handoff does not trigger deployment. This supersedes the earlier automatic website-update rule. After an explicit publish instruction, use the existing authorized site owner, destination and audience, then verify the actual hosted result. Keep public/private access boundaries and separate installation permissions.
- **delivery.maintain-rule-docs — Documentation and active-rule cleanup** [documented]: After every /world, /plugin, /rule, /universal or other command that adds or changes rules, update the owning manuals and regenerate the grouped views and prompts. Review meanings for duplicate, superseded, old, deprecated or conflicting active instructions; consolidate compatible facets by subject/property and retain required inactive history only as clearly non-authoritative evidence. Current human intent wins; ask for a genuinely missing decision instead of silently adopting a conflict. Record actual behavior, checks and limits; saving documentation alone is not implementation, publication or installation.

### Site Presentation & Status Palette (site-presentation)

- **site-presentation.progress — Progress** [documented]: Use green for the site progress status.
- **site-presentation.backlog — Backlog** [documented]: Use blue for the site backlog status.
- **site-presentation.blocked — Blocked** [documented]: Use red for the site blocked status.
- **site-presentation.idle — Idle** [documented]: Use lavender for the site confirmed idle status.
- **site-presentation.accepted — Accepted** [documented]: Use pale green only for the site evidence-backed accepted status.
- **site-presentation.semantics — Status meaning** [documented]: Keep status text and readable contrast. Colors never change task/agent state or invent progress, acceptance or freshness; unknown/stale data stays neutral. This site rule is plugin scope and is excluded from the world-only prompt.

### Viewport & Touch (mobile-layout)

- **mobile-layout.portrait — Portrait composition** [documented]: Use deliberate full-height portrait composition with safe areas, readable touch controls and contained content.
- **mobile-layout.landscape — Landscape composition** [documented]: Fit landscape independently rather than treating a simulated portrait width as landscape acceptance.
- **mobile-layout.browser-zoom — Browser zoom** [documented]: Keep native browser text and pinch zoom enabled. Camera controls must not disable accessibility zoom.
- **mobile-layout.physical-checks — Physical and native checks** [documented]: Record physical-phone and native-panel checks independently from simulated browser widths.

### Camera (camera)

- **camera.zoom-pan — Camera zoom and pan** [documented]: Support 100–300% camera zoom and bounded pan using one shared transform for art, actors, plaques, labels and hit testing. Keep native browser zoom enabled.

### Typography (typography)

- **typography.white-text — World text** [documented]: Use white ALife World text with readable contrasting backgrounds.
- **typography.licensed-fonts — UI fonts** [documented]: Use available licensed UI fonts and retain any required attribution; do not redistribute unlicensed font files.

### Plugin Presentation (launcher)

- **launcher.planet-icon — Planet icon** [documented]: Retain the exact human-selected existing planet icon asset; this does not select any older code, hook, setting or other asset.
- **launcher.open-worlds — Launcher wording** [documented]: Use Open ALife Worlds for accessing project worlds/sites. Prepared metadata wording is separate from an actually tested native side panel; preserve the current connection/installation hold.

### Image Reference Workflow (image-workflow)

- **image-workflow.inspect-all — Inspect every image** [documented]: On first invocation with a supplied image folder, inventory and visually inspect EVERY image before choosing a coherent style/aesthetic; a full prose description is optional.
- **image-workflow.generate-integrate — Generate and integrate** [documented]: Use the reviewed references to generate needed coherent sprites/images, preserve useful transparency/scale/pivots, inspect each result and integrate it into the actual renderer. Never claim a supplied folder was inspected or assets generated when no folder/tool/result exists.

### Custom Worlds & Upgrades (custom-worlds)

- **custom-worlds.preserve-worlds — Preserve custom worlds** [documented]: Plugin upgrades preserve each existing custom world, its identity, artwork/assets, configuration and local world data. Never clear, replace or force the user to rebuild or set up that custom world again.
- **custom-worlds.preserve-rules — Preserve custom rules and edits** [documented]: Keep custom world rules, overrides and the user’s changes across plugin updates. New bundled defaults must not silently overwrite or reset those custom values.
- **custom-worlds.update-defaults — Update bundled defaults** [documented]: Apply default-world updates to the world bundled with the plugin and update compatible shared plugin code while retaining custom-world content and overrides. Do not automatically copy default artwork, music or rules over a custom world.
- **custom-worlds.recoverable-merge — Recoverable customization merge** [documented]: Preserve recovery for custom content before conflicting or replacing updates. Merge compatible changes without losing user work; if a conflict prevents a safe merge, keep the existing custom world usable rather than wiping it or forcing re-setup.

### Private & Public World Links (links-and-access)

- **links-and-access.private-link — Private operator link** [documented]: Provide a distinct private operator world link with the plugin for the selected project, usable on phone and computer. Hosted access requires sign-in and server-side owner authorization; a hidden URL or presentation mode is not access control.
- **links-and-access.private-editing — Private project editing** [documented]: The private operator world lets its owner view and modify the selected project, including its sprints, world settings and custom rules. Preserve canonical records, stable identities, existing work and recoverable history; use revision-aware edits and do not turn a planning edit into task acceptance or observed agent activity.
- **links-and-access.private-messages — Real private agent messages** [documented]: Support explicit owner-initiated real messages to the selected project’s exact existing bound agents through a supported authenticated transport. Preserve recipient and request identities, prevent duplicate sends, distinguish queued, delivered, failed and unknown results, and retain current agent settings. Keep dispatch unavailable until the actual connector is implemented and verified; world animation is not a delivery receipt.
- **links-and-access.public-link — Shared world, read-only public viewer** [documented]: When the owner has authorized a public website viewer, use the same maintained world renderer/art and current canonical progress as the local world. Prepare and verify matching qualified world source for the website, while keeping its sanitized display distinct from private operator data. Public visitors cannot alter sprints, tasks, real agent work or invoke native commands. Any later operational access requires the human explicit authorization and the actual supported authenticated capability; a display toggle or decorative interaction never grants it. Private creation alone does not publish a world. Website deployment follows the explicit publish-to-website gate.
- **links-and-access.public-domain — Public website and domain** [documented]: Allow the optional public viewer to connect to an owner-selected website or custom domain through the supported hosting/domain workflow. Keep its audience and destination independent of the private operator link; a domain change never exposes the private dashboard.
- **links-and-access.access-isolation — Keep private and public access separate** [documented]: Keep private sprint/task details, project editing, agent message endpoints, native identities and credentials behind the private owner boundary. Public visitors cannot read private operator data or invoke its actions; do not use a display-mode toggle as an audience switch.
- **links-and-access.public-fullscreen — Public viewer fullscreen** [documented]: Provide an accessible fullscreen control for the public world viewer. Use supported browser fullscreen with an exit path and a dedicated full-window viewer fallback where native fullscreen is unavailable, while keeping the public view read-only.


## Complete reviewed World Rules

### Appearance & Layout (appearance)

- **appearance.style — Style** [implemented]: Use the current procedural ALife World colony with warm sand, muted soil, sage/brass accents and blue water. Preserve its existing artwork unless the human selects a replacement.
- **appearance.agents — Agents** [implemented]: Render the same six-legged articulated ALife Agents and role costumes. Actual observed model identity controls the maintained family colors, relative visual body sizes and trail shapes. Preserve real model, reasoning effort, speed, status and anatomy; these appearance sizes do not alter native settings or navigation.
- **appearance.rooms — Rooms** [implemented]: Use compact front-facing soil rooms with floor-grounded beds/plants and wall-mounted props. Keep the hill entrance and travel shaft clear.
- **appearance.model-loot-colors — Observed model appearance** [implemented]: Use the approved muted model palette and strictly descending relative body size at the same pose: Astra largest, lavender/purple with star-like trails; Sol 6.1 second largest, orange/gold with diamond-like trails; Sol 6 medium, blue with dotted trails; Terra second smallest, green with leafy trails; Luna smallest, pale gold with ring-like trails. Derive appearance from actual observed model identity. Unrecognized or unavailable model metadata stays unknown with a neutral gray fallback. This replaces the earlier legendary-orange/epic-purple/rare-blue loot palette. Never change real model selection, reasoning effort, speed, status or custom-world overrides.
- **appearance.ant-key — Collapsible Ant key** [implemented]: Provide a compact, initially collapsed Ant key near the world controls. Use the same production ant silhouettes to explain each model family color and relative body size. It is a generic appearance guide, not a roster or a claim about running models. Keep it within existing metadata privacy boundaries and omit it from the sanitized public viewer. Do not restore the old bottom speed strip, weather caption or gem-click text.

### Activity & Progress (activity)

- **activity.working — Working** [implemented]: Only fresh actual native/report evidence drives work trips and gestures; task ownership or stage alone does not prove activity.
- **activity.idle — Awake Idle** [documented]: Confirmed Idle with existing eligible work stays awake; native idle is not automatically Sleeping.
- **activity.unavailable — Unavailable** [implemented]: Stop busy-work routines for missing/stale activity. Do not fabricate fresh work through polling.
- **activity.blockers — Blocked alarms and fire** [documented]: A real unresolved blocker shows fire and an exclamation mark. Wake a blocked sleeper and circle its burning bed; a travelling blocked ALife Agent stops with fire ahead. Keep the incident until canonical resolution.
- **activity.sleeping — Sleeping** [documented]: An idle ALife Agent with no current eligible work sleeps gray in a tucked rest pose, eyes closed, with animated Zzz.
- **activity.retirement — Retirement ghost and grave** [documented]: A genuine recorded retirement need shows a wandering ghost with an exclamation mark and a gravestone at the body location. Keep the gray corpse and flies until verified recovery; stale or idle alone never means dead.
- **activity.wake-task-search — Wake Up and Director request** [documented]: Show Wake Up for an eligible sleeping ALife Agent. Through a verified enabled connector, look for work it can actually tackle; if no eligible task exists, send a real request to the current Director to assign useful next work and help move the project forward. Keep it sleeping if no assignment results. Unavailable transport cannot simulate a sent request or fabricate work.
- **activity.unblock-request — Unblock request** [documented]: Show Unblock for an actual blocked ALife Agent. A verified enabled action tells current Agent Support that this exact agent/task needs help; clicking does not resolve it. Keep unavailable when native transport is disabled.
- **activity.retire-request — Retire request** [documented]: Show Retire for a genuine recorded retirement need. A verified enabled action tells current Agent Support that the agent needs retirement, preserving current continuity rules; never retire through animation or an unavailable connector.
- **activity.disabled-tooltips — Unavailable action reasons** [documented]: When a name-plaque action is gray or disabled, hovering its control or surrounding plaque shows the exact current reason in a native cursor tooltip. Keep the reason available to keyboard/touch accessibility too, including unavailable connection, current agent/task eligibility and pending request state.
- **activity.sprint-tree — Selected sprint tree** [implemented]: A side tree represents the currently selected real sprint. Grow from a seed at 0 percent toward a full tree at 100 percent using only the canonical sprint progress already used by the world. Selecting another sprint updates this same representation. No active sprint or valid progress shows unavailable feedback rather than fabricated zero or completion. Preserve role trees, their existing exceptions, the acceptance ledger and resource behavior; mining and elapsed animation time grant no growth.
- **activity.tree-inspection — Transient sprint tree details** [implemented]: Show the selected sprint name and completion percentage only on hover, keyboard focus or a brief accessible touch inspection. Keep scene percentages hidden at rest, respect existing Private concealment and public sanitization, and show truthful no-active-sprint or unavailable feedback when appropriate.
- **activity.human-input-attention — Needs human input attention pose** [implemented]: When current verified lifecycle evidence explicitly requests human input or approval, the affected living ant faces the viewer, stands upright on its two rear legs, waves both front legs and makes small attention jumps like a character asking the viewer for help. Show a yellow triangle with a black exclamation mark above its head. Ordinary waiting, an intentional pause, a blocker, idle or stale activity alone must not trigger this pose. Preserve the existing ant anatomy, real task state, model/speed, blocker/recovery semantics and privacy; expose a bounded needs-input flag only to the local and authenticated owner-private world, never the public showcase or private request content. A resumed/completed request clears it. Pause, hidden-page, reduced-motion and stale-data guards stop autonomous attention motion; View remains noninteractive.

### Movement & Interaction (movement)

- **movement.routes — Routes and obstacle awareness** [documented]: Use grounded six-leg distance gait, real shaft/mound routes and safe paths around rocks, intact gems and rooms unless entering the intended room. Broken gem debris is walkable; wait if no safe route exists.
- **movement.supplies — Own-work supplies** [documented]: Fresh confirmed own-work randomly collects water, gems or outdoor grass. Plucked grass visibly disappears and regrows over time; collecting a gem spawns a replacement in a safe random underground position. Recorded addressed traffic has priority and resource trips earn no task credit.
- **movement.trails — Trails** [implemented]: Only actual eligible underground walking strengthens fixed-width sand wear. Clicks, dragging, falling and teleports do not carve progress or trails.
- **movement.controls — Interaction controls** [documented]: Keep room-anchored plaque details, local hop and safe pointer-captured drag/drop in interactive modes. Remove the separate magnifying-glass button. View disables plaques, mining, drag, hop, scenery taps and other world interactions.
- **movement.mail — Addressed messages** [documented]: An actual recorded addressed message is carried as an envelope visibly marked M to its real recipient. Never fabricate messages or count visual delivery as native receipt/task completion.
- **movement.diagonal — Forward diagonal walking** [documented]: Walking diagonally keeps the ant facing its actual travel direction with the same forward fore/aft tripod foot cycle, natural foot lift/plant and distance-driven stride as other directions. Avoid lateral sliding, sideways foot shuffles and abrupt perspective flips.
- **movement.speed — Baseline speed and progress-paced travel** [documented]: Keep regular baseline walking/research speed and a separate 1.5× walking mode that is always faster than the regular baseline. Message/activity travel pacing is separate: use actual recorded progress, status and timing to slow a long-running transfer, accelerate with faster real progress, and move very quickly toward its intended endpoint as actual delivery/completion approaches or is observed. This pacing may exceed 1.5×. Never change real agent settings or manufacture native progress/completion from animation time. Retain existing speed-streak and distinct dirt-footprint presentation for eligible faster walking.
- **movement.drag — Dangling drag** [documented]: Held ALife Agents dangle and animate their legs with no grounded steps/trails; resume safe travel after release.
- **movement.delivery-distance — Progress-aware dragging and catch-up** [documented]: Dragging away preserves the same recorded message/activity identity, recipient and intended destination. After any required landing, replan the remaining safe route from the released position and pace travel from that same operation’s actual progress/status. Near or completed operations use very fast non-teleporting catch-up to the endpoint, independent of the regular 1.5× walking mode. Visual catch-up grants no extra native delivery, work or task acceptance.
- **movement.room-details — Room-anchored details** [documented]: Clicking an ALife Agent name plaque opens a small popup anchored at its own room, with relevant current work, observed model/state and blocker details, respecting Private view.
- **movement.gravity — Outdoor gravity** [documented]: Dragged/released ALife Agents above outdoor ground fall with gravity, land on the actual mound or grass surface, then resume safe routing. Airborne and held motion creates no footprints or progress.
- **movement.big-legs — Grounded background human legs** [documented]: Give the large scenery legs realistic alternating planted feet, raised swing feet and coherent human proportions at a believable scale relative to the hill. Draw them behind the hill at a real background ground contact, with a separate nearer foreground layer for depth. Tapping makes the person jump or run away; scenery never changes real agent tasks.

### Privacy & Controls (site)

- **site.order — Page order** [implemented]: Show the world first, current sprint board, current assignments and recorded handoffs, agent responsibilities, then a collapsible epic/sprint plan with both progress meters visible in its header.
- **site.progress — Progress** [implemented]: Use evidence-backed credits with separate current-sprint and full-epic scope. Future work must not inflate selected-sprint execution or completion.
- **site.privacy — Private mode** [documented]: Private locks the world to one fitted screen and removes operational sections from layout instead of retaining masked scroll space. Block page scrolling until Public is restored.
- **site.view-mode — View mode** [documented]: View fits one screen, removes operational sections and locks page scrolling. Disable plaques, mining, drag, hops and other world interactions; viewing controls and the single Sound control remain available.
- **site.public-mode — Public mode** [documented]: Public restores ordinary page scrolling, including wheel scrolling with the pointer inside the world.
- **site.team-details — Collapsed team details** [documented]: Team responsibilities/details start collapsed and open only when the viewer chooses.
- **site.sand-mountains — Progress art** [documented]: Remove the bottom sand mountain/chamber artwork. Retain truthful evidence-backed sprint/epic progress in the site meters without decorative sand credit.
- **site.public-viewer — Read-only public viewer** [documented]: Provide a special world-only URL suitable for embedding on the existing landing page. It exposes a sanitized read-only view, cannot edit actual tasks/data or send native commands, and uses no AI/model calls or viewer-triggered agent work. Verify hosting/audience separately from a prepared local URL.

### Sound (sound-and-motion)

- **sound-and-motion.muted-start — Sound** [implemented]: Start every page load muted regardless of remembered privacy. Only the single Sound toggle enables/resumes audio; Wake, dragging, magnifying and other gestures never unmute it.
- **sound-and-motion.suppression — Motion guards** [implemented]: Pause, hidden pages and reduced motion suppress autonomous movement/effects/audio. Motion controls do not pause real agents.
- **sound-and-motion.one-toggle — One control** [implemented]: Use one Sound toggle.
- **sound-and-motion.short-spatial-cues — Short spatial cues** [implemented]: Use soft filtered/panned movement, water and prop cues with short gain envelopes and an approximately 65ms trigger cap.
- **sound-and-motion.immediate-mute — Immediate mute** [documented]: The one Mute/Sound control immediately silences every active cue, ambience and music loop and prevents new playback. Every load starts muted; no other gesture or remembered privacy choice unmutes.
- **sound-and-motion.licensed-assets — Bundled CC0 Freesound** [documented]: Every audible world/space/UI sample, including music, is bundled locally from Freesound with a verified CC0 license and author/source/license/hash manifest. Replace procedural audible synthesis; no runtime CDN fetch is needed.
- **sound-and-motion.listening-evidence — Listening evidence** [documented]: Verify physical listening separately from transport, code or gain checks; do not claim audible quality from a source test.
- **sound-and-motion.no-replayed-cues — No replay** [implemented]: Do not replay old completion-pour cues on refresh or unchanged observations.
- **sound-and-motion.mining-cues — Mining sound** [documented]: Play soft distinct click/chip/break mining cues sourced from Freesound.org for gem interaction, only after the single Sound toggle enables audio. Keep immediate mute, motion guards and bounded cue triggering.
- **sound-and-motion.music — Default-world lo-fi chill beat** [implemented]: Use the previously bundled CC0 Freesound Lofi Beat Loop Schmoop as the DEFAULT world background music, with the existing optional UI, water, grass and mining cues. The world music loop is the lo-fi beat; the separate galaxy ambience is not a replacement for it. Do not replace custom-world music. Every load starts muted, only the single Sound control enables audio, mute immediately silences everything, and Pause/hidden-page/reduced-motion guards remain active. Preserve the bundled author/source/license/hash manifest; no runtime online audio fetch is required.

### Agent Support & Rescue (rescue)

- **rescue.clinic — First responder room** [documented]: Agent Support has a first-responder medical/garage room, medical cross and alarms for genuine help incidents. Do not write CLINIC in the room.
- **rescue.ambulance — Ambulance and CPR** [documented]: For a genuine retirement incident, Agent Support uses an ambulance with flashing lights to reach the room, lifts the corpse from its grave and animates CPR beside it until verified recovery. The visual response does not itself revive or retire a native agent.
- **rescue.firetruck — Fire response** [documented]: For a genuine fire/blocker incident, Agent Support drives a firefighter truck to the affected ALife Agent and animates a water hose. Only actual issue resolution extinguishes the fire. Response movement requires actual assigned/observed Support work; an alert alone does not invent a real dispatch.

### Mining & Underground Materials (mining)

- **mining.obstacles — Materials and debris** [documented]: Place mining rocks/gems inside the hill; intact materials block walking. Broken gems remain as low debris and are walkable.
- **mining.clicks — Mining hits** [documented]: Each decorative rock or gem has one random requirement of 2–8 hits. Hits visibly chip, crack and shrink it in proportion to its own required total; the final hit leaves walkable debris. This supersedes the earlier 1–8 requirement and never changes a task or its progress.
- **mining.cursor — Dirt and tree feedback** [documented]: Clicks/touches on hill dirt create bounded dirt puffs; cursor dirt remains local. Tree taps release leaves. Mineral taps make chips/cracks. Respect motion guards and disable these interactions in View.

### Projects & Galaxy (projects)

- **projects.dropdown — Project selection** [documented]: Replace the site/world title with a dropdown of actual registered projects using this plugin. Use each project folder name as its displayed world name. Selecting a project resolves that exact world; unknown or mismatched IDs fail instead of falling back to another project.
- **projects.show-all — Galaxy overview** [documented]: Put Show all last in the dropdown. Show one planet per real registered world with stable random placement, and center the planet when only one exists. A world fits wholly inside its planet with no art or interaction bleeding outside.
- **projects.space — Space atmosphere** [documented]: Use coherent semi-realistic space art that accommodates differently styled world planets, with bounded decorative space motion, opt-in ASMR and interactions. It never fabricates projects, work or progress.

### Exterior & Terrain (exterior)

- **exterior.flies — Exterior flies** [documented]: Bounded decorative flies approach the exterior hill. Each fly gets one random target of 1–5 clicks; hitting that total makes that same fly leave. Keep the counter stable through redraws, avoid a task/progress effect, honor motion guards and disable fly interaction in View.
- **exterior.day-night — Day, night, sunrise and sunset** [documented]: Cycle the exterior smoothly through day, sunset, night and sunrise with coherent sky/ground lighting and a moving sun/moon. This is decorative local time, never agent work or task progress; Pause, hidden-page and reduced-motion guards stop autonomous animation.
- **exterior.night-fireflies — Night fireflies** [documented]: At night, bounded exterior fireflies appear and leave over time. Clicking a firefly makes it flee quickly away from the cursor with a fading glow. Respect motion guards and View interaction restrictions; do not confuse decorative fireflies with real pending-request indicators.
- **exterior.clouds — Parallax clouds** [documented]: Move clouds of different sizes in separate depth/parallax layers, with coherent gentle drift, restrained opacity and motion guards.
- **exterior.soil-depth — Dirt depth gradient** [documented]: Give the dirt layer a readable depth gradient that becomes darker toward the bottom, preserving artwork, white text and agent/prop contrast.
- **exterior.surface-band — Thick grass–dirt transition** [documented]: Add a thicker continuous transition layer between exterior grass and underground dirt, connecting the visible hill into the ground with coherent edge texture and roots.
- **exterior.foreground — Exterior depth layers** [documented]: Keep distant feet/legs behind the hill, the hill and agents in their grounded middle plane, and a separate nearer foreground detail layer. Preserve clear travel silhouettes, ground contact and occlusion instead of making all exterior art share one flat plane.

### Special Forces Exterior Defense (defense)

- **defense.unit — Three-soldier visual unit** [documented]: Fresh observed Special Forces work on its real assigned issue sends a three-ant soldier-costumed visual unit together from its room to the exterior hill top to defend it. These are the existing role avatar plus visual squad companions, not newly created native agents, chats or tasks; the actual roster remains unchanged.
- **defense.wasps — Wasps and projectiles** [documented]: While the real assigned issue remains unresolved and activity is verified, spawn bounded animated enemy wasps that approach, throw projectiles and attack the soldier unit. Soldiers shoot or throw weapon projectiles back. Local random exchanges can kill either side visually; keep movement, attacks and death animations readable and bounded.
- **defense.casualties — Visual deaths and reinforcements** [documented]: Show distinct animated soldier and wasp defeats. Replace a fallen soldier with a new visual reinforcement that travels to join the unit, and continue bounded wasp waves during the unresolved issue. Cosmetic casualties never mark a native agent dead/retired, change identities or grant task credit.
- **defense.resolution — Verified defense resolution** [documented]: Only actual task/issue resolution ends defense: stop new wasps, animate remaining enemies being cleared, and return the soldier unit to its real room. Missing/stale activity pauses the represented fight rather than inventing victory or resolution. Apply Pause, hidden-page and reduced-motion guards and keep View interaction disabled.

## Evidence and limits

Exact input snapshots and all candidate evidence/wording are in runtime/step4-rules-review-20261106/comparison.json and reviewed-authoring-plugin/world.json. Reviewer originals stay in the existing Technical Support and Director homes. Private prompts/transcripts, credentials, native bindings and live task stores are excluded from this report.

Scope: owning product, operating, connection, role, startup/intake/retirement/clone/reset/view contracts and current registries/shared roles. This is not exhaustive execution/security review of every legacy file. Earlier87-row totals are historical. Candidate groups overlap and must not be summed as a count of unique rules.

Every humanSelection is null; every adopted flag is false. No deprecated rule/code/hook/asset/settings import follows from the review. The separately approved local-world activation and version-number refresh have independent receipts and change no migration decision.

