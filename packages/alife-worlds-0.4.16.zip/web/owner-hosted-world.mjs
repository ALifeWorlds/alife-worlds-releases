import './audio.mjs';
import './agent-outpost/colony-art.js';
import './agent-outpost/agent-outpost.js';
import {createOwnerOperatorViewport} from './owner-operator-viewport.mjs';

export const HOSTED_OWNER_PREVIEW_LIMIT=327680;
export function hostedOwnerContext(value,{windowRef=window}={}){
 try{
  const q=new URLSearchParams(windowRef.location.search),keys=['embed','project','hostOrigin'];
  if(!value||value.schemaVersion!==1||value.access!=='owner-private'||typeof value.worldId!=='string'||!/^world-[a-z0-9-]{1,58}$/.test(value.worldId)||value.ownerOrigin!==windowRef.location.origin||windowRef.location.pathname!=='/operator'||windowRef.location.hash||windowRef.parent===windowRef||windowRef.parent.location.origin!==value.ownerOrigin||[...q.keys()].length!==keys.length||keys.some(key=>q.getAll(key).length!==1)||q.get('embed')!=='1'||q.get('project')!==value.worldId||q.get('hostOrigin')!==value.ownerOrigin)return null;
  if(value.worldVersion!==null&&(typeof value.worldVersion!=='string'||!/^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$/.test(value.worldVersion)))return null;
  const renderer=value.renderer,fields=['schemaVersion','bundleId','worldVersion','artifactSha256'];if(renderer!==null&&(!renderer||Object.keys(renderer).length!==fields.length||fields.some(key=>!Object.hasOwn(renderer,key))||renderer.schemaVersion!==1||typeof renderer.bundleId!=='string'||!/^[a-z][a-z0-9-]{0,79}$/.test(renderer.bundleId)||typeof renderer.worldVersion!=='string'||!/^\d+\.\d+\.\d+$/.test(renderer.worldVersion)||typeof renderer.artifactSha256!=='string'||!/^[a-f0-9]{64}$/.test(renderer.artifactSha256)))return null;
  return value;
 }catch{return null;}
}

export function createHostedOwnerWorld({context,windowRef=window,documentRef=document,fetcher=fetch,renderer=globalThis.AgentOutpost,viewportFactory=createOwnerOperatorViewport,autoStart=true}={}){
 context=hostedOwnerContext(context,{windowRef});if(!context)throw Error('Exact private owned frame required.');
 const main=documentRef.getElementById('owner-hosted-world'),anchor=documentRef.getElementById('world-anchor'),status=documentRef.getElementById('world-profile-status');if(!main||!anchor||!status||typeof renderer?.mount!=='function')throw Error('Owned frame surface unavailable.');
 const farm=renderer.mount(anchor,{cosmeticOnly:true,operatorPresentation:true,presentationMode:'view',defaultWorld:context.renderer!==null,transparentBackground:true,fillViewport:true});
 let viewport;try{viewport=viewportFactory({farm,context,windowRef,documentRef});}catch(error){farm.destroy?.();throw error;}
 farm.setAudioPreferenceKey?.(context.worldId);farm.setWorldVersion?.(context.worldVersion);
 let disposed=false,active=null,timer=null;
 const progress=input=>({sprint:input.snapshot.summary.current,epic:input.snapshot.summary.epic});
 function unavailable(){
  if(disposed)return;
  viewport.unavailable();const held=viewport.cachedInput();main.dataset.sourceState='unavailable';status.hidden=false;status.textContent='Selected world updates unavailable.';
  if(held)try{farm.render(held.model,{...held.feed,error:'Owner world updates unavailable'},progress(held));}catch{}
 }
 async function refresh(){
  if(disposed||documentRef.hidden||active)return;windowRef.clearTimeout(timer);timer=null;const controller=new AbortController();active=controller;const deadline=windowRef.setTimeout(()=>controller.abort(),8000);let discardPrivateScene=false;
  try{
   const url=new URL('/api/owner-world-preview',context.ownerOrigin);url.searchParams.set('project',context.worldId);
   const response=await fetcher(url.href,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',headers:{Accept:'application/json'},signal:controller.signal});
   if([401,403].includes(response.status))discardPrivateScene=true;
   if(!response.ok||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')||'')||Number(response.headers.get('content-length'))>HOSTED_OWNER_PREVIEW_LIMIT)throw Error('Owner world unavailable.');
   const reader=response.body.getReader(),parts=[];let size=0;
   try{while(true){const row=await reader.read();if(row.done)break;size+=row.value.byteLength;if(size>HOSTED_OWNER_PREVIEW_LIMIT){await reader.cancel();throw Error('Owner preview too large.');}parts.push(row.value);}}finally{reader.releaseLock();}
   const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}const preview=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
   if(preview?.schemaVersion!==3||preview.kind!=='owner-world-preview'||preview.worldId!==context.worldId){discardPrivateScene=true;throw Error('Owner preview identity/version mismatch.');}
   if(disposed||documentRef.hidden||controller.signal.aborted)throw Error('Owner read no longer current.');const input=await viewport.resolve(preview);
   if(disposed||documentRef.hidden||controller.signal.aborted)throw Error('Owner read no longer current.');if(!input)throw Error('Exact world join unavailable.');
   farm.render(input.model,input.feed,progress(input));if(!viewport.rendered(input))throw Error('World render unavailable.');main.dataset.sourceState='ready';status.hidden=true;status.textContent='';
  }catch{controller.abort();if(!disposed){if(discardPrivateScene){dispose();main.dataset.sourceState='unavailable';status.hidden=false;status.textContent='Private world access or identity changed. Reopen the verified owner Site.';}else unavailable();}}
  finally{windowRef.clearTimeout(deadline);if(active===controller)active=null;if(!disposed&&!documentRef.hidden)timer=windowRef.setTimeout(()=>void refresh(),5000);}
 }
 function visibility(){windowRef.clearTimeout(timer);timer=null;farm.setWorldVisible?.(!documentRef.hidden);if(documentRef.hidden){active?.abort();unavailable();}else void refresh();}
 function dispose(){if(disposed)return;disposed=true;windowRef.clearTimeout(timer);active?.abort();viewport.dispose();farm.destroy?.();documentRef.removeEventListener('visibilitychange',visibility);windowRef.removeEventListener('pagehide',dispose);}
 documentRef.addEventListener('visibilitychange',visibility);windowRef.addEventListener('pagehide',dispose,{once:true});farm.setWorldVisible?.(!documentRef.hidden);if(autoStart)void refresh();
 return Object.freeze({refresh,dispose,unavailable});
}

if(typeof document!=='undefined'){
 const main=document.getElementById('owner-hosted-world');if(main){try{const context=JSON.parse(main.dataset.ownerContext);createHostedOwnerWorld({context});}catch{const status=document.getElementById('world-profile-status');if(status){status.hidden=false;status.textContent='Selected private world unavailable.';}main.dataset.sourceState='unavailable';}}
}
