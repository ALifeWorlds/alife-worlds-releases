import {configureScrollableList,preserveListPositions} from './list-presentation.mjs';
import {validatePortablePacket,portableClipboard,PORTABLE_MAX_BYTES,LOGICAL_ID} from './portable-definitions.mjs';

export const OWNER_RULE_LIBRARY_LIMIT=PORTABLE_MAX_BYTES*2+8192;
const closed=(value,keys)=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
export function assertOwnerRuleLibraryResponse(value,{worldId}={}){
 if(!closed(value,['schemaVersion','kind','worldId','scopes'])||value.schemaVersion!==1||value.kind!=='owner-rule-library'||typeof value.worldId!=='string'||!/^world-[a-z0-9-]{1,58}$/.test(value.worldId)||worldId!==undefined&&value.worldId!==worldId||!Array.isArray(value.scopes)||value.scopes.length!==2)throw Error('Exact owner rule library required.');
 const seen=new Set(),scopes=value.scopes.map(row=>{
  if(!closed(row,['scope','revision','packet'])||!['plugin','world'].includes(row.scope)||seen.has(row.scope)||!Number.isSafeInteger(row.revision)||row.revision<0)throw Error('Invalid rule scope.');seen.add(row.scope);
  const source=row.packet;if(!closed(source,['format','schemaVersion','kind','title',row.scope])||source.schemaVersion!==2||source.kind!==row.scope||!closed(source[row.scope],['groups']))throw Error('Only active portable v2 rule groups are permitted.');
  for(const group of source[row.scope].groups||[])for(const property of group.properties||[])if(!Object.hasOwn(property,'description'))throw Error('Human rule descriptions are required.');
  return {scope:row.scope,revision:row.revision,packet:validatePortablePacket(source)};
 });
 const result={schemaVersion:1,kind:'owner-rule-library',worldId:value.worldId,scopes};
 if(new TextEncoder().encode(JSON.stringify(result)).byteLength>OWNER_RULE_LIBRARY_LIMIT)throw Error('Owner rule library exceeds its bound.');
 return result;
}

export function selectRuleLibraryPacket(value,{scope,groupId,propertyId}={}){
 const library=assertOwnerRuleLibraryResponse(value),row=library.scopes.find(row=>row.scope===scope);if(!row||propertyId!==undefined&&groupId===undefined||[groupId,propertyId].some(id=>id!==undefined&&(typeof id!=='string'||!LOGICAL_ID.test(id))))throw Error('Exact rule selection required.');
 let packet=row.packet;if(groupId!==undefined){const group=packet[scope].groups.find(group=>group.id===groupId);if(!group)throw Error('Rule group unavailable.');let selected=group;if(propertyId!==undefined){const property=group.properties.find(property=>property.id===propertyId);if(!property)throw Error('Rule unavailable.');selected={...group,properties:[property]};}packet={...packet,title:propertyId===undefined?group.title:selected.properties[0].title,[scope]:{groups:[selected]}};}
 return validatePortablePacket(packet);
}

export function mountOwnerRuleLibrary(container,{worldId,request,clipboard,download,documentRef=container?.ownerDocument??globalThis.document}={}){
 if(!container||!documentRef||typeof worldId!=='string'||!/^world-[a-z0-9-]{1,58}$/.test(worldId))throw Error('Owner rule library container and exact world required.');
 const make=(tag,className,text)=>{const node=documentRef.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node;};
 const section=make('details','wf-rule-library'),heading=make('summary','','Rules'),body=make('div','wf-rule-library-body'),status=make('p','wf-mini','Open Rules to read the current definitions.'),content=make('div','wf-rule-library-scopes'),refreshButton=make('button','wf-button','Refresh rules');refreshButton.type='button';status.setAttribute('role','status');body.append(status,refreshButton,content);section.append(heading,body);container.replaceChildren(section);
 let library=null,libraryKey='',disposed=false,sequence=0,busy=false;
 const copy=clipboard??(text=>{if(!globalThis.navigator?.clipboard?.writeText)throw Error('Clipboard unavailable.');return globalThis.navigator.clipboard.writeText(text);});
 const clone=download??((text,name)=>{const url=URL.createObjectURL(new Blob([text],{type:'application/json'})),link=make('a');link.href=url;link.download=name;documentRef.body.append(link);try{link.click();}finally{link.remove();URL.revokeObjectURL(url);}});
 const unavailable=(message='Rules unavailable. Refresh to retry.')=>{if(disposed)return;sequence++;library=null;libraryKey='';content.replaceChildren();status.textContent=message;};
 function exportsFor(selection,label){
  const actions=make('div','wf-rule-actions');for(const action of ['Copy import','Clone definition']){const button=make('button','wf-button',action);button.type='button';button.setAttribute('aria-label',action+': '+label);button.onclick=async()=>{if(disposed||!library)return;button.disabled=true;try{const packet=selectRuleLibraryPacket(library,selection);if(action==='Copy import')await copy(portableClipboard(packet));else await clone(JSON.stringify(packet,null,2)+'\n',(selection.scope+'-'+(selection.groupId||'rules')+(selection.propertyId?'-'+selection.propertyId:'')+'.json'));if(!disposed)status.textContent=action==='Copy import'?'Import command copied. Review it in the destination before applying.':'Definition saved. Review it in the destination before applying.';}catch{if(!disposed)status.textContent=action==='Copy import'?'Could not copy. Check clipboard access and retry.':'Could not save this definition.';}finally{button.disabled=disposed||!library;}};actions.append(button);}return actions;
 }
 function update(value){
  if(disposed)return;let next;try{next=assertOwnerRuleLibraryResponse(value,{worldId});}catch{unavailable();throw Error('Owner rule library refused.');}
  const nextKey=JSON.stringify(next);if(nextKey===libraryKey){library=next;status.textContent='Current effective Plugin and World definitions. Copying or cloning does not apply them.';return;}
  const restore=preserveListPositions(content);const open=new Set([...content.querySelectorAll('details[data-rule-key]')].filter(node=>node.open).map(node=>node.dataset.ruleKey));library=next;libraryKey=nextKey;const fragment=documentRef.createDocumentFragment();
  for(const scope of ['plugin','world']){const row=next.scopes.find(row=>row.scope===scope),scopeNode=make('details','wf-rule-scope'),label=scope==='plugin'?'Plugin rules':'World rules';scopeNode.dataset.ruleKey=scope;scopeNode.open=open.has(scope);scopeNode.append(make('summary','',label),make('p','wf-mini','Definition revision '+row.revision),exportsFor({scope},label));
   const groups=configureScrollableList(make('div','wf-rule-groups'),row.packet[scope].groups.length,label+' groups',scope+':groups');for(const group of row.packet[scope].groups){const groupNode=make('details','wf-rule-group');groupNode.dataset.ruleKey=scope+'.'+group.id;groupNode.open=open.has(groupNode.dataset.ruleKey);groupNode.append(make('summary','',group.title),exportsFor({scope,groupId:group.id},group.title));const properties=configureScrollableList(make('div','wf-rule-properties'),group.properties.length,group.title+' rules',scope+':'+group.id);for(const property of group.properties){const item=make('article','wf-rule-property'),instruction=make('details','wf-rule-instruction');instruction.dataset.ruleKey=scope+'.'+group.id+'.'+property.id+'.ai';instruction.open=open.has(instruction.dataset.ruleKey);item.append(make('h4','',property.title),make('p','wf-rule-description',property.description));instruction.append(make('summary','','AI instructions'),make('pre','wf-rule-ai',property.text));item.append(instruction,exportsFor({scope,groupId:group.id,propertyId:property.id},property.title));properties.append(item);}groupNode.append(properties);groups.append(groupNode);}scopeNode.append(groups);fragment.append(scopeNode);
  }content.replaceChildren(fragment);restore();status.textContent='Current effective Plugin and World definitions. Copying or cloning does not apply them.';
 }
 async function refresh(){if(disposed||busy||typeof request!=='function')return;busy=true;const own=++sequence;refreshButton.disabled=true;status.textContent='Reading current rules…';try{const value=await request();if(!disposed&&own===sequence)update(value);}catch{if(!disposed&&own===sequence)unavailable();}finally{busy=false;refreshButton.disabled=disposed;}}
 const onToggle=()=>{if(section.open)void refresh();};section.addEventListener('toggle',onToggle);refreshButton.onclick=()=>void refresh();
 return Object.freeze({update,unavailable,refresh,isOpen:()=>section.open,dispose(){if(disposed)return;disposed=true;sequence++;library=null;section.removeEventListener('toggle',onToggle);refreshButton.onclick=null;container.replaceChildren();}});
}
