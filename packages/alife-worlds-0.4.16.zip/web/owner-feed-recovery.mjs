const closed=(v,keys)=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const utc=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v)&&Number.isFinite(Date.parse(v));
const descriptor=v=>closed(v,['schemaVersion','bundleId','worldVersion','artifactSha256'])&&v.schemaVersion===1&&typeof v.bundleId==='string'&&/^[a-z0-9][a-z0-9-]{0,79}$/.test(v.bundleId)&&typeof v.worldVersion==='string'&&/^\d{1,5}\.\d{1,5}\.\d{1,5}$/.test(v.worldVersion)&&typeof v.artifactSha256==='string'&&/^[a-f0-9]{64}$/.test(v.artifactSha256);
const key=d=>[d.schemaVersion,d.bundleId,d.worldVersion,d.artifactSha256].join('|');
const preference=s=>closed(s,['mode','paused','volume','soundEnabled'])&&['public','private','view'].includes(s.mode)&&typeof s.paused==='boolean'&&typeof s.volume==='number'&&Number.isFinite(s.volume)&&s.volume>=0&&s.volume<=1&&typeof s.soundEnabled==='boolean';

// This is only an update hint from the existing protected GET. It never
// accepts new-artifact data for rendering or supplies a navigation URL.
export function sameWorldUpdate(value,{worldId,current,now=Date.now()}={}){
 if(!descriptor(current)||!closed(value,['schemaVersion','kind','worldId','renderer','snapshot','appearance','names','metadata'])||value.schemaVersion!==3||value.kind!=='owner-world-preview'||value.worldId!==worldId||value.snapshot?.world?.id!==worldId||value.snapshot?.feed?.error!==null||!descriptor(value.renderer)||!utc(value.snapshot?.observedUtc)||value.appearance?.worldId!==worldId||!descriptor(value.appearance?.renderer)||key(value.appearance.renderer)!==key(value.renderer)||value.appearance.observedUtc!==value.snapshot.observedUtc||!Number.isSafeInteger(value.metadata?.revision)||value.metadata.revision<0||!/^[a-f0-9]{64}$/.test(value.metadata?.contentHash))return null;
 const age=now-Date.parse(value.snapshot.observedUtc);if(!Number.isFinite(age)||age< -5000||age>45000||key(value.renderer)===key(current))return null;
 return Object.freeze({target:key(value.renderer),version:value.renderer.worldVersion,immutableVersionConflict:value.renderer.worldVersion===current.worldVersion});
}

export function createOwnerFeedRecovery({worldId,current,status,documentRef=document,storage,capture=()=>null,restore=()=>{},canAutoReload=()=>true,reload=()=>location.reload(),now=Date.now}={}){
 if(typeof worldId!=='string'||!worldId||!descriptor(current)||!status)throw Error('Exact owner recovery scope required');
 if(storage===undefined)try{storage=globalThis.sessionStorage;}catch{storage=null;}
 const storageKey='alife-owner-world-recovery:'+worldId;let attempted=null,pending=null,target=null,reloading=false,resumeSound=false;
 function read(){try{const text=storage.getItem(storageKey);if(!text||text.length>2048)return;const v=JSON.parse(text);if(!closed(v,['schemaVersion','worldId','attempted','pending'])||v.schemaVersion!==1||v.worldId!==worldId||v.attempted!==null&&(typeof v.attempted!=='string'||v.attempted.length>200)||v.pending!==null&&!preference(v.pending))return;attempted=v.attempted;pending=v.pending;}catch{}}
 function save(nextAttempt,nextPending){try{const text=JSON.stringify({schemaVersion:1,worldId,attempted:nextAttempt,pending:nextPending});storage.setItem(storageKey,text);if(storage.getItem(storageKey)!==text)return false;attempted=nextAttempt;pending=nextPending;return true;}catch{return false;}}
 function paint(state,text,{reconnect=false,keepMuted=false}={}){status.hidden=false;status.dataset.ownerFeedStatus=state;const label=documentRef.createElement('span');label.textContent=text;status.replaceChildren(label);if(reconnect){const button=documentRef.createElement('button');button.type='button';button.textContent='Reconnect world';button.title='Reloads this same world, keeping view, motion and volume. Sound starts muted after a page load.';button.addEventListener('click',()=>navigate(true));status.append(button);}if(keepMuted){const button=documentRef.createElement('button');button.type='button';button.textContent='Keep muted';button.addEventListener('click',()=>{resumeSound=false;status.hidden=true;status.replaceChildren();});status.append(button);}}
 function navigate(manual=false){if(reloading)return false;const preferences=capture(),safe=preference(preferences)?preferences:null,identity=target?.target??key(current);if(!manual&&(!canAutoReload()||attempted===identity))return false;const persisted=save(identity,safe);if(!manual&&!persisted)return false;reloading=true;paint('reconnecting','Reconnecting this world…');reload();return true;}
 read();if(pending){const preferences=pending;pending=null;save(attempted,null);resumeSound=preferences.soundEnabled;restore(preferences);}
 paint('connecting','Connecting to world updates…');
 return{
  // A changed descriptor does not prove a replacement scene is mounted and ready.
  // Keep the current page; only explicit Reconnect navigates in this interface.
  consider(value){if(reloading)return true;const update=sameWorldUpdate(value,{worldId,current,now:now()});if(!update)return false;target=update;if(update.immutableVersionConflict){paint('unverified','World updates could not be verified. Showing the last snapshot.',{reconnect:true});return true;}paint('update-available','A world update is available. Reconnect when you choose.',{reconnect:true});return true;},
  current(){target=null;if(reloading)return;if(resumeSound&&capture()?.soundEnabled!==true){paint('ready-muted','World reconnected. Use Sound to resume playback.',{keepMuted:true});return;}resumeSound=false;status.hidden=true;status.dataset.ownerFeedStatus='current';status.replaceChildren();},
  unavailable({hasSnapshot=false}={}){if(reloading)return;paint('unavailable',hasSnapshot?'World updates unavailable. Showing the last snapshot.':'World updates unavailable. Reconnect to try again.',{reconnect:true});},
  getState:()=>({attempted,target:target?.target??null,reloading}),
 };
}
