import {assertOwnerCandidateFrameContext} from './owner-candidate-readiness.mjs';

const keys=['schemaVersion','kind','worldId','access','ownerOrigin','websiteVersion','current','previous'];
const closed=value=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
const version=value=>typeof value==='string'&&/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(value);

// Structural/identity validation of the existing authenticated Root response.
// The caller supplies its trusted world/access/origin; no child chooses a URL.
export function assertOwnerReleaseOffer(value,{worldId,access,ownerOrigin}={}){
 if(!closed(value)||value.schemaVersion!==1||value.kind!=='owner-world-release'||value.worldId!==worldId||value.access!==access||value.ownerOrigin!==ownerOrigin||!version(value.websiteVersion)||new TextEncoder().encode(JSON.stringify(value)).byteLength>16384)throw Error('Exact bounded owner release offer required');
 const qualify=context=>assertOwnerCandidateFrameContext(context,{worldId,access,ownerOrigin,renderer:context?.renderer});
 const current=qualify(value.current),previous=value.previous===null?null:qualify(value.previous);
 // Root retains at most one distinct immutable previous release. Do not infer
 // version ordering: a selected rollback can legitimately change that ordering.
 if(previous&&(previous.renderer.artifactSha256===current.renderer.artifactSha256||previous.renderer.worldVersion===current.renderer.worldVersion))throw Error('Distinct qualified previous release required');
 return Object.freeze({schemaVersion:1,kind:'owner-world-release',worldId,access,ownerOrigin,websiteVersion:value.websiteVersion,current,previous});
}
