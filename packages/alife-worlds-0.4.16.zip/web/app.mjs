await import('./audio.mjs').catch(()=>{});
await import('./agent-outpost/colony-art.js').catch(()=>{});
import './agent-outpost/agent-outpost.js';
import './command-exchange.js';
import {portableClipboard,portablePacketFromCatalog,validatePortablePacket} from './portable-definitions.mjs';
import {createWorldShell} from './world-shell.mjs';
import {dashboardProgress,progressFor,recentHandoffs,siteTaskStatus,siteActivityStatus} from './dashboard-model.mjs';
const nodes=new Map([...document.querySelectorAll('[id]')].map(n=>[n.id,n]));
const $=id=>nodes.get(id)||document.getElementById(id),el=(tag,cls,value)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(value!==undefined)n.textContent=value;return n;};
let current=null,loading=false,poll=null,roadmapSignature=null,dashboardController=null,disposed=false;
let ownerViewportAPI=null;
if(new URLSearchParams(location.search).get('worldViewport')==='1'&&globalThis.ALIFE_OWNER_SITE_CONTEXT)try{ownerViewportAPI=await import('./owner-operator-viewport.mjs');}catch{}
const viewportContext=ownerViewportAPI?.ownerOperatorContext(globalThis.ALIFE_OWNER_SITE_CONTEXT)??null;
const commandHost=globalThis.FarmCommandBrowserExchange.create(window.FARM_COMMAND_CONTEXT);
const farm=globalThis.AgentOutpost.mount($('world-anchor'),{roomLabelPlacement:'below-room',farmCommandHost:viewportContext?undefined:commandHost,cameraControls:true,defaultWorld:false,publicTitle:document.title,...(viewportContext?{cosmeticOnly:true,operatorPresentation:true,presentationMode:'view',fillViewport:true,transparentBackground:true}:{})});
farm.host.hidden=true;
const viewport=viewportContext?ownerViewportAPI.createOwnerOperatorViewport({farm,context:viewportContext}):null;
const shell=viewport||createWorldShell(farm);
const requestedScene=new URLSearchParams(location.search).get('scene');
if([...$('scene').options].some(o=>o.value===requestedScene))$('scene').value=requestedScene;
const stages=['Backlog','Shaping','Ready','In Progress','QA','In Review','Done'];
function bullets(values){const list=el('ul');for(const value of values)list.append(el('li','',value));return list;}
function detail(label,value){const p=el('p','clone-task-detail');p.append(el('strong','',label+' '),document.createTextNode(value||'Not recorded.'));return p;}
function taskCard(t,{future=false}={}){
 const item=el('article','clone-task');item.dataset.siteStatus=siteTaskStatus(t);item.dataset.stage=t.stage;item.id=(future?'roadmap-task-':'sprint-outcome-')+t.id;
 item.append(el('h3','',t.title),el('small','task-owner',t.owners.join(', ')+' · '+t.stage+(t.milestone?.delivered?' · Accepted':'')));
 const activity=el('span','task-native');activity.dataset.taskLiveRole=t.ownerRoleId;item.append(activity);
 if(t.scope)item.append(detail('Scope:',t.scope));
 item.append(detail('Current:',t.current),detail('Next:',t.next));
 if(t.dependencies.length){const names=new Map(current.model.tasks.map(t=>[t.id,t.title]));item.append(detail('Depends on:',t.dependencies.map(id=>names.get(id)||id+' (not in this snapshot)').join('; ')));}
 if(t.blocker)item.append(el('p','clone-blocker',t.blocker));
 const list=el('ul','clone-steps');
 for(const s of t.milestone?.steps||[]){const row=el('li'),box=el('span','clone-check',s.complete?'\u2713':'');box.dataset.done=String(s.complete);box.setAttribute('aria-label',s.complete?'Completed with evidence':'Incomplete');row.append(box,el('span','',s.title));list.append(row);}
 if(list.children.length)item.append(el('h4','','Implementation steps'),list);
 if(t.acceptance.length)item.append(el('h4','','Acceptance checks'),bullets(t.acceptance));
 if(t.qaResult&&t.qaResult!=='NOT TESTED')item.append(detail('Recorded QA result:',t.qaResult));
 if(t.milestone?.acceptanceEvidence)item.append(detail('Recorded outcome:',t.milestone.acceptanceEvidence));
 return item;
}
function renderRoadmap(){
 const m=current.model,r=m.roadmap,planning=m.tasks.map(({checkedUtc,updatedUtc,ownerIds,...task})=>task),signature=JSON.stringify([r,planning,m.presentation]);
 if(signature===roadmapSignature)return;roadmapSignature=signature;
 const host=$('roadmap-content');host.replaceChildren();
 if(!r){host.append(el('p','clone-empty','No recovery roadmap has been recorded. The live team remains connected.'));return;}
 host.append(el('p','roadmap-goal',r.goal||'Project goal not recorded.'),el('p','roadmap-status',r.status||'Status not recorded.'),detail('Current focus:',r.currentFocus));
 if(r.epic){const epic=el('div','roadmap-epic');epic.append(el('h3','',r.epic.title||'Epic'),el('p','',r.epic.goal));if(r.epic.acceptance.length)epic.append(el('h4','','Epic acceptance'),bullets(r.epic.acceptance));host.append(epic);}
 if(r.constraints.length){const constraints=el('details','roadmap-constraints');constraints.append(el('summary','','Scope and constraints'),bullets(r.constraints));host.append(constraints);}
 const core=r.coreRoles.map(id=>m.agents.find(a=>a.roleId===id)?.title||id);
 if(core.length)host.append(el('p','source-note','Core recovery roles: '+core.join(', ')+'. All connected team members remain in the farm.'));
 const sequence=el('ol','roadmap-sequence'),tasksById=new Map(m.tasks.map(t=>[t.id,t])),sprintsById=new Map(r.sprints.map(s=>[s.id,s]));
 for(const s of r.sprints){
  const selected=s.id===m.presentation.id,entry=el('li','roadmap-sprint');entry.id='roadmap-sprint-'+s.id;entry.dataset.status=selected?'current':s.status;
  entry.append(el('span','roadmap-sprint-state',selected?'Selected current sprint':s.status==='complete'?'Reported complete':'Planned sprint'),el('h3','',s.title),el('p','',s.goal));
  if(s.dependencySprintIds.length)entry.append(detail('Sprint prerequisites:',s.dependencySprintIds.map(id=>sprintsById.get(id)?.title||id).join('; ')));
  if(s.exitCriteria.length)entry.append(el('h4','','Exit criteria'),bullets(s.exitCriteria));
  if(selected){const link=el('a','','View selected sprint tasks');link.href='#active-work';entry.append(link);}
  else {const details=el('details','roadmap-task-group');details.append(el('summary','',s.taskIds.length+' tasks / '+(s.status==='complete'?'recorded history':'outside current sprint')));const list=el('div','clone-task-list');for(const id of s.taskIds){const t=tasksById.get(id);if(t)list.append(taskCard(t,{future:true}));}details.append(list);entry.append(details);}
  sequence.append(entry);
 }
 host.append(el('h3','','Sprint sequence'),sequence);
}
function renderProgress(){
 const p=dashboardProgress(current.model);for(const key of ['sprint','epic']){const value=p[key],bar=$(key+'-progress');$(key+'-progress-label').textContent=(key==='sprint'?'Current sprint':'Epic')+' · '+(value.percent===null?'Not scoped':value.percent+'%')+' · '+value.accepted+'/'+value.tasks+(key==='sprint'?' tasks completed':' sprints completed');if(value.percent===null)bar.removeAttribute('value');else bar.value=value.percent;}
}
function renderHandoffs(){const events=recentHandoffs(current.model,current.feed);$('handoff-list').replaceChildren(...events.map(e=>{const row=el('li'),time=el('time','',new Date(e.observedUtc).toLocaleString());time.dateTime=e.observedUtc;row.append(el('span','',e.kind+' · '+e.from+' → '+e.to),time);return row;}));$('handoff-empty').hidden=events.length>0;}
let ruleSignature=null;
async function portableAction({scope,agentId,download=false}){
 const status=$('portable-status');try{
  if(!current?.project?.id)throw Error('Choose a connected project first.');
  let packet;if(scope){const catalog=current.ruleCatalog?.[scope];if(!catalog)throw Error('Effective project rules are unavailable.');packet=portablePacketFromCatalog(scope,scope==='world'?'ALife World rules':'ALife plugin rules',catalog);}
  else {const response=await fetch('/api/portable-export?kind=agent&agent='+encodeURIComponent(agentId)+'&project='+encodeURIComponent(current.project.id),{cache:'no-store'});const value=await response.json();if(!response.ok)throw Error(value.error||'This role has no safe portable definition.');packet=validatePortablePacket(value);}
  const text=portableClipboard(packet);
  if(download){const url=URL.createObjectURL(new Blob([text+'\n'],{type:'text/plain;charset=utf-8'})),a=el('a');a.href=url;a.download='alife-'+(scope||'agent')+'-import.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status.textContent='Definition downloaded. Paste it with /import in the destination project to review.';}
  else {if(!navigator.clipboard?.writeText)throw Error('Clipboard is unavailable; use Clone to download the same import.');await navigator.clipboard.writeText(text);status.textContent='Import copied. Paste it in the destination project to review; no agents or tasks were changed.';}
 }catch(e){status.textContent=typeof e.message==='string'?e.message:'Portable definition unavailable.';}
}
function portableButton(label,options){const button=el('button','portable-action',label);button.type='button';button.onclick=()=>void portableAction(options);return button;}
function renderRules(){
 const catalog=current.ruleCatalog,signature=JSON.stringify(catalog);if(signature===ruleSignature)return;ruleSignature=signature;const host=$('rule-catalog');host.replaceChildren();
 if(!catalog){host.append(el('p','clone-empty','Effective project rules are unavailable. Reconcile the original content operation before copying or exporting.'));return;}
 for(const scope of ['plugin','world']){const section=el('section','rule-scope');section.append(el('h3','',scope==='plugin'?'Plugin Rules':'World Rules'));const value=catalog[scope];section.append(portableButton('Copy import',{scope}),portableButton('Clone definition',{scope,download:true}));if(!value?.groups.length)section.append(el('p','clone-empty','No rules recorded.'));
 for(const group of value?.groups||[]){const active=group.properties.filter(p=>p.active),details=el('details','rule-group');details.open=group.id==='delivery';details.append(el('summary','',group.title+' · '+active.length));const list=el('ul');for(const p of active){const row=el('li'),instructions=el('details'),prompt=el('p','rule-ai-instructions',p.text);prompt.style.whiteSpace='pre-wrap';instructions.append(el('summary','','AI instructions'),prompt);row.append(el('strong','',p.title),el('p','',p.description||p.title),instructions,el('small','',group.id+'.'+p.id+' · '+p.implementation));list.append(row);}details.append(list);const inactive=group.properties.filter(p=>!p.active);if(inactive.length)details.append(el('p','source-note',inactive.length+' inactive properties; excluded from the active prompt.'));section.append(details);}host.append(section);}
}
function renderLists(){
 if(!current)return;const m=current.model,query=$('search').value.toLowerCase(),selected=m.tasks.filter(t=>t.inCurrentSprint),tasks=selected.filter(t=>(t.title+' '+t.owners.join(' ')).toLowerCase().includes(query));
 renderRoadmap();renderProgress();renderHandoffs();renderRules();$('current-sprint-title').textContent=m.presentation.title;
 const sprint=m.roadmap?.sprints.find(s=>s.id===m.presentation.id);
 $('current-sprint-goal').textContent=sprint?.goal||'Only the selected sprint is shown here. Native activity remains visible in the farm.';
 const previousOpen=new Set([...$('task-list').querySelectorAll('.task-more[open]')].map(d=>d.closest('article').id));$('task-list').replaceChildren(...tasks.map(t=>taskCard(t)));for(const d of $('task-list').querySelectorAll('.task-more'))if(previousOpen.has(d.closest('article').id))d.open=true;if(!tasks.length)$('task-list').append(el('p','clone-empty',selected.length?'No matching current-sprint tasks.':'No tasks are selected for this sprint. Future roadmap tasks do not count toward it.'));
 const qa=selected.filter(t=>t.stage==='QA');$('qa-list').replaceChildren(...qa.map(t=>{const card=taskCard(t);card.removeAttribute('id');return card;}));if(!qa.length)$('qa-list').append(el('p','clone-empty','No selected-sprint cards are currently in QA.'));$('product-queue').hidden=!qa.length;$('qa-title').textContent='QA queue · '+qa.length;
 $('board').replaceChildren(...stages.map(stage=>{const col=el('section','clone-column');col.dataset.stage=stage;col.append(el('h3','',stage));for(const t of selected.filter(t=>t.stage===stage)){const card=el('a','board-task',t.title);card.dataset.siteStatus=siteTaskStatus(t);card.dataset.stage=t.stage;card.href='#sprint-outcome-'+encodeURIComponent(t.id);card.append(el('small','',t.owners.join(', ')));col.append(card);};return col;}));
 $('roles').replaceChildren(...m.agents.map(a=>{const article=el('article'),h=current.feed.agentHealth.find(h=>h.threadId===a.threadId),activity=current.feed.error?'Activity unavailable':h?.activityState==='idle'?'Idle / ready':h?.activityState==='working'?'Working':h?.activityState==='waiting'?'Waiting':'Activity unavailable';article.dataset.siteStatus=siteActivityStatus(a,h,current.feed);article.append(el('h3','',a.title),el('p','',a.roleLabel),el('p','',a.connected?'Connected / '+activity:'Not connected / '+(a.connectionState||'unconfirmed')),el('small','',a.onboarded?'Onboarding receipt verified':'Onboarding receipt pending'));if(a.chatUrl){const link=el('a','','Open agent chat');link.href=a.chatUrl;article.append(link);}article.append(portableButton('Copy agent import',{agentId:a.roleId}),portableButton('Clone agent definition',{agentId:a.roleId,download:true}));return article;}));
}
async function refresh(){
 if(loading||document.hidden||disposed)return;loading=true;const active=new AbortController();dashboardController=active;const timeout=setTimeout(()=>active.abort(),8000);
 try{const r=await fetch('/api/dashboard?scene='+encodeURIComponent($('scene').value)+(shell.projectId()?'&project='+encodeURIComponent(shell.projectId()):''),{cache:'no-store',signal:active.signal});if(!r.ok)throw Error('Feed unavailable');const next=await r.json();if(active.signal.aborted||disposed)throw Error('Feed unavailable');shell.acceptProject(next.project);for(const a of document.querySelectorAll('[data-rule-export]')){const url=new URL(a.href,location.origin);url.searchParams.set('project',next.project.id);a.href=url.href;}farm.setAudioPreferenceKey?.(viewportContext?.worldId||next.project?.id);const profileReady=next.worldProfile?.status==='ready';farm.host.hidden=!profileReady;farm.setDefaultWorld(next.worldProfile?.renderer==='midnight-colony');$('world-profile-status').hidden=profileReady;$('world-profile-status').textContent=next.worldProfile?.reason||'The selected world is unavailable. The world owner must reconcile its saved profile.';current=next;const ownerInput=viewport?await viewport.resolve(next.ownerPreview):null;if(active.signal.aborted||disposed)throw Error('Feed unavailable');const displayInput=ownerInput||viewport?.cachedInput();if(!viewport)farm.setWorldVersion?.(next.worldProfile?.status==='ready'&&next.worldProfile.source==='project'?next.worldProfile.worldVersion:null);farm.render(displayInput?.model??current.model,displayInput?(ownerInput?displayInput.feed:{...displayInput.feed,error:'World updates unavailable'}):current.feed,displayInput?{sprint:displayInput.snapshot.summary?.current,epic:displayInput.snapshot.summary?.epic}:dashboardProgress(current.model));viewport?.rendered(ownerInput);
  const projected=farm.getSnapshot(),s=projected.sprint;$('connection').textContent=current.mode==='demo'?'Fictional demo':'Live project feed';$('scene-label').hidden=current.mode!=='demo';
  $('overview-text').textContent=current.model.agents.length+' roles / '+s.tasks+' selected-sprint tasks / '+current.model.tasks.length+' tasks in the full roadmap';$('updated').textContent='Live feed observed '+new Date(current.feed.observedUtc).toLocaleString();renderLists();
 }catch{if(disposed)return;viewport?.unavailable();const feed=current?{...current.feed,error:'Project feed unavailable'}:{error:'Project feed unavailable'};if(current){current={...current,feed};const held=viewport?.cachedInput();farm.render(held?.model??current.model,held?{...held.feed,error:'Project feed unavailable'}:feed,held?{sprint:held.snapshot.summary?.current,epic:held.snapshot.summary?.epic}:dashboardProgress(current.model));renderLists();}$('connection').textContent='Feed unavailable';}
 finally{clearTimeout(timeout);if(dashboardController===active)dashboardController=null;loading=false;if(!poll&&!disposed)poll=setInterval(refresh,current?.pollMs||5000);}
}
$('scene').onchange=refresh;$('refresh').onclick=refresh;$('search').oninput=renderLists;document.addEventListener('visibilitychange',()=>{if(document.hidden)dashboardController?.abort();else refresh();});window.addEventListener('pagehide',()=>{disposed=true;dashboardController?.abort();clearInterval(poll);viewport?.dispose();});
refresh();
