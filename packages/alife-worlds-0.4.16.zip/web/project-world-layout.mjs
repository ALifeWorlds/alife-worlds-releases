// Stable per-project variation inside the responsive gallery's padded cells.
// Neither wall time, viewport size nor live-feed refresh changes a project's seed.
export function projectWorldOffsets(id,count){
 if(typeof id!=='string'||!/^[a-z][a-z0-9-]{0,63}$/.test(id)||!Number.isInteger(count)||count<1||count>32)throw Error('Validated project layout required');
 if(count===1)return Object.freeze({x:0,y:0});
 const seed=[...id].reduce((n,c)=>Math.imul(n^c.charCodeAt(0),16777619)>>>0,2166136261);
 return Object.freeze({x:seed%23-11,y:(seed>>>9)%25-12});
}
export function layoutProjectWorlds(element){
 const cards=[...element.children].filter(node=>node.dataset?.projectId);
 for(const card of cards){const p=projectWorldOffsets(card.dataset.projectId,cards.length);card.style.setProperty('--pw-offset-x',p.x+'px');card.style.setProperty('--pw-offset-y',p.y+'px');}
}
