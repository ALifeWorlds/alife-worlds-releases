import {createOwnerPreviewJoin} from '../lib/owner-preview-join.mjs';
import {canonicalWorldJSON} from '../lib/local-world-appearance.mjs';

const closed=(v,keys)=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const opaque=v=>typeof v==='string'&&v.length>0&&v.length<=256&&v===v.trim()&&!/[\x00-\x20\x7f/\\]/.test(v);
const scopeKeys=['projectId','worldId','access','ownerOrigin','visualStateScope'];
function scope(value){
 if(!closed(value,scopeKeys)||!opaque(value.projectId)||value.projectId!==value.worldId||
  typeof value.worldId!=='string'||!/^[a-z][a-z0-9-]{0,63}$/.test(value.worldId)||!['local-owner','owner-private'].includes(value.access))throw Error('Exact private candidate scope required');
 const visual=value.visualStateScope;
 if(visual!==null&&(!closed(visual,['worldKey','artKey','audienceKey'])||typeof visual.worldKey!=='string'||!/^scene-[a-f0-9]{14}$/.test(visual.worldKey)||typeof visual.artKey!=='string'||!/^art-[a-f0-9]{64}$/.test(visual.artKey)||typeof visual.audienceKey!=='string'||!/^audience-[a-f0-9]{64}$/.test(visual.audienceKey)))throw Error('Root-qualified cosmetic scope or null required');
 const u=new URL(value.ownerOrigin);
 if(u.origin!==value.ownerOrigin||u.username||u.password||u.pathname!=='/'||u.search||u.hash||
  !(u.protocol==='https:'||value.access==='local-owner'&&u.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname)&&u.port))throw Error('Qualified owner origin required');
 return value;
}
function freeze(value){if(value&&typeof value==='object'&&!Object.isFrozen(value)){Object.freeze(value);for(const part of Object.values(value))freeze(part);}return value;}
const MAX_CANDIDATE_BYTES=1024*1024;

// Validate Root's actual closed frame-context DTO before creating its trusted
// parent binding. No offer URL or project identity is accepted from a child.
export function assertOwnerCandidateFrameContext(value,{worldId,access,ownerOrigin,renderer}={}){
 const descriptor=createOwnerPreviewJoin(renderer).descriptor;
 const actual=createOwnerPreviewJoin(value?.renderer).descriptor;
 const base='/world-frame/'+descriptor.artifactSha256+'/';
 if(!closed(value,['schemaVersion','kind','worldId','access','ownerOrigin','websiteVersion','renderer','framePath','snapshotPath','resourceBase','visualStateScope'])||value.schemaVersion!==1||value.kind!=='owner-world-frame'||value.worldId!==worldId||value.access!==access||value.ownerOrigin!==ownerOrigin||typeof value.websiteVersion!=='string'||!/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(value.websiteVersion)||canonicalWorldJSON(actual)!==canonicalWorldJSON(descriptor)||value.framePath!==base||value.snapshotPath!==base+'snapshot'||value.resourceBase!==base+'assets/'||new TextEncoder().encode(JSON.stringify(value)).byteLength>4096)throw Error('Exact server-qualified frame context required');
 scope({projectId:worldId,worldId,access,ownerOrigin,visualStateScope:value.visualStateScope});
 return freeze(structuredClone(value));
}

// These collaborators are parent-owned, not message-selected:
// getCandidateBinding reads the current Root-qualified offer and returns only
// {scope,renderer,url,epoch,nonce,controlRevision}; verifyResources checks that exact offer's actual
// loaded assets/receiver. Missing, async or merely queued resource evidence fails.
// No navigation, DOM mutation, feed producer, timer or mounted-scene reference.
export function createOwnerCandidateReadiness({getCurrentScope,getCandidateBinding,verifyResources,assertFrameMessage,now=Date.now,subtle=globalThis.crypto?.subtle}={}){
 if([getCurrentScope,getCandidateBinding,verifyResources,assertFrameMessage,now].some(fn=>typeof fn!=='function')||!subtle?.digest)throw Error('Actual private candidate collaborators required');
 let disposed=false,lastRejection=null;
 const attempts=new WeakMap(),proofs=new WeakMap(),metadata=new WeakMap();
 function reject(reason){lastRejection=reason;return null;}
 function binding(candidate,{frame,epoch}={}){
  if(disposed||!candidate||typeof candidate!=='object'||!frame?.isConnected||!frame.contentWindow||!Number.isSafeInteger(epoch)||epoch<1)throw Error('Current candidate lifetime required');
  const value=getCandidateBinding(candidate,{frame,epoch});
  if(!closed(value,['scope','renderer','url','epoch','nonce','controlRevision'])||value.epoch!==epoch||typeof value.nonce!=='string'||!/^[A-Za-z0-9_-]{16,128}$/.test(value.nonce)||!Number.isSafeInteger(value.controlRevision)||value.controlRevision<0||canonicalWorldJSON(scope(value.scope))!==canonicalWorldJSON(scope(getCurrentScope())))throw Error('Candidate identity changed');
  // Reuse the source descriptor validator; a child cannot select the renderer.
  const join=createOwnerPreviewJoin(value.renderer),url=new URL(value.url);
  if(url.href!==value.url||url.origin!==value.scope.ownerOrigin||url.username||url.password||url.search||url.hash||url.pathname!=='/world-frame/'+join.descriptor.artifactSha256+'/'||frame.src!==value.url)throw Error('Exact pinned candidate receiver required');
  if(verifyResources({candidate,frame,binding:value})!==true)throw Error('Candidate assets or receiver unavailable');
  const copy={scope:{...value.scope,visualStateScope:value.scope.visualStateScope===null?null:{...value.scope.visualStateScope}},renderer:{...join.descriptor},url:value.url,epoch,nonce:value.nonce,controlRevision:value.controlRevision};
  return{value:freeze(copy),key:canonicalWorldJSON(copy),join};
 }
 function frameInput(event,checked,{frame,epoch,candidate},at){
  const input=assertFrameMessage(event,{frame,candidate,ownerOrigin:checked.value.scope.ownerOrigin,worldId:checked.value.scope.worldId,epoch,renderer:checked.value.renderer,nonce:checked.value.nonce,controlRevision:checked.value.controlRevision,now:at});
  if(input===null)return null;
  if(!closed(input,['preview','joined','receivedUtc','nonce','controlRevision'])||input.nonce!==checked.value.nonce||input.controlRevision!==checked.value.controlRevision||typeof input.receivedUtc!=='string'||!Number.isFinite(Date.parse(input.receivedUtc))||new Date(Date.parse(input.receivedUtc)).toISOString()!==input.receivedUtc||Date.parse(input.receivedUtc)>at+5000||at-Date.parse(input.receivedUtc)>45000)throw Error('Current challenged render receipt required');
  const observed=Date.parse(input.preview?.snapshot?.observedUtc);
  if(input.preview?.schemaVersion!==3||input.preview?.snapshot?.feed?.error!==null||!Number.isFinite(observed)||observed>at+5000||at-observed>45000)throw Error('Original fresh validated source required');
  const visual=checked.value.scope.visualStateScope;
  if(visual!==null&&input.preview?.snapshot?.model?.visualWorldKey!==visual.worldKey)throw Error('Actual visual world key required');
  return input;
 }
 function current(proof,context){
  const refuse=()=>{proofs.delete(proof);return false;};
  try{
   const record=proofs.get(proof);
   if(!record||record.candidate!==context?.candidate||record.frame!==context.frame||record.epoch!==context.epoch||attempts.get(record.candidate)!==record.attempt)return refuse();
   const checked=binding(record.candidate,context),at=now();
   return Number.isFinite(at)&&checked.key===record.bindingKey&&frameInput(record.event,checked,context,at)!==null?true:refuse();
  }catch{return refuse();}
 }
 async function qualifyReady(event,context={}){
  const {candidate,frame,epoch}=context;
  // Unrelated window traffic must not supersede a valid candidate proof.
  if(!frame||event?.source!==frame.contentWindow)return null;
  if(!candidate||typeof candidate!=='object')return reject('candidate-required');
  const attempt=(attempts.get(candidate)||0)+1;attempts.set(candidate,attempt);
  let checked;
  try{checked=binding(candidate,context);if(event.origin!==checked.value.scope.ownerOrigin)return reject('candidate-origin-changed');}catch{return reject('identity-or-resources');}
  try{
   const at=now();if(!Number.isFinite(at))return reject('invalid-clock');
   if(frameInput(event,checked,context,at)===null)return reject('feed-unavailable');
   // Bound before copying; preserve structured-clone aliasing for snapshot identity.
   const serialized=JSON.stringify(event.data);
   if(new TextEncoder().encode(serialized).byteLength>MAX_CANDIDATE_BYTES)return reject('oversized-receipt');
   const data=structuredClone(event.data),received={source:event.source,origin:event.origin,data};
   const input=frameInput(received,checked,context,at);
   const joined=await checked.join.ownerWorldInput(input.preview,{expectedWorldId:checked.value.scope.worldId,previousMetadata:metadata.get(candidate)??null,now:at,subtle});
   // The receiver must acknowledge the exact successful joined model/feed, not
   // merely a valid preview paired with different rendered data.
   if(canonicalWorldJSON(input.joined)!==canonicalWorldJSON(joined))return reject('rendered-input-mismatch');
   if(attempts.get(candidate)!==attempt||binding(candidate,context).key!==checked.key)return reject('superseded');
   const after=now();if(!Number.isFinite(after)||frameInput(received,checked,context,after)===null)return reject('expired-after-validation');
   const proof=freeze({preview:input.preview,joined,receivedUtc:input.receivedUtc,observedUtc:input.preview.snapshot.observedUtc,metadataMarker:joined.metadataMarker,nonce:input.nonce,controlRevision:input.controlRevision,binding:checked.value});
   // Freeze detached data only; never traverse or freeze the real Window object.
   freeze(data);Object.freeze(received);
   proofs.set(proof,{candidate,frame,epoch,attempt,bindingKey:checked.key,event:received});
   if(!current(proof,context))return reject('not-current');
   metadata.set(candidate,joined.metadataMarker);lastRejection=null;return proof;
  }catch{return reject('invalid-or-unavailable');}
 }
 return Object.freeze({qualifyReady,isReadyCurrent:current,
  invalidate(candidate){if(candidate&&typeof candidate==='object')attempts.set(candidate,(attempts.get(candidate)||0)+1);},
  getLastRejection:()=>lastRejection,
  dispose(){disposed=true;}
 });
}
