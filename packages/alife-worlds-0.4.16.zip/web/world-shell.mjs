import {planetLayout,matchingProject,createWorldAudioBridge,assertOwnerWorldInventory,readOwnerWorldJSON,createOwnerWorldSelection,createOwnerPlanetViews} from './world-shell-model.mjs';
export function createWorldShell(farm){
 const main=document.querySelector('main'),toolbar=document.createElement('nav');toolbar.id='world-toolbar';toolbar.setAttribute('aria-label','World controls');
 const label=document.createElement('label'),select=document.createElement('select');label.className='project-picker';label.append(document.createTextNode('Project '),select);select.setAttribute('aria-label','Current project');select.disabled=true;select.add(new Option('Reading projects…',''));toolbar.append(label);
 const mode=document.createElement('select');mode.setAttribute('aria-label','Presentation mode');for(const [id,title]of [['public','Public'],['private','Private'],['view','View']])mode.add(new Option(title,id));toolbar.append(mode);
 const controls=farm.host.querySelector('.ag-controls');toolbar.append(controls);farm.host.before(toolbar);farm.host.dataset.shell='true';
 const galaxy=document.createElement('section');galaxy.id='world-galaxy';galaxy.hidden=true;galaxy.setAttribute('aria-label','Project galaxy');farm.host.after(galaxy);
 const operations=[...main.children].filter(n=>![toolbar,farm.host,galaxy].includes(n)&&n.id!=='world-anchor'&&!n.classList.contains('ag-privacy-bar')).map(node=>{const marker=document.createComment('operational section');node.before(marker);return{node,marker};});
 let selection=null,disposed=false,planetViews=null,planetObserver=null;const planetVisibility=new Map();const listingAbort=new AbortController(),rowStates=new Map(),planetControls=new Map();
 let registry=null,all=false,modeValue=farm.host.dataset.mode||'public',soundIntent=false;const soundBridge=createWorldAudioBridge({parentOrigin:location.origin,getEnabled:()=>soundIntent&&farm.audio.state()?.enabled===true,canPlay:()=>all&&!document.hidden&&farm.host.dataset.controlMotion==='running',cue:(key,options)=>farm.audio.cue(key,options)});window.addEventListener('message',event=>soundBridge.handle(event));farm.host.addEventListener('alife-sound',event=>{soundIntent=event.detail?.enabled===true;soundBridge.broadcast();});
 function showOperations(show){for(const {node,marker}of operations)if(show){if(!node.isConnected)marker.after(node);}else node.remove();}
 function applyMode(value){modeValue=value;mode.value=value;document.documentElement.dataset.worldMode=value;showOperations(value==='public'&&!all);farm.setPresentationMode(value);toolbar.dispatchEvent(new CustomEvent('alife-world-mode',{bubbles:true,detail:{mode:value}}));}
 function showAll(value){all=value;farm.host.hidden=value;galaxy.hidden=!value;document.documentElement.dataset.worldOverview=String(value);showOperations(modeValue==='public'&&!value);farm.setWorldVisible?.(!value);farm.audio.setScene(value?'space':'world');if(value)drawGalaxy();else clearPlanets();soundBridge.broadcast();}

 function clearPlanets(){planetObserver?.disconnect();planetObserver=null;planetViews?.dispose();planetViews=null;planetVisibility.clear();soundBridge.clear();planetControls.clear();}
 function updatePlanetVisibility(){for(const[id,shown]of planetVisibility)planetViews?.setVisible(id,all&&!disposed&&!document.hidden&&shown);}
 function drawGalaxy(){
  clearPlanets();galaxy.replaceChildren();galaxy.dataset.count=String(registry?.projects.length||0);
  const projects=planetLayout(registry?.projects||[]),space=document.createElement('div');space.className='galaxy-space';
  space.style.setProperty('--planet-columns',Math.max(1,Math.ceil(Math.sqrt(projects.length))));
  space.style.setProperty('--planet-rows',Math.max(1,Math.ceil(projects.length/Math.ceil(Math.sqrt(projects.length)))));galaxy.append(space);
  space.addEventListener('pointerdown',e=>{if(e.target!==space||matchMedia('(prefers-reduced-motion: reduce)').matches)return;const spark=document.createElement('span');spark.className='space-spark';spark.style.left=e.offsetX+'px';spark.style.top=e.offsetY+'px';space.append(spark);farm.audio.cue('ui',{volume:.12});setTimeout(()=>spark.remove(),900);});
  for(const p of projects){
   const planet=document.createElement('article');planet.className='world-planet';planet.style.left=p.x+'%';planet.style.top=p.y+'%';
   const scene=document.createElement('div');scene.className='planet-scene';scene.setAttribute('aria-hidden','true');scene.dataset.worldAlias=p.id;
   const hit=document.createElement('button');hit.type='button';hit.className='planet-hit-area';hit.setAttribute('aria-label',(p.id===registry.currentId?'Show current world: ':'Verify and open world: ')+p.name);
   const caption=document.createElement('div');caption.className='planet-caption';
   const link=document.createElement('button');link.type='button';link.textContent=p.name;link.title=p.name;link.className='planet-name';
   const status=document.createElement('p');status.id='planet-status-'+p.id;status.className='planet-status';status.textContent='World view not loaded · unconfirmed';
   link.setAttribute('aria-describedby',status.id);hit.setAttribute('aria-describedby',status.id);
   const choose=()=>{if(!disposed)void selection?.select(p.id);};hit.onclick=choose;link.onclick=choose;
   caption.append(link,status);planet.append(scene,hit,caption);space.append(planet);planetControls.set(p.id,{status,scene,viewState:status.textContent});
   planetVisibility.set(p.id,typeof IntersectionObserver==='undefined');planet.addEventListener('pointerdown',()=>farm.audio.cue('ui',{volume:.14}));
  }
  planetViews=createOwnerPlanetViews({inventory:registry,request:requestWorld,mount:(p,selected)=>{
   const entry=planetControls.get(p.id),frame=document.createElement('iframe'),preview=new URL(selected.viewerUrl);
   preview.searchParams.set('embedded','planet');preview.searchParams.set('soundHost',location.origin);
   frame.src=preview.href;frame.title=p.name+' · world preview';frame.loading='lazy';frame.referrerPolicy='no-referrer';frame.tabIndex=-1;frame.inert=true;frame.setAttribute('aria-hidden','true');frame.setAttribute('allow','');
   entry.scene.append(frame);
   try{soundBridge.register(frame.contentWindow,{origin:selected.origin,worldId:p.worldId});}catch{frame.remove();throw Error('Preview audio identity unavailable');}
   frame.addEventListener('load',()=>{if(!all||disposed||!entry.scene.children.length)return;entry.viewState='World view loaded';refreshLabels();soundBridge.broadcast();});
   frame.addEventListener('error',()=>{if(!all||disposed)return;entry.viewState='World view unavailable';refreshLabels();});
   return()=>{soundBridge.unregister(frame.contentWindow);frame.remove();};
  },onState:(id,state)=>{const entry=planetControls.get(id);if(!entry)return;entry.viewState=({checking:'Checking world connection…',ready:'World connection verified · loading view',unavailable:'World view unavailable · choose to retry',paused:'World preview paused'})[state];if(state==='ready')rowStates.set(id,'verified');refreshLabels();}});
  if(typeof IntersectionObserver!=='undefined'){
   planetObserver=new IntersectionObserver(entries=>{for(const e of entries)planetVisibility.set(e.target.dataset.worldAlias,e.isIntersecting);updatePlanetVisibility();},{root:galaxy});
   for(const entry of planetControls.values())planetObserver.observe(entry.scene);
  }
  updatePlanetVisibility();
  const caption=document.createElement('p');caption.className='galaxy-caption';caption.textContent=projects.length+' '+(registry.source==='launcher-profile'?'registered':'legacy configured')+' '+(projects.length===1?'project':'projects')+' · Each visible planet loads its own verified world';galaxy.append(caption);
 }
 function projectLabel(project){const availability=rowStates.get(project.id)||project.availability;return project.name+(registry.source==='legacy-config'?' · Legacy':'')+' · '+availability;}
 function planetStatus(project){return planetControls.get(project.id)?.viewState||'World view not loaded · unconfirmed';}
 function refreshLabels(){for(const option of select.options){const project=matchingProject(registry,option.value);if(project)option.textContent=projectLabel(project);}for(const [id,entry]of planetControls){const project=matchingProject(registry,id);if(project)entry.status.textContent=planetStatus(project);}}
 select.onchange=()=>{if(disposed||!selection)return;if(select.value==='__all__'){selection.cancel();showAll(true);return;}const project=matchingProject(registry,select.value);if(!project){selection.cancel();select.value=registry?.currentId||'';return;}void selection.select(project.id);};mode.onchange=()=>{if(!disposed)applyMode(mode.value);};
 async function requestWorld({id,projectId,signal}){return readOwnerWorldJSON(await fetch('/api/world-projects/open?'+new URLSearchParams({project:projectId,worldId:id}),{cache:'no-store',credentials:'same-origin',redirect:'error',headers:{Accept:'application/json'},signal}));}
 async function load(){try{const query=expected?'?'+new URLSearchParams({project:expected}):'',response=await fetch('/api/world-projects'+query,{cache:'no-store',credentials:'same-origin',redirect:'error',headers:{Accept:'application/json'},signal:listingAbort.signal}),next=assertOwnerWorldInventory(await readOwnerWorldJSON(response),{projectId:expected||undefined});if(disposed)return;if(next.status==='unavailable')throw Error('Registry unavailable');registry=next;selection=createOwnerWorldSelection({inventory:next,request:requestWorld,navigate:url=>location.assign(url),onState:(id,state)=>{if(disposed)return;rowStates.set(id,state==='current'?'unconfirmed':state);refreshLabels();if(state==='current'){showAll(false);select.value=registry.currentId;}else if(state==='unavailable')select.value=all?'__all__':registry.currentId;}});select.replaceChildren();for(const p of registry.projects)select.add(new Option(projectLabel(p),p.id));select.add(new Option('Show all','__all__'));select.value=registry.currentId;select.disabled=false;}catch{if(!disposed){select.replaceChildren(new Option('Project registry unavailable',''));select.disabled=true;}}}
 const expected=new URLSearchParams(location.search).get('project');
 const motionObserver=new MutationObserver(()=>{galaxy.dataset.motion=farm.host.dataset.controlMotion||'paused';soundBridge.broadcast();});motionObserver.observe(farm.host,{attributes:true,attributeFilter:['data-control-motion']});document.addEventListener('visibilitychange',()=>{galaxy.dataset.hidden=String(document.hidden);updatePlanetVisibility();soundBridge.broadcast();});applyMode(modeValue);void load();
 function dispose(){if(disposed)return;disposed=true;listingAbort.abort();selection?.dispose();motionObserver.disconnect();clearPlanets();}
 window.addEventListener('pagehide',dispose,{once:true});
 return{dispose,acceptProject(project){if(expected&&project?.id!==expected||registry&&project?.id!==registry.projectId)throw Error('Project identity mismatch');if(!registry&&project?.name)select.options[0].textContent=project.name;farm.setWorldTitle((project?.name||'ALife Worlds')+' · ALife Worlds');},projectId:()=>expected};
}
