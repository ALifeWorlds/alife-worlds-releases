// Invoke publish only after the owned frame's normal owner join and world render.
// This reuses that already sanitized input; it has no fetch, timer or native action.
export function createOwnerProjectPreviewBridge({worldId,renderer,parentOrigin,windowRef=window,now=Date.now}={}){
 const closed=(v,keys)=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
 const keys=['schemaVersion','bundleId','worldVersion','artifactSha256'];
 const descriptor=v=>closed(v,keys)&&keys.every(k=>v[k]===renderer?.[k]);
 if(typeof worldId!=='string'||!/^[a-z][a-z0-9-]{0,63}$/.test(worldId)||!closed(renderer,keys)||renderer.schemaVersion!==1||typeof renderer.artifactSha256!=='string'||!/^[a-f0-9]{64}$/.test(renderer.artifactSha256)||windowRef.location.origin!==parentOrigin||new URL(parentOrigin).origin!==parentOrigin)throw Error('Explicit same-origin owned frame required');
 let epoch=null,current=null,disposed=false;
 function accepted(value){
  const preview=value?.preview,joined=value?.joined,at=Date.parse(preview?.snapshot?.observedUtc);
  return closed(preview,['schemaVersion','kind','worldId','renderer','snapshot','appearance','names','metadata'])&&preview.schemaVersion===3&&preview.kind==='owner-world-preview'&&preview.worldId===worldId&&descriptor(preview.renderer)&&preview.snapshot?.world?.id===worldId&&preview.snapshot.feed?.error===null&&Number.isFinite(at)&&at<=now()+5000&&now()-at<=45000&&closed(joined,['snapshot','model','feed','metadataMarker'])&&joined.snapshot===preview.snapshot&&joined.metadataMarker?.worldId===worldId&&joined.metadataMarker.artifactSha256===renderer.artifactSha256&&joined.metadataMarker.revision===preview.metadata?.revision&&joined.metadataMarker.contentHash===preview.metadata?.contentHash;
 }
 function send(){
  if(disposed||epoch===null||windowRef.parent===windowRef)return;
  if(!accepted(current))current=null;
  windowRef.parent.postMessage({type:'alife-project-world-preview',worldId,epoch,receivedUtc:new Date(now()).toISOString(),preview:current?.preview??null,joined:current?.joined??null},parentOrigin);
 }
 function request(event){
  if(disposed||event.source!==windowRef.parent||event.origin!==parentOrigin||!closed(event.data,['type','worldId','epoch'])||event.data.type!=='alife-project-world-request'||event.data.worldId!==worldId||!Number.isSafeInteger(event.data.epoch)||event.data.epoch<1)return;
  epoch=event.data.epoch;send();
 }
 function dispose(){if(disposed)return;disposed=true;current=null;windowRef.removeEventListener('message',request);windowRef.removeEventListener('pagehide',dispose);}
 windowRef.addEventListener('message',request);windowRef.addEventListener('pagehide',dispose,{once:true});
 return Object.freeze({publish(preview,joined){if(disposed)return false;current={preview,joined};if(!accepted(current)){current=null;send();return false;}send();return true;},unavailable(){if(disposed)return;current=null;send();},dispose});
}
