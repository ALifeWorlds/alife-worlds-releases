import {createProjectWorldShell} from './project-world-presentation.mjs';
import {qualifiedProjectWorldAppearance} from './project-world-appearance.mjs';

// Reuses existing receiver observations. No fetch, clock, poller or native action.
export function createProjectWorldGallery({document:doc=globalThis.document,container,expectedWorldId,ownerOrigin,approvedRenderer,assertCatalogResponse,createPreview,getCurrentInput,onSelect=()=>{}}={}){
 if(!doc||!container||typeof assertCatalogResponse!=='function'||typeof createPreview!=='function'||typeof getCurrentInput!=='function'||typeof onSelect!=='function'||typeof expectedWorldId!=='string'||!expectedWorldId)throw Error('Existing owner receiver and freshness guards required');
 const element=doc.createElement('div');element.className='pw-gallery';element.setAttribute('aria-label','Project worlds');container.append(element);
 const note=doc.createElement('p');note.className='pw-catalog-note';note.textContent='Project catalogue unavailable';
 let entries=new Map(),active=false,disposed=false,disposing=false,receiptSequence=0,cleanupFailures=0,rootRecovery=null,motion={running:false,visible:false};
 function safely(action){try{action();return true;}catch{cleanupFailures++;return false;}}
 const hasContent=node=>!!(node.firstChild||node.childNodes?.length||node.children?.length);
 function pending(){return [...entries.values()].filter(entry=>entry.recoveryRequired).length;}
 function reflectCleanup(){element.dataset.cleanupState=disposed?'disposed':pending()||rootRecovery?'recovery-required':disposing?'disposing':'ready';}
 function recoveryButton(parent,label){
  const button=doc.createElement('button');button.type='button';button.className='pw-recover';button.textContent=label;button.addEventListener('click',event=>{event.preventDefault?.();event.stopPropagation?.();retryCleanup();});parent.append(button);return button;
 }
 function retain(entry,label='World return unavailable; scene retained'){
  const first=!entry.recoveryRequired;entry.recoveryRequired=true;if(entry.instance)entry.instance.cancelled=true;
  if(first&&entry.instance?.api)safely(()=>entry.instance.api.setMotion?.({running:false,visible:false}));
  // Retain the original API and host. The explicit retry control also keeps
  // that recovery handle reachable if a parent discards its controller.
  if(!entry.recoveryButton)entry.recoveryButton=recoveryButton(entry.shell.element,'Retry world return');
  const operation=entry.instance?.cleanup;
  entry.recoveryButton.disabled=operation?.state==='pending';
  entry.recoveryButton.textContent=operation?.state==='pending'?'Waiting for world return':operation?.state==='succeeded'?'Finish world cleanup':'Retry world return';
  safely(()=>entry.shell.setState({state:'unavailable',label,canSelect:false}));
  entry.shell.element.dataset.preview='unavailable';entry.shell.status.textContent=label;entry.shell.previewHost.hidden=true;
  for(const button of [entry.shell.selectButton,entry.shell.nameButton])button.disabled=true;
  safely(()=>entry.shell.setMotion({running:false,visible:false}));
  reflectCleanup();return false;
 }
 function removePreview(entry,{retry=false}={}){
  if(entry.recoveryRequired&&!retry)return false;
  const instance=entry.instance;if(instance)instance.cancelled=true;
  const operation=instance?.cleanup;
  if(operation?.state==='pending')return retain(entry,'World return pending; scene retained');
  if(operation?.state!=='succeeded'&&instance?.api){
   let result;
   try{if(typeof instance.api.dispose!=='function')throw Error('Missing owned teardown');result=instance.api.dispose();}
   catch{cleanupFailures++;return retain(entry);}
   if(result&&typeof result.then==='function'){
    const original={state:'pending'};instance.cleanup=original;
    // Never replay an in-flight teardown. Settlement records the original
    // result; one explicit retry can finish or retry it, without a timer.
    Promise.resolve(result).then(value=>{if(entry.instance!==instance||instance.cleanup!==original)return;original.state=value===false?'failed':'succeeded';if(value===false)cleanupFailures++;retain(entry,value===false?'World return unavailable; scene retained':'World return settled; finish cleanup');},()=>{if(entry.instance!==instance||instance.cleanup!==original)return;original.state='failed';cleanupFailures++;retain(entry);});
    return retain(entry,'World return pending; scene retained');
   }
   if(result===false){cleanupFailures++;return retain(entry);}
  }
  // A successful dispose must return/remove its own content. A non-throwing
  // callback is not permission to delete the sole scene still in this host.
  if(hasContent(entry.shell.previewHost)){cleanupFailures++;return retain(entry,'World return incomplete; scene retained');}
  entry.instance=null;entry.recoveryRequired=false;
  entry.recoveryButton?.remove();entry.recoveryButton=null;reflectCleanup();return true;
 }
 function removeEntry(entry,options){entry.retiring=true;if(!removePreview(entry,options))return false;if(!safely(()=>entry.shell.dispose())||!safely(()=>entry.shell.element.remove()))return retain(entry,'World cleanup unavailable; retained for retry');return true;}
 function clear(options){for(const[id,entry]of entries)if(removeEntry(entry,options))entries.delete(id);note.remove();reflectCleanup();return entries.size===0;}
 function invalidate(entry,label='World connection unavailable'){
  if(!removePreview(entry))return false;entry.shell.setAppearance(null);entry.shell.setState({state:active?'unavailable':'paused',label,canSelect:false});entry.shell.setMotion({running:false,visible:false});return true;
 }
 function empty(){for(const entry of entries.values())invalidate(entry);if(!entries.size)element.append(note);}
 function validated(value){return assertCatalogResponse(value?.catalogResponse,{expectedWorldId,ownerOrigin});}
 function currentInput(){try{return getCurrentInput();}catch{return null;}}
 function ready(project,response){
  if(!active||response.state!=='current'||project?.connection?.state!=='ready'||!project.connection.target)return false;
  return true;
 }
 function eligible(value,id){
  const response=validated(value),catalog=response.catalog,project=catalog?.worlds.find(row=>row.id===id);
  const appearance=qualifiedProjectWorldAppearance({project,catalog,catalogState:response.state,preview:value?.preview,joined:value?.joined,approvedRenderer});
  return{project,response,appearance,permitted:appearance!==null&&ready(project,response)};
 }
 function selected(id){
  if(disposed||disposing||!active)return;const value=currentInput();
  try{const response=validated(value),project=response.catalog?.worlds.find(row=>row.id===id);if(ready(project,response))onSelect(id);else if(entries.has(id))invalidate(entries.get(id));}catch{empty();}
 }
 function paint(entry,instance){entry.shell.setState({state:instance.state==='ready'?'live':'loading',label:instance.state==='ready'?null:'Loading own world…',canSelect:instance.canSelect});}
 function status(entry,instance,value){
  if(disposed||disposing||!active||instance.cancelled||entry.recoveryRequired||entry.instance!==instance||entries.get(instance.projectId)!==entry||!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2||!['loading','ready','unavailable'].includes(value.state)||value.token!==instance.token)return;
  const fresh=currentInput();let context;
  try{context=eligible(fresh,instance.projectId);}catch{invalidate(entry);return;}
  if(!context.permitted){invalidate(entry);return;}
  if(fresh.preview!==instance.preview||fresh.joined!==instance.joined)return;
  if(value.state==='unavailable'){if(removePreview(entry))entry.shell.setState({state:'unavailable',label:'Own-world preview unavailable',canSelect:ready(context.project,context.response)});return;}
  instance.state=value.state;instance.canSelect=ready(context.project,context.response);paint(entry,instance);
 }
 function update(){
  if(disposed||disposing)return false;const value=currentInput();let response;
  try{response=validated(value);}catch{empty();return false;}
  const catalog=response.catalog;if(!catalog){clear();element.append(note);return false;}
  const next=new Map();
  for(const project of catalog.worlds){
   let entry=entries.get(project.id);
   if(entry&&!entry.recoveryRequired&&entry.name!==project.name){entry.shell.setProjectName(project.name);entry.name=project.name;}
   if(!entry){const shell=createProjectWorldShell({document:doc,project,onSelect:selected});entry={name:project.name,shell,instance:null,attached:false};}
   next.set(project.id,entry);
  }
  for(const[id,entry]of entries)if(!next.has(id)&&!removeEntry(entry))next.set(id,entry);
  entries=next;note.remove();for(const entry of entries.values())if(!entry.attached){element.append(entry.shell.element);entry.attached=true;}
  for(const project of catalog.worlds){
   const entry=entries.get(project.id);if(entry.recoveryRequired||entry.retiring)continue;const context=eligible(value,project.id);
   const canSelect=ready(project,response);
   if(!context.permitted){if(removePreview(entry)){entry.shell.setAppearance(context.appearance);entry.shell.setState({state:active?'unavailable':'paused',label:!active?'World preview paused':response.state!=='current'?'Connection unconfirmed':'Own-world preview unavailable',canSelect});}}
   else{
    entry.shell.setAppearance(context.appearance);
    try{
     let instance=entry.instance;
     if(!instance){instance={api:null,state:'loading',token:0,projectId:project.id,preview:null,joined:null,canSelect,cancelled:false};entry.instance=instance;instance.api=createPreview({host:entry.shell.previewHost,project,renderer:approvedRenderer,onStatus:value=>status(entry,instance,value)});if(!instance.api||!['render','setMotion','dispose'].every(key=>typeof instance.api[key]==='function'))throw Error('Owned preview lifecycle required');}
     instance.canSelect=canSelect;
     if(instance.preview!==value.preview||instance.joined!==value.joined){instance.preview=value.preview;instance.joined=value.joined;instance.token=++receiptSequence;instance.state='loading';paint(entry,instance);instance.api.render({preview:value.preview,joined:value.joined,token:instance.token});}
     if(entry.instance===instance){instance.api.setMotion(motion);paint(entry,instance);}
    }catch{if(removePreview(entry))entry.shell.setState({state:'unavailable',label:'Own-world preview unavailable',canSelect});}
   }
   if(!entry.recoveryRequired)entry.shell.setMotion({running:active&&motion.running,visible:active&&motion.visible});
  }
  return true;
 }
 function setMotion({running=false,visible=true}={}){
  if(typeof running!=='boolean'||typeof visible!=='boolean')throw Error('Actual receiver motion required');motion={running,visible};
  for(const entry of entries.values()){if(entry.recoveryRequired||disposing)continue;entry.shell.setMotion({running:active&&running,visible:active&&visible});if(entry.instance)try{entry.instance.api.setMotion({running:active&&running,visible:active&&visible});}catch{invalidate(entry,'Own-world preview unavailable');}}
 }
 function setActive(value){
  if(typeof value!=='boolean')throw Error('Actual overview visibility required');if(disposed||disposing||active===value)return;active=value;element.hidden=!value;
  if(!value){for(const entry of entries.values())invalidate(entry,'World preview paused');return;}
  update();
 }
 function finishDispose(options){
  if(!clear(options))return false;
  rootRecovery?.remove();rootRecovery=null;
  if(hasContent(element)||!safely(()=>element.remove())){if(!rootRecovery)rootRecovery=recoveryButton(element,'Retry retained world cleanup');note.textContent='World cleanup incomplete; retained content needs recovery';element.append(note);reflectCleanup();return false;}
  disposed=true;disposing=false;reflectCleanup();return true;
 }
 function dispose(){if(disposed)return true;if(disposing)return false;disposing=true;active=false;return finishDispose();}
 function retryCleanup(){
  if(disposed)return true;if(disposing)return finishDispose({retry:true});
  for(const[id,entry]of entries)if(entry.recoveryRequired){if(entry.retiring){if(removeEntry(entry,{retry:true}))entries.delete(id);}else removePreview(entry,{retry:true});}
  reflectCleanup();return pending()===0;
 }
 function setApprovedRenderer(value){
  const keys=['schemaVersion','bundleId','worldVersion','artifactSha256'];
  if(value!==null&&(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||!keys.every(key=>Object.hasOwn(value,key))||value.schemaVersion!==1||typeof value.bundleId!=='string'||!/^[a-z][a-z0-9-]{0,79}$/.test(value.bundleId)||typeof value.worldVersion!=='string'||!/^\d+\.\d+\.\d+$/.test(value.worldVersion)||typeof value.artifactSha256!=='string'||!/^[a-f0-9]{64}$/.test(value.artifactSha256)))throw Error('Explicit qualified gallery renderer or null required');
  if(disposed||disposing)return false;if(value===null&&approvedRenderer===null||value!==null&&approvedRenderer!=null&&keys.every(key=>value[key]===approvedRenderer[key]))return true;for(const entry of entries.values())if(!removePreview(entry))return false;approvedRenderer=value===null?null:Object.freeze({...value});update();return true;
 }
 element.hidden=true;reflectCleanup();return{element,update,setMotion,setActive,setApprovedRenderer,dispose,retryCleanup,getDiagnostics:()=>({cleanupFailures,previewInstances:[...entries.values()].filter(entry=>entry.instance).length,pendingRecoveries:pending()+(rootRecovery?1:0),pendingTeardowns:[...entries.values()].filter(entry=>entry.instance?.cleanup?.state==='pending').length,disposing,disposed})};
}
