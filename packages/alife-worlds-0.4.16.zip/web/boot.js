window.__antGardenPublicTitle=document.title;try{if(localStorage.getItem('ant-garden-private-view')==='true'){document.documentElement.dataset.agPrivate='true';}}catch{}
