import {configureScrollableList,preserveListPositions} from './list-presentation.mjs';
import {createSiteAgentMetadataContract,SITE_AGENT_METADATA_LIMIT} from '../lib/site-agent-metadata.mjs';

export const OWNER_AGENT_SETTINGS_LIMIT=SITE_AGENT_METADATA_LIMIT+1024;
const stamp=value=>typeof value==='string'&&Number.isFinite(Date.parse(value))&&new Date(value).toISOString()===value;
export function createOwnerAgentSettings({root,worldId,roles,documentRef=document,windowRef=window,fetcher=fetch,now=Date.now}={}){
 const container=root?.querySelector('#wf-agent-settings');if(!container||root.dataset.workspaceAudience!=='owner')throw Error('Private owner agent settings required.');
 const contract=createSiteAgentMetadataContract({worldId,roles}),make=(tag,className,text)=>{const node=documentRef.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node;};
 const section=make('details','wf-agent-settings'),summary=make('summary','','Agent model settings'),body=make('div','wf-agent-settings-body'),status=make('p','wf-mini','Open to read selected and applied model evidence.'),records=make('div','wf-agent-settings-records');status.setAttribute('role','status');body.append(status,records);section.append(summary,body);container.replaceChildren(section);
 let workspace=null,active=null,disposed=false,sequence=0,lastKey='',pendingRefresh=false;
 const visible=()=>!disposed&&!documentRef.hidden&&root.dataset.operatorMode!=='view'&&root.dataset.operatorMode!=='private';
 function unavailable(message='Agent model settings unavailable.') {sequence++;lastKey='';records.replaceChildren();status.textContent=message;}
 function observeWorkspace(value){
  const allowed=new Set(roles.map(role=>'role-'+role.id));
  if(!value?.available||value.worldId!==worldId||!stamp(value.observedUtc)||!Array.isArray(value.agents)||value.agents.length>100||new Set(value.agents.map(a=>a.alias)).size!==value.agents.length||value.agents.some(a=>!allowed.has(a.alias)||typeof a.name!=='string'||!a.name||a.name.length>160)){workspace=null;active?.abort();unavailable();return;}
  workspace={observedUtc:value.observedUtc,current:value.current===true,agents:new Map(value.agents.map(a=>[a.alias,a.name]))};if(section.open)void refresh();
 }
 const time=value=>value===null?'Not observed':value;
 function update(response){
  if(disposed)return false;if(!visible()){unavailable();return false;}let value;try{value=contract.assertResponse(response,{now:now()});}catch{unavailable();throw Error('Owner agent settings refused.');}const metadata=value.metadata;
  if(!workspace||!metadata||metadata.worldId!==worldId||value.observedUtc!==workspace.observedUtc||metadata.observedUtc!==workspace.observedUtc||metadata.agents.length!==workspace.agents.size||metadata.agents.some(a=>workspace.agents.get(a.id)!==a.name)){unavailable('Waiting for settings from the same workspace observation.');return false;}
  const age=now()-Date.parse(metadata.observedUtc),receivedAge=now()-Date.parse(value.receivedUtc),current=value.state==='current'&&workspace.current&&age>=-5000&&age<=45000&&receivedAge>=-5000&&receivedAge<=45000;
  const message=current?metadata.agents.length?'Current source record. A selection is separate from the model applied to an existing turn.':'Current source record. No active agent settings in this workspace observation.':'Last verified source record. Current settings are unconfirmed.',key=JSON.stringify({value,current});if(key===lastKey){status.textContent=message;return true;}lastKey=key;
  const restore=preserveListPositions(records);const open=new Set([...records.querySelectorAll('details[data-agent-alias]')].filter(n=>n.open).map(n=>n.dataset.agentAlias)),fragment=documentRef.createDocumentFragment();
  const freshness=(state,clock,{shortLived=false,connected=true}={})=>state==='unknown'||clock===null?'Unknown':current&&connected&&state==='current'&&(!shortLived||now()-Date.parse(clock)>=-5000&&now()-Date.parse(clock)<=120000)?'Current':'Last verified';
  for(const agent of metadata.agents){
   const row=make('details','wf-agent-settings-record');row.dataset.agentAlias=agent.id;row.open=open.has(agent.id);const heading=make('summary'),name=make('strong','',agent.name),labels=make('span','wf-agent-settings-pair','Selected: '+(agent.selection.model??'Unknown')+' · Applied: '+(agent.applied.model??'Unknown'));heading.append(name,labels);row.append(heading);
   const list=make('dl','wf-agent-settings-fields'),field=(label,value)=>list.append(make('dt','',label),make('dd','',value));
   field('Selected model',agent.selection.model??'Unknown');field('Selection evidence',freshness(agent.selection.state,agent.selection.observedUtc,{connected:agent.connected}));field('Selection source',agent.selection.source??'Not observed');field('Selection observed UTC',time(agent.selection.observedUtc));
   field('Last applied model',agent.applied.model??'Unknown');field('Applied model evidence',freshness(agent.applied.state,agent.applied.observedUtc,{connected:agent.connected}));field('Applied model source',agent.applied.source??'Not observed');field('Applied model observed UTC',time(agent.applied.observedUtc));
   field('Applied reasoning',agent.applied.reasoning??'Unknown');field('Reasoning evidence',agent.applied.reasoning===null?'Unknown':freshness(agent.applied.state,agent.applied.reasoningObservedUtc,{shortLived:true,connected:agent.connected}));field('Reasoning observed UTC',time(agent.applied.reasoningObservedUtc));
   const speed=agent.applied.speed;field('Applied speed',speed==='default'?'Standard (default)':speed==='priority'?'Fast (priority)':speed==='flex'?'Flex (flex)':'Unknown');field('Speed evidence',speed===null?'Unknown':freshness(agent.applied.state,agent.applied.speedObservedUtc,{shortLived:true,connected:agent.connected}));field('Speed observed UTC',time(agent.applied.speedObservedUtc));
   field('Source observation UTC',metadata.observedUtc);field('Source receipt UTC',time(value.receivedUtc));field('Settings revision',String(metadata.revision));configureScrollableList(list,17,agent.name+' model evidence','settings:'+agent.id);row.append(list);fragment.append(row);
  }records.replaceChildren(fragment);configureScrollableList(records,metadata.agents.length,'Agent model settings','settings');restore();status.textContent=message;return true;
 }
 async function refresh(){
  if(!visible()||!section.open||!workspace)return;if(active){pendingRefresh=true;return;}const own=++sequence,controller=new AbortController();active=controller;const deadline=windowRef.setTimeout(()=>controller.abort(),6000);status.textContent='Reading selected and applied settings…';
  try{
   const url=new URL(container.dataset.agentMetadataSource||'/api/agent-metadata',windowRef.location.href);if(url.origin!==windowRef.location.origin||url.pathname!=='/api/agent-metadata'||url.search||url.hash)throw Error('Exact owner metadata source required.');url.searchParams.set('project',worldId);
   const response=await fetcher(url.href,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',headers:{Accept:'application/json'},signal:controller.signal});if(!response.ok||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')||'')||Number(response.headers.get('content-length'))>OWNER_AGENT_SETTINGS_LIMIT)throw Error('Owner settings unavailable.');
   const reader=response.body.getReader(),parts=[];let size=0;try{while(true){const row=await reader.read();if(row.done)break;size+=row.value.byteLength;if(size>OWNER_AGENT_SETTINGS_LIMIT){await reader.cancel();throw Error('Owner settings exceed their bound.');}parts.push(row.value);}}finally{reader.releaseLock();}
   const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}if(disposed||controller.signal.aborted||own!==sequence||!visible())return;update(JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes)));
  }catch{controller.abort();if(!disposed&&own===sequence)unavailable();}
  finally{windowRef.clearTimeout(deadline);if(active===controller)active=null;const again=pendingRefresh;pendingRefresh=false;if(again&&visible()&&section.open)void refresh();}
 }
 const workspaceEvent=event=>observeWorkspace(event.detail),toggle=()=>{if(section.open)void refresh();else{active?.abort();pendingRefresh=false;}},visibility=()=>{if(!visible()){active?.abort();pendingRefresh=false;unavailable();}else if(section.open)void refresh();};
 function dispose(){if(disposed)return;disposed=true;sequence++;active?.abort();observer?.disconnect();workspace=null;container.replaceChildren();root.removeEventListener('alife-workspace-refresh',workspaceEvent);section.removeEventListener('toggle',toggle);documentRef.removeEventListener('visibilitychange',visibility);windowRef.removeEventListener('pagehide',dispose);}
 const observer=windowRef.MutationObserver?new windowRef.MutationObserver(visibility):null;observer?.observe(root,{attributes:true,attributeFilter:['data-operator-mode']});section.addEventListener('toggle',toggle);root.addEventListener('alife-workspace-refresh',workspaceEvent);documentRef.addEventListener('visibilitychange',visibility);windowRef.addEventListener('pagehide',dispose);
 return Object.freeze({observeWorkspace,update,refresh,unavailable,dispose});
}
