export function countProgress(snapshot,m){
 const config=m.cfg?.antGardenSprint||{},scope=String(config.id||m.presentation?.id||'current-sprint'),credits=new Map();
 const unique=values=>[...new Set((values||[]).filter(v=>typeof v==='string'&&v))],records=new Map((snapshot.tasks||[]).map(t=>[t.id,t]));
 const done=t=>t?.stage==='Done'&&t?.milestone?.delivered===true;
 function members(row){
  const goals=new Map((row.requiredGoals||[]).map(g=>[g.id,g])),ids=unique([...(row.taskIds||[]),...(row.requiredGoalIds||[]),...(row.remainingGoalIds||[]),...goals.keys()]);
  let completed=0,missing=!!row.missingGoalRefs?.length;
  for(const id of ids){const task=records.get(id),goal=goals.get(id);if(!task&&!goal)missing=true;else if(task?done(task):goal.complete===true)completed++;}
  return{ids,completed,total:ids.length,missing,complete:ids.length>0&&!missing&&completed===ids.length};
 }
 let ids=[],units=0,total=0,missing=false,complete=false,unit='tasks';
 if(config.unit==='sprints'){
  unit='sprints';const rows=config.sprints||m.roadmap?.sprints||[],seen=new Set();
  for(const row of rows){if(!row?.id||seen.has(row.id)){missing=true;continue;}seen.add(row.id);const p=members(row);total++;if(p.missing)missing=true;if(p.complete){units++;credits.set(row.id+':done',{task:row.id,weight:1,title:row.title||row.id});}}
  complete=total>0&&!missing&&units===total;
 }else{
  const row=m.roadmap?.sprints?.find(s=>s.id===scope)||{},p=members({...row,taskIds:unique([...(row.taskIds||[]),...(config.taskIds||m.presentation?.taskIds||[])])});
  ids=p.ids;units=p.completed;total=p.total;missing=p.missing;complete=p.complete;
  for(const id of ids){const t=records.get(id),goal=row.requiredGoals?.find(g=>g.id===id);if(t?done(t):goal?.complete===true)credits.set(id+':done',{task:id,owner:t?.owner,weight:1,title:t?.title||id});}

 }
 return{scope,title:config.title||m.presentation?.title||'Current sprint',credits,total,units,complete,percent:total&&!missing?Math.floor(units/total*100):null,tasks:total,accepted:units,unit};
}
export function progressFor(model,taskIds,title,credits=countProgress){
 const sprint=model.roadmap?.sprints?.find(s=>s.id===title||s.title===title),ids=[...new Set([...(taskIds||[]),...(sprint?.taskIds||[])])];
 return credits({tasks:model.tasks},{...model,cfg:{...model.cfg,antGardenSprint:{id:sprint?.id||model.presentation?.id||title,title,taskIds:ids}}});
}
export function dashboardProgress(model,credits=countProgress){
 return {sprint:progressFor(model,model.presentation.taskIds,model.presentation.title,credits),epic:credits({tasks:model.tasks},{...model,cfg:{...model.cfg,antGardenSprint:{id:model.roadmap?.epic?.id||'epic',title:model.roadmap?.epic?.title||'Epic',unit:'sprints',sprints:model.roadmap?.sprints||[]}}})};
}
export function recentHandoffs(model,feed,limit=12){
 const names=new Map(model.agents.map(a=>[a.threadId,a.title])),seen=new Set();
 return (feed.motionEvents||[]).filter(e=>{if(!e.id||seen.has(e.id)||!names.has(e.fromThreadId)||!names.has(e.toThreadId)||!Number.isFinite(Date.parse(e.observedUtc)))return false;seen.add(e.id);return true;}).sort((a,b)=>Date.parse(b.observedUtc)-Date.parse(a.observedUtc)).slice(0,limit).map(e=>({id:e.id,from:names.get(e.fromThreadId),to:names.get(e.toThreadId),observedUtc:e.observedUtc,kind:({handoff:'Handoff','follow-up':'Follow-up',stage:'Stage update',step:'Step update',publication:'Publication',acceptance:'Acceptance'}[e.transferKind||e.kind]||'Message')}));
}

export function siteTaskStatus(task){
 if(task?.blocker||task?.condition==='blocked'||task?.state==='blocked')return'blocked';
 if(task?.milestone?.delivered===true)return'accepted';
 if(['Backlog','Shaping','Ready'].includes(task?.stage))return'backlog';
 if(['In Progress','QA','In Review'].includes(task?.stage))return'progress';
 return'unknown';
}
export function siteActivityStatus(agent,health,feed,now=Date.now()){
 const age=now-Date.parse(feed?.observedUtc),activityAge=now-Date.parse(health?.activityObservedUtc);
 if(!agent?.connected||feed?.error||!Number.isFinite(age)||age< -5000||age>120000||!Number.isFinite(activityAge)||activityAge< -5000||activityAge>120000&&!(health?.terminal&&health.activityState==='idle'))return'unknown';
 return health.activityState==='idle'?'idle':health.activityState==='working'?'progress':'unknown';
}
