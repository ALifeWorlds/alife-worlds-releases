import {createOwnerCandidateReadiness,assertOwnerCandidateFrameContext} from '../owner-candidate-readiness.mjs';
import {assertOwnerReleaseOffer} from '../owner-release-offer.mjs';
import {createOwnerGalleryApproval} from '../owner-gallery-approval.mjs';
import {createMountedWorldSwap} from '../mounted-world-swap.mjs';
import {assertReplacementFrameMessage} from './replacement-message.mjs';

const replacementClosed=(value,keys)=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
const replacementSameRenderer=(a,b)=>a&&b&&['schemaVersion','bundleId','worldVersion','artifactSha256'].every(key=>a[key]===b[key]);
const replacementPreferences=value=>value&&['public','private','view'].includes(value.mode)&&typeof value.paused==='boolean'&&typeof value.volume==='number'&&Number.isFinite(value.volume)&&value.volume>=0&&value.volume<=1&&typeof value.soundEnabled==='boolean';
const replacementCommon=['type','worldId','epoch','nonce','controlRevision'];

// Root's protected offer/context owns navigation. Existing catalog refresh calls
// refresh(); this controller creates no permanent release poller.
export function createOwnerMountedReplacement({scene,activeFrame,context,getPreferences,onRevoke=()=>{},onStatus=()=>{},documentRef=document,windowRef=window,fetcher=fetch,now=Date.now,cryptoRef=globalThis.crypto,timeoutMs=45000}={}){
 if(!scene?.isConnected||!activeFrame||!scene.contains(activeFrame)||context?.ownerOrigin!==windowRef.location.origin||!['local-owner','owner-private'].includes(context.access)||typeof getPreferences!=='function'||!cryptoRef?.getRandomValues)throw Error('Configured private mounted receiver required');
 if(!/^\/world-frame\/[a-f0-9]{64}\/$/.test(new URL(activeFrame.src,context.ownerOrigin).pathname))return null;
 const ownerOrigin=context.ownerOrigin,worldId=context.worldId,scopeKey=[worldId,context.access,ownerOrigin].join('|');
 const offerURL=new URL('/api/owner-world-release',ownerOrigin);offerURL.searchParams.set('project',worldId);
 let active=null,offer=null,disposed=false,revoked=false,epoch=0,revision=0,refreshing=null,refreshController=null,failures=0,nextRead=0,galleryEstablished=false;
 const initialGallery=context.qualifiedGalleryRenderer??null,galleryApproval=createOwnerGalleryApproval({initialRenderer:initialGallery,worldId,access:context.access,ownerOrigin});
 const sessions=new Map(),receivers=new Set(),observers=new Set();
 const sameContext=(a,b)=>a&&b&&JSON.stringify(a)===JSON.stringify(b);
 const preferences=()=>{const p=getPreferences();return replacementPreferences(p)?{mode:p.mode,paused:p.paused,volume:p.volume,soundEnabled:p.soundEnabled}:null;};
 function status(state,reason){try{onStatus({state,reason});}catch{}}
 function nonce(){return Array.from(cryptoRef.getRandomValues(new Uint8Array(24)),v=>v.toString(16).padStart(2,'0')).join('');}
 function notify(){for(const observer of observers)try{observer();}catch{}}
 const sameAuthority=(a,b)=>a&&b&&sameContext({...a,websiteVersion:null},{...b,websiteVersion:null});
 function allowed(entry){return!disposed&&!revoked&&entry.live&&offer&&[offer.current,offer.previous].some(value=>sameAuthority(value,entry.context));}
 function post(entry,type,extra={}){if(!entry?.frame?.contentWindow||!entry.live)return false;try{entry.frame.contentWindow.postMessage({type,...entry.correlation,...extra},ownerOrigin);return true;}catch{return false;}}
 function wait(entry,type,signal,predicate=()=>true){
  return new Promise((resolve,reject)=>{
   if(!entry.live||signal?.aborted){reject(Error('Receiver lifetime ended'));return;}
   const pending={type,predicate,resolve(value){cleanup();resolve(value);},reject(error){cleanup();reject(error);}};
   const abort=()=>pending.reject(Error('Receiver lifetime ended')),timer=windowRef.setTimeout(()=>pending.reject(Error('Receiver acknowledgment timed out')),8000);
   function cleanup(){windowRef.clearTimeout(timer);signal?.removeEventListener('abort',abort);entry.waiters.delete(pending);}
   entry.waiters.add(pending);signal?.addEventListener('abort',abort,{once:true});
  });
 }
 function disposeSession(entry){
  if(!entry?.live)return;try{post(entry,'alife-world-frame-dispose');}catch{}entry.live=false;entry.proof=null;entry.resource=null;entry.applied=null;entry.shield?.remove();entry.shield=null;
  for(const pending of [...entry.waiters])pending.reject(Error('Receiver disposed'));entry.frame?.removeEventListener('load',entry.loaded);entry.qualifier.dispose();sessions.delete(entry.frame);
 }
 function revoke(reason='World access could not be verified'){
  if(disposed||revoked)return;revoked=true;refreshController?.abort();swap.cancel(reason);
  for(const entry of [...sessions.values()])disposeSession(entry);active=null;offer=null;
  try{onRevoke();}finally{scene.replaceChildren();notify();status('unavailable',reason);}
 }
 function identity(value){if(value&&(['worldId','access','ownerOrigin'].some(key=>typeof value[key]==='string'&&value[key]!==({worldId,access:context.access,ownerOrigin})[key]))){const error=Error('Root world or audience changed');error.revoked=true;throw error;}}
 async function jsonAt(url,limit,signal){
  const response=await fetcher(url,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',headers:{Accept:'application/json'},signal});
  if(response.status===401||response.status===403){const error=Error('Owner access unavailable');error.revoked=true;throw error;}
  if(!response.ok||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')||''))throw Error('Owner update unavailable');
  if(response.url&&new URL(response.url).origin!==ownerOrigin){const error=Error('Owner source origin changed');error.revoked=true;throw error;}
  const reader=response.body?.getReader();if(!reader)throw Error('Missing owner response body');let length=0;const chunks=[];
  try{while(true){const part=await reader.read();if(part.done)break;length+=part.value.byteLength;if(length>limit){await reader.cancel();throw Error('Owner response too large');}chunks.push(part.value);}}finally{reader.releaseLock();}
  const bytes=new Uint8Array(length);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.byteLength;}return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
 }
 function createSession(frameContext,frame=null){
  const entry={context:frameContext,frame,live:true,resource:null,resourceAt:0,proof:null,applied:null,waiters:new Set(),sequence:0,restoreSequence:0};
  entry.correlation={worldId,epoch:++epoch,nonce:nonce(),controlRevision:revision};
  entry.scope={projectId:worldId,worldId,access:context.access,ownerOrigin,visualStateScope:frameContext.visualStateScope};
  entry.candidate=Object.freeze({url:new URL(frameContext.framePath,ownerOrigin).href,epoch:entry.correlation.epoch});
  entry.qualifier=createOwnerCandidateReadiness({
   getCurrentScope:()=>allowed(entry)?entry.scope:null,
   getCandidateBinding:()=>({scope:entry.scope,renderer:entry.context.renderer,url:entry.candidate.url,...{epoch:entry.correlation.epoch,nonce:entry.correlation.nonce,controlRevision:entry.correlation.controlRevision}}),
   verifyResources:({frame:receiver})=>allowed(entry)&&entry.frame===receiver&&receiver?.isConnected===true&&entry.resource?.receiverReady===true&&entry.resource.resources.ready===true&&entry.resource.resources.art==='ready'&&entry.resource.resources.font==='ready'&&entry.resource.resources.disposed===false&&replacementSameRenderer(entry.resource.renderer,entry.context.renderer)&&now()-entry.resourceAt>=0&&now()-entry.resourceAt<=10000&&entry.applied!==null,
   assertFrameMessage:assertReplacementFrameMessage,now,subtle:cryptoRef.subtle
  });return entry;
 }
 function attach(entry,frame){entry.frame=frame;sessions.set(frame,entry);entry.loaded=()=>{if(entry!==active||!allowed(entry))return;entry.proof=null;entry.resource=null;entry.qualifier.invalidate(entry.candidate);challenge(entry,preferences());post(entry,'alife-world-frame-commit');notify();};frame.addEventListener('load',entry.loaded);}
 function find(candidate){for(const entry of sessions.values())if(entry.candidate===candidate)return entry;return null;}
 function challenge(entry,p){if(!entry?.live||!p)return false;entry.desired={mode:p.mode,paused:p.paused,volume:p.volume};entry.applied=null;entry.proof=null;post(entry,'alife-world-controls',entry.desired);post(entry,'alife-project-world-request');return true;}
 const swap=createMountedWorldSwap({scene,activeFrame,ownerOrigin,getContextKey:()=>revoked?'revoked':scopeKey,getPreferences:()=>{const p=preferences();if(!p)throw Error('Actual controls not observed');return p;},timeoutMs,documentRef,windowRef,
  qualifyCandidate:candidate=>{const entry=find(candidate);if(!entry||!allowed(entry)||!sameContext(entry.context,offer.current))throw Error('Current Root candidate required');return candidate;},
  requestReadiness:({frame,candidate,preferences:p,signal})=>{const entry=find(candidate);if(!entry||entry.frame!==frame)throw Error('Owned candidate receiver required');signal.addEventListener('abort',()=>disposeSession(entry),{once:true});challenge(entry,p);},
  qualifyReady:(event,options)=>{const entry=find(options.candidate);return entry?.qualifier.qualifyReady(event,options)??null;},
  isReadyCurrent:(proof,options)=>find(options.candidate)?.qualifier.isReadyCurrent(proof,options)===true,
  async transferWorldState({previousFrame,candidateFrame,candidate,signal}){
   const previous=sessions.get(previousFrame),next=find(candidate);if(!previous?.live||next?.frame!==candidateFrame)throw Error('Actual transfer receivers required');
   // Block new pointer starts during the final capture/restore/hash boundary.
   // Leave the old iframe/focus/capture intact so an existing World drag can
   // explicitly refuse adoption and keep its original pointer custody.
   const shield=documentRef.createElement('div');shield.className='wf-transfer-shield';shield.setAttribute('aria-hidden','true');Object.assign(shield.style,{position:'absolute',inset:'0',zIndex:'2147483647',background:'transparent',pointerEvents:'auto'});next.shield=shield;scene.append(shield);
   const captured=wait(previous,'alife-world-capture-result',signal);post(previous,'alife-world-capture-request');const capture=(await captured).data.result;
   if(capture.reason==='interaction-active')throw Error('Current world interaction is active');
   const floor=next.sequence,restored=wait(next,'alife-world-restore-result',signal);
   const rendered=wait(next,'alife-project-world-preview',signal,()=>next.restoreSequence>floor&&next.sequence>next.restoreSequence);
   // Keep both rejection paths observed even when only one acknowledgment fails.
   const completion=Promise.all([restored,rendered]);post(next,'alife-world-restore-request',{capsule:capture.captured?capture.capsule:null});
   const [restoreEvent,renderEvent]=await completion;if(restoreEvent.data.result.reason==='interaction-active')throw Error('Replacement interaction is active');
   if(!next.applied)throw Error('Applied controls unavailable');return{ready:true,...next.applied,soundEnabled:false,renderEvent,visualTransfer:restoreEvent.data.result};
  },
  prepareBindings({previousFrame,candidateFrame,candidate,ready}){
   const previous=active,next=find(candidate);if(previous?.frame!==previousFrame||next?.frame!==candidateFrame)throw Error('Current receiver bindings changed');
   const detail={frame:candidateFrame,previousFrame,renderer:next.context.renderer,qualifiedGalleryRenderer:galleryApproval.rendererFor(next.context),context:next.context,preview:ready.preview,joined:ready.joined};
   const bindings=[...receivers].map(prepare=>prepare(detail));if(bindings.some(binding=>!binding||!['commit','rollback','disposePrevious'].every(key=>typeof binding[key]==='function')))throw Error('Synchronous receiver transaction required');
   return{commit(){active=next;next.proof=ready;next.worldKey=ready.preview.snapshot.model.visualWorldKey;for(const binding of bindings){const result=binding.commit();if(result&&typeof result.then==='function')throw Error('Receiver bindings must commit synchronously');}post(next,'alife-world-frame-commit');},rollback(){for(const binding of bindings.slice().reverse())try{binding.rollback();}catch{}active=previous;next.proof=null;},disposePrevious(){disposeSession(previous);next.shield?.remove();next.shield=null;for(const binding of bindings)binding.disposePrevious();notify();}};
  },onStatus:value=>{if(value.state==='retained'){const frame=swap.getPendingFrame();for(const entry of [...sessions.values()])if(entry!==active&&entry.frame!==frame)disposeSession(entry);}status(value.state,value.reason);}
 });
 function validReply(entry,data){
  if(!data||Object.keys(entry.correlation).some(key=>data[key]!==entry.correlation[key]))return false;
  if(data.type==='alife-world-resource-state')return replacementClosed(data,[...replacementCommon,'renderer','resources','receiverReady'])&&replacementSameRenderer(data.renderer,entry.context.renderer)&&replacementClosed(data.resources,['ready','art','font','disposed'])&&typeof data.resources.ready==='boolean'&&['loading','ready','fallback'].includes(data.resources.art)&&['loading','ready','fallback'].includes(data.resources.font)&&typeof data.resources.disposed==='boolean'&&typeof data.receiverReady==='boolean';
  if(data.type==='alife-world-controls-applied')return replacementClosed(data,replacementCommon);
  if(data.type==='alife-world-capture-result')return replacementClosed(data,[...replacementCommon,'result'])&&replacementClosed(data.result,['captured','reason','capsule'])&&typeof data.result.captured==='boolean'&&typeof data.result.reason==='string'&&data.result.reason.length<=128&&(data.result.captured?data.result.capsule&&typeof data.result.capsule==='object':data.result.capsule===null);
  if(data.type==='alife-world-restore-result'){const result=data.result,keys=result&&Object.hasOwn(result,'actors')?['applied','reason','actors']:['applied','reason'];return replacementClosed(data,[...replacementCommon,'result'])&&replacementClosed(result,keys)&&typeof result.applied==='boolean'&&typeof result.reason==='string'&&result.reason.length<=128&&(!Object.hasOwn(result,'actors')||Number.isSafeInteger(result.actors)&&result.actors>=0&&result.actors<=100);}
  return data.type==='alife-project-world-preview'&&replacementClosed(data,[...replacementCommon,'receivedUtc','preview','joined']);
 }
 function message(event){
  if(disposed||revoked||event.origin!==ownerOrigin)return;const entry=[...sessions.values()].find(row=>row.frame?.contentWindow===event.source);if(!entry||!allowed(entry)||!validReply(entry,event.data))return;
  const data=event.data;entry.sequence++;
  if(data.type==='alife-world-resource-state'){entry.resource=data;entry.resourceAt=now();if(!data.receiverReady){entry.proof=null;entry.qualifier.invalidate(entry.candidate);if(entry===active)notify();}return;}
  if(data.type==='alife-world-controls-applied'&&entry.desired)entry.applied={...entry.desired,soundEnabled:false};
  if(data.type==='alife-world-restore-result')entry.restoreSequence=entry.sequence;
  for(const pending of [...entry.waiters])if(pending.type===data.type&&pending.predicate())pending.resolve(event);
  if(data.type==='alife-project-world-preview'){
   if(entry===active){void entry.qualifier.qualifyReady(event,{frame:entry.frame,candidate:entry.candidate,epoch:entry.correlation.epoch}).then(proof=>{if(disposed||revoked||entry!==active||!entry.live)return;entry.proof=proof;if(proof)entry.worldKey=proof.preview.snapshot.model.visualWorldKey;notify();});}
   else void swap.accept(event);
  }
 }
 async function refresh({force=false}={}){
  if(disposed||revoked||documentRef.hidden||refreshing||!force&&now()<nextRead)return refreshing;
  const controller=new AbortController();refreshController=controller;const timeout=windowRef.setTimeout(()=>controller.abort(),8000);
  refreshing=(async()=>{
   try{
    const raw=await jsonAt(offerURL.href,16384,controller.signal);identity(raw);const nextOffer=assertOwnerReleaseOffer(raw,{worldId,access:context.access,ownerOrigin});
    const rawContext=await jsonAt(new URL(nextOffer.current.framePath+'context',ownerOrigin).href,4096,controller.signal);identity(rawContext);
    const current=assertOwnerCandidateFrameContext(rawContext,{worldId,access:context.access,ownerOrigin,renderer:nextOffer.current.renderer});if(!sameContext(current,nextOffer.current))throw Error('Root offer/context changed during read');
    if(!galleryEstablished&&initialGallery){
     const approved=[nextOffer.current,nextOffer.previous].find(value=>value&&replacementSameRenderer(value.renderer,initialGallery));
     if(approved){let checked=current;if(approved!==nextOffer.current){const rawApproved=await jsonAt(new URL(approved.framePath+'context',ownerOrigin).href,4096,controller.signal);identity(rawApproved);checked=assertOwnerCandidateFrameContext(rawApproved,{worldId,access:context.access,ownerOrigin,renderer:initialGallery});if(!sameContext(checked,approved))throw Error('Approved gallery context changed during read');}galleryEstablished=galleryApproval.establish(checked);}
    }
    if(disposed||revoked||controller.signal.aborted)return false;
    const before=active?.context.visualStateScope,after=current.visualStateScope,beforeWorld=before?.worldKey??active?.worldKey;
    if(after&&(beforeWorld&&beforeWorld!==after.worldKey||before&&before.audienceKey!==after.audienceKey)){const error=Error('Selected world or audience changed');error.revoked=true;throw error;}
    offer=nextOffer;failures=0;nextRead=0;
    if(!active){
     const initial=[offer.current,offer.previous].find(value=>value&&new URL(value.framePath,ownerOrigin).href===activeFrame.src&&replacementSameRenderer(value.renderer,context.renderer));
     if(!initial)throw Error('Initial frame is outside the qualified release pair');
     if(initial!==offer.current){const rawInitial=await jsonAt(new URL(initial.framePath+'context',ownerOrigin).href,4096,controller.signal);identity(rawInitial);const checked=assertOwnerCandidateFrameContext(rawInitial,{worldId,access:context.access,ownerOrigin,renderer:initial.renderer});if(!sameContext(initial,checked))throw Error('Previous frame context changed during read');}
     if(disposed||revoked||controller.signal.aborted)return false;
     active=createSession(initial,activeFrame);attach(active,activeFrame);challenge(active,preferences());post(active,'alife-world-frame-commit');return true;
    }
    if(replacementSameRenderer(active.context.renderer,current.renderer)){if(!active.applied)challenge(active,preferences());return true;}
    if(!allowed(active))throw Error('Active release is outside the qualified recovery pair');
    const pending=swap.getPendingFrame();if(pending&&replacementSameRenderer(sessions.get(pending)?.context.renderer,current.renderer))return true;
    if(!preferences())return false;
    const entry=createSession(current);sessions.set(entry.candidate,entry);
    try{const attempt=swap.begin(entry.candidate);sessions.delete(entry.candidate);attach(entry,attempt.frame);attempt.signal.addEventListener('abort',()=>disposeSession(entry),{once:true});return true;}catch(error){sessions.delete(entry.candidate);disposeSession(entry);throw error;}
   }catch(error){if(error.revoked){revoke(error.message);return false;}if(!disposed&&!revoked){failures=Math.min(6,failures+1);nextRead=now()+Math.min(30000,1000*2**failures);status('retained','World updates unavailable. The current scene is retained.');}return false;}
   finally{windowRef.clearTimeout(timeout);if(refreshController===controller)refreshController=null;refreshing=null;}
  })();return refreshing;
 }
 function preferencesChanged(){
  if(disposed||revoked)return;const p=preferences();if(!p)return;swap.contextChanged();if(!active)return;
  const desired=active.desired;if(desired&&['mode','paused','volume'].every(key=>desired[key]===p[key]))return;
  revision++;active.correlation={...active.correlation,controlRevision:revision};active.resource=null;active.qualifier.invalidate(active.candidate);challenge(active,p);
 }
 function getCurrentInput(){if(!active?.proof||!allowed(active)||!active.qualifier.isReadyCurrent(active.proof,{frame:active.frame,candidate:active.candidate,epoch:active.correlation.epoch}))return null;return{preview:active.proof.preview,joined:active.proof.joined};}
 function dispose(){if(disposed)return;swap.dispose();refreshController?.abort();for(const entry of [...sessions.values()])disposeSession(entry);disposed=true;active=null;offer=null;receivers.clear();observers.clear();windowRef.removeEventListener('message',message);windowRef.removeEventListener('pagehide',dispose);}
 windowRef.addEventListener('message',message);windowRef.addEventListener('pagehide',dispose,{once:true});
 return Object.freeze({refresh,preferencesChanged,getCurrentInput,revoke,dispose,getActiveFrame:()=>active?.frame??activeFrame,getActiveRenderer:()=>active?.context.renderer??context.renderer,getGalleryRenderer:()=>active&&allowed(active)?galleryApproval.rendererFor(active.context):null,
  subscribe(prepare){if(typeof prepare!=='function')throw Error('Receiver transaction factory required');receivers.add(prepare);return()=>receivers.delete(prepare);},observe(listener){observers.add(listener);return()=>observers.delete(listener);},
  diagnostics:()=>({disposed,revoked,sessions:sessions.size,pending:swap.getPendingFrame(),active:active?.frame??null,nextRead,failures})});
}
