import {configureScrollableList,preserveListPositions} from '../list-presentation.mjs';
import {HUMAN_QA_LIMITS,HUMAN_QA_ATTESTATION,qaClosed,qaHash,qaUtc,qaText,assertQaEnvelope,assertQaSubmission,verifyQaManifest} from './human-qa-contract.mjs';
// Owner-private presentation and client for Root's exact authenticated QA protocol.
// Request storage contains only the protocol's opaque identity/body, never goal text or credentials.
const verificationLabels={unreported:'Not yet recorded',submitting:'Submitting…',recorded:'Verification saved','prior-pass':'Earlier human pass preserved',unknown:'Submission status unknown',unavailable:'Verification unavailable'};
const deliveryLabels={'not-attempted':'Not sent to QA',queued:'Queued for QA',unavailable:'QA connection unavailable',unknown:'QA delivery unconfirmed',delivered:'Delivered to QA'};
export function humanGoalPresentation(item){
 const prior=item.verificationState==='prior-pass',recorded=prior||item.verificationState==='recorded';
 const delivery=item.deliveryState==='delivered'&&item.deliveryReceiptVerified!==true?'unknown':item.deliveryState;
 return {checked:recorded,verification:verificationLabels[item.verificationState]||verificationLabels.unknown,delivery:deliveryLabels[delivery]||deliveryLabels.unknown,prior};
}
export function renderHumanGoals({container,view,documentRef=document,onVerify=()=>{},onRefresh=()=>{}}){
 if(view.audience!=='owner')throw Error('Owner-private goal view required');
 const el=(tag,cls,text)=>{const node=documentRef.createElement(tag);if(cls)node.className=cls;if(text!==undefined)node.textContent=text;return node;};
 const restore=preserveListPositions(container);const previousHistory=container.querySelector?.('.wf-human-history')?.open===true;
 const focusKey=documentRef.activeElement?.dataset?.humanGoalKey;
 const focusTargets=new Map();
 const header=el('div','wf-section-title'),title=el('h3','', 'Human goal verification');title.id='wf-human-goals-title';
 const refresh=el('button','wf-button','Refresh');refresh.type='button';refresh.addEventListener('click',onRefresh);header.append(title,refresh);
 const intro=el('p','wf-mini','Confirm only goals you have checked. Saved confirmations and delivery to QA are shown separately.');
 const state=el('p','wf-mini wf-human-list-state');state.setAttribute('role','status');
 state.textContent=view.sourceState==='current'?'Recorded goals ready for review':view.sourceState==='stale'?'Last recorded goals · confirmations unavailable until the list is current':'Goal list unavailable';
 const reviews=el('div','wf-human-goal-list');
 const items=Array.isArray(view.items)?view.items:[],history=Array.isArray(view.history)?view.history:[];
 function card(item,index,historical=false){
  const row=el('article','wf-human-goal'),presentation=humanGoalPresentation(item),top=el('div','wf-human-goal-top');
  const name=el('h4','',item.title),tag=el('span','wf-human-kind',historical?'Completed history':item.optional===true?'Optional review':'Delivered goal');top.append(name,tag);
  row.append(top,el('p','wf-human-goal-purpose',item.goal));
  if(presentation.prior)row.append(el('p','wf-mini','Pass scope: '+(item.passScopeLabel||'Earlier candidate; version not separately recorded')));
  else if(item.candidateLabel)row.append(el('p','wf-mini',item.candidateLabel));
  if(item.surface?.url){const link=el('a','wf-mini wf-human-try','Open '+item.surface.label);link.href=item.surface.url;link.target='_blank';link.rel='noopener noreferrer';row.append(link);}
  const verify=el('div','wf-human-result');
  if(!historical||presentation.checked){
   const label=el('label','wf-human-checkbox'),input=el('input');input.type='checkbox';input.checked=presentation.checked;
   input.id='wf-human-goal-'+index;input.dataset.humanGoalKey=item.key;
   input.disabled=historical||presentation.checked||view.sourceState!=='current'||view.canSubmit!==true||item.canVerify!==true||['submitting','unknown','unavailable'].includes(item.verificationState);
   const text=el('span','',presentation.checked?'Human verification recorded':HUMAN_QA_ATTESTATION);label.append(input,text);verify.append(label);
   let requested=false;
   input.addEventListener('change',event=>{input.checked=presentation.checked;if(input.disabled||requested||event.isTrusted!==true)return;requested=true;input.disabled=true;onVerify(item.key);});
   focusTargets.set(item.key,input);
  }
  const status=el('p','wf-mini');status.setAttribute('role','status');
  status.textContent=historical&&!presentation.checked?'Recorded complete · no separate human result':presentation.verification;
  verify.append(status);row.append(verify);
  if(!historical)row.append(el('p','wf-mini wf-human-delivery',item.deliveryMessage||presentation.delivery));
  if(item.pendingActions){const actions=el('div','wf-human-actions');for(const [text,action]of item.pendingActions){const button=el('button','wf-button',text);button.type='button';button.disabled=view.canSubmit!==true||item.verificationState==='submitting';button.addEventListener('click',event=>{if(event.isTrusted===true)action();});actions.append(button);}row.append(actions);}
  if(item.canonicalStatus)row.append(el('p','wf-mini','Task status: '+item.canonicalStatus));
  if(item.recordedAtLabel)row.append(el('p','wf-mini',item.recordedAtLabel));
  return row;
 }
 configureScrollableList(reviews,items.length,'Goals awaiting human review','human-goals');items.forEach((item,index)=>reviews.append(card(item,index)));
 if(!items.length)reviews.append(el('p','wf-mini',view.sourceState==='current'?'No delivered goals are listed for a new review.':'No current goal list is available.'));
 const older=el('details','wf-disclosure wf-human-history'),summary=el('summary');summary.append(el('span','', 'Earlier completed goals · '+history.length));older.append(summary);
 const body=el('div','wf-disclosure-body');history.forEach((item,index)=>body.append(card(item,items.length+index,true)));configureScrollableList(body,history.length,'Earlier completed goals','human-goal-history');older.append(body);older.open=previousHistory;
 const transport=el('p','wf-mini wf-human-transport',view.transportMessage||'QA connection unavailable');
 const notice=el('p','wf-mini',view.message||'');notice.setAttribute('role','status');
 container.replaceChildren(header,intro,state,transport,notice,reviews,older);restore();
 container.setAttribute('aria-labelledby','wf-human-goals-title');
 if(focusKey)focusTargets.get(focusKey)?.focus?.();
}

const qaKey=g=>JSON.stringify([g.entryId,g.candidateId,g.surface.id]);
const qaBodyKey=b=>JSON.stringify([b.entryId,b.candidateId,b.surfaceId]);
const qaVersions=g=>Object.entries(g.candidate).filter(([,v])=>v!==null).map(([key,v])=>({websiteVersion:'Website',pluginVersion:'Plugin',worldVersion:'World'}[key])+' '+v).join(' / ');
const qaReported=value=>'Human report recorded '+new Date(value).toLocaleString();
export function qaViewModel(envelope){
 const view={audience:'owner',sourceState:envelope.state,canSubmit:envelope.canSubmit,transportMessage:envelope.transport.message,message:envelope.message,items:[],history:[]};
 for(const row of envelope.goals){const g=row.goal,historical=g.reviewState==='historical',prior=historical&&g.prior.state==='pass';
  const item={key:qaKey(g),title:g.title,goal:g.goal,optional:g.optional,surface:g.surface,candidateLabel:qaVersions(g)||'Candidate versions not separately recorded',passScopeLabel:qaVersions(g)||'Earlier candidate; version not separately recorded',canVerify:!historical&&g.prior.state==='unconfirmed'&&row.verification.state==='unconfirmed',verificationState:prior?'prior-pass':row.verification.state==='saved'?'recorded':'unreported',deliveryState:row.delivery.state,deliveryMessage:row.delivery.message,deliveryReceiptVerified:row.delivery.state==='delivered',recordedAtLabel:prior?qaReported(g.prior.reportedUtc):row.verification.reportedUtc?qaReported(row.verification.reportedUtc):null};
  (historical?view.history:view.items).push(item);
 }return view;
}
export function createQaChecklistClient({root,documentRef=document,windowRef=window,fetcher=fetch,storage,autoStart=true,ownerLifetime=null}={}){
 if(root?.dataset.workspaceAudience!=='owner')throw Error('Owner-private QA client required');
 if(ownerLifetime!==null&&(!ownerLifetime||typeof ownerLifetime.observe!=='function'||typeof ownerLifetime.diagnostics!=='function'))throw Error('Actual owner lifetime binding required');
 const container=root.querySelector('#wf-human-goals'),main=root.querySelector('.wf-main');if(!container||!main)throw Error('Owner Agents QA placement required');
 const worldId=OWNER_SITE_CONTEXT.worldId,origin=windowRef.location.origin,goalsURL=new URL('/api/qa-goals',origin),writeURL=new URL('/api/qa-verifications',origin),storageKey='alife:owner-qa-requests:v1:'+worldId;
 let store=storage;try{store??=windowRef.sessionStorage;}catch{}
 let envelope=null,view=null,notice='',timer=null,readController=null,disposed=false,revoked=false,lifetime=0,readBusy=false,storageReady=!!store,mutationBusy=false,unsubscribeOwner=null;
 const pending=new Map(),receiptReads=new Set(),operationTimers=new Map();
 const ownerEnded=()=>{try{return ownerLifetime?.diagnostics()?.revoked===true;}catch{return true;}};
 function remember(){if(!store)throw Error('request-storage-unavailable');store.setItem(storageKey,JSON.stringify([...pending.values()].map(p=>p.text)));}
 try{const saved=store?.getItem(storageKey);if(saved){const texts=JSON.parse(saved);if(!Array.isArray(texts)||texts.length>HUMAN_QA_LIMITS.goals)throw Error('pending-limit');for(const text of texts){if(typeof text!=='string'||new TextEncoder().encode(text).length>HUMAN_QA_LIMITS.body)throw Error('pending-shape');const body=assertQaSubmission(JSON.parse(text),{worldId});pending.set(body.requestId,{body,text,key:qaBodyKey(body),state:'unknown'});}}if(store&&!ownerEnded())remember();}catch{storageReady=false;notice='Saved request identifiers are unavailable. No new confirmation will be submitted.';}
 const alive=token=>{if(!revoked&&ownerEnded())revokeOwner();return!disposed&&!revoked&&(token===undefined||token===lifetime);};
 const visible=()=>alive()&&!documentRef.hidden&&!main.hidden;
 function revokeOwner(){
  if(revoked||disposed)return;revoked=true;lifetime++;windowRef.clearTimeout(timer);timer=null;
  for(const [active,timeout]of operationTimers){windowRef.clearTimeout(timeout);active.abort();}operationTimers.clear();readController=null;receiptReads.clear();
  for(const p of pending.values())p.state='unknown';
  // Retain exact opaque request identities/bodies in their existing storage.
  // A cancelled request may already have reached the server; never drop/replay it.
  envelope=null;view=null;notice='';repaint();
 }
 function ownerChanged(){if(ownerEnded())revokeOwner();}
 async function json(response,limit){if(!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')||''))throw Error('response-type');const reader=response.body?.getReader();if(!reader)throw Error('body');const chunks=[];let size=0;try{while(true){const r=await reader.read();if(r.done)break;size+=r.value.byteLength;if(size>limit){await reader.cancel();throw Error('limit');}chunks.push(r.value);}}finally{reader.releaseLock();}const all=new Uint8Array(size);let offset=0;for(const chunk of chunks){all.set(chunk,offset);offset+=chunk.byteLength;}return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(all));}
 function repaint(){
  if(revoked){envelope=null;view=null;notice='';const unavailable=documentRef.createElement('p');unavailable.setAttribute('role','status');unavailable.textContent='Private verification unavailable.';container.replaceChildren(unavailable);container.removeAttribute?.('aria-labelledby');return;}
  if(!envelope){view={audience:'owner',sourceState:'unavailable',canSubmit:false,items:[],history:[],transportMessage:'QA connection unavailable',message:notice};}
  else{view=qaViewModel(envelope);view.canSubmit=view.canSubmit&&storageReady;if(notice)view.message=notice;for(const p of pending.values()){const item=view.items.find(i=>i.key===p.key);if(!item)continue;item.verificationState=p.state==='submitting'?'submitting':'unknown';item.canVerify=false;item.deliveryMessage='Saved status must be reconciled; no new request will be created.';item.pendingActions=[['Check saved status',()=>reconcile(p)],['Retry original request',()=>post(p)]];}}
  renderHumanGoals({container,view,documentRef,onVerify:key=>verify(key),onRefresh:()=>refresh(true)});
 }
 function drop(p){if(!alive())return;pending.delete(p.body.requestId);try{remember();}catch{storageReady=false;notice='Request status was read, but this browser could not update its saved identifier.';}}
 function readReceipt(value,p){
  const keys=['schemaVersion','kind','worldId','requestId','state','manifestId','entryId','candidateId','surfaceId','verification','delivery','duplicate','message'];
  if(!qaClosed(value,keys)||value.schemaVersion!==1||value.kind!=='owner-human-qa-submission'||value.worldId!==worldId||value.requestId!==p.body.requestId||value.manifestId!==p.body.manifestId||value.entryId!==p.body.entryId||value.candidateId!==p.body.candidateId||value.surfaceId!==p.body.surfaceId||!['saved','pending'].includes(value.state)||typeof value.duplicate!=='boolean'||!qaText(value.message,500)||!qaClosed(value.verification,['state','eventId','reportedUtc'])||!qaClosed(value.delivery,['state','message'])||!['not-attempted','unavailable','queued','unknown','delivered'].includes(value.delivery.state)||!qaText(value.delivery.message,300))throw Error('receipt-identity');
  if(value.state==='saved'&&(value.verification?.state!=='saved'||!qaHash(value.verification.eventId)||!qaUtc(value.verification.reportedUtc)))throw Error('receipt-proof');
  if(value.state==='pending'&&(value.verification.state!=='unconfirmed'||value.verification.eventId!==null||value.verification.reportedUtc!==null))throw Error('receipt-state');
  const goal=envelope?.goals.find(r=>qaKey(r.goal)===p.key)?.goal;
  if(goal)assertQaEnvelope({...envelope,manifestId:p.body.manifestId,goals:[{goal,verification:value.verification,delivery:value.delivery}],message:value.message},{worldId});
  return value;
 }
 function savedReceipt(receipt,p){if(!alive())return;drop(p);const row=envelope?.goals.find(r=>qaKey(r.goal)===p.key);if(row){row.verification=receipt.verification;row.delivery=receipt.delivery;}notice=receipt.delivery.message;repaint();}
 async function reconcile(p){
  if(!visible()||p.state==='submitting'||!pending.has(p.body.requestId))return;
  const token=lifetime,active=new AbortController();receiptReads.add(active);const timeout=windowRef.setTimeout(()=>active.abort(),8000);operationTimers.set(active,timeout);
  try{const response=await fetcher(writeURL.href+'?'+new URLSearchParams({requestId:p.body.requestId}),{method:'GET',cache:'no-store',credentials:'same-origin',redirect:'error',headers:{Accept:'application/json'},signal:active.signal});if(!alive(token))return;if(active.signal.aborted)throw Error('unconfirmed');if(!response.ok){notice=response.status===404?'The original request is not recorded yet. Its identifier is retained.':'Saved status is unavailable; the original request is retained.';repaint();return;}const value=await json(response,HUMAN_QA_LIMITS.record);if(!alive(token))return;if(active.signal.aborted)throw Error('unconfirmed');const receipt=readReceipt(value,p);if(receipt.state==='saved'){savedReceipt(receipt,p);await refresh(false);}else{p.state='unknown';notice=receipt.message;repaint();}}catch{if(!alive(token))return;p.state='unknown';notice='Submission status remains unknown. The original request is retained.';repaint();}finally{windowRef.clearTimeout(timeout);receiptReads.delete(active);operationTimers.delete(active);}
 }
 async function refresh(reconcilePending=false){
  if(!visible()||readBusy)return;const token=lifetime;readBusy=true;windowRef.clearTimeout(timer);const active=new AbortController();readController=active;const timeout=windowRef.setTimeout(()=>active.abort(),8000);operationTimers.set(active,timeout);
  try{const response=await fetcher(goalsURL.href,{method:'GET',cache:'no-store',credentials:'same-origin',redirect:'error',headers:{Accept:'application/json'},signal:active.signal});if(!alive(token)||active.signal.aborted)return;if([401,403].includes(response.status)||![200,503].includes(response.status)){envelope=null;throw Error('owner-access');}const value=assertQaEnvelope(await json(response,HUMAN_QA_LIMITS.manifest+HUMAN_QA_LIMITS.goals*1024),{worldId});if(!alive(token)||active.signal.aborted)return;if(value.state==='current')await verifyQaManifest({schemaVersion:1,kind:'owner-human-qa-manifest',worldId,manifestId:value.manifestId,sourceRecordedUtc:value.sourceRecordedUtc,goals:value.goals.map(r=>r.goal)},{worldId});if(!alive(token)||active.signal.aborted)return;envelope=value;if(notice==='Goal list unavailable. Pending request identifiers are retained.')notice='';repaint();}
  catch{if(alive(token)){envelope=null;notice='Goal list unavailable. Pending request identifiers are retained.';repaint();}}
  finally{windowRef.clearTimeout(timeout);operationTimers.delete(active);readBusy=false;if(readController===active)readController=null;if(visible())timer=windowRef.setTimeout(()=>refresh(false),15000);}
  if(reconcilePending&&envelope?.canSubmit)for(const p of [...pending.values()])await reconcile(p);
 }
 async function post(p){
  if(!alive()||mutationBusy||p.state==='submitting'||!pending.has(p.body.requestId)||!envelope?.canSubmit||!storageReady)return;
  mutationBusy=true;p.state='submitting';notice='Submitting your report…';repaint();
  const token=lifetime,active=new AbortController(),timeout=windowRef.setTimeout(()=>active.abort(),10000);operationTimers.set(active,timeout);
  try{const response=await fetcher(writeURL.href,{method:'POST',cache:'no-store',credentials:'same-origin',redirect:'error',headers:{Accept:'application/json','Content-Type':'application/json'},body:p.text,signal:active.signal,keepalive:true});if(!alive(token))return;if(active.signal.aborted)throw Error('unconfirmed');const value=await json(response,HUMAN_QA_LIMITS.record);if(!alive(token))return;if(active.signal.aborted)throw Error('unconfirmed');if(!response.ok){const refusal=response.status===409&&qaClosed(value,['schemaVersion','kind','worldId','error','message'])&&value.schemaVersion===1&&value.kind==='owner-human-qa-error'&&value.worldId===worldId&&qaText(value.message,500)&&['goal-list-changed','goal-not-open-for-confirmation'].includes(value.error);if(refusal){drop(p);notice='The goal list changed. Review the current scope before confirming it.';await refresh(false);return;}throw Error('unconfirmed');}const receipt=readReceipt(value,p);if(receipt.state==='saved'){savedReceipt(receipt,p);await refresh(false);}else{p.state='unknown';notice=receipt.message;repaint();}}
  catch{if(!alive(token))return;p.state='unknown';notice='Submission status unknown. Check saved status or retry only this original request.';repaint();}
  finally{windowRef.clearTimeout(timeout);operationTimers.delete(active);mutationBusy=false;}
 }
 async function verify(key){
  if(!visible()||!storageReady||mutationBusy||envelope?.state!=='current'||!envelope.canSubmit)return;
  if(pending.size>=HUMAN_QA_LIMITS.goals){notice='Reconcile the saved request identifiers before starting another confirmation.';repaint();return;}
  const row=envelope.goals.find(r=>qaKey(r.goal)===key);if(!row||row.goal.reviewState!=='current'||row.goal.prior.state!=='unconfirmed'||row.verification.state!=='unconfirmed'||[...pending.values()].some(p=>p.key===key))return;
  const body=assertQaSubmission({schemaVersion:1,requestId:windowRef.crypto.randomUUID(),worldId,manifestId:envelope.manifestId,entryId:row.goal.entryId,candidateId:row.goal.candidateId,surfaceId:row.goal.surface.id,result:'pass',attestation:HUMAN_QA_ATTESTATION},{worldId}),p={body,text:JSON.stringify(body),key,state:'new'};
  pending.set(body.requestId,p);try{remember();}catch{pending.delete(body.requestId);storageReady=false;notice='This browser could not retain the request identifier. Nothing was submitted.';repaint();return;}await post(p);
 }
 function visibility(){windowRef.clearTimeout(timer);if(!visible()){readController?.abort();for(const active of receiptReads)active.abort();}else refresh(false);}
 const Observer=windowRef.MutationObserver,observer=Observer?new Observer(visibility):null;observer?.observe(main,{attributes:true,attributeFilter:['hidden']});
 function dispose(){disposed=true;lifetime++;windowRef.clearTimeout(timer);readController?.abort();for(const active of receiptReads)active.abort();unsubscribeOwner?.();unsubscribeOwner=null;observer?.disconnect();documentRef.removeEventListener('visibilitychange',visibility);windowRef.removeEventListener('pagehide',dispose);}
 if(ownerLifetime)unsubscribeOwner=ownerLifetime.observe(ownerChanged);ownerChanged();
 documentRef.addEventListener('visibilitychange',visibility);windowRef.addEventListener('pagehide',dispose);repaint();if(autoStart)refresh(true);
 return{refresh,dispose,verify,reconcilePending:async()=>{for(const p of [...pending.values()])await reconcile(p);}};
}
if(typeof document!=='undefined'){const root=document.getElementById('alife-world-first');if(root?.dataset.workspaceAudience==='owner'&&root.querySelector('#wf-human-goals')&&root.dataset.qaChecklistMounted!=='true'){root.dataset.qaChecklistMounted='true';createQaChecklistClient({root,ownerLifetime:typeof ownerMountedReplacement==='undefined'?null:ownerMountedReplacement});}}
