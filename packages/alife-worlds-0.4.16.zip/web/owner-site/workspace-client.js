(()=>{
'use strict';
const {WORKSPACE_WORLD_ID,WORKSPACE_LIMIT,WORKSPACE_STALE_MS,WORKSPACE_ROLES,assertWorkspaceResponse,workspaceEnvelope}=createOwnerWorkspaceContract(OWNER_SITE_CONTEXT);
const root=document.getElementById('alife-world-first');if(!root)return;
const audience=root.dataset.workspaceAudience==='owner'?'owner':'public',publicOrigin=OWNER_SITE_CONTEXT.publicOrigin;
const $=id=>root.querySelector('#'+id),make=(tag,className,text)=>{const n=document.createElement(tag);if(className)n.className=className;if(text!==undefined)n.textContent=text;return n;};
let snapshot=null,envelope=null,timer=null,controller=null,disposed=false,worldAccessRevoked=false,scope='current';
const sectionKeys=new Map(),assignmentNodes=new Map();
function clearWorkspaceSnapshot(){snapshot=null;envelope=null;sectionKeys.clear();assignmentNodes.clear();observations.clear();}
const prefix='alife-workspace:'+audience+':'+WORKSPACE_WORLD_ID+':',preferences=new Map(),observations=new Map();
const saved=(key,fallback)=>{if(preferences.has(key))return preferences.get(key);let value=fallback;try{value=localStorage.getItem(prefix+key)??fallback;}catch{}preferences.set(key,value);return value;};
const save=(key,value)=>{preferences.set(key,value);try{localStorage.setItem(prefix+key,value);}catch{}};
scope=saved('task-scope','current')==='all'?'all':'current';$('wf-task-scope').value=scope;
function badge(text,state=text){const n=make('span','wf-badge',text);n.dataset.state=state;return n;}
function textOr(value,fallback){return value||fallback;}
function date(value){return value?new Date(value).toLocaleString():'Not recorded';}
function paintMeter(p,value){
 if(value===null){p.removeAttribute('value');p.style.removeProperty('--wf-progress-color');p.style.removeProperty('--wf-progress-gradient');return;}
 p.value=value;
 const stops=[[0,[222,133,59]],[25,[231,169,61]],[50,[222,195,78]],[75,[166,198,101]],[100,[48,139,72]]],at=Math.max(0,Math.min(100,value)),i=Math.min(3,Math.floor(at/25)),a=stops[i],b=stops[i+1],f=(at-a[0])/25,color='rgb('+a[1].map((v,j)=>Math.round(v+(b[1][j]-v)*f)).join(',')+')';
 const start='rgb('+a[1].join(',')+')';
 p.style.setProperty('--wf-progress-color',color);p.style.setProperty('--wf-progress-gradient',at===100?'none':'linear-gradient(90deg, '+start+', '+color+')');
}
function meter(progress,label){const p=make('progress','wf-native-meter');p.max=100;p.setAttribute('aria-label',label);paintMeter(p,progress.percent);p.setAttribute('aria-valuetext',progress.percent===null?'Progress unavailable':progress.percent+'%');return p;}
function countLabel(p){return p.completed+'/'+p.total+' '+p.unit+' completed';}
function percent(p){return p.percent===null?'—':p.percent+'%';}
function currentSource(){if(!envelope||!snapshot)return false;const now=Date.now(),sourceAt=Date.parse(snapshot.observedUtc),receivedAt=Date.parse(envelope.receivedUtc);return envelope.state==='current'&&snapshot.sourceState==='current'&&now-sourceAt<=120000&&sourceAt<=now+5000&&now-receivedAt<=WORKSPACE_STALE_MS&&receivedAt<=now+5000;}
function nativeActivity(a){return audience==='owner'&&snapshot?.schemaVersion>=4?a.nativeActivity:null;}
function latestNativeActivity(a){return audience==='owner'&&snapshot?.schemaVersion>=4?[...(a.nativeEvents||[]),...(nativeActivity(a)?[nativeActivity(a)]:[])].sort((x,y)=>Date.parse(y.recordedUtc)-Date.parse(x.recordedUtc)||x.id.localeCompare(y.id))[0]||null:null;}
function latestReportedWork(a){const report=workReport(a),progress=progressUpdate(a);return [report,progress].filter(Boolean).sort((x,y)=>Date.parse(y.recordedUtc)-Date.parse(x.recordedUtc)||x.id.localeCompare(y.id))[0]||null;}
function agentState(a){if(!currentSource())return'unknown';if(a.state==='inactive')return'inactive';if(!a.connected)return a.state==='offline'?'offline':'unknown';const age=Date.now()-Date.parse(a.observedUtc);return age>=-5000&&(age<=120000||a.terminalIdle&&a.state==='idle')?a.state:'unknown';}
const stateNames={working:'Working',idle:'Idle',waiting:'Waiting','needs-input':'Needs input',failure:'Failure',unknown:'Unknown',offline:'Offline',inactive:'Inactive'};
function field(label,value,fallback){const block=make('div','wf-task-field');block.append(make('span','wf-field-label',label),make('p','wf-detail-copy',textOr(value,fallback)));return block;}
function ownerName(alias){return snapshot.agents.find(a=>a.alias===alias)?.name||WORKSPACE_ROLES.find(r=>'role-'+r.id===alias)?.title||'Not recorded';}
function disclosure(card,key,initial='closed'){
 card.dataset.disclosureKey=key;card.open=saved(key,initial)==='open';
 card.addEventListener('toggle',()=>{if(card.isConnected)save(key,card.open?'open':'closed');});
 return card;
}
function taskCard(task,context='tasks'){
 const card=disclosure(make('details','wf-read-task'),'task:'+context+':'+task.id);card.dataset.taskId=task.id;
 const summary=make('summary','wf-task-summary');summary.dataset.focusKey=context+':'+task.id;
 const arrow=make('span','wf-disclosure-arrow','›');arrow.setAttribute('aria-hidden','true');
 summary.append(arrow,make('span','wf-task-summary-title',task.title));
 const body=make('div','wf-task-body'),details=taskDetails(task),privateFallback=audience==='owner'?'Not recorded.':'Operational details stay private.';
 body.append(field('Goal',task.goal,audience==='owner'?'Goal not recorded.':'Task goal is private.'),field('QA needed',details?.qaRequired===true?'Yes':details?.qaRequired===false?'No':null,privateFallback),field('What QA entails',details?.qaRequirements,privateFallback),field('Blockers',details?.blocker,privateFallback),field('Next',details?.next,privateFallback));
 card.append(summary,body);return card;
}

function renderProgress(){
 const epic=snapshot.epic,current=snapshot.sprints.find(s=>s.id===snapshot.currentSprintId),area=$('wf-progress-content'),card=make('div','wf-progress'),left=make('div'),right=make('div','wf-progress-right');
 card.setAttribute('role','group');card.setAttribute('aria-labelledby','wf-progress-title');
 left.append(make('p','wf-kicker','Epic goal'),make('h2','',epic.title));
 left.append(field('Epic goal description',epic.goal,audience==='public'?'Detailed project goals stay private.':'Epic goal description not recorded.'));
 const measure=make('div','wf-measure');measure.append(make('strong','wf-number',percent(epic.progress)),make('span','wf-mini',countLabel(epic.progress)));left.append(measure,meter(epic.progress,'Epic completion'));
 right.append(make('p','wf-kicker','Current sprint'),make('h3','',current?.title||'Current sprint unavailable'));
 if(current){if(current.goal)right.append(make('p','wf-detail-copy',current.goal));const value=make('div','wf-measure');value.append(make('strong','wf-number',percent(current.progress)),make('span','wf-mini',countLabel(current.progress)));right.append(value,meter(current.progress,'Current sprint completion'));}
 card.append(left,right);area.replaceChildren(card);
 $('wf-epic-summary-count').textContent=epic.title+' · '+percent(epic.progress)+' · '+countLabel(epic.progress);
 const bar=$('wf-epic-meter');paintMeter(bar,epic.progress.percent);
 bar.setAttribute('aria-valuetext',epic.progress.percent===null?'Progress unavailable':percent(epic.progress));
}
function renderSprints(){
 const list=$('wf-sprint-list'),tasks=new Map(snapshot.tasks.map(t=>[t.id,t])),fragment=document.createDocumentFragment();
 for(const [i,s]of snapshot.sprints.entries()){
  const card=disclosure(make('details','wf-sprint'),'sprint:'+s.id);card.dataset.sprintId=s.id;
  const summary=make('summary');summary.dataset.focusKey=s.id;
  const name=make('div','wf-sprint-name');name.append(make('span','',s.title),badge(s.status==='current'?'Current':s.status==='complete'?'Complete':s.status==='unknown'?'Unknown':'Planned'));
  const progress=make('div','wf-sprint-progress');progress.append(make('span','wf-mini',countLabel(s.progress)),meter(s.progress,'Sprint completion: '+s.title));
  summary.append(make('span','wf-sprint-number',String(i+1)),name,progress,make('strong','wf-sprint-percent',percent(s.progress)));
  const body=make('div','wf-sprint-description'),members=configureScrollableList(make('div','wf-task-list'),s.taskIds.length,s.title+' tasks','sprint:'+s.id);if(s.goal)body.append(make('p','',s.goal));for(const id of s.taskIds)members.append(taskCard(tasks.get(id),'sprint:'+s.id));body.append(members);
  if(!s.taskIds.length)body.append(make('p','wf-mini','No task membership recorded. Completion is unavailable.'));
  card.append(summary,body);fragment.append(card);
 }
 list.replaceChildren(fragment);configureScrollableList(list,snapshot.sprints.length,'Sprints');if(!snapshot.sprints.length)list.append(make('p','wf-mini','No sprint scope is available.'));
}
function scopedTasks(){
 const current=snapshot.sprints.find(s=>s.id===snapshot.currentSprintId),ids=new Set(current?.taskIds||[]);
 return scope==='all'?snapshot.tasks:snapshot.tasks.filter(t=>ids.has(t.id));
}
function renderTasks(){
 const previous=$('wf-board-content').querySelectorAll('.wf-lane-cards'),scrolls=new Map([...previous].map(n=>[n.dataset.stage,n.scrollTop])),horizontal=$('wf-board-content').querySelector('.wf-board')?.scrollLeft||0;
 const current=snapshot.sprints.find(s=>s.id===snapshot.currentSprintId),rows=scopedTasks(),board=make('div','wf-board'),list=make('div','wf-task-list');
 $('wf-task-scope-label').textContent=scope==='all'?'All recorded tasks':current?.title||'Current sprint unavailable';
 $('wf-task-count').textContent=rows.length+' task records';$('wf-current-work-count').textContent=String(rows.length);
 const columns=['Backlog','Shaping','Ready','In Progress','QA','In Review','Done',...['Deferred','Unknown'].filter(stage=>rows.some(t=>t.stage===stage))];
 for(const stage of columns){
  const lane=make('section','wf-lane'),cards=rows.filter(t=>t.stage===stage),heading=make('h3','',stage);heading.append(make('span','',String(cards.length)));lane.append(heading);
  const cardList=configureScrollableList(make('div','wf-lane-cards'),cards.length,stage+' tasks','lane:'+stage);cardList.dataset.stage=stage;
  for(const t of cards)cardList.append(taskCard(t,'board'));
  if(!cards.length)cardList.append(make('p','wf-lane-empty','No recorded tasks'));lane.append(cardList);board.append(lane);
 }
 for(const t of rows)list.append(taskCard(t,'current-work'));
 configureScrollableList(list,rows.length,'Task records','task-records');
 $('wf-board-content').replaceChildren(board);board.scrollLeft=horizontal;for(const n of board.querySelectorAll('.wf-lane-cards'))n.scrollTop=scrolls.get(n.dataset.stage)||0;$('wf-task-content').replaceChildren(list);
 if(!rows.length)$('wf-task-content').append(make('p','wf-mini','No tasks recorded in this scope.'));
}
function recordedAssignments(a){return snapshot.tasks.filter(t=>!t.done&&(t.actingOwner===a.alias||t.assignedOwners.includes(a.alias)));}
function taskDetails(task){return audience==='owner'&&task.known===true&&task.details?.source==='canonical-task'?task.details:null;}
function renderAgents(){
 const host=$('wf-agent-list'),fragment=document.createDocumentFragment(),currentAgents=snapshot.agents.filter(a=>a.state!=='inactive');
 for(const a of currentAgents){
  const card=make('article','wf-agent'),top=make('div','wf-agent-top'),state=agentState(a),assigned=recordedAssignments(a);
  card.dataset.state=state;top.append(make('h3','',a.name),badge(stateNames[state],stateNames[state]));card.append(top);
  const activity=latestNativeActivity(a),report=latestReportedWork(a);
  const observed=field('Observed activity',activity?nativeEventText(activity):null,'Activity detail unavailable.');if(activity)observed.append(make('p','wf-mini','Event '+date(activity.recordedUtc)));card.append(observed);
  const reported=field('Last reported work',report?.headline||report?.text,'Work detail unavailable.');if(report?.detail)reported.append(make('p','wf-detail-copy',report.detail));if(report)reported.append(make('p','wf-mini','Reported '+date(report.recordedUtc)));card.append(reported);
  card.append(make('p','wf-mini','State observed · '+date(a.observedUtc)));
  if(assigned.length){
   const key=JSON.stringify(assigned);let cached=assignmentNodes.get(a.alias);
   if(!cached||cached.key!==key){
    const assignments=disclosure(make('details','wf-agent-assignments'),'agent:'+a.alias+':assignments'),list=configureScrollableList(make('div','wf-agent-task-list'),assigned.length,a.name+' recorded assignments','agent:'+a.alias);
    const heading=make('summary','','Recorded assignments ('+assigned.length+')');heading.dataset.focusKey='agent:'+a.alias+':assignments';assignments.append(heading);
    for(const task of assigned)list.append(taskCard(task,'agent:'+a.alias));
    assignments.append(list);cached={key,node:assignments};assignmentNodes.set(a.alias,cached);
   }card.append(cached.node);
  }else card.append(make('p','wf-mini','No assignment recorded.'));
  fragment.append(card);
 }
 for(const alias of assignmentNodes.keys())if(!currentAgents.some(a=>a.alias===alias))assignmentNodes.delete(alias);
 host.replaceChildren(fragment);configureScrollableList(host,currentAgents.length,'Agents');$('wf-agent-count').textContent=currentAgents.length+' current agents';
}
function workReport(a){return audience==='owner'&&snapshot?.kind==='owner-workspace'&&snapshot.schemaVersion>=2?a.workSummary:null;}
function progressUpdate(a){return audience==='owner'&&snapshot?.kind==='owner-workspace'&&snapshot.schemaVersion>=5?a.progressUpdate:null;}
const nativeKindNames={processing:'Processing',tool:'Tool step',command:'Command',research:'Research',fetch:'Fetching data',message:'Message request',handoff:'Handoff request',file:'File operation',turn:'Work turn',input:'Input request'};
const nativePhaseNames={started:'started',completed:'completed',requested:'requested',received:'received',failed:'failed',interrupted:'interrupted'};
function nativeEventText(event){return (nativeKindNames[event.kind]||'Activity')+' · '+(nativePhaseNames[event.phase]||'detail unavailable');}
function activityRows(){return [...observations.values()].sort((a,b)=>Date.parse(b.observedUtc)-Date.parse(a.observedUtc)||a.id.localeCompare(b.id));}
function stateObservationText(state){return {working:'Working — step not reported yet.',idle:'Idle — no active work reported.',waiting:'Waiting — reason not reported.','needs-input':'Waiting for input — response requested.',failure:'Failure reported — details not reported.'}[state]||'Status unavailable.';}
function nativeFallbackText(row){
 if(row.phase==='failed')return 'Step failed — details not reported.';
 if(row.phase==='interrupted')return 'Work interrupted — details not reported.';
 if(row.nativeKind==='message')return row.phase==='completed'?'Message request finished — delivery not confirmed.':'Message request — recipient detail not reported.';
 if(row.nativeKind==='handoff')return row.phase==='completed'?'Handoff request finished — execution not confirmed.':'Handoff request — target detail not reported.';
 if(row.nativeKind==='input')return 'Waiting for input — request detail not reported.';
 if(row.phase==='completed')return row.nativeKind==='turn'?'Work turn finished — result not reported.':'Step finished — details not reported.';
 if(row.phase==='requested')return 'Work requested — step not reported yet.';
 if(row.phase==='received')return 'Update received — step not reported yet.';
 if(row.nativeKind==='fetch')return 'Fetching data — target not reported yet.';
 if(row.nativeKind==='research')return 'Researching — topic not reported yet.';
 return 'Working — step not reported yet.';
}
function activityPhaseText(row){return {started:'Started',completed:row.nativeKind==='message'||row.nativeKind==='handoff'?'Request finished':'Step finished',requested:'Request made',received:'Update received',failed:'Step failed',interrupted:'Interrupted'}[row.phase]||'';}
function nativeExplainsState(event,state){
 if(state==='working')return event.nativeKind!=='input'&&(event.phase==='started'||event.phase==='requested'||event.phase==='received'||event.phase==='completed'&&event.nativeKind!=='turn');
 if(state==='idle')return event.nativeKind==='turn'&&['completed','interrupted'].includes(event.phase);
 if(state==='waiting'||state==='needs-input')return event.nativeKind==='input'&&['requested','started'].includes(event.phase);
 return state==='failure'&&event.phase==='failed';
}
function matchingNativeObservation(row){return [...observations.values()].some(event=>event.alias===row.alias&&event.observedUtc===row.observedUtc&&(event.kind==='native'&&nativeExplainsState(event,row.state)||event.kind==='progress'&&row.state==='working'));}
function recordObservations(){
 if(!snapshot||!currentSource())return;
 for(const a of snapshot.agents){
  const progress=progressUpdate(a);if(progress){const id='progress:'+a.alias+':'+progress.id;if(!observations.has(id))observations.set(id,Object.freeze({id,kind:'progress',alias:a.alias,observedUtc:progress.recordedUtc,headline:progress.headline,detail:progress.detail,source:progress.source}));}
  const report=workReport(a);
  if(report){const id='work:'+a.alias+':'+report.id;if(!observations.has(id))observations.set(id,Object.freeze({id,kind:'work',alias:a.alias,observedUtc:report.recordedUtc,text:report.text,source:report.source}));}
  const events=audience==='owner'&&snapshot.schemaVersion>=4?[...(a.nativeEvents||[]),...(nativeActivity(a)?[nativeActivity(a)]:[])]:[];
  for(const event of events){const id='native:'+a.alias+':'+event.id+':'+event.phase;if(!observations.has(id))observations.set(id,Object.freeze({id,eventId:event.id,kind:'native',nativeKind:event.kind,alias:a.alias,observedUtc:event.recordedUtc,text:nativeEventText(event),phase:event.phase}));}
  // Later detail may explain an already retained generic observation. Keep other transitions.
  for(const row of observations.values())if(row.kind==='state'&&row.alias===a.alias&&matchingNativeObservation(row))observations.delete(row.id);
  if(matchingNativeObservation({alias:a.alias,observedUtc:a.observedUtc,state:a.state}))continue;
  if(!a.connected||!a.observedUtc||!['working','idle','waiting','needs-input','failure'].includes(a.state))continue;
  const at=Date.parse(a.observedUtc);if(at>Date.now()+5000)continue;
  const id='state:'+a.alias+':'+a.observedUtc+':'+a.state;
  if(!observations.has(id))observations.set(id,Object.freeze({id,kind:'state',alias:a.alias,state:a.state,observedUtc:a.observedUtc}));
 }
 const counts=new Map(),aliases=new Set(snapshot.agents.map(a=>a.alias));
 // One shared three-entry window per recorded actor; source IDs and clocks own
 // deduplication and eviction. Task edits and poll time never create activity.
 for(const row of activityRows()){const count=counts.get(row.alias)||0;if(!aliases.has(row.alias)||count>=3)observations.delete(row.id);else counts.set(row.alias,count+1);}
}
function renderObservations(){
 const list=$('wf-activity-list'),scrollTop=list.scrollTop||0,height=list.scrollHeight||0,rows=activityRows(),fragment=document.createDocumentFragment();
 for(const row of rows){
  const li=make('li',row.kind==='state'?'wf-state-event':'wf-work-event'),time=make('time','',date(row.observedUtc));time.dateTime=row.observedUtc;const detail=make('div','wf-activity-detail');li.dataset.eventId=row.id;
  if(row.kind==='state')detail.append(make('p','wf-work-summary',ownerName(row.alias)+' · '+stateObservationText(row.state)));
  else{
   const headline=row.headline||(row.kind==='work'?row.text:nativeFallbackText(row));
   detail.append(make('p','wf-work-summary',ownerName(row.alias)+' · '+headline));
   if(row.detail)detail.append(make('p','wf-mini',row.detail));
   const phase=row.kind==='work'||row.kind==='progress'?'Agent update':activityPhaseText(row);if(phase)detail.append(make('span','wf-mini',phase));
  }
  li.append(detail,time);fragment.append(li);
 }
 list.replaceChildren(fragment);if(!rows.length)list.append(make('li','wf-mini','No observed activity detail or work reports available.'));
 configureScrollableList(list,rows.length,'Agent activity','agent-activity');
 if(scrollTop>0)list.scrollTop=scrollTop+Math.max(0,(list.scrollHeight||0)-height);
}
function reflect(){
 const note=$('wf-source-status'),fresh=currentSource();root.dataset.freshness=!snapshot?'unavailable':fresh?'current':'stale';
 note.textContent=!snapshot?'Updates unavailable':fresh?(audience==='owner'?'Private source connected':'Public source connected · read-only'):envelope?.state==='unavailable'?'Reconnecting · showing the last recorded snapshot':'Last recorded snapshot · updates unconfirmed';
 if(!snapshot){
  for(const id of ['wf-progress-content','wf-sprint-list','wf-board-content','wf-task-content','wf-agent-list'])$(id).replaceChildren(make('p','wf-mini','Current data is unavailable.'));
  $('wf-activity-list').replaceChildren(make('li','wf-mini','No timestamped observations available.'));$('wf-epic-summary-count').textContent='Epic progress unavailable';$('wf-epic-meter').removeAttribute('value');$('wf-project-name').textContent='ALife World';$('wf-current-work-count').textContent='';
  $('wf-agent-count').textContent='Agent state unavailable';$('wf-task-count').textContent='Task scope unavailable';$('wf-updated').textContent='No current observation available';return;
 }
 $('wf-project-name').textContent=snapshot.project.name;
 recordObservations();
 // Observation clocks change on polls; they must not rebuild every task card.
 const restore=preserveListPositions(root),focus=document.activeElement?.dataset?.focusKey;
 const renderChanged=(section,value,render)=>{const key=JSON.stringify(value);if(sectionKeys.get(section)!==key){render();sectionKeys.set(section,key);}};
 renderChanged('progress',[snapshot.epic,snapshot.currentSprintId,snapshot.sprints],renderProgress);
 renderChanged('sprints',[snapshot.sprints,snapshot.tasks],renderSprints);
 renderChanged('tasks',[snapshot.currentSprintId,scope,snapshot.sprints,snapshot.tasks],renderTasks);
 renderChanged('agents',[snapshot.tasks,snapshot.agents.map(a=>({...a,shownState:agentState(a)}))],renderAgents);
 renderChanged('activity',[activityRows(),snapshot.agents.map(a=>[a.alias,a.name])],renderObservations);
 restore();if(focus)root.querySelector('[data-focus-key="'+focus+'"]')?.focus({preventScroll:true});
 $('wf-updated').textContent='Source observed '+date(snapshot.observedUtc)+' · Plan recorded '+date(snapshot.planningObservedUtc);
}
async function jsonBody(response){
 const reader=response.body.getReader(),parts=[];let used=0;
 try{while(true){const r=await reader.read();if(r.done)break;used+=r.value.byteLength;if(used>WORKSPACE_LIMIT+1024){await reader.cancel();throw Error('Oversized response');}parts.push(r.value);}}finally{reader.releaseLock();}
 const bytes=new Uint8Array(used);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
async function refresh(){
 if(disposed||worldAccessRevoked||document.hidden||controller)return;const active=new AbortController();controller=active;const timeout=setTimeout(()=>active.abort(),6000);
 if($('wf-activity-sync'))$('wf-activity-sync').textContent='Reading activity updates…';
 try{
  const source=new URL(root.dataset.workspaceSource,location.href),allowed=audience==='owner'?source.origin===location.origin&&source.pathname==='/api/workspace':(source.origin===location.origin||source.origin===publicOrigin)&&source.pathname==='/api/workspace-summary';
  if(!allowed||source.search||source.hash){ownerMountedReplacement?.revoke('Workspace source changed');clearWorkspaceSnapshot();throw Error('Invalid workspace source');}
  const response=await fetch(source.href,{method:'GET',cache:'no-store',credentials:audience==='owner'?'same-origin':'omit',redirect:'error',headers:{Accept:'application/json'},signal:active.signal});
  if(response.status===401||response.status===403){ownerMountedReplacement?.revoke('Owner access unavailable');clearWorkspaceSnapshot();throw Error('Owner access unavailable');}
  if(!response.ok||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')||''))throw Error('Unavailable response');
  const value=await jsonBody(response);if(disposed||worldAccessRevoked||active.signal.aborted)return;
  if(value?.snapshot&&(value.snapshot.worldId!==WORKSPACE_WORLD_ID||value.snapshot.kind!==(audience==='owner'?'owner-workspace':'public-workspace'))){ownerMountedReplacement?.revoke('Workspace context changed');clearWorkspaceSnapshot();throw Error('Workspace context changed');}
  const next=assertWorkspaceResponse(value,{audience});
  // An unavailable response carries no replacement. Retain only this context's
  // validated snapshot; its source/receipt times and unavailable state stay intact.
  envelope=next.snapshot?next:{...next,receivedUtc:envelope?.receivedUtc??next.receivedUtc};if(next.snapshot)snapshot=next.snapshot;reflect();
  if($('wf-activity-sync'))$('wf-activity-sync').textContent=currentSource()?'Source observed '+date(snapshot.observedUtc)+' · Events keep their original times.':'Updates unavailable · Existing reports retain their original times.';
  root.dispatchEvent(new CustomEvent('alife-workspace-refresh',{detail:{available:!!snapshot,current:currentSource(),worldId:snapshot?.worldId??null,observedUtc:snapshot?.observedUtc??null,agents:snapshot?.agents.map(agent=>({alias:agent.alias,name:agent.name}))??[]}}));
 }catch{if(!disposed&&!document.hidden){envelope={state:'unavailable',receivedUtc:envelope?.receivedUtc??null};reflect();root.dispatchEvent(new CustomEvent('alife-workspace-refresh',{detail:{available:false}}));if($('wf-activity-sync'))$('wf-activity-sync').textContent='Updates unavailable · Existing reports retain their original times.';}}
 finally{
  clearTimeout(timeout);if(controller===active)controller=null;
  const waiting=currentSource()&&snapshot.agents.some(agent=>agent.state==='needs-input');
  if(!disposed&&!worldAccessRevoked&&!document.hidden)timer=setTimeout(refresh,waiting?2000:10000);
 }
}
disclosure($('wf-current-work'),'section:current-work');disclosure($('wf-epic-details'),'section:epic','open');
$('wf-task-scope').addEventListener('change',event=>{scope=event.target.value==='all'?'all':'current';save('task-scope',scope);if(snapshot)renderTasks();});

let frame=root.querySelector('.wf-scene iframe');
const expectedWorld=OWNER_SITE_CONTEXT.worldId,websiteVersion=OWNER_SITE_CONTEXT.websiteVersion;
let worldLoaded=false,worldControls=null,websiteMode=['public','private','view'].includes(saved('world-mode','public'))?saved('world-mode','public'):'public';
function applyWebsiteMode(mode){
 websiteMode=mode;root.dataset.operatorMode=mode;
 const visible=mode==='public';root.querySelector('.wf-main').hidden=!visible;root.querySelector('.wf-footer').hidden=!visible;
 ownerMountedReplacement?.preferencesChanged();
}
function sendWebsiteContext(){if(!worldLoaded)return;const target=new URL(frame.src,location.href).origin;frame.contentWindow.postMessage({type:'alife-website-context',worldId:expectedWorld,websiteVersion,mode:websiteMode},target);frame.contentWindow.postMessage({type:'alife-world-mode',worldId:expectedWorld,mode:websiteMode},target);}
applyWebsiteMode(websiteMode);
function worldPresentation(event){
 if(worldAccessRevoked)return;
 if(event.source!==frame.contentWindow||event.origin!==new URL(frame.src,location.href).origin||event.data?.worldId!==expectedWorld)return;
 const data=event.data;
 if(data.type==='alife-world-ready'||data.type==='alife-world-controls-ready'){if(!worldLoaded){worldLoaded=true;sendWebsiteContext();}return;}
 if(!worldLoaded)return;
 if(data.type==='alife-world-state'&&Object.keys(data).length===7&&['type','worldId','mode','paused','volume','soundEnabled','fullscreen'].every(key=>Object.hasOwn(data,key))&&['public','private','view'].includes(data.mode)&&typeof data.paused==='boolean'&&typeof data.volume==='number'&&Number.isFinite(data.volume)&&data.volume>=0&&data.volume<=1&&typeof data.soundEnabled==='boolean'&&typeof data.fullscreen==='boolean'){
  worldControls={mode:data.mode,paused:data.paused,volume:data.volume,soundEnabled:data.soundEnabled};ownerMountedReplacement?.preferencesChanged();
 }
 if(data.type==='alife-website-toolbar-ready'&&data.websiteVersion===websiteVersion)root.dataset.viewerToolbarReady='true';
 if(data.type==='alife-operator-mode-request'&&['public','private','view'].includes(data.mode)){save('world-mode',data.mode);applyWebsiteMode(data.mode);sendWebsiteContext();}
 if(data.type==='alife-world-fullscreen'&&typeof data.active==='boolean')root.dataset.worldFullscreen=String(data.active);
}
window.addEventListener('message',worldPresentation);
if(audience==='owner'&&frame&&OWNER_SITE_CONTEXT.renderer){
 ownerMountedReplacement=createOwnerMountedReplacement({scene:root.querySelector('.wf-scene'),activeFrame:frame,context:OWNER_SITE_CONTEXT,getPreferences:()=>worldControls?{...worldControls,mode:websiteMode}:null,onRevoke(){worldAccessRevoked=true;clearTimeout(timer);controller?.abort();worldLoaded=false;worldControls=null;clearWorkspaceSnapshot();reflect();root.dispatchEvent(new CustomEvent('alife-workspace-refresh',{detail:{available:false}}));},onStatus:({state})=>{root.dataset.worldReplacement=state;}});
 ownerMountedReplacement?.subscribe(({frame:next})=>{const previous=frame,loaded=worldLoaded;return{commit(){frame=next;worldLoaded=true;root.dataset.viewerToolbarReady='false';sendWebsiteContext();},rollback(){frame=previous;worldLoaded=loaded;},disposePrevious(){}};});
}
window.addEventListener('pagehide',()=>window.removeEventListener('message',worldPresentation),{once:true});
function relayScroll(event){
 if(worldAccessRevoked||!frame||event.source!==frame.contentWindow||event.origin!==new URL(frame.src,location.href).origin||event.data?.type!=='alife-farm-scroll'||typeof event.data.deltaY!=='number'||!Number.isFinite(event.data.deltaY)||document.fullscreenElement)return;
 window.scrollBy(0,Math.max(-800,Math.min(800,event.data.deltaY)));
}
window.addEventListener('message',relayScroll);
function visibility(){clearTimeout(timer);if(document.hidden){controller?.abort();return;}reflect();void refresh();}
document.addEventListener('visibilitychange',visibility);
window.addEventListener('pagehide',()=>{disposed=true;clearTimeout(timer);controller?.abort();observations.clear();ownerMountedReplacement?.dispose();window.removeEventListener('message',relayScroll);document.removeEventListener('visibilitychange',visibility);},{once:true});
void refresh();
})();
