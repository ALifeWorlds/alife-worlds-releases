import {mountOwnerRuleLibrary,OWNER_RULE_LIBRARY_LIMIT} from '../owner-rule-library.mjs';

export function createOwnerRuleLibraryClient({root,worldId,documentRef=document,windowRef=window,fetcher=fetch}={}){
 const container=root?.querySelector('#wf-rule-library');if(!container||root.dataset.workspaceAudience!=='owner')throw Error('Owner rules surface required.');
 let active=null,disposed=false;
 const visible=()=>!disposed&&!documentRef.hidden&&root.dataset.operatorMode!=='view'&&root.dataset.operatorMode!=='private';
 async function request(){
  if(!visible())throw Error('Rules surface unavailable.');const source=new URL(container.dataset.ruleLibrarySource||'/api/rule-library',windowRef.location.href);
  if(source.origin!==windowRef.location.origin||source.pathname!=='/api/rule-library'||source.search||source.hash)throw Error('Exact owner rules source required.');source.searchParams.set('project',worldId);
  const controller=new AbortController();active=controller;const timeout=windowRef.setTimeout(()=>controller.abort(),6000);
  try{
   const response=await fetcher(source.href,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',headers:{Accept:'application/json'},signal:controller.signal});
   if(!response.ok||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')||'')||Number(response.headers.get('content-length'))>OWNER_RULE_LIBRARY_LIMIT)throw Error('Owner rules unavailable.');
   const reader=response.body.getReader(),parts=[];let size=0;
   try{while(true){const row=await reader.read();if(row.done)break;size+=row.value.byteLength;if(size>OWNER_RULE_LIBRARY_LIMIT){await reader.cancel();throw Error('Owner rules response exceeds its bound.');}parts.push(row.value);}}finally{reader.releaseLock();}
   const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}if(disposed||controller.signal.aborted||!visible())throw Error('Rules request no longer current.');return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
  }catch(error){controller.abort();throw error;}finally{windowRef.clearTimeout(timeout);if(active===controller)active=null;}
 }
 const library=mountOwnerRuleLibrary(container,{worldId,request,documentRef});
 const refresh=()=>{if(!visible()){active?.abort();library.unavailable('Rules are unavailable in this presentation.');return;}if(library.isOpen())void library.refresh();};
 const workspace=event=>{if(event.detail?.available===false){active?.abort();library.unavailable();return;}refresh();};
 const dispose=()=>{if(disposed)return;disposed=true;active?.abort();observer?.disconnect();library.dispose();root.removeEventListener('alife-workspace-refresh',workspace);documentRef.removeEventListener('visibilitychange',refresh);windowRef.removeEventListener('pagehide',dispose);};
 const observer=windowRef.MutationObserver?new windowRef.MutationObserver(refresh):null;observer?.observe(root,{attributes:true,attributeFilter:['data-operator-mode']});
 root.addEventListener('alife-workspace-refresh',workspace);documentRef.addEventListener('visibilitychange',refresh);windowRef.addEventListener('pagehide',dispose);
 return Object.freeze({refresh,dispose,update:library.update,unavailable:library.unavailable});
}
if(typeof document!=='undefined'){const root=document.getElementById('alife-world-first');if(root?.dataset.workspaceAudience==='owner'&&root.querySelector('#wf-rule-library')&&root.dataset.ruleLibraryMounted!=='true'){root.dataset.ruleLibraryMounted='true';createOwnerRuleLibraryClient({root,worldId:OWNER_SITE_CONTEXT.worldId});}}
