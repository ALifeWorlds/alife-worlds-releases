import {configureScrollableList} from '../list-presentation.mjs';
import {assertPrivateWorldCatalogResponse,privateWorldCatalogEnvelope,PRIVATE_CATALOG_LIMIT,PRIVATE_CATALOG_STALE_MS} from './private-world-catalog-contract.mjs';
import {createProjectWorldGallery} from './project-world-gallery.mjs';
import {layoutProjectWorlds} from './project-world-layout.mjs';
import {PROJECT_WORLD_RENDERER,assertProjectWorldFrameMessage,createExistingWorldFramePreview} from './project-world-frame-adapter.mjs';
export function createPrivateWorldCatalogController({root,documentRef=document,windowRef=window,fetcher=fetch,now=Date.now,autoStart=true}={}){
 const picker=root.querySelector('#wf-world-picker'),open=root.querySelector('#wf-world-open'),status=root.querySelector('#wf-world-catalog-status'),note=root.querySelector('#wf-world-target-note');
 if(!picker||!open||!status||!note)throw Error('Private world controls required');
 const overview=root.querySelector('#wf-world-overview'),planets=root.querySelector('#wf-world-planets'),overviewStatus=root.querySelector('#wf-overview-status'),worldWrap=root.querySelector('.wf-world-wrap');
 const allId='__all__',expectedWorldId=OWNER_SITE_CONTEXT.worldId,ownerOrigin=root.dataset.catalogOwnerOrigin||windowRef.location.origin;
 const source=new URL('/api/world-catalog',windowRef.location.href);
 const liveScene=root.querySelector('.wf-scene');let frame=liveScene?.querySelector('iframe'),renderer=OWNER_SITE_CONTEXT.renderer;
 const replacement=typeof ownerMountedReplacement==='undefined'?null:ownerMountedReplacement;
 let previewEvent=null,worldPaused=true,frameEpoch=0;
 let envelope=null,selectedId=null,selectionInitialized=false,optionsKey='',timer=null,controller=null,disposed=false;
 let gallery=overview&&planets&&worldWrap&&frame?createProjectWorldGallery({document:documentRef,container:planets,expectedWorldId,ownerOrigin,approvedRenderer:replacement?replacement.getGalleryRenderer():OWNER_SITE_CONTEXT.qualifiedGalleryRenderer,assertCatalogResponse:assertPrivateWorldCatalogResponse,getCurrentInput,createPreview:({host,project,renderer:approved,onStatus})=>createExistingWorldFramePreview({host,project,renderer:approved,approvedRenderer:renderer,scene:liveScene,frame,worldId:expectedWorldId,currentId:envelope?.catalog?.currentId,getCurrentInput,syncVisibility:syncWorldVisibility,onStatus}),onSelect:id=>{if(id===envelope?.catalog?.currentId){selectedId=id;render();}else navigate(id);}}):null;
 function syncWorldVisibility(){const overviewActive=root.dataset.worldOverview==='true';if(worldWrap)worldWrap.hidden=overviewActive;if(liveScene)liveScene.hidden=liveScene.parentElement===worldWrap&&overviewActive;}
 function fresh(){return envelope?.state==='current'&&envelope.catalog&&privateWorldCatalogEnvelope(envelope.catalog,envelope.receivedUtc,now()).state==='current';}
 function ready(row){if(!row)return false;const checked=Date.parse(row.connection.checkedUtc);return Boolean(fresh()&&row.connection.state==='ready'&&row.connection.target&&Number.isFinite(checked)&&now()-checked>=-5000&&now()-checked<=PRIVATE_CATALOG_STALE_MS);}
 function getCurrentInput(){
  const catalog=envelope?.catalog,rows=catalog?.worlds||[],current=fresh();
  let input=null;try{if(ready(rows.find(row=>row.id===catalog?.currentId))){if(replacement)input=replacement.getCurrentInput();else if(previewEvent)input=assertProjectWorldFrameMessage(previewEvent,{frame,ownerOrigin,worldId:expectedWorldId,epoch:frameEpoch,renderer,now:now()});}}catch{}
  const catalogResponse=envelope?{...envelope,state:current?'current':envelope.catalog?'stale':'unavailable',catalog:catalog?{...catalog,worlds:rows.map(row=>ready(row)?row:{...row,connection:{...row.connection,state:'unavailable',target:null}})}:null}:{schemaVersion:1,kind:'owner-world-catalog-response',state:'unavailable',receivedUtc:null,catalog:null};
  return{catalogResponse,preview:input?.preview??null,joined:input?.joined??null};
 }
 function requestFrameInput(){previewEvent=null;worldPaused=true;if(replacement)return;frameEpoch++;try{frame?.contentWindow.postMessage({type:'alife-project-world-request',worldId:expectedWorldId,epoch:frameEpoch},ownerOrigin);}catch{}}
 function frameLoad(){if(disposed)return;requestFrameInput();render();}
 function render(){
  const catalog=envelope?.catalog,rows=catalog?.worlds||[],current=fresh();
  if(!selectionInitialized&&catalog?.sourceState==='current'){selectedId=catalog.currentId;selectionInitialized=true;}
  const key=JSON.stringify(rows.map(row=>[row.id,row.name,ready(row)?row.connection.target.kind:'unavailable',row.id===catalog.currentId]));
  if(key!==optionsKey||!rows.length){
   const fragment=documentRef.createDocumentFragment();
   if(!rows.length){const option=documentRef.createElement('option');option.value='';option.textContent='World list unavailable';fragment.append(option);}
   else {for(const row of rows){const option=documentRef.createElement('option');option.value=row.id;option.disabled=!ready(row);option.textContent=row.name;option.title=row.id===catalog.currentId?'Current project':ready(row)?row.connection.target.kind==='this-computer'?'Local only':'Owner-private':'Connection unavailable';fragment.append(option);}const all=documentRef.createElement('option');all.value=allId;all.textContent='All planets';fragment.append(all);}
   picker.replaceChildren(fragment);optionsKey=key;
  }
  picker.value=selectedId===allId&&rows.length?allId:rows.some(row=>row.id===selectedId)?selectedId:'';
  picker.disabled=!rows.length;
  const row=rows.find(row=>row.id===selectedId),canOpen=ready(row);open.disabled=!canOpen;
  status.textContent=!catalog||catalog.sourceState!=='current'?'World list unavailable':current?rows.length+' registered worlds · '+rows.filter(ready).length+' ready':'Last recorded world list · connections unconfirmed';
  note.textContent=selectedId===allId?'Registered worlds only. Unavailable worlds have no verified scene or opening target.':!canOpen?'Select a ready world. Unavailable entries have no verified target.':row.connection.target.kind==='this-computer'?'Local only · open on the computer hosting this world.':'Owner-private site · opens this world’s existing workspace.';
  if(overview&&planets&&worldWrap){configureScrollableList(planets,rows.length,'Registered worlds','world-planets');
   const showAll=selectedId===allId&&rows.length>0&&root.dataset.operatorMode!=='view'&&root.dataset.worldFullscreen!=='true';overview.hidden=!showAll;root.dataset.worldOverview=String(Boolean(showAll));syncWorldVisibility();

   open.hidden=Boolean(showAll||row?.id===catalog?.currentId);
   if(showAll){
    overviewStatus.textContent=current?rows.length+' registered worlds · '+rows.filter(ready).length+' ready':'Last recorded world list · connections unconfirmed';

   }
   if(gallery){
    gallery.update(getCurrentInput());gallery.setActive(Boolean(showAll));layoutProjectWorlds(gallery.element);gallery.setMotion({running:!worldPaused,visible:Boolean(showAll)&&!documentRef.hidden});syncWorldVisibility();
   }
  }
 }
 function worldMessage(event){
  if(replacement?.diagnostics().revoked)return;
  if(!frame||event.source!==frame.contentWindow||event.origin!==ownerOrigin||event.data?.worldId!==expectedWorldId)return;
  if(event.data.type==='alife-project-world-preview'&&!replacement){if(event.data.epoch!==frameEpoch)return;try{assertProjectWorldFrameMessage(event,{frame,ownerOrigin,worldId:expectedWorldId,epoch:frameEpoch,renderer,now:now()});previewEvent=event;}catch{previewEvent=null;}render();}
  else if(event.data.type==='alife-world-state'&&typeof event.data.paused==='boolean'){worldPaused=event.data.paused;render();}
 }
 async function body(response){
  const reader=response.body?.getReader();if(!reader)throw Error('Missing catalog body');const chunks=[];let length=0;
  try{while(true){const part=await reader.read();if(part.done)break;length+=part.value.byteLength;if(length>PRIVATE_CATALOG_LIMIT+1024){await reader.cancel();throw Error('Catalog too large');}chunks.push(part.value);}}finally{reader.releaseLock();}
  const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
 }
 async function refresh(){
  if(disposed||replacement?.diagnostics().revoked||documentRef.hidden||controller)return;windowRef.clearTimeout(timer);
  const active=new AbortController();controller=active;const timeout=windowRef.setTimeout(()=>active.abort(),6000);
  try{
   const response=await fetcher(source.href,{method:'GET',cache:'no-store',credentials:'same-origin',redirect:'error',headers:{Accept:'application/json'},signal:active.signal});
   if(response.status===401||response.status===403){replacement?.revoke('Owner access unavailable');envelope=null;selectedId=null;selectionInitialized=false;optionsKey='';throw Error('Owner access unavailable');}
   if(!response.ok||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')||''))throw Error('Catalog unavailable');
   const raw=await body(response);if(raw?.catalog&&raw.catalog.worldId!==expectedWorldId){replacement?.revoke('World catalog context changed');envelope=null;throw Error('World catalog context changed');}
   const value=assertPrivateWorldCatalogResponse(raw,{expectedWorldId,ownerOrigin});if(disposed||replacement?.diagnostics().revoked||active.signal.aborted)return;envelope=value;render();void replacement?.refresh();
  }catch{if(!disposed){if(envelope)envelope={...envelope,state:'unavailable'};render();}}
  finally{windowRef.clearTimeout(timeout);if(controller===active)controller=null;if(!disposed&&!replacement?.diagnostics().revoked&&!documentRef.hidden)timer=windowRef.setTimeout(refresh,10000);}
 }
 function selected(){selectedId=picker.value;render();}
 function navigate(id=selectedId){
  const row=envelope?.catalog?.worlds.find(row=>row.id===id);if(!ready(row)){render();return;}
  assertPrivateWorldCatalogResponse(envelope,{expectedWorldId,ownerOrigin});
  try{windowRef.location.assign(row.connection.target.url);}catch{note.textContent='This world could not be opened. The current view is unchanged.';}
 }
 function visibility(){windowRef.clearTimeout(timer);gallery?.setMotion({running:!worldPaused,visible:!documentRef.hidden&&root.dataset.worldOverview==='true'});if(documentRef.hidden)controller?.abort();else refresh();}
 function dispose(){disposed=true;unsubscribe?.();unobserve?.();windowRef.clearTimeout(timer);controller?.abort();root.dataset.worldOverview='false';if(overview)overview.hidden=true;gallery?.dispose();syncWorldVisibility();previewEvent=null;frame?.removeEventListener('load',frameLoad);windowRef.removeEventListener('message',worldMessage);picker.removeEventListener('change',selected);open.removeEventListener('click',openSelected);documentRef.removeEventListener('visibilitychange',visibility);windowRef.removeEventListener('pagehide',dispose);}
 const unsubscribe=replacement?.subscribe(({frame:next,renderer:nextRenderer,qualifiedGalleryRenderer})=>{const previous=frame,previousRenderer=renderer,previousGallery=replacement.getGalleryRenderer();return{commit(){frame?.removeEventListener('load',frameLoad);frame=next;renderer=nextRenderer;previewEvent=null;frameEpoch++;frame.addEventListener('load',frameLoad);if(gallery?.setApprovedRenderer(qualifiedGalleryRenderer)===false)throw Error('Existing gallery scene return needs recovery');},rollback(){frame?.removeEventListener('load',frameLoad);frame=previous;renderer=previousRenderer;frame?.addEventListener('load',frameLoad);gallery?.setApprovedRenderer(previousGallery);},disposePrevious(){render();}};});
 const unobserve=replacement?.observe(()=>{if(replacement.diagnostics().revoked){windowRef.clearTimeout(timer);controller?.abort();envelope=null;selectedId=null;selectionInitialized=false;optionsKey='';previewEvent=null;gallery?.dispose();gallery=null;}else gallery?.setApprovedRenderer(replacement.getGalleryRenderer());render();});
 const openSelected=()=>navigate();
 windowRef.addEventListener('message',worldMessage);frame?.addEventListener('load',frameLoad);requestFrameInput();
 picker.addEventListener('change',selected);open.addEventListener('click',openSelected);documentRef.addEventListener('visibilitychange',visibility);windowRef.addEventListener('pagehide',dispose);
 render();if(autoStart)refresh();return{refresh,render,dispose};
}
if(typeof document!=='undefined'){const root=document.getElementById('alife-world-first');if(root?.dataset.workspaceAudience==='owner'&&root.querySelector('#wf-world-picker'))createPrivateWorldCatalogController({root});}
