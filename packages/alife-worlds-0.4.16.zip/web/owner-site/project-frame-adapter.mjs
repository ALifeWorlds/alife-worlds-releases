// Site-owned bridge: the existing isolated owner renderer remains the only live world.
export const PROJECT_WORLD_RENDERER=Object.freeze({...OWNER_SITE_CONTEXT.renderer});
const closed=(v,keys)=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const descriptorKeys=['schemaVersion','bundleId','worldVersion','artifactSha256'];
const sameRenderer=(v,expected=PROJECT_WORLD_RENDERER)=>closed(v,descriptorKeys)&&descriptorKeys.every(k=>v[k]===expected?.[k]);
const utc=v=>typeof v==='string'&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString()===v;
export function assertProjectWorldFrameMessage(event,{frame,ownerOrigin,worldId,epoch,renderer=PROJECT_WORLD_RENDERER,now=Date.now()}={}){
 if(!frame||event.source!==frame.contentWindow||event.origin!==ownerOrigin||new URL(frame.src,ownerOrigin).origin!==ownerOrigin)throw Error('Exact isolated owner window required');
 const value=event.data;
 if(!Number.isSafeInteger(epoch)||epoch<1||!closed(value,['type','worldId','epoch','receivedUtc','preview','joined'])||value.type!=='alife-project-world-preview'||value.worldId!==worldId||value.epoch!==epoch||!utc(value.receivedUtc)||Date.parse(value.receivedUtc)>now+5000||now-Date.parse(value.receivedUtc)>45000)throw Error('Current private world update required');
 if(value.preview===null||value.joined===null){if(value.preview!==null||value.joined!==null)throw Error('Invalid unavailable world');return null;}
 const {preview,joined}=value;
 if(!closed(preview,['schemaVersion','kind','worldId','renderer','snapshot','appearance','names','metadata'])||preview.schemaVersion!==3||preview.kind!=='owner-world-preview'||preview.worldId!==worldId||!sameRenderer(preview.renderer,renderer)||preview.snapshot?.world?.id!==worldId||!utc(preview.snapshot?.observedUtc)||Date.parse(preview.snapshot.observedUtc)>now+5000||now-Date.parse(preview.snapshot.observedUtc)>45000||preview.snapshot.feed?.error!==null)throw Error('Qualified current owner preview required');
 if(!closed(joined,['snapshot','model','feed','metadataMarker'])||joined.snapshot!==preview.snapshot||!closed(joined.metadataMarker,['worldId','artifactSha256','revision','contentHash'])||joined.metadataMarker.worldId!==worldId||joined.metadataMarker.artifactSha256!==renderer.artifactSha256||joined.metadataMarker.revision!==preview.metadata?.revision||joined.metadataMarker.contentHash!==preview.metadata?.contentHash)throw Error('Original qualified join required');
 return {preview,joined};
}
export function createExistingWorldFramePreview({host,project,renderer,approvedRenderer=PROJECT_WORLD_RENDERER,scene,frame,worldId,currentId,getCurrentInput,syncVisibility,onStatus=()=>{}}={}){
 if(!host?.isConnected||!scene?.isConnected||!frame||!scene.contains(frame)||project?.id!==currentId||!sameRenderer(renderer,approvedRenderer)||typeof host.moveBefore!=='function')throw Error('State-preserving own-world window unavailable');
 const originalParent=scene.parentElement,originalNext=scene.nextSibling;
 if(!originalParent?.isConnected||typeof originalParent.moveBefore!=='function')throw Error('State-preserving return unavailable');
 if(typeof getCurrentInput!=='function'||typeof syncVisibility!=='function'||typeof onStatus!=='function')throw Error('Actual receiver readiness required');
 const current=getCurrentInput();
 if(current?.preview?.worldId!==worldId||current.joined?.snapshot!==current.preview.snapshot||!sameRenderer(current.preview.renderer,approvedRenderer))throw Error('Owned iframe is not ready');
 let disposed=false;
 host.moveBefore(scene,null);
 scene.classList.add('wf-project-live-scene');syncVisibility();
 return {
  render({preview,joined,token}={}){const latest=getCurrentInput();if(!Number.isSafeInteger(token)||token<1||disposed||preview?.worldId!==worldId||joined?.snapshot!==preview.snapshot||!sameRenderer(preview.renderer,approvedRenderer)||latest?.preview!==preview||latest?.joined!==joined)throw Error('Owned iframe update is not ready');syncVisibility();onStatus({state:'ready',token});},
  setMotion({running=false,visible=true}={}){if(typeof running!=='boolean'||typeof visible!=='boolean')throw Error('Actual preview motion required');},
  dispose(){if(disposed)return;if(!originalParent.isConnected||!scene.isConnected)throw Error('Owned scene return target lost');originalParent.moveBefore(scene,originalNext?.parentElement===originalParent?originalNext:null);scene.classList.remove('wf-project-live-scene');disposed=true;syncVisibility();}
 };
}
