import {assertProjectWorldFrameMessage} from './project-frame-adapter.mjs';

const closed=(value,keys)=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
const keys=['type','worldId','epoch','receivedUtc','preview','joined','nonce','controlRevision'];

// Candidate-only correlated receipt. Keep the original six-key bridge parser
// strict and available independently for legacy callers.
export function assertReplacementFrameMessage(event,options={}){
 const value=event?.data,{nonce,controlRevision}=options;
 if(!closed(value,keys)||typeof nonce!=='string'||!/^[A-Za-z0-9_-]{16,128}$/.test(nonce)||value.nonce!==nonce||!Number.isSafeInteger(controlRevision)||controlRevision<0||value.controlRevision!==controlRevision)throw Error('Exact current candidate render correlation required');
 // Real MessageEvent source/origin are getters, not spreadable own properties.
 const input=assertProjectWorldFrameMessage({
  source:event.source,origin:event.origin,
  data:{type:value.type,worldId:value.worldId,epoch:value.epoch,receivedUtc:value.receivedUtc,preview:value.preview,joined:value.joined}
 },options);
 return input===null?null:{...input,receivedUtc:value.receivedUtc,nonce:value.nonce,controlRevision:value.controlRevision};
}
