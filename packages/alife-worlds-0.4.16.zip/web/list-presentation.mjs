// Count real records, not headings or empty-state messages. Keep every record
// available; a long collection scrolls without clipping its expanded children.
export function configureScrollableList(node,count,label,key=label){
 node.dataset.listCount=String(count);node.dataset.listKey=key;
 node.dataset.focusKey='list:'+key;
 node.dataset.longList=String(count>5);
 node.tabIndex=count>5?0:-1;node.setAttribute('aria-label',label+' · '+count+' items');
 return node;
}

export function preserveListPositions(root){
 const positions=new Map([...root.querySelectorAll('[data-list-key]')].map(node=>[node.dataset.listKey,{top:node.scrollTop,left:node.scrollLeft}]));
 return ()=>{for(const node of root.querySelectorAll('[data-list-key]')){const p=positions.get(node.dataset.listKey);if(p){node.scrollTop=p.top;node.scrollLeft=p.left;}}};
}
