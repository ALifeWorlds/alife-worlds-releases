// Browser-safe counterpart of lib/portable-definitions.mjs. Keep the closed wire schema identical.
const utf8Bytes=v=>new TextEncoder().encode(v).byteLength;

export const PORTABLE_FORMAT='alife-portable';
export const PORTABLE_MAX_BYTES=1024*1024;
export const LOGICAL_ID=/^[a-z][a-z0-9-]{0,63}$/;
const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v));
export function closed(v,keys,label='record'){
 if(!plain(v)||Object.keys(v).some(k=>!keys.includes(k)||['__proto__','constructor','prototype'].includes(k)))throw Error('Unsupported '+label+' field.');
 return v;
}
export function boundedText(v,max=48000){
 if(typeof v!=='string'||!v.trim()||v.length>max||/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(v))throw Error('Invalid bounded portable text.');
 const s=v.trim();
 if(/(?:[A-Za-z]:[\\/]|\\\\[^\s]+|(?:^|[\s"'(])\/(?:Users|home|root|mnt|Volumes|etc|var)\/|\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b|\b(?:api[_-]?key|password|access[_-]?token|client[_-]?secret)\s*[:=]|\bsk-[A-Za-z0-9_-]{16,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)/i.test(s))throw Error('Private identity, path or credential refused.');
 for(const match of s.matchAll(/https?:\/\/[^\s<>"')]+/gi)){
  let u;try{u=new URL(match[0]);}catch{throw Error('Malformed portable URL.');}
  if(u.username||u.password||/^(localhost|127(?:\.\d+){3}|0\.0\.0\.0|\[?::1\]?)$/i.test(u.hostname)||[...u.searchParams.keys()].some(k=>/token|secret|password|credential|auth|api.?key/i.test(k)))throw Error('Private endpoint or credential-bearing URL refused.');
 }
 return s;
}
export function logicalId(v){if(typeof v!=='string'||!LOGICAL_ID.test(v)||['constructor','prototype'].includes(v))throw Error('Invalid logical ID.');return v;}
export function normalizeGroups(value=[],{descriptions=false}={}){
 if(!Array.isArray(value)||value.length>64)throw Error('Invalid portable group count.');
 const seen=new Set();let count=0;
 return value.map(g=>{
  closed(g,['id','title','properties'],'group');const id=logicalId(g.id);
  if(seen.has(id)||!Array.isArray(g.properties)||g.properties.length>100)throw Error('Duplicate group or invalid property count.');seen.add(id);
  const ids=new Set();
  return {id,title:boundedText(g.title,160),properties:g.properties.map(p=>{
   closed(p,['id','title','description','text'],'property');const pid=logicalId(p.id);
   if(ids.has(pid)||++count>512)throw Error('Duplicate or excessive property.');ids.add(pid);
   return {id:pid,title:boundedText(p.title,160),...(p.description!==undefined||descriptions?{description:boundedText(p.description??p.title,600)}:{}),text:boundedText(p.text,p.description!==undefined||descriptions?12000:4000)};
  })};
 });
}
function section(v,version){
 closed(v,['prompt','groups'],'section');const out={groups:normalizeGroups(v.groups,{descriptions:version===2})};
 if(v.prompt!==undefined)out.prompt=boundedText(v.prompt,600000);
 if(!out.prompt&&!out.groups.some(g=>g.properties.length))throw Error('Empty portable section.');
 return out;
}
export function canonicalJSON(v){
 if(v===null||typeof v==='boolean'||typeof v==='string')return JSON.stringify(v);
 if(typeof v==='number'&&Number.isFinite(v))return JSON.stringify(v);
 if(Array.isArray(v))return '['+v.map(canonicalJSON).join(',')+']';
 if(!plain(v))throw Error('Only JSON data is supported.');
 return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonicalJSON(v[k])).join(',')+'}';
}
export function validatePortablePacket(v){
 closed(v,['format','schemaVersion','kind','title','world','plugin','agents'],'packet');
 if(v.format!==PORTABLE_FORMAT||![1,2].includes(v.schemaVersion)||!['world','plugin','agent','bundle'].includes(v.kind))throw Error('Unsupported portable format/version/kind.');
 const described=[...(v.world?.groups||[]),...(v.plugin?.groups||[]),...(v.agents||[]).flatMap(a=>a.groups||[])].some(g=>g.properties?.some(p=>p.description!==undefined));
 const version=v.schemaVersion===2||described?2:1;
 const out={format:PORTABLE_FORMAT,schemaVersion:version,kind:v.kind,title:boundedText(v.title,160)};
 if(v.world!==undefined)out.world=section(v.world,version);
 if(v.plugin!==undefined)out.plugin=section(v.plugin,version);
 if(v.agents!==undefined){
  if(!Array.isArray(v.agents)||v.agents.length>32)throw Error('Invalid portable agents.');
  const ids=new Set();out.agents=v.agents.map(a=>{
   closed(a,['id','title','prompt','groups'],'agent');const id=logicalId(a.id);
   if(ids.has(id))throw Error('Duplicate portable role.');ids.add(id);
   return {id,title:boundedText(a.title,160),prompt:boundedText(a.prompt),groups:normalizeGroups(a.groups,{descriptions:version===2})};
  });
 }
 if(v.kind==='world'&&(!out.world||out.plugin)||v.kind==='plugin'&&(!out.plugin||out.world)||v.kind==='agent'&&(!out.agents?.length||out.world||out.plugin)||v.kind==='bundle'&&!out.world&&!out.plugin&&!out.agents?.length)throw Error('Kind/content mismatch.');
 if(utf8Bytes(canonicalJSON(out))>PORTABLE_MAX_BYTES)throw Error('Portable packet too large.');
 return out;
}
export function parsePortableImport(input,{kind,title='Imported ALife definition',agentId='imported-agent'}={}){
 if(typeof input!=='string'||utf8Bytes(input)>PORTABLE_MAX_BYTES)throw Error('Paste one bounded import.');
 let text=input.trim().replace(/^\/import(?:\s+|$)/,'').trim();
 const fenced=text.match(/^\x60\x60\x60(?:json)?\s*\n([\s\S]*?)\n\x60\x60\x60$/i);if(fenced)text=fenced[1].trim();
 if(text.startsWith('{'))return validatePortablePacket(JSON.parse(text));
 if(!kind){
  if(/^# Shareable world prompt(?:\r?\n|$)/i.test(text))kind='world';
  else if(/^# Shareable plugin rules prompt(?:\r?\n|$)/i.test(text))kind='plugin';
  else if(/^# (?:Creation contract for |Agent-specific rules prompt)/i.test(text))kind='agent';
  else throw Error('Plain text needs an explicit world, plugin or agent scope.');
 }
 if(!['world','plugin','agent'].includes(kind))throw Error('Plain prompt scope is invalid.');
 return validatePortablePacket({format:PORTABLE_FORMAT,schemaVersion:1,kind,title,...(kind==='agent'?{agents:[{id:agentId,title,prompt:text,groups:[]}]}:{[kind]:{prompt:text,groups:[]}})});
}
export const portableClipboard=p=>'/import '+JSON.stringify(validatePortablePacket(p),null,2);
export function portablePacketFromCatalog(kind,title,catalog,agents=[]){
 if(!['world','plugin'].includes(kind)||catalog?.scope!==kind)throw Error('Exact catalogue scope required.');
 const groups=catalog.groups.map(g=>({id:g.id,title:g.title,properties:g.properties.filter(p=>p.active===true).map(p=>({id:p.id,title:p.title,description:p.description||p.title,text:p.text}))})).filter(g=>g.properties.length);
 return validatePortablePacket({format:PORTABLE_FORMAT,schemaVersion:1,kind,title,[kind]:{groups},...(agents.length?{agents}:{})});
}
