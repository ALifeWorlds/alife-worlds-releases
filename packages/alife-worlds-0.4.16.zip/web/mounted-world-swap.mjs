// Parent-owned DOM lifetime only. Candidate qualification and World transfer remain
// explicit collaborators; a load/controls-ready event is never a commit signal.
export function createMountedWorldSwap({
 scene,activeFrame,ownerOrigin,getContextKey,getPreferences,
 qualifyCandidate,requestReadiness,qualifyReady,isReadyCurrent,transferWorldState,prepareBindings,
 onStatus=()=>{},documentRef=document,windowRef=window,timeoutMs=20000
}={}){
 const functions=[getContextKey,getPreferences,qualifyCandidate,requestReadiness,qualifyReady,isReadyCurrent,transferWorldState,prepareBindings,onStatus];
 if(!scene?.isConnected||!activeFrame||!scene.contains(activeFrame)||functions.some(fn=>typeof fn!=='function')||new URL(ownerOrigin).origin!==ownerOrigin)throw Error('Exact mounted-world collaborators required');
 if(!Number.isFinite(timeoutMs)||timeoutMs<1000||timeoutMs>60000)throw Error('Bounded candidate lifetime required');
 let active=activeFrame,pending=null,serial=0,disposed=false;
 const canonicalPreferences=()=>{const p=getPreferences();if(!p||!['public','private','view'].includes(p.mode)||typeof p.paused!=='boolean'||typeof p.soundEnabled!=='boolean'||typeof p.volume!=='number'||!Number.isFinite(p.volume)||p.volume<0||p.volume>1)throw Error('Current presentation preferences required');return{mode:p.mode,paused:p.paused,volume:p.volume,soundEnabled:p.soundEnabled};};
 const contextKey=()=>{const key=getContextKey();if(typeof key!=='string'||!key||key.length>2048)throw Error('Current owner/world/access identity required');return key;};
 function current(p){try{return!disposed&&pending===p&&!p.abort.signal.aborted&&p.context===contextKey()&&p.preferencesKey===JSON.stringify(canonicalPreferences())&&active===p.previous&&scene.isConnected&&scene.contains(active)&&p.frame.src===p.url;}catch{return false;}}
 function notify(state,reason){try{onStatus({state,reason});}catch{}}
 function removeCandidate(p){windowRef.clearTimeout(p.timeout);p.abort.abort();p.frame.removeEventListener('load',p.loaded);p.frame.removeEventListener('error',p.error);p.frame.remove();}
 function reject(p,reason='Candidate unavailable'){
  if(pending!==p)return false;pending=null;removeCandidate(p);notify('retained',reason);return false;
 }
 function cancel(reason='Candidate cancelled'){return pending?reject(pending,reason):false;}
 function begin(request){
  if(disposed)throw Error('Mounted-world lifecycle disposed');
  // This validator consumes the server-owned descriptor; messages cannot choose URLs.
  const qualified=qualifyCandidate(request);if(!qualified||typeof qualified.url!=='string'||!Number.isSafeInteger(qualified.epoch)||qualified.epoch<1)throw Error('Qualified candidate URL/epoch required');
  const url=new URL(qualified.url,ownerOrigin);if(url.origin!==ownerOrigin||url.username||url.password||url.hash)throw Error('Exact same-origin candidate required');
  const context=contextKey(),preferences=canonicalPreferences();cancel('Superseded candidate');
  const frame=documentRef.createElement('iframe'),abort=new AbortController();
  frame.title=active.title||'ALife World';frame.className=active.className||'';frame.src=url.href;frame.tabIndex=-1;
  for(const attr of ['allow','sandbox','referrerpolicy','allowfullscreen','scrolling'])if(active.hasAttribute(attr))frame.setAttribute(attr,active.getAttribute(attr));
  frame.setAttribute('aria-hidden','true');frame.inert=true;
  // Keep a fitted, renderable viewport. display:none/hidden would defeat real readiness.
  Object.assign(frame.style,{position:'absolute',inset:'0',width:'100%',height:'100%',visibility:'hidden',pointerEvents:'none'});
  const p={id:++serial,frame,url:url.href,qualified,abort,context,preferences,preferencesKey:JSON.stringify(preferences),previous:active,loadedCount:0,processing:false,timeout:null};
  p.loaded=()=>{if(!current(p))return reject(p,'Candidate context changed');if(++p.loadedCount>1)return reject(p,'Candidate navigated during preparation');try{requestReadiness({frame,candidate:qualified,preferences:{...preferences,soundEnabled:false},signal:abort.signal});notify('loading','Waiting for a completed matching render');}catch{return reject(p,'Candidate readiness challenge failed');}};
  p.error=()=>reject(p,'Candidate failed to load');frame.addEventListener('load',p.loaded);frame.addEventListener('error',p.error);
  pending=p;scene.append(frame);p.timeout=windowRef.setTimeout(()=>reject(p,'Candidate readiness timed out'),timeoutMs);notify('loading','Preparing same-world replacement');
  return Object.freeze({frame,epoch:qualified.epoch,generation:p.id,signal:abort.signal});
 }
 async function accept(event){
  const p=pending;if(!p||p.processing||p.loadedCount!==1||event.source!==p.frame.contentWindow||event.origin!==ownerOrigin)return false;
  try{
   if(!current(p))return reject(p,'Candidate context changed');
   p.processing=true;
   const readyContext={frame:p.frame,candidate:p.qualified,epoch:p.qualified.epoch};
   const ready=await qualifyReady(event,readyContext);
   if(!current(p))return reject(p,'Candidate superseded during readiness validation');
   if(!ready){p.processing=false;return false;}
   if(isReadyCurrent(ready,readyContext)!==true)throw Error('Candidate readiness proof expired');
   // The actual World consumer must capture/restore and acknowledge its rendered result.
   // No native activity/feed timestamps or automatically enabled audio are accepted here.
   const applied=await transferWorldState({previousFrame:p.previous,candidateFrame:p.frame,candidate:p.qualified,ready,preferences:{...p.preferences,soundEnabled:false},resumeSoundIntent:p.preferences.soundEnabled,signal:p.abort.signal});
   if(!current(p))return reject(p,'Candidate superseded during transfer');
   if(!applied||applied.ready!==true||applied.mode!==p.preferences.mode||applied.paused!==p.preferences.paused||applied.volume!==p.preferences.volume||applied.soundEnabled!==false)throw Error('World transfer readiness not acknowledged');
   // Restore can render a newer input. Qualify that actual final receipt rather
   // than pair the old proof with a different metadata marker/observed time.
   const finalEvent=applied.renderEvent;
   if(!finalEvent||finalEvent.source!==p.frame.contentWindow||finalEvent.origin!==ownerOrigin)throw Error('Actual post-transfer render receipt required');
   const finalReady=await qualifyReady(finalEvent,readyContext);
   if(!current(p))return reject(p,'Candidate superseded during final render validation');
   if(!finalReady||isReadyCurrent(finalReady,readyContext)!==true)throw Error('Candidate final render proof expired');
   const bindings=prepareBindings({previousFrame:p.previous,candidateFrame:p.frame,candidate:p.qualified,ready:finalReady,transfer:applied});
   if(!bindings||typeof bindings.commit!=='function'||typeof bindings.rollback!=='function'||typeof bindings.disposePrevious!=='function')throw Error('Transactional active-frame bindings required');
   if(!current(p))return reject(p,'Candidate context changed before reveal');
   if(isReadyCurrent(finalReady,readyContext)!==true)throw Error('Candidate readiness expired before commit');
   try{const result=bindings.commit();if(result&&typeof result.then==='function')throw Error('Frame bindings must commit synchronously');}
   catch(error){bindings.rollback();throw error;}
   // One JS turn: matching receiver references commit before the candidate is revealed.
   const previous=p.previous,focused=documentRef.activeElement===previous;
   active=p.frame;pending=null;windowRef.clearTimeout(p.timeout);
   p.frame.removeEventListener('load',p.loaded);p.frame.removeEventListener('error',p.error);
   Object.assign(active.style,{position:'',inset:'',width:'',height:'',visibility:'',pointerEvents:''});
   active.removeAttribute('aria-hidden');active.inert=false;active.removeAttribute('tabindex');
   previous.remove();if(focused)active.focus({preventScroll:true});
   // Cleanup cannot undo an already coherent visible swap or dispose the new frame.
   let cleanupFailed=false;try{bindings.disposePrevious();}catch{cleanupFailed=true;}
   // Successful adoption is not cancellation of the new active frame's attempt.
   notify('ready',cleanupFailed?'Replacement ready; previous receiver cleanup needs attention':p.preferences.soundEnabled?'Replacement ready; use Sound to resume playback':'Replacement ready');return true;
  }catch(error){return reject(p,error?.message||'Candidate could not be verified');}
 }
 return Object.freeze({begin,accept,cancel,getActiveFrame:()=>active,getPendingFrame:()=>pending?.frame??null,
  contextChanged(){if(pending&&!current(pending))return reject(pending,'World, access or presentation changed');return false;},
  dispose(){if(disposed)return;cancel('Parent lifecycle disposed');disposed=true;}
 });
}
