/* Human-selected muted procedural woodland. Art only: no roster, activity, mining or task simulation. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.AlifeColonyArt=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const seasonalWorld=(function(){'use strict';
const SEASONS=['spring','summer','autumn','winter'];
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const ease=x=>{x=clamp(x);return x*x*(3-2*x);};
const hash=value=>{let h=2166136261;for(const c of String(value))h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return h;};
function seasonFrame(environment,visualSeconds,{worldSeed='world',reducedMotion=false}={}){
 const valid=!!environment&&SEASONS.includes(environment.season)&&Number.isFinite(visualSeconds)&&visualSeconds>=0;
 if(!valid)return Object.freeze({valid:false,season:null,seconds:null,phase:null,weather:null,light:null,reducedMotion:!!reducedMotion,snowCover:0,freezeAmount:0,gust:0,fauna:Object.freeze({spring:false,butterflies:false,birds:false}),springFlowers:false,worldSeed:String(worldSeed)});
 const season=environment.season,phase=(visualSeconds%360)/360,snowCover=season==='winter'?ease(phase*20)*ease((1-phase)*20):0;
 const h=hash(worldSeed),period=32+h%9,gustSeconds=6+(h>>>8)%3,local=(visualSeconds+(h%997)/997*period)%period,start=period-gustSeconds;
 const pulse=local<=start?0:Math.sin(Math.PI*(local-start)/gustSeconds)**2;
 const force=environment.weather==='breeze'||environment.weather==='rain'||environment.weather==='snow'?3:1.6;
 return Object.freeze({valid:true,season,seconds:visualSeconds,phase,weather:environment.weather??null,light:Number.isFinite(environment.light)?clamp(environment.light):null,reducedMotion:!!reducedMotion,snowCover,freezeAmount:season==='winter'?snowCover:0,gust:reducedMotion?0:pulse*force,fauna:Object.freeze({spring:season==='spring',butterflies:season==='spring'||season==='summer',birds:season!=='winter'}),springFlowers:season==='spring',worldSeed:String(worldSeed)});
}
function pineWind(frame,key){if(!frame?.valid||frame.reducedMotion)return 0;return clamp(Math.sin(frame.seconds*.9+(hash(key)%628)/100)*frame.gust,-3,3);}
const PINE_CAPS={
 'near-tall':[[.51,.015,.025],[.50,.155,.10],[.50,.285,.18],[.49,.425,.27],[.49,.565,.35],[.48,.705,.43]],
 'near-small':[[.50,.015,.025],[.50,.145,.11],[.50,.285,.20],[.50,.435,.30],[.50,.585,.39],[.50,.735,.46]]
};
const TREE_CAPS={seed:[[.5,.30,.34]],sprout:[[.5,.16,.27]],sapling:[[.61,.10,.29],[.29,.31,.15]],young:[[.54,.11,.28],[.28,.39,.18],[.75,.56,.16]],mature:[[.52,.10,.31],[.25,.31,.20],[.77,.39,.18]],complete:[[.57,.10,.32],[.27,.30,.24],[.78,.40,.19]]};
function defaultCanvas(w,h){if(typeof OffscreenCanvas==='function')return new OffscreenCanvas(w,h);if(typeof document!=='undefined'&&typeof document.createElement==='function'){const c=document.createElement('canvas');c.width=w;c.height=h;return c;}return null;}
function frameOkay(frame){return frame&&typeof frame.id==='string'&&Array.isArray(frame.rect)&&frame.rect.length===4&&frame.rect.every(Number.isFinite)&&frame.rect[2]>0&&frame.rect[3]>0&&Array.isArray(frame.pivot)&&frame.pivot.length===2&&frame.pivot.every(Number.isFinite);}
function polygon(ctx,points,color){ctx.fillStyle=color;ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();ctx.fill();}
function snowCaps(ctx,frame,amount){const [,,w,h]=frame.rect,caps=PINE_CAPS[frame.id]||TREE_CAPS[frame.id]||[];ctx.save();ctx.globalCompositeOperation='source-atop';ctx.globalAlpha=.9*amount;
 for(const [nx,ny,nw]of caps){const x=nx*w,y=ny*h,r=nw*w,d=Math.max(3,h*.012);polygon(ctx,[[x-r,y+d],[x-r*.62,y+d*.25],[x-r*.29,y],[x,y-d*.08],[x+r*.31,y],[x+r*.66,y+d*.35],[x+r,y+d],[x+r*.88,y+d*1.38],[x+r*.42,y+d*.57],[x,y+d*.45],[x-r*.44,y+d*.7],[x-r*.92,y+d*1.4]],'#dce6d9');}
 ctx.restore();}
function createPainter({canvasFactory=defaultCanvas,maxEntries=32}={}){
 maxEntries=Math.max(1,Math.min(32,Math.floor(maxEntries)||32));const cache=new Map();const ids=new WeakMap();let nextId=0;
 function prepared(image,frame,state){if(!frameOkay(frame)||!image)return{image:null,ready:false,reason:'invalid-image-or-frame'};
  if(!state?.valid||state.season==='summer')return{image:null,ready:true,original:true};
  if(typeof image!=='object'&&typeof image!=='function')return{image:null,ready:false,reason:'invalid-image'};
  if(!ids.has(image))ids.set(image,++nextId);const winter=state.season==='winter',snow= winter?Math.round(state.snowCover*8)/8:0;
  // One bounded cache; winter uses at most9 quantized cap states, not one canvas per frame.
  const key=ids.get(image)+'|'+frame.id+'|'+frame.rect.join(',')+'|'+state.season+'|'+snow;
  if(cache.has(key)){const hit=cache.get(key);cache.delete(key);cache.set(key,hit);return hit;}
  const [sx,sy,w,h]=frame.rect,c=canvasFactory(w,h),ctx=c?.getContext?.('2d');if(!ctx)return{image:null,ready:false,reason:'seasonal-canvas-unavailable'};
  ctx.imageSmoothingEnabled=false;ctx.drawImage(image,sx,sy,w,h,0,0,w,h);
  ctx.save();ctx.globalCompositeOperation='source-atop';ctx.beginPath();ctx.rect(0,0,w,h*.79);ctx.clip();
  if(state.season==='autumn'){ctx.globalAlpha=.23;ctx.fillStyle='#b08b4d';ctx.fillRect(0,0,w,h*.79);}
  if(state.season==='spring'){ctx.globalAlpha=.09;ctx.fillStyle='#a4b67b';ctx.fillRect(0,0,w,h*.79);}
  if(winter){ctx.globalAlpha=.10;ctx.fillStyle='#aec5be';ctx.fillRect(0,0,w,h*.79);}ctx.restore();if(winter)snowCaps(ctx,frame,snow);
  const value={image:c,ready:true,original:false};cache.set(key,value);while(cache.size>maxEntries)cache.delete(cache.keys().next().value);return value;
 }
 function paintTree(ctx,{image,frame,x,y,scale=1,state,key=frame?.id,wind=true}={}){
  if(!frameOkay(frame)||!image||![x,y,scale].every(Number.isFinite)||scale<=0)return{painted:false,reason:'invalid-sprite-input'};
  const variant=prepared(image,frame,state),[sx,sy,w,h]=frame.rect,[px,py]=frame.pivot,source=variant.image||image;
  const wave=wind?pineWind(state,key):0;ctx.save();ctx.translate(x,y);ctx.imageSmoothingEnabled=false;
  if(!wave){if(variant.image)ctx.drawImage(source,0,0,w,h,-px*scale,-py*scale,w*scale,h*scale);else ctx.drawImage(image,sx,sy,w,h,-px*scale,-py*scale,w*scale,h*scale);}
  else{const cut=Math.floor(h*.82),hinge=(cut-py)*scale,shear=wave/(cut*scale);ctx.save();ctx.transform(1,0,shear,1,-shear*hinge,0);
   ctx.drawImage(source,variant.image?0:sx,variant.image?0:sy,w,cut,-px*scale,-py*scale,w*scale,cut*scale);ctx.restore();
   ctx.drawImage(source,variant.image?0:sx,(variant.image?0:sy)+cut,w,h-cut,-px*scale,(cut-py)*scale,w*scale,(h-cut)*scale);
  }ctx.restore();return{painted:true,seasonalReady:variant.ready,fallbackReason:variant.reason??null,wind:wave};
 }
 return{paintTree,prepared,clear(){cache.clear();},cacheSize:()=>cache.size};
}
// Optional Worker1 adapter: traceWater is its EXISTING exact visual path; no navigation shape is created.
function paintIce(ctx,{state,traceWater,bounds,openWater=[],visualScale=1}={}){
 if(!state?.valid||!state.freezeAmount||typeof traceWater!=='function'||!bounds||![bounds.x,bounds.y,bounds.w,bounds.h].every(Number.isFinite)||bounds.w<=0||bounds.h<=0)return false;
 const holes=Array.isArray(openWater)?openWater.slice(0,8).filter(p=>[p.x,p.y,p.rx,p.ry].every(Number.isFinite)&&p.rx>0&&p.ry>0):[];
 ctx.save();ctx.beginPath();traceWater(ctx);ctx.clip();for(const p of holes){ctx.beginPath();ctx.rect(bounds.x,bounds.y,bounds.w,bounds.h);ctx.moveTo(p.x+p.rx,p.y);ctx.ellipse(p.x,p.y,p.rx,p.ry,0,0,Math.PI*2);ctx.clip('evenodd');}
 ctx.globalAlpha=.65*state.freezeAmount;ctx.fillStyle='#9fbdb9';ctx.fillRect(bounds.x,bounds.y,bounds.w,bounds.h);ctx.globalAlpha=.55*state.freezeAmount;ctx.strokeStyle='#d2dfd1';ctx.lineWidth=Number.isFinite(visualScale)?clamp(visualScale,.25,4):1;
 for(let i=0;i<5;i++){const x=bounds.x+bounds.w*(.12+i*.17),y=bounds.y+bounds.h*(.25+(i%3)*.2);ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+bounds.w*.06,y+bounds.h*.09);ctx.lineTo(x+bounds.w*.13,y+bounds.h*.04);ctx.stroke();}ctx.restore();return true;
}

function seasonalPalette(state){const season=typeof state==='string'?state:state?.valid?state.season:null;if(!SEASONS.includes(season))return null;const palettes={spring:{leaf:'#7f9a62',deep:'#405e47',highlight:'#aec18b',grass:'#75915a'},summer:{leaf:'#698052',deep:'#354b3d',highlight:'#a1ae79',grass:'#698052'},autumn:{leaf:'#8f8853',deep:'#54583a',highlight:'#b09b68',grass:'#83815b'},winter:{leaf:'#819a8f',deep:'#435b56',highlight:'#a9bdb2',grass:'#94a997'}};return Object.freeze({...palettes[season],bark:'#806f50',snow:'#dce6d9',ice:'#9fbdb9'});}
function seasonalWaterTreatment(ctx,e,time,bounds,scale=1){if(!bounds)return false;const state=seasonFrame(e,time,{worldSeed:bounds.worldSeed??'world',reducedMotion:bounds.reducedMotion===true});return paintIce(ctx,{state,traceWater:bounds.traceWater,bounds,openWater:bounds.openWater,visualScale:scale});}

return Object.freeze({seasonFrame,seasonalPalette,pineWind,createPainter,paintIce,seasonalWaterTreatment});
})();
const seasonalPainter=seasonalWorld.createPainter();
const appearanceFor=(e,t)=>seasonalWorld.seasonFrame(e,t,{worldSeed:e.worldSeed||'world',reducedMotion:e.reducedMotion===true});
function seeded(seed=4708){return()=>{seed|=0;seed=seed+0x6D2B79F5|0;let n=Math.imul(seed^seed>>>15,1|seed);n=n+Math.imul(n^n>>>7,61|n)^n;return((n^n>>>14)>>>0)/4294967296;};}

function geometry(width=1600){const f=Math.min(width/1600,1.7);return{artScale:f,surface:300*f,peak:207*f,cx:width/2,half:380*f,mouth:{x:width/2,y:217*f,outside:false},shaft:{x:width/2,y:324*f,outside:false}};}
function surface(width,x){const g=geometry(width),d=(x-g.cx)/g.half,points=[[-1,300],[-.8,280],[-.6,257],[-.4,244],[-.17,217],[0,207],[.15,217],[.4,249],[.65,268],[1,300]];if(d<=-1||d>=1)return{y:g.surface,dy:0,hill:false};for(let i=1;i<points.length;i++){const p=points[i-1],q=points[i];if(d<=q[0])return{y:(p[1]+(d-p[0])/(q[0]-p[0])*(q[1]-p[1]))*g.artScale,dy:(q[1]-p[1])/((q[0]-p[0])*g.half)*g.artScale,hill:true};}return{y:g.surface,dy:0,hill:false};}
function layout(stations,{compact=false,width=1600,hasTree=()=>true,extraHeight=0,bottomPad=64,plaquePad=128,labelFit=1,labelFont=14}={}){
 const H=(compact?Math.max(1300,1000+stations.length*50):Math.max(1080,(1000+Math.max(0,stations.length-3)*22)*geometry(width).artScale))+extraHeight+Math.max(0,stations.length-20)*35,cols=compact?3:5,cell=width/cols,artScale=geometry(width).artScale,roomWidthScale=1,soilTop=geometry(width).shaft.y+10,bottomReserve=Math.max(64,bottomPad),minimumRoomGap=44,packGap=compact?8:minimumRoomGap,margin=compact?4:32,hash=s=>{let h=2166136261;for(const c of s)h=Math.imul(h^c.charCodeAt(0),16777619)>>>0;return h;},priority=s=>s.agent?.role==='director'?0:s.agent?.role==='support'?1:s.agent?.role==='world-requests'?2:3,ordered=[...stations].sort((a,b)=>priority(a)-priority(b)||((b.agent?.role==='cleanup'||b.agent?.role==='special-forces')?1:0)-((a.agent?.role==='cleanup'||a.agent?.role==='special-forces')?1:0)||(113-(hash(b.agent?.roleId||b.key)%24))-(113-(hash(a.agent?.roleId||a.key)%24))||hash(a.agent?.roleId||a.key)-hash(b.agent?.roleId||b.key));

 const labelReserve=(s,w)=>{const f=Math.max(.025,labelFit),chars=Math.max(1,Math.floor((w*f-6)/(labelFont*.65))),lines=Math.max(1,Math.ceil([...String(s.agent?.title||s.key)].length/chars));return Math.max(plaquePad,Math.ceil((lines*(labelFont+2)+8)/f));};
  const ref=[[800,395],[290,416],[1250,405],[530,552],[1120,815],[1060,542],[1340,657],[250,646],[785,670],[500,750],[1450,830],[340,888],[705,902],[1015,680],[90,816],[1485,530],[120,520],[1315,925],[800,535],[540,383]],others=ordered.filter(q=>!['director','support','world-requests','special-forces','cleanup','shaping'].includes(q.agent?.role||q.key));
 const shapes=ordered.map(s=>{const kind=s.agent?.role||s.key,seed=hash(s.agent?.roleId||s.key),rx=(kind==='director'?145:kind==='support'?121:kind==='world-requests'?129:kind==='special-forces'?115:kind==='cleanup'?116:90+seed%24)*artScale*roomWidthScale,ry=(kind==='director'?65:kind==='support'?54:kind==='world-requests'?58:['special-forces','cleanup'].includes(kind)?52:40+(seed>>>8)%10)*artScale,slot=kind==='director'?0:kind==='support'?1:kind==='world-requests'?2:kind==='special-forces'?3:kind==='cleanup'?4:kind==='shaping'?5:6+others.findIndex(q=>q.key===s.key)%14,a=ref[slot];return{key:s.key,w:compact?Math.max(320,rx*2*1.144):rx*2*1.144,h:ry*2*1.144+labelReserve(s,rx*2*1.144),ax:a[0]/1600*width,ay:geometry(width).surface+(a[1]-300)/700*(H-geometry(width).surface-bottomReserve)+labelReserve(s,rx*2*1.144)/2,core:priority(s)<3};});
 const clampPoint=p=>{p.x=Math.max(margin+p.w/2,Math.min(width-margin-p.w/2,p.x));p.y=Math.max(soilTop+p.h/2,Math.min(H-bottomReserve-p.h/2,p.y));};let relaxed=null;
 for(let pass=0;pass<12&&!relaxed;pass++){const rng=seeded(6741+pass*931),points=shapes.map(p=>{const q={...p,x:p.ax+(pass?(rng()-.5)*width*.12:0),y:p.ay+(pass?(rng()-.5)*100:0)};clampPoint(q);return q;});for(let round=0;round<900;round++){let overlaps=0;for(let i=0;i<points.length;i++)for(let j=i+1;j<points.length;j++){const a=points[i],b=points[j],dx=b.x-a.x,dy=b.y-a.y,px=(a.w+b.w)/2+packGap+1-Math.abs(dx),py=(a.h+b.h)/2+packGap+1-Math.abs(dy);if(px<=0||py<=0)continue;overlaps++;const total=(a.core?.35:1)+(b.core?.35:1),wa=(a.core?.35:1)/total,wb=1-wa;if(px<py){const push=(px+.05)*(dx<0?-1:1);a.x-=push*wa;b.x+=push*wb;}else{const push=(py+.05)*(dy<0?-1:1);a.y-=push*wa;b.y+=push*wb;}clampPoint(a);clampPoint(b);}if(!overlaps){relaxed=new Map(points.map(p=>[p.key,{x:p.x-p.w/2,y:p.y-p.h/2,w:p.w,h:p.h}]));break;}if(round<500&&round%4===0)for(const p of points){p.x+=(p.ax-p.x)*.012;p.y+=(p.ay-p.y)*.012;clampPoint(p);}}}
 for(let attempt=0;attempt<8;attempt++){const places=new Map(),occupied=[];let free=[{x:margin-packGap/2,y:soilTop-packGap/2,w:width-margin*2+packGap,h:H-soilTop-bottomReserve+packGap}];let failed=false;function reserve(room){const n={x:room.x-packGap/2,y:room.y-packGap/2,w:room.w+packGap,h:room.h+packGap},next=[];for(const r of free){if(n.x>=r.x+r.w||n.x+n.w<=r.x||n.y>=r.y+r.h||n.y+n.h<=r.y){next.push(r);continue;}if(n.x>r.x)next.push({x:r.x,y:r.y,w:n.x-r.x,h:r.h});if(n.x+n.w<r.x+r.w)next.push({x:n.x+n.w,y:r.y,w:r.x+r.w-n.x-n.w,h:r.h});if(n.y>r.y)next.push({x:r.x,y:r.y,w:r.w,h:n.y-r.y});if(n.y+n.h<r.y+r.h)next.push({x:r.x,y:n.y+n.h,w:r.w,h:r.y+r.h-n.y-n.h});}free=next.filter((r,i)=>r.w>0&&r.h>0&&!next.some((q,j)=>j!==i&&q.x<=r.x&&q.y<=r.y&&q.x+q.w>=r.x+r.w&&q.y+q.h>=r.y+r.h&&(q.w>r.w||q.h>r.h||j<i)));}
 for(const s of ordered){const kind=s.agent?.role||s.key,seed=hash(s.agent?.roleId||s.key),rx=(kind==='director'?145:kind==='support'?121:kind==='world-requests'?129:kind==='special-forces'?115:kind==='cleanup'?116:90+seed%24)*artScale*roomWidthScale,ry=(kind==='director'?65:kind==='support'?54:kind==='world-requests'?58:['special-forces','cleanup'].includes(kind)?52:40+(seed>>>8)%10)*artScale,floorW=rx*2*1.144,floorH=ry*2*1.144,w=compact?Math.max(320,floorW):floorW,h=floorH+labelReserve(s,floorW),rng=seeded(seed+attempt*4877),fits=r=>occupied.every(q=>r.x>=q.x+q.w+packGap||r.x+r.w+packGap<=q.x||r.y>=q.y+q.h+packGap||r.y+r.h+packGap<=q.y),minimumY=soilTop+h/2,maximumY=H-h/2-bottomReserve;let room=attempt===0?relaxed?.get(s.key)||null:null,best=-Infinity;
 const anchors=[[800,395],[290,416],[1250,405],[530,552],[1120,815],[1060,542],[1340,657],[250,646],[785,670],[500,750],[1450,830],[340,888],[705,902],[1015,680],[90,816],[1485,530],[120,520],[1315,925],[800,535],[540,383]],slot=kind==='director'?0:kind==='support'?1:kind==='world-requests'?2:kind==='special-forces'?3:kind==='cleanup'?4:kind==='shaping'?5:6+ordered.filter(q=>!['director','support','world-requests','special-forces','cleanup','shaping'].includes(q.agent?.role||q.key)).findIndex(q=>q.key===s.key)%14,anchor=anchors[slot],desired={x:anchor[0]/1600*width,y:geometry(width).surface+(anchor[1]-300)/700*(H-geometry(width).surface-bottomReserve)+labelReserve(s,floorW)/2};if(!room&&desired&&(attempt<5||priority(s)<3)){const r={x:Math.max(margin,Math.min(width-w-margin,desired.x-w/2)),y:Math.min(maximumY,Math.max(minimumY,desired.y))-h/2,w,h};if(fits(r))room=r;}
 const preferredPlaced=!!room;for(let n=0;!preferredPlaced&&n<6000;n++){const choices=free.filter(q=>q.w>=w+packGap&&q.h>=h+packGap);if(!choices.length)break;const f=choices[Math.floor(rng()*choices.length)],r={x:attempt<5?Math.max(f.x+packGap/2,Math.min(f.x+f.w-w-packGap/2,desired.x-w/2+(rng()-.5)*14*artScale)):f.x+packGap/2+rng()*Math.min(24*artScale,f.w-w-packGap),y:attempt<5?Math.max(f.y+packGap/2,Math.min(f.y+f.h-h-packGap/2,desired.y-h/2+(rng()-.5)*12)):f.y+packGap/2+rng()*Math.min(22,f.h-h-packGap),w,h};if(!fits(r))continue;const score=attempt<5?-Math.hypot((r.x+w/2-desired.x)/artScale,r.y+h/2-desired.y):-(f.w*f.h-(w+packGap)*(h+packGap));if(score>best){best=score;room=r;}}
 if(!room){failed=true;break;}occupied.push(room);reserve(room);const packingRoom=room,jitter=compact?((seed%101)/100-.5)*Math.max(0,w-floorW-44):0;room={x:Math.max(32,Math.min(width-floorW-32,packingRoom.x+(w-floorW)/2+jitter)),y:packingRoom.y,w:floorW,h:floorH};const cx=room.x+floorW/2,cy=room.y+floorH/2,treeX=cx+rx*.42,treeY=cy+5,tree=hasTree(s)?{x:treeX-10*artScale,y:treeY-23*artScale,w:20*artScale,h:28*artScale}:null,patchRandom=seeded(seed+4708),patch={x:cx,y:cy,rx,ry,patch:Array.from({length:18},()=>.84+patchRandom()*.2),seed};
 places.set(s.key,{x:treeX,y:treeY,bed:{x:cx-rx*.45,y:cy+5},label:{x:room.x,y:room.y+room.h+3/Math.max(.025,labelFit),w:room.w,h:h-floorH-6/Math.max(.025,labelFit)},room,patch,entry:{x:cx+8,y:room.y+room.h+18},desk:{x:cx+35*artScale,y:cy},tree,treeScale:.25*artScale,space:{x:packingRoom.x,y:packingRoom.y,w,h}});
 }
 if(failed)continue;const bank={x:width/2,y:geometry(width).shaft.y+8};bank.label={x:bank.x-25,y:bank.y+13,w:50,h:14};return{width,places,cols,cell,minimumRoomGap,plaqueMaxWidth:Math.min(320,cell-16),labelFont:12,labelTarget:compact?9:10,rows:0,wide:true,compact,natural:true,anthill:true,referenceArt:true,roomScale:1,entrance:geometry(width).mouth,hill:geometry(width),tunnelBranches:[],antScale:.85,treeScale:.25,bodyRadius:29,walkBottom:H-12,sandTop:H-10,sandBottom:H,sandHeight:0,bank,center:{x:width*.5,y:geometry(width).surface+(H-geometry(width).surface)*.5},H};
 }if(extraHeight<640)return layout(stations,{compact,width,hasTree,extraHeight:extraHeight+40,bottomPad,plaquePad,labelFit,labelFont});throw Error('Natural world layout could not preserve separated room edges');
}



function fitLayout(stations,{width,height,compact=width<480,natural=false,hasTree=()=>true}={}){const inner=Math.max(224,width-16),minimum=compact?1000:1600,labelFont=width<480?12:14;let estimate=compact?Math.max(1300,1000+stations.length*50):1700+Math.max(0,stations.length-20)*35,sceneWidth=natural?Math.max(minimum,Math.round(inner)):Math.max(minimum,Math.ceil(inner*estimate/Math.max(100,height))),chosen;for(let pass=0;pass<8;pass++){const labelFit=Math.min(1,inner/sceneWidth,(natural?1:Math.max(100,height)/estimate));chosen=layout(stations,{width:sceneWidth,compact,hasTree,bottomPad:Math.ceil(48/labelFit),plaquePad:Math.ceil(32/labelFit),labelFit,labelFont});const scale=Math.min(1,inner/chosen.width,(natural?1:Math.max(100,height)/chosen.H));if(scale+1e-8<labelFit){estimate=chosen.H;if(!natural)sceneWidth=Math.max(minimum,Math.ceil(inner*chosen.H/Math.max(100,height)));continue;}if(natural||chosen.width*scale/inner>=.995)return chosen;estimate=chosen.H;sceneWidth=Math.max(minimum,Math.ceil(inner*chosen.H/Math.max(100,height)));}return chosen;}

let referenceBundle=null,injectedReference=null;
const referenceAtlasSpec={trees:{file:'sprint-tree-states.png',ids:['seed','sprout','sapling','young','mature','complete']},pines:{file:'woodland-pines.png',ids:['near-tall','near-small']},scenery:{file:'woodland-scenery.png',ids:['forest-far','forest-near','house-a','house-b','house-c','shore-a','shore-b','shore-c']},props:{file:'house-people-pine-style-v2.png',ids:["house-a","house-b","house-c","person-moss-stand","person-moss-step-a","person-moss-step-b","person-oat-stand","person-oat-step-a","person-oat-step-b"]}};
const referenceClosed=(value,keys)=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.prototype.hasOwnProperty.call(value,key));
function referenceFrames(manifest){
 if(manifest?.schemaVersion!==1||!referenceClosed(manifest.atlases,Object.keys(referenceAtlasSpec)))throw Error('Invalid reference atlas manifest');
 const result={};
 for(const[key,spec]of Object.entries(referenceAtlasSpec)){
  const atlas=manifest.atlases[key];
  if(!atlas||atlas.file!==spec.file||atlas.width!==1536||atlas.height!==1024||!Array.isArray(atlas.frames)||atlas.frames.length!==spec.ids.length)throw Error('Invalid reference atlas definition');
  const seen=new Set(),frames=atlas.frames.map(frame=>{
   if(!referenceClosed(frame,['id','rect','pivot'])||!spec.ids.includes(frame.id)||seen.has(frame.id)||!Array.isArray(frame.rect)||frame.rect.length!==4||!Array.isArray(frame.pivot)||frame.pivot.length!==2||!frame.rect.every(Number.isSafeInteger)||!frame.pivot.every(Number.isSafeInteger))throw Error('Invalid reference frame');
   const[x,y,w,h]=frame.rect,[px,py]=frame.pivot;
   if(x<0||y<0||w<=0||h<=0||x+w>atlas.width||y+h>atlas.height||px<0||py<0||px>w||py>h)throw Error('Reference frame outside atlas');
   seen.add(frame.id);return Object.freeze({id:frame.id,rect:Object.freeze([...frame.rect]),pivot:Object.freeze([...frame.pivot])});
  });
  result[key]=Object.freeze({file:spec.file,width:atlas.width,height:atlas.height,frames:Object.freeze(frames)});
 }
 return Object.freeze(result);
}
function referenceImageReady(image){
 const element=typeof Image!=='undefined'&&image instanceof Image;
 const bitmap=typeof ImageBitmap!=='undefined'&&image instanceof ImageBitmap;
 return element?image.complete===true&&image.naturalWidth===1536&&image.naturalHeight===1024:bitmap&&image.width===1536&&image.height===1024;
}
// Host verifies pinned bytes/world binding and loads the exact font first.
// Configure before create/mount; retain decoded images for the renderer lifetime.
function provideReferenceAssets(input){
 if(referenceBundle)throw Error('Provide reference assets before creating the world painter');
 try{
  if(!referenceClosed(input,['manifest','images','fontReady'])||input.fontReady!==true||!referenceClosed(input.images,Object.keys(referenceAtlasSpec)))throw Error('Reference images and loaded font required');
  const frames=referenceFrames(input.manifest),images={};
  for(const key of Object.keys(referenceAtlasSpec)){if(!referenceImageReady(input.images[key]))throw Error('Decoded reference atlas image required');images[key]=input.images[key];}
  injectedReference={state:'ready',source:'injected',images:Object.freeze(images),frames,fontReady:true,error:null};
 }catch(error){injectedReference={state:'fallback',source:'injected',images:{},frames:null,fontReady:false,error:String(error.message)};}
 return{state:injectedReference.state,source:'injected',fontReady:injectedReference.fontReady,error:injectedReference.error};
}
function referenceAssets(){
 if(referenceBundle)return referenceBundle;
 if(injectedReference){referenceBundle={...injectedReference,ready:Promise.resolve(injectedReference.state==='ready')};return referenceBundle;}
 const bundle={state:'loading',source:'same-origin',images:{},frames:null,fontReady:null,error:null,ready:null};referenceBundle=bundle;
 bundle.ready=(async()=>{try{
  if(typeof document==='undefined'||typeof Image==='undefined')throw Error('Browser art loader unavailable');
  const link=[...document.querySelectorAll('link[rel="stylesheet"]')].find(n=>new URL(n.href,document.baseURI).pathname.endsWith('/agent-outpost/agent-outpost.css'));
  if(!link)throw Error('Shared world stylesheet base unavailable');
  const base=new URL('./assets/midnight-colony-reference-20261107/',link.href);
  if(base.origin!==location.origin)throw Error('World art must be same-origin');
  const response=await fetch(new URL('sprites.json',base));if(!response.ok)throw Error('World sprite manifest unavailable');
  const raw=await response.text();if(raw.length>32768)throw Error('World sprite manifest too large');
  const frames=referenceFrames(JSON.parse(raw)),images={};
  await Promise.all(Object.entries(referenceAtlasSpec).map(async([key,spec])=>{
   const image=new Image();image.decoding='async';
   await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(Error('World image unavailable'));image.src=new URL(spec.file,base).href;});
   if(image.naturalWidth!==1536||image.naturalHeight!==1024)throw Error('World atlas dimensions changed');
   await image.decode?.();images[key]=image;
  }));
  bundle.images=Object.freeze(images);bundle.frames=frames;bundle.state='ready';return true;
 }catch(error){bundle.images={};bundle.frames=null;bundle.state='fallback';bundle.error=String(error.message);return false;}})();
 return bundle;
}

function treeState(percent){if(typeof percent!=='number'||!Number.isFinite(percent)||percent<0||percent>100)return{id:null,height:12};const index=percent===0?0:percent<25?1:percent<50?2:percent<75?3:percent<100?4:5;return{id:['seed','sprout','sapling','young','mature','complete'][index],height:[66,121,258,339,378,430][index]};}

// Finite, source-independent worker art composed under the shared painter.
const woodlandAmbient=(function ambientFactory() {
  // The retained two-pixel box snap paints the old road/curb through edge214.
  const ROAD = Object.freeze({ top:201, bottom:214, sidewalkTop:214, sidewalkBottom:220, peopleY:218, carY:203 });
  const BUDGET = Object.freeze({ people:7, cars:4, clouds:9, flies:5, butterflies:3, beetles:2, birds:4 });
  const mod = (x,n) => ((x % n) + n) % n;
  const clamp = (x,a,b) => Math.max(a,Math.min(b,x));
  const mix = (a,b,t) => a+(b-a)*t;
  function hash(seed,feature,slot=0) {
    let h=2166136261;
    for(const c of ['ambient-v1',seed,feature,slot].join('|')) h=Math.imul(h^c.charCodeAt(0),16777619);
    return h>>>0;
  }
  function random(seed,feature,slot=0) {
    let s=hash(seed,feature,slot);
    return () => { s=s+0x6D2B79F5|0;let n=Math.imul(s^s>>>15,1|s);n=n+Math.imul(n^n>>>7,61|n)^n;return((n^n>>>14)>>>0)/4294967296; };
  }
  const cache=new Map();
  function config(seed='unavailable') {
    const key=String(seed); if(cache.has(key))return cache.get(key);
    const clouds=Array.from({length:BUDGET.clouds},(_,i)=>{
      const r=random(key,'cloud',i);return {shape:Math.floor(r()*3),x:i*2080/BUDGET.clouds+(r()-.5)*170,y:7+r()*76,scale:.62+r()*.95,speed:.85+r()*2.45,parallax:2+r()*7};
    });
    const fauna=Array.from({length:10},(_,i)=>{
      const r=random(key,'fauna',i),kind=i<5?'fly':i<8?'butterfly':'beetle';
      return {id:i<5?'exterior-fly-'+i:'ambient-'+kind+'-'+(i<8?i-5:i-8),kind,slot:i,offset:r()*66,period:44+r()*22,target:.29+r()*.42,lift:kind==='beetle'?0:14+r()*22,side:r()<.5?-1:1,phase:r()*Math.PI*2};
    });
    const birds=Array.from({length:BUDGET.birds},(_,i)=>{const r=random(key,'bird',i);return{id:'ambient-bird-'+i,period:28+r()*24,offset:r()*50,height:.11+r()*.25,direction:r()<.5?-1:1,phase:r()*Math.PI*2};});
    const result={clouds,fauna,birds};cache.set(key,result);if(cache.size>8)cache.delete(cache.keys().next().value);return result;
  }
  function cloudInstances(seed){return config(seed).clouds;}
  function roadActors({seed='unavailable',visualSeconds=0}={}) {
    if(!Number.isFinite(visualSeconds))throw Error('Finite guarded visual time required');
    const people=Array.from({length:BUDGET.people},(_,i)=>{
      const r=random(seed,'person',i),direction=i%2?1:-1,speed=4.2+r()*3,offset=r()*1660;
      return {id:i,x:mod(offset+visualSeconds*speed*direction,1660)-30,y:ROAD.peopleY,direction,speed,pose:Math.floor(visualSeconds*speed/5+i)%2?'step-a':'step-b',palette:i%2?'moss':'oat'};
    });
    const cars=Array.from({length:BUDGET.cars},(_,i)=>{const r=random(seed,'car',i),direction=i%2?-1:1,speed=13+r()*5;return{id:i,x:mod(r()*1660+visualSeconds*speed*direction,1660)-30,y:ROAD.carY,direction};});
    return {people,cars,road:ROAD};
  }
  // Worker2 may supply these density weights from its existing season state.
  // There is no independent seasonal clock, duplicate wildlife or weather state.
  function weights(season,profile) {
    const defaults=season==='winter'?{fly:.45,butterfly:0,beetle:.45,bird:.7}:season==='autumn'?{fly:.8,butterfly:.5,beetle:1,bird:.85}:{fly:1,butterfly:1,beetle:1,bird:1};
    return Object.fromEntries(Object.entries(defaults).map(([k,v])=>[k,Number.isFinite(profile?.[k])?clamp(profile[k],0,1):v]));
  }
  function frame({seed='unavailable',visualSeconds=0,width=1600,surfaceY=170,artScale=1,groundAt=null,season='summer',weather='clear',day=true,faunaActivity=null}={}) {
    if(![visualSeconds,width,surfaceY,artScale].every(Number.isFinite)||width<=0||artScale<=0)throw Error('Finite ambient geometry/time required');
    const t=Math.max(0,visualSeconds),c=config(seed),w=weights(season,faunaActivity),visitors=[];
    if(!day){w.butterfly=0;w.bird*=.25;}
    if(weather==='rain'||weather==='snow'){w.butterfly=0;w.fly*=.55;w.bird*=.6;}
    for(const f of c.fauna){
      if(hash(seed,'density',f.slot)/4294967296>=w[f.kind])continue;
      const total=t+f.offset,episode=Math.floor(total/f.period),u=mod(total,f.period)/f.period;
      if(u<.18)continue;
      const target=f.target*width,off=f.side<0?-25*artScale:width+25*artScale;
      const sample=typeof groundAt==='function'?groundAt(target):surfaceY;
      const ground=Number.isFinite(sample)?sample:surfaceY;
      let x=target,y=ground,phase='idle';
      if(u<.38){const q=(u-.18)/.20;phase='arriving';x=mix(off,target,q);y=ground-(f.kind==='beetle'?0:(1-q)*50+f.lift)*artScale;}
      else if(u<.59){phase='visiting';x=target+Math.sin(t*1.1+f.phase)*10*artScale;y=ground-(f.kind==='beetle'?0:f.lift+Math.sin(t*1.7+f.phase)*5)*artScale;}
      else if(u<.79){phase='idle';x=target;y=ground;}
      else{const q=(u-.79)/.21;phase='departing';x=mix(target,f.side<0?width+25*artScale:-25*artScale,q);y=ground-(f.kind==='beetle'?0:q*65)*artScale;}
      const sampled=typeof groundAt==='function'?groundAt(clamp(x,0,width)):surfaceY;
      const actual=Number.isFinite(sampled)?sampled:surfaceY;
      if(f.kind==='beetle')y=actual;
      else y=Math.min(y,actual-(phase==='idle'?0:3*artScale));
      visitors.push({id:f.id,kind:f.kind,episode,phase,x,y,wing:Math.sin(t*7+f.phase),requiredHits:1+hash(seed,'fly-hits',f.slot+episode*17)%5});
    }
    const birds=[];
    for(let i=0;i<c.birds.length;i++){
      const b=c.birds[i];if(hash(seed,'bird-density',i)/4294967296>=w.bird)continue;
      const u=mod(t+b.offset,b.period)/b.period;if(u>.76)continue;
      const q=u/.76;birds.push({id:b.id,x:b.direction>0?mix(-20*artScale,width+20*artScale,q):mix(width+20*artScale,-20*artScale,q),y:Math.max(10*artScale,surfaceY*b.height)+Math.sin(q*Math.PI)*5*artScale,wing:Math.sin(t*5+b.phase),direction:b.direction});
    }
    return {cosmetic:true,visualSeconds:t,visitors,birds,budget:BUDGET};
  }
  function paint(ctx,state,{artScale=1,layer='fauna',omitFlies=false}={}) {
    const pixel=(x,y,w,h,color)=>{ctx.fillStyle=color;ctx.fillRect(Math.round(x),Math.round(y),Math.max(1,w*artScale),Math.max(1,h*artScale));};
    ctx.save();try{
      ctx.imageSmoothingEnabled=false;
      if(layer==='birds')for(const b of state.birds){const s=b.wing>0?-1:1;pixel(b.x,b.y,3,1,'#344b45');pixel(b.x-3*artScale,b.y+s*artScale,3,1,'#647d6c');pixel(b.x+3*artScale,b.y+s*artScale,3,1,'#647d6c');pixel(b.x-5*artScale,b.y+2*s*artScale,2,1,'#344b45');pixel(b.x+6*artScale,b.y+2*s*artScale,2,1,'#344b45');}
      else for(const f of state.visitors){
        if(omitFlies&&f.kind==='fly')continue;
        const idle=f.phase==='idle';
        if(f.kind==='fly'){const k=idle?0:f.wing*artScale;pixel(f.x-3*artScale,f.y-5*artScale+k,3,1,'#9aaf9a');pixel(f.x+artScale,f.y-5*artScale-k,3,1,'#7d9687');pixel(f.x-artScale,f.y-4*artScale,2,4,'#344b3b');}
        else if(f.kind==='butterfly'){const k=idle?1:1+Math.abs(f.wing)*2;pixel(f.x-(k+1)*artScale,f.y-5*artScale,k,3,'#b4aa70');pixel(f.x+artScale,f.y-5*artScale,k,3,'#83956b');pixel(f.x-artScale,f.y-5*artScale,2,5,'#344b3b');}
        else{pixel(f.x-2*artScale,f.y-3*artScale,4,2,'#637a50');pixel(f.x-3*artScale,f.y-artScale,2,1,'#344b3b');pixel(f.x+2*artScale,f.y-artScale,2,1,'#344b3b');pixel(f.x-artScale,f.y-4*artScale,2,1,'#344b3b');}
      }
    }finally{ctx.restore();}
  }
  return {ROAD,BUDGET,hash,cloudInstances,roadActors,weights,frame,paint};
})();
const woodlandSky=(()=>{/** Source-independent draft for World 1.2.5. No timers, IO, randomness or state. */
const EXTERIOR = Object.freeze({ width: 1600, height: 310, clipBottom: 188, pixel: 2 });

// Each lobe belongs to the same connected cloud. The ellipses are sampled onto
// a two-unit pixel grid; no smooth/blurred path or rectangular strip is drawn.
const CLOUD_VARIATIONS = Object.freeze([
  { id: 'quiet-veil', width: 180, height: 42, lobes: [[24,26,24,9],[51,22,30,15],[85,18,31,16],[117,23,29,13],[148,28,29,8]], detail: 0 },
  { id: 'rounded-cluster', width: 132, height: 58, lobes: [[22,39,21,12],[43,28,26,19],[68,23,27,22],[92,32,25,17],[111,42,19,9]], detail: 1 },
  { id: 'wind-comb', width: 212, height: 42, lobes: [[20,29,20,5],[51,25,29,10],[84,21,34,15],[122,22,31,13],[155,27,28,9],[186,31,25,5]], detail: 2 }
]);

const MOUNTAIN_TIERS = Object.freeze([{"id":"haze-ranges","baseline":186,"parallax":0.5,"roughness":1.2,"seed":17,"ridge":[[-24,145],[88,118],[146,126],[216,108],[290,122],[376,114],[456,134],[540,126],[614,146],[720,150],[796,158],[876,148],[952,136],[1036,110],[1104,114],[1174,94],[1250,104],[1320,120],[1402,96],[1506,114],[1624,100]],"night":["#566673","#4b5c68","#667681","#7d8991"],"day":["#a7adb0","#959fa6","#bac0bf","#cbd0c9"],"dusk":["#aaa0a5","#918b99","#b8adb3","#cec1bd"],"summits":[]},{"id":"distant-crags","baseline":188,"parallax":1.2,"roughness":2.3,"seed":31,"ridge":[[-24,142],[52,134],[108,112],[148,104],[174,88],[186,78],[202,76],[214,68],[234,72],[246,84],[258,108],[282,122],[324,130],[368,114],[390,102],[424,102],[454,112],[500,140],[570,156],[642,162],[720,170],[792,166],[862,150],[918,142],[958,116],[994,104],[1012,80],[1036,68],[1048,48],[1064,40],[1080,36],[1094,28],[1110,30],[1128,42],[1140,68],[1160,82],[1186,112],[1210,126],[1246,132],[1270,122],[1298,108],[1320,84],[1340,74],[1358,72],[1382,84],[1400,104],[1430,118],[1480,136],[1544,128],[1624,102]],"night":["#3d4f60","#2f4052","#5b6974","#7e8790"],"day":["#8c9397","#707b83","#a7aaa8","#c8c7bd"],"dusk":["#817b83","#625f70","#a18f97","#beb0ad"],"summits":[{"x":214,"y":69,"left":98,"right":134,"lean":22,"seed":3},{"x":1094,"y":30,"left":210,"right":186,"lean":38,"seed":5},{"x":1358,"y":74,"left":104,"right":140,"lean":18,"seed":9}]},{"id":"folded-middle-ranges","baseline":188,"parallax":2.2,"roughness":2,"seed":59,"ridge":[[-24,150],[34,140],[86,122],[134,128],[178,144],[220,136],[252,118],[284,116],[306,106],[330,110],[356,130],[404,146],[450,140],[478,132],[510,146],[552,158],[598,150],[646,166],[710,172],[770,174],[830,170],[890,164],[944,150],[984,138],[1016,142],[1048,128],[1084,110],[1114,114],[1146,130],[1188,140],[1228,130],[1262,108],[1292,102],[1314,94],[1340,106],[1360,126],[1410,142],[1458,136],[1504,118],[1544,122],[1624,140]],"night":["#3a444a","#2b343d","#586168","#778088"],"day":["#7c7a72","#615f5a","#969185","#b2ac9d"],"dusk":["#746c70","#534e5c","#94838a","#b2a09e"],"summits":[{"x":86,"y":123,"left":94,"right":96,"lean":20,"seed":17},{"x":306,"y":108,"left":110,"right":124,"lean":-12,"seed":22},{"x":1084,"y":112,"left":96,"right":140,"lean":18,"seed":33},{"x":1314,"y":96,"left":104,"right":142,"lean":14,"seed":41}]},{"id":"near-foothills","baseline":188,"parallax":3.5,"roughness":1.5,"seed":83,"ridge":[[-24,164],[54,156],[112,162],[166,150],[218,158],[276,150],[328,156],[380,168],[436,158],[488,166],[544,174],[600,170],[656,182],[728,184],[802,184],[864,180],[918,170],[972,174],[1032,158],[1088,150],[1146,160],[1206,152],[1258,140],[1314,150],[1372,146],[1432,158],[1488,150],[1548,156],[1624,146]],"night":["#333b3c","#282d31","#4a5251","#646d65"],"day":["#706f60","#53584c","#8a846f","#a9a18b"],"dusk":["#62585c","#48434e","#817074","#a58c87"],"summits":[]}]);

const INSTANCES = Object.freeze([
  { shape: 0, x: 108, y: 16, scale: .80, speed: .44, parallax: 1.0 },
  { shape: 2, x: 486, y: 8, scale: 1.02, speed: .68, parallax: 2.0 },
  { shape: 1, x: 954, y: 24, scale: .88, speed: .92, parallax: 3.0 },
  { shape: 0, x: 1390, y: 8, scale: 1.14, speed: .56, parallax: 2.0 }
]);
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const mod = (n, d) => ((n % d) + d) % d;
const snap = n => Math.round(n / 2) * 2;
const rgb = h => [1,3,5].map(i => Number.parseInt(h.slice(i, i + 2), 16));
function mix(a, b, t) {
  const x = rgb(a), y = rgb(b);
  return '#' + x.map((v, i) => Math.round(v + (y[i] - v) * t).toString(16).padStart(2, '0')).join('');
}
function colorsFor(tier,daylight,season){const twilight=Math.max(0,1-Math.abs(daylight-.38)/.25)*.72,colors=tier.night.map((c,i)=>mix(mix(c,tier.day[i],daylight),tier.dusk[i],twilight)),tint=season==='autumn'?'#887e64':season==='winter'?'#9eb6b1':'#859887',amount=season==='autumn'?.04:season==='winter'?.06:.012;return colors.map(c=>mix(c,tint,amount));}
function ridgeAt(points, x) {
  let i = 0;
  while (i < points.length - 2 && x > points[i + 1][0]) i++;
  const a = points[i], b = points[i + 1];
  const t = clamp((x - a[0]) / (b[0] - a[0]), 0, 1);
  return { y: a[1] + (b[1] - a[1]) * t, rising: b[1] < a[1], t, segment: i };
}
function add(out, layer, x, y, w, h, fill, opacity = 1) {
  const left = clamp(snap(x), 0, EXTERIOR.width), right = clamp(snap(x + w), 0, EXTERIOR.width);
  const top = clamp(snap(y), 0, EXTERIOR.clipBottom), bottom = clamp(snap(y + h), 0, EXTERIOR.clipBottom);
  if(right>left&&bottom>top){const emit=(x,w,a)=>out.push({layer,x,y:top,width:w,height:bottom-top,fill,opacity:a});if(layer!=='clouds'&&opacity<1&&!(left===0&&right===1600)){for(let x=left;x<right;){const next=x<160?Math.min(right,x+4,160):x<1440?Math.min(right,1440):Math.min(right,x+4),u=Math.min(1,(x+next)/2/160,(1600-(x+next)/2)/160),fade=u*u*(3-2*u);emit(x,next-x,opacity*fade);x=next;}}else emit(left,right-left,opacity);}
}

function hash(n){let x=(n|0)^0x6d2b79f5;x=Math.imul(x^(x>>>15),x|1);x^=x+Math.imul(x^(x>>>7),x|61);return((x^(x>>>14))>>>0)/4294967295;}
function noiseAt(x,p,s){const i=Math.floor(x/p),t=(x-i*p)/p,u=t*t*(3-2*t);return(hash(i+s)*2-1)*(1-u)+(hash(i+s+1)*2-1)*u;}
function topAt(t,x){const phase=mod(x,1600),edge=160,sample=q=>ridgeAt(t.ridge,q).y+noiseAt(q,22,t.seed)*t.roughness+noiseAt(q,7,t.seed+119)*t.roughness*.55,join=(sample(0)+sample(1600))/2,u=Math.min(1,phase/edge,(1600-phase)/edge),blend=u*u*(3-2*u);return snap(join+(sample(phase)-join)*blend);}
function mountainPolygon(out,tier,points,fill,opacity,offset){
 const first=Math.max(0,snap(Math.min(...points.map(p=>p[1])))),last=Math.min(tier.baseline,snap(Math.max(...points.map(p=>p[1]))));
 for(let y=first;y<last;y+=2){const hits=[];for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length];if((a[1]<=y+1&&b[1]>y+1)||(b[1]<=y+1&&a[1]>y+1))hits.push(a[0]+(y+1-a[1])*(b[0]-a[0])/(b[1]-a[1]));}hits.sort((a,b)=>a-b);for(let i=0;i+1<hits.length;i+=2){let run=null;const left=Math.max(0,snap(hits[i])),right=Math.min(1600,snap(hits[i+1]));for(let x=left;x<right;x+=2){const inside=y>=topAt(tier,x-offset);if(inside&&run===null)run=x;if(!inside&&run!==null){add(out,tier.id,run,y,x-run,2,fill,opacity);run=null;}}if(run!==null)add(out,tier.id,run,y,right-run,2,fill,opacity);}}
}
function pixelRunnel(out,tier,points,fill,opacity,offset){
 for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1],n=Math.ceil(Math.max(Math.abs(b[0]-a[0]),Math.abs(b[1]-a[1]))/2);for(let j=0;j<=n;j++){const t=j/Math.max(1,n),x=snap(a[0]+(b[0]-a[0])*t),y=snap(a[1]+(b[1]-a[1])*t);if(y>=topAt(tier,x-offset)&&y<tier.baseline)add(out,tier.id,x,y,2,2,fill,opacity);}}
}
function mountainsUncached(out,tier,daylight,season,pointer){
 const c=colorsFor(tier,daylight,season),offset=snap(pointer*tier.parallax);
 for(let x=0;x<1600;x+=2){const y=topAt(tier,x-offset);add(out,tier.id,x,y,2,tier.baseline-y,c[0]);}
 for(const p of tier.summits){
  const x=p.x+offset,y=p.y,h=tier.baseline-y,L=p.left,R=p.right,lean=p.lean,P=(u,v)=>[x+u,y+h*v],s=p.seed;
  mountainPolygon(out,tier,[P(-8,0),P(-L*.14,.17),P(-L*.10,.31),P(-L*.36,.45),P(-L*.31,.58),P(-L*.72,.84),P(-L,1),P(lean*.20,1),P(lean*.14,.45),P(4,.15)],c[1],.67,offset);
  mountainPolygon(out,tier,[P(4,.03),P(18,.14),P(14,.25),P(lean+16,.42),P(lean+8,.56),P(R*.42,.76),P(R*.72,1),P(R*.30,1),P(lean-4,.62),P(8,.34)],c[2],.64,offset);
  mountainPolygon(out,tier,[P(2,.05),P(8,.11),P(6,.19),P(16,.26),P(12,.32),P(28,.46),P(22,.51),P(6,.37),P(-4,.15)],c[3],.48,offset);
  mountainPolygon(out,tier,[P(-L*.28,.34),P(-L*.19,.31),P(-L*.12,.44),P(-L*.20,.50),P(-L*.17,.60),P(-L*.34,.76),P(-L*.51,.90),P(-L*.38,.65)],c[2],.32,offset);
  mountainPolygon(out,tier,[P(R*.20,.49),P(R*.29,.46),P(R*.40,.62),P(R*.35,.72),P(R*.62,.94),P(R*.43,.84)],c[3],.22,offset);
  for(let k=0;k<4;k++){const f=.23+k*.14,j=(hash(s+k*17)-.5)*10;pixelRunnel(out,tier,[P(-L*(.06+k*.075),f),P(-L*(.10+k*.085)+j,f+.08),P(-L*(.16+k*.10)+j,f+.14),P(-L*(.24+k*.12),Math.min(.98,f+.27))],c[1],.43,offset);}
  for(let k=0;k<26;k++){const v=.34+hash(s+k*9)*.58,u=(hash(s+k*13+71)-.45)*(L+R)*.35,xx=x+u+v*lean,yy=y+h*v;if(yy>=topAt(tier,xx-offset)+6){add(out,tier.id,xx,yy,2+(k%3)*2,2,k%4?c[2]:c[3],k%4?.24:.35);if(k%3===0)add(out,tier.id,xx+2,yy+2,2,4,c[1],.30);}}
 }
 if(tier.id!=='near-foothills'){const band=[];for(let x=-8;x<=1608;x+=48)band.push([x,164+noiseAt(x,150,tier.seed+211)*5]);band.push([1608,188],[-8,188]);mountainPolygon(out,tier,band,c[3],tier.id==='haze-ranges'?.08:.045,offset);}
}
const mountainCache=new Map();
function mountains(out,tier,daylight,season,pointer){const key=tier.id+'|'+colorsFor(tier,daylight,season).join(',')+'|'+snap(pointer*tier.parallax);let cells=mountainCache.get(key);if(!cells){cells=[];mountainsUncached(cells,tier,daylight,season,pointer);mountainCache.set(key,cells);if(mountainCache.size>16)mountainCache.delete(mountainCache.keys().next().value);}out.push(...cells);}
function inCloud(shape, x, y) {
  return shape.lobes.some(([cx,cy,rx,ry]) => ((x-cx)/rx)**2 + ((y-cy)/ry)**2 <= 1);
}
function cloudCells(shape) {
  const cells = [];
  for (let y = 0; y < shape.height; y += 2) {
    let run = null;
    for (let x = 0; x <= shape.width; x += 2) {
      const inside = x < shape.width && inCloud(shape, x+1, y+1);
      const lowerEdge = inside && !inCloud(shape, x+1, y+7);
      const upperEdge = inside && !inCloud(shape, x+1, y-3);
      const depth = inside ? lowerEdge ? 0 : upperEdge ? 2 : 1 : -1;
      if (run && run.depth !== depth) { cells.push({ ...run, width:x-run.x }); run=null; }
      if (inside && !run) run={x,y,depth};
    }
    if(run) cells.push({...run,width:shape.width-run.x});
  }
  return cells;
}
const MASKS = CLOUD_VARIATIONS.map(cloudCells);
function clouds(out, daylight, weather, visualSeconds, pointer) {
  const colors = [mix('#365465','#81988f',daylight),mix('#4c6979','#adbaab',daylight),mix('#637c88','#c4cbbb',daylight)];
  const wet = weather === 'rain' || weather === 'snow';
  const opacity = wet ? .76 : .62;
  const thickness = 1.35;
  for (const instance of INSTANCES) {
    const shape=CLOUD_VARIATIONS[instance.shape], period=2080;
    const x=mod(instance.x + visualSeconds*instance.speed + pointer*instance.parallax + 240,period)-240;
    for (const shift of [-period,0,period]) {
      const left=x+shift;
      if(left>1600||left+shape.width*instance.scale<0) continue;
      for (const cell of MASKS[instance.shape]) add(out,'clouds',left+cell.x*instance.scale,instance.y+cell.y*instance.scale*thickness,cell.width*instance.scale,2*instance.scale*thickness,colors[cell.depth],opacity);
    }
  }
}

/** Caller supplies the EXISTING guarded decorative clock, not wall time.
 * environment: existing e.day/e.light/e.season/e.weather/e.raining/e.snowing.
 * parallaxX is a normalized existing pointer offset [-1,1], never camera/nav.
 * Paused/hidden/reduced-motion: reuse the last frame or the last guarded time
 * and parallax. This pure draft neither advances nor resets that phase.
 */
function buildCloudMountainFrame({ visualSeconds=0, environment={}, parallaxX=0, includeClouds=true }={}) {
  if(!Number.isFinite(visualSeconds)||!Number.isFinite(parallaxX)) throw new TypeError('Finite decorative inputs required');
  const light=clamp(Number.isFinite(environment.light)?environment.light:.4,0,1);
  const daylight=environment.day ? light : light*.12;
  const season=['spring','summer','autumn','winter'].includes(environment.season)?environment.season:'summer';
  const weather=environment.snowing?'snow':environment.raining?'rain':environment.weather;
  const p=clamp(parallaxX,-1,1), commands=[];
  // Existing celestial bodies/stars precede this transparent cloud pass;
  // existing forest/landscape panels follow both distant mountain tiers.
  if(includeClouds)clouds(commands,daylight,weather,visualSeconds,p);
  for(const tier of MOUNTAIN_TIERS) mountains(commands,tier,daylight,season,p);
  if(commands.length>12000) throw new RangeError('Draft command budget exceeded');
  return { schemaVersion:1,width:1600,height:310,clipBottom:188,visualSeconds,commands };
}

function buildCloudFrame({width=1600,originX=0,visualSeconds=0,environment={},parallaxX=0,worldSeed=0}={}){if(!Number.isFinite(width)||width<=0||!Number.isFinite(originX)||!Number.isFinite(visualSeconds)||!Number.isFinite(parallaxX))throw Error('Finite cloud frame required');const light=clamp(Number.isFinite(environment.light)?environment.light:.4,0,1),daylight=environment.day?light:light*.12,p=clamp(parallaxX,-1,1),wet=environment.raining||environment.snowing||['rain','snow'].includes(environment.weather),opacity=wet?.58:.43,colors=[mix('#365465','#81988f',daylight),mix('#4c6979','#adbaab',daylight),mix('#637c88','#c4cbbb',daylight)],commands=[];for(const instance of woodlandAmbient.cloudInstances(worldSeed)){const shape=CLOUD_VARIATIONS[instance.shape],period=2080,base=originX+instance.x+visualSeconds*instance.speed+p*instance.parallax,first=Math.floor((-base-shape.width*instance.scale)/period),last=Math.ceil((width-base)/period);for(let k=first;k<=last;k++){const left=base+k*period;if(left>width||left+shape.width*instance.scale<0)continue;for(const cell of MASKS[instance.shape]){const x=clamp(snap(left+cell.x*instance.scale),0,width),right=clamp(snap(left+(cell.x+cell.width)*instance.scale),0,width),y=clamp(snap(instance.y+cell.y*instance.scale),0,188),bottom=clamp(snap(instance.y+(cell.y+2)*instance.scale),0,188);if(right>x&&bottom>y)commands.push({layer:'clouds',x,y,width:right-x,height:bottom-y,fill:colors[cell.depth],opacity});}}}return{schemaVersion:1,width,height:310,clipBottom:188,visualSeconds,commands};}
function paintCloudMountainFrame(ctx, frame) {
  ctx.save();
  try {
    const inheritedAlpha=ctx.globalAlpha;
    ctx.beginPath();ctx.rect(0,0,frame.width,frame.clipBottom);ctx.clip();
    ctx.imageSmoothingEnabled=false;
    for(const c of frame.commands){ctx.globalAlpha=inheritedAlpha*c.opacity;ctx.fillStyle=c.fill;ctx.fillRect(c.x,c.y,c.width,c.height);}
  } finally { ctx.restore(); }
}


return{buildCloudMountainFrame,buildCloudFrame,paintCloudMountainFrame};})();
const woodlandShore=(()=>{// Finite Worker #2 placement draft only. No source/runtime/native dependencies or side effects.
const LAKE = [[0,230],[100,217],[222,224],[320,240],[454,247],[475,269],[396,291],[229,305],[89,291],[0,278]];
const FRAMES = {
 'near-tall': {atlas:'pines',file:'woodland-pines.png',rect:[88,39,650,929],pivot:[332,926],root:[245,789,424,929]},
 'near-small': {atlas:'pines',file:'woodland-pines.png',rect:[881,231,536,737],pivot:[268,734],root:[196,626,343,737]},
 'shore-a': {atlas:'scenery',file:'woodland-scenery.png',rect:[817,803,200,90],pivot:[100,87]},
 'shore-b': {atlas:'scenery',file:'woodland-scenery.png',rect:[1055,813,180,80],pivot:[90,77]},
 'shore-c': {atlas:'scenery',file:'woodland-scenery.png',rect:[1282,803,192,90],pivot:[96,87]}
};
// Authoring coordinates are 1600x310. Heights/scales retain native atlas density.
const SLOTS = [
 ['house-pine-1','house-pines','near-small',60,198,86],
 ['house-pine-2','house-pines','near-tall',398,199,91],
 ['house-pine-3','house-pines','near-small',470,198,72],
 ['house-pine-4','house-pines','near-small',710,199,64],
 ['house-pine-5','house-pines','near-tall',865,198,98],
 ['house-pine-6','house-pines','near-small',985,198,76],
 ['house-pine-7','house-pines','near-tall',1350,199,87],
 ['house-pine-8','house-pines','near-small',1460,198,70],
 ['shore-pine-edge','shore-pines','near-tall',-44,272,140],
 ['shore-pine-bank','shore-pines','near-tall',510,282,136],
 ['shore-pine-middle','shore-pines','near-small',574,260,158],
 ['shore-pine-right-bank','shore-pines','near-tall',640,252,124],
 ['shore-pine-east-1','shore-pines','near-small',1527,281,155],
 ['shore-pine-east-2','shore-pines','near-tall',1559,270,132],
 ['shore-rock-north-1','shore-rocks','shore-b',75,211,.18],
 ['shore-rock-north-2','shore-rocks','shore-a',330,231,.21],
 ['shore-rock-east','shore-rocks','shore-c',515,282,.26],
 ['shore-rock-dry-east','shore-rocks','shore-a',1199,279,.24],
 ['shore-rock-dry-edge','shore-rocks','shore-c',1505,296,.29]
].map(([id,layer,frame,x,y,size])=>({id,layer,frame,x,y,size}));
const box=(x,y,w,h)=>({x,y,w,h});
const inflate=(r,p)=>box(r.x-p,r.y-p,r.w+2*p,r.h+2*p);
const overlaps=(a,b)=>a.x<=b.x+b.w&&a.x+a.w>=b.x&&a.y<=b.y+b.h&&a.y+a.h>=b.y;
const pointInRect=(p,r)=>p[0]>=r.x&&p[0]<=r.x+r.w&&p[1]>=r.y&&p[1]<=r.y+r.h;
const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
const onSegment=(a,b,p)=>Math.abs(cross(a,b,p))<1e-8&&p[0]>=Math.min(a[0],b[0])-1e-8&&p[0]<=Math.max(a[0],b[0])+1e-8&&p[1]>=Math.min(a[1],b[1])-1e-8&&p[1]<=Math.max(a[1],b[1])+1e-8;
function segmentsMeet(a,b,c,d){const ac=cross(a,b,c),ad=cross(a,b,d),ca=cross(c,d,a),cb=cross(c,d,b);return(ac*ad<0&&ca*cb<0)||onSegment(a,b,c)||onSegment(a,b,d)||onSegment(c,d,a)||onSegment(c,d,b);}
function inPolygon(p,poly){let inside=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if(onSegment(a,b,p))return true;if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])inside=!inside;}return inside;}
function rectMeetsPolygon(r,poly){const corners=[[r.x,r.y],[r.x+r.w,r.y],[r.x+r.w,r.y+r.h],[r.x,r.y+r.h]];return corners.some(p=>inPolygon(p,poly))||poly.some(p=>pointInRect(p,r))||corners.some((a,i)=>poly.some((c,j)=>segmentsMeet(a,corners[(i+1)%4],c,poly[(j+1)%poly.length])));}
function buildPineShoreLayout({width=1600,progressClearRect=null}={}){
 if(!Number.isFinite(width)||width<1600)throw Error('Draft allocation covers widths >=1600; smaller worlds require owner fit review.');
 const f=Math.min(width/1600,1.7),span=1600*f,offset=(width-span)/2,extra=Math.ceil(Math.max(0,offset)/span);
 const panels=Array.from({length:extra*2+1},(_,j)=>({index:j-extra,x:offset+(j-extra)*span}));
 const lakes=panels.map(p=>({panel:p.index,points:LAKE.map(([x,y])=>[p.x+x*f,y*f])}));
 // Same progress root/site as retained renderer, never repeated with panels.
 const root={x:Math.max(80*f,width*.12),y:298*f};
 const progressReserve=progressClearRect??box(root.x-90*f,root.y-230*f,180*f,240*f);
 const placements=[],omitted=[];
 for(const panel of panels)for(const slot of SLOTS){
  const frame=FRAMES[slot.frame],s=slot.layer==='shore-rocks'?slot.size:slot.size/frame.rect[3],scale=s*f;
  const ax=panel.x+slot.x*f,ay=slot.y*f;
  const bounds=box(ax-frame.pivot[0]*scale,ay-frame.pivot[1]*scale,frame.rect[2]*scale,frame.rect[3]*scale);
  const rb=frame.root??[0,0,frame.rect[2],frame.rect[3]];
  const footprint=box(ax+(rb[0]-frame.pivot[0])*scale,ay+(rb[1]-frame.pivot[1])*scale,(rb[2]-rb[0])*scale,(rb[3]-rb[1])*scale);
  const guardedFootprint=inflate(footprint,3*f),crownEnvelope=inflate(bounds,3*f);
  const id='panel'+panel.index+':'+slot.id;
  // Check every repeated water polygon, not only the root's own tile. Reject, never clamp/crop a root.
  const water=lakes.find(l=>rectMeetsPolygon(guardedFootprint,l.points));
  const reason=water?'full-root-or-rock-water-overlap':overlaps(crownEnvelope,progressReserve)?'reserved-progress-canopy-label-site':bounds.x+bounds.w<0||bounds.x>width?'fully-offscreen':null;
  if(reason){omitted.push({id,reason,waterPanel:water?.panel??null,anchor:{x:ax,y:ay},bounds,footprint});continue;}
  placements.push({id,panel:panel.index,slotId:slot.id,layer:slot.layer,source:{atlas:frame.atlas,file:frame.file,frame:slot.frame,rect:frame.rect,pivot:frame.pivot},anchor:{x:ax,y:ay},authoredAnchor:{x:slot.x,y:slot.y},scale,authoredScale:s,bounds,rootOrRockBounds:footprint,guardedFootprint,groundRationale:slot.layer==='house-pines'?'Roots on land before the 217+ lake boundary; same house-depth ground 198-199.':slot.layer==='shore-rocks'?'Full source crop, including rock/reeds/base, plus 3-unit guard is disjoint from every lake polygon.':'Entire measured root base plus fringe/wind guard stays on land; transparent crown may overhang water.',nativeOrProgressEffect:false});
 }
 const layerRank={'house-pines':0,'shore-pines':1,'shore-rocks':1};
 placements.sort((a,b)=>layerRank[a.layer]-layerRank[b.layer]||a.anchor.y-b.anchor.y||a.anchor.x-b.anchor.x||a.id.localeCompare(b.id));
 return{width,artScale:f,authoredExterior:{width:1600,height:310},panels,lakes,progressRoot:root,progressReserve,placements,omitted};
}
// Adapter draft. Call once per world stage after ALL opaque panels; do not call per panel.
// images are ALREADY decoded selected atlases from the existing verified loader. No fetch/loading here.
function paintDraftLayer(ctx,layout,images,layer,{season='summer',wind=0,state=null}={}){
 const filter=season==='autumn'?'sepia(.18) saturate(.8) hue-rotate(-18deg)':season==='winter'?'saturate(.35) brightness(1.08)':'none';
 for(const p of layout.placements.filter(p=>layer==='shore'?p.layer!=='house-pines':p.layer===layer)){
  const image=images[p.source.atlas];if(!image)throw Error('Missing decoded selected atlas '+p.source.atlas);
  if(state?.valid&&p.source.atlas==='pines'){const result=seasonalPainter.paintTree(ctx,{image,frame:{...p.source,id:p.source.frame},x:p.anchor.x,y:p.anchor.y,scale:p.scale,state,key:p.id||p.source.frame+'|'+p.anchor.x+'|'+p.anchor.y});if(result.painted)continue;}
  const wave=Math.max(-3,Math.min(3,wind))*layout.artScale;
  ctx.save();ctx.translate(p.anchor.x,p.anchor.y);ctx.transform(1,0,wave/(p.source.rect[3]*p.scale),1,0,0);ctx.imageSmoothingEnabled=false;if('filter'in ctx)ctx.filter=filter;
  ctx.drawImage(image,...p.source.rect,-p.source.pivot[0]*p.scale,-p.source.pivot[1]*p.scale,p.source.rect[2]*p.scale,p.source.rect[3]*p.scale);ctx.restore();
 }
}

return{buildPineShoreLayout,paintDraftLayer,rectMeetsPolygon};})();
function pineWaterPalette(environment = {}, kind = 'lake') {
  const light = Number.isFinite(environment.light)
    ? Math.max(0, Math.min(1, environment.light))
    : environment.day === false ? 0.25 : 1;
  const brightness = 0.68 + light * 0.32;
  const colors = kind === 'pool' ? {shallow:'#478eae', middle:'#478eae', deep:'#285b70', shadow:'#285b70', glint:'#a8d9e5'} : {shallow:'#638eac', middle:'#456b88', deep:'#2e506c', shadow:'#243e54', glint:'#a1c5d5'};
  const shade = hex => {
    const channel = offset => Math.round(parseInt(hex.slice(offset, offset + 2), 16) * brightness);
    return '#' + [channel(1), channel(3), channel(5)].map(n => n.toString(16).padStart(2, '0')).join('');
  };
  return Object.fromEntries(Object.entries(colors).map(([key, value]) => [key, shade(value)]));
}

function pineWaterPath(g, points, pixel = 0) {
  g.beginPath();
  g.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i <= points.length; i++) {
    const a = points[i - 1], b = points[i % points.length];
    if (!pixel) { g.lineTo(b[0], b[1]); continue; }
    const steps = Math.max(1, Math.min(32, Math.ceil(Math.max(Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1])) / pixel)));
    let lastY = a[1];
    for (let n = 1; n <= steps; n++) {
      const x = Math.round((a[0] + (b[0] - a[0]) * n / steps) / pixel) * pixel;
      const y = Math.round((a[1] + (b[1] - a[1]) * n / steps) / pixel) * pixel;
      g.lineTo(x, lastY); g.lineTo(x, y); lastY = y;
    }
  }
  g.closePath();
}

function pinePoolContour(p) {
  // The existing 16 vertices and jitter are retained verbatim.
  return Array.from({length:16}, (_, i) => {
    const a = i * Math.PI / 8, d = 1 + Math.sin(i * 7) * 0.09;
    return [p.x + Math.cos(a) * p.rx * d, p.y + Math.sin(a) * p.ry * d];
  });
}

// Stepped, low-contrast contact shadows share the pines' moss/soil palette.
function paintWoodlandContactShadow(g,{x,y,width,height},environment={}){
 if(![x,y,width,height].every(Number.isFinite)||width<=0||height<=0)return;
 g.save();const alpha=g.globalAlpha,light=Number.isFinite(environment.light)?Math.max(0,Math.min(1,environment.light)):environment.day===false?.25:1;
 g.globalAlpha=alpha*(.10+light*.10);g.fillStyle='#1c3028';
 const snap=n=>Math.round(n/2)*2;
 for(let i=0;i<3;i++){const inset=i===1?0:width*.12;g.fillRect(snap(x-width*.48+inset+i*height*.18),snap(y+i*height/3),snap(width-inset*2),Math.max(2,snap(height/3)));}
 g.globalAlpha=alpha*.13;g.fillRect(snap(x-width*.27),snap(y),snap(width*.56),2);g.restore();
}

function paintPineWaterMaterial(g, points, options = {}) {
  if (!Array.isArray(points) || points.length < 3 || points.length > 64 ||
      points.some(p => !Array.isArray(p) || p.length !== 2 || !p.every(Number.isFinite))) return false;
  const xs = points.map(p => p[0]), ys = points.map(p => p[1]);
  const left = Math.min(...xs), top = Math.min(...ys), width = Math.max(...xs) - left, height = Math.max(...ys) - top;
  if (!(width > 0 && height > 0)) return false;
  const kind = options.kind === 'pool' ? 'pool' : 'lake';
  const palette = pineWaterPalette(options.environment || {}, kind);
  const pixel = Math.max(0.5, Number.isFinite(options.pixel) ? options.pixel : height / (kind === 'pool' ? 11 : 26));
  const time = options.environment?.reducedMotion===true||options.environment?.season==='winter'?0:Number.isFinite(options.time)?Math.floor(options.time*6)/6:0;
  const cx = left + width * 0.5, cy = top + height * 0.5;
  g.save();
  try {
    // All new depth, bank shadow, glints and ice stay within the ORIGINAL path.
    // Only inner material bands are stepped; the visible shoreline is not snapped.
    pineWaterPath(g, points); g.clip();
    const alpha = g.globalAlpha;
    g.imageSmoothingEnabled = false;
    g.fillStyle = palette.shallow;
    g.fillRect(left, top, width, height);
    const band = (sx, sy, dx, dy, color) => {
      const inner = points.map(([x, y]) => [cx + (x - cx) * sx + dx, cy + (y - cy) * sy + dy]);
      pineWaterPath(g, inner, pixel); g.fillStyle = color; g.fill();
    };
    band(0.96, 0.77, -pixel, pixel * 0.6, palette.middle);
    band(0.84, 0.51, width * 0.025, height * 0.085, palette.deep);
    // Broken far-bank contact shadow, not a full dark outline around the water.
    g.globalAlpha = alpha * 0.42;
    const edge = points.slice(0, Math.min(5, points.length));
    const shadow = edge.concat([...edge].reverse().map(([x, y]) => [x + pixel * 1.6, y + pixel * 1.8]));
    pineWaterPath(g, shadow, pixel); g.fillStyle = palette.shadow; g.fill();
    g.globalAlpha = alpha * 0.30;
    const lower = [[left + width * 0.62, top + height * 0.56], [left + width, top + height * 0.37],
      [left + width, top + height], [left + width * 0.48, top + height]];
    pineWaterPath(g, lower, pixel); g.fillStyle = palette.shadow; g.fill();
    // Broken vertical pine-tone reflections and broad stepped facets, not a glossy fill.
    const snap = n => Math.round(n / pixel) * pixel;
    g.globalAlpha=alpha*.16;g.fillStyle=palette.shadow;
    for(let i=0;i<(kind==='pool'?3:7);i++){
      const x=left+width*(.08+((i*.217+.13)%1)*.8),y=top+height*(.16+(i%3)*.06);
      for(let row=0;row<3;row++){const w=pixel*(5-row);g.fillRect(snap(x-w/2+Math.sin(time*.45+i+row)*pixel),snap(y+row*pixel*1.4),w,pixel);}
    }
    g.fillStyle=palette.middle;g.globalAlpha=alpha*.27;
    for(let i=0;i<5;i++)g.fillRect(snap(left+width*(.13+i*.17)),snap(top+height*(.35+(i%3)*.15)),pixel*(4+i%3),pixel*2);
    // Three slow broken ripple fronts; visual time freezes with pause/hidden guards.
    g.fillStyle=palette.glint;
    for(let i=0;i<3;i++){
      const phase=(time*.055+i/3)%1,y=snap(top+height*(.21+phase*.61)),x=snap(left+width*(.19+i*.21));
      g.globalAlpha=alpha*(.06+Math.sin(phase*Math.PI)*.13);
      g.fillRect(x,y,pixel*(3+phase*5),pixel*.6);g.fillRect(x+pixel*(5+phase*5),y+pixel,pixel*2,pixel*.6);
    }
    g.globalAlpha = alpha * 0.46;g.fillStyle = palette.glint;
    const count = kind === 'pool' ? 4 : 14;
    for (let i = 0; i < count; i++) {
      const u = (i * 0.61803398875 + 0.17) % 1, v = (i * 0.38196601125 + 0.11) % 1;
      const drift = Math.sin(time * 0.55 + i * 1.7) * pixel * 1.8;
      const x = snap(left + width * (0.08 + u * 0.81) + drift), y = snap(top + height * (0.21 + v * 0.57)+Math.sin(time*.4+i)*pixel*.5);
      const length = pixel * (kind === 'pool' ? 2 + i % 2 : 2 + i % 4);
      g.fillRect(x, y, length, pixel * 0.55);
    }
    // Worker2 owns the ice/snow pixels. Compose its one allocated pure hook
    // after water depth while the ORIGINAL shoreline clip is still active.
    if (typeof options.seasonalWaterTreatment === 'function') {
      g.globalAlpha = alpha;
      g.save();
      try {
        options.seasonalWaterTreatment(g, options.environment || {}, time,
          {x:left, y:top, w:width, h:height,traceWater:ctx=>pineWaterPath(ctx,points),worldSeed:options.environment?.worldSeed,reducedMotion:options.environment?.reducedMotion===true}, Number.isFinite(options.scale) ? options.scale : 1);
      } finally { g.restore(); }
    }
  } finally { g.restore(); }
  return true;
}

function create(){const reference=referenceAssets();let landscapeCache=null;const W=1600,H=1000,sceneryRandom=seeded(54298),random=seeded(91378);let ctx,time=0,growth=0,seasonState=null,pointer={x:0,y:0};const hills=Array.from({length:42},(_,i)=>({x:i*47-80,y:80+sceneryRandom()*75,h:30+sceneryRandom()*80,w:80+sceneryRandom()*70})),trees=Array.from({length:27},(_,i)=>({x:i*64-70,y:220+sceneryRandom()*45,h:70+sceneryRandom()*100,seed:Math.floor(sceneryRandom()*99999)})),rain=Array.from({length:150},()=>({x:random()*1700,y:random()*340,speed:180+random()*140,len:7+random()*13})),clouds=Array.from({length:9},()=>({x:random()*1750,y:25+random()*90,w:60+random()*190}));
const poly=(g,points,color)=>{g.fillStyle=color;g.beginPath();points.forEach((p,i)=>i?g.lineTo(...p):g.moveTo(...p));g.closePath();g.fill();};
const line=(g,points,color,width=2)=>{g.strokeStyle=color;g.lineWidth=width;g.beginPath();points.forEach((p,i)=>i?g.lineTo(...p):g.moveTo(...p));g.stroke();};
const oval=(g,x,y,rx,ry,color)=>{g.fillStyle=color;g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);g.fill();};
const box=(g,x,y,w,h,color)=>{g.fillStyle=color;g.fillRect(Math.round(x/2)*2,Math.round(y/2)*2,Math.round(w/2)*2||2,Math.round(h/2)*2||2);};

function patchPoints(r,scale=1){return r.patch.map((v,i)=>{const a=i/r.patch.length*Math.PI*2;return[r.x+Math.cos(a)*r.rx*v*scale,r.y+Math.sin(a)*r.ry*v*scale];});}
function sprite(g,key,id,x,y,scale=1,season='summer',wind=0){if(reference.state!=='ready')return false;const atlas=reference.frames[key],f=atlas.frames.find(f=>f.id===id);if(!f)return false;if(seasonState?.valid&&['pines','trees'].includes(key)){seasonalPainter.paintTree(g,{image:reference.images[key],frame:f,x:Math.round(x),y:Math.round(y),scale,state:seasonState,key:key+'|'+id+'|'+x+'|'+y,wind:key==='pines'});return true;}g.save();g.translate(Math.round(x),Math.round(y));g.transform(1,0,wind/Math.max(1,f.rect[3]*scale),1,0,0);g.imageSmoothingEnabled=false;if('filter'in g)g.filter=season==='autumn'?'sepia(.18) saturate(.8) hue-rotate(-18deg)':season==='winter'?'saturate(.35) brightness(1.08)':'none';g.drawImage(reference.images[key],...f.rect,-f.pivot[0]*scale,-f.pivot[1]*scale,f.rect[2]*scale,f.rect[3]*scale);g.restore();return true;}
function forest(g,id,y,scale,parallax,season,extent=W,origin=0){const width=717*scale,period=width-2,first=Math.floor(-origin/period)-2,last=Math.ceil((extent-origin)/period)+2;for(let i=first;i<=last;i++)sprite(g,'scenery',id,origin+i*period+width/2+pointer.x*parallax,y,scale,season);}
function pine(g,x,y,h,colors,seed,wind=0,season='summer'){const index=Math.abs(seed)%2;if(sprite(g,'pines',index?'near-small':'near-tall',x,y,h/(index?737:929),season,Math.sin(time*1.2+seed)*wind))return;const r=seeded(seed);box(g,x-4,y-h*.65,8,h*.65,'#29372c');for(let j=0;j<6;j++){const k=j/6,py=y-h+h*k*.86,w=h*(.12+k*.25),shift=Math.sin(time*1.2+seed)*wind*(1-k);poly(g,[[x+shift,py-13],[x-w+shift,py+h*.25],[x+w+shift,py+h*.25]],colors[j%colors.length]);for(let n=0;n<9;n++)box(g,x+(r()-.5)*w*1.4+shift,py+h*(.12+r()*.11),4+r()*8,3,colors[(j+1)%colors.length]);}}
function broadTree(g,x,y,h,season,seed,wind=0){if(sprite(g,'trees','complete',x,y,h/430,season,Math.sin(time*1.3+seed)*wind))return;
 const r=seeded(seed),c=season==='autumn'?['#55513a','#777047','#9a8153','#b79759']:season==='winter'?['#435454','#687b79','#94a6a0','#bac6b8']:season==='spring'?['#48634a','#658358','#819761','#a1ae79']:['#354b3d','#45644b','#58734f','#7b8e5a'];
 const sway=Math.sin(time*1.3+seed)*wind;line(g,[[x,y],[x+sway*.4,y-h*.5],[x-8+sway,y-h*.84]],'#3d4131',10);line(g,[[x+sway*.4,y-h*.5],[x-30+sway,y-h*.7]],'#4c503a',6);line(g,[[x+sway*.4,y-h*.46],[x+30+sway,y-h*.73]],'#5e6041',5);
 for(let j=0;j<70;j++){const a=r()*Math.PI*2,d=Math.sqrt(r()),px=x+sway+Math.cos(a)*h*.39*d,py=y-h*.73+Math.sin(a)*h*.29*d;box(g,px,py,12+r()*22,8+r()*18,c[Math.floor(r()*c.length)]);if(season==='spring'&&j%8===0){box(g,px+5,py+3,6,4,'#c7ae9a');box(g,px+7,py+1,2,8,'#dfc5ac');}}
 box(g,x-12,y-1,27,4,'#292e24');
}
function drawDistant(e,extent=W,origin=0){const light=e.light,sky=ctx.createLinearGradient(0,0,0,310);sky.addColorStop(0,e.day?(light>.6?'#608688':'#59666e'):'#172b3c');sky.addColorStop(.7,e.day?(light>.6?'#a5b6a1':'#c2a18b'):'#435d68');sky.addColorStop(1,e.day?'#9aab89':'#607473');ctx.fillStyle=sky;ctx.fillRect(0,0,extent,310);const celestialX=origin+100+e.u*1400,cy=150-Math.sin(e.u*Math.PI)*102;if(!e.hideCelestial){ctx.save();ctx.translate(celestialX,cy);ctx.scale(1/(e.horizontalScale||1),1);if(e.day){oval(ctx,0,0,19,19,'#e6c987');oval(ctx,0,0,25,25,'#d7b47730');}else{oval(ctx,0,0,17,17,'#d1d9c5');oval(ctx,7,-6,15,15,'#213748');}ctx.restore();}if(!e.hideCelestial&&!e.day)for(let i=0;i<28;i++)box(ctx,origin+(i*167+89)%1600,25+(i*43)%110,2,2,i%3?'#8daca356':'#a8bab765');ctx.save();ctx.translate(pointer.x*2,0);woodlandSky.paintCloudMountainFrame(ctx,woodlandSky.buildCloudFrame({width:extent,originX:origin,visualSeconds:time,environment:e,parallaxX:pointer.x,worldSeed:e.ambientSeed??0}));const first=Math.floor(-origin/1600),last=Math.ceil((extent-origin)/1600);for(let i=first;i<last;i++){ctx.save();ctx.translate(origin+i*1600,0);ctx.beginPath();ctx.rect(0,0,1600,188);ctx.clip();woodlandSky.paintCloudMountainFrame(ctx,woodlandSky.buildCloudMountainFrame({visualSeconds:time,environment:e,parallaxX:pointer.x,includeClouds:false}));ctx.restore();}if(reference.state==='ready'){forest(ctx,'forest-far',190,.43,2,e.season,extent,origin);forest(ctx,'forest-near',198,.37,3,e.season,extent,origin);}else for(let i=Math.floor(-origin/1600);i<Math.ceil((extent-origin)/1600);i++)for(const t of hills)pine(ctx,origin+i*1600+t.x,t.y+85,t.h,['#3c5658','#425f5d','#4b6761'],Math.floor(t.x),0);ctx.restore();}
function paintDistant(g,e,t,width,p={x:0,y:0}){ctx=g;time=t;seasonState=appearanceFor(e,t);pointer=p;const f=geometry(width).artScale;ctx.save();ctx.scale(f,f);drawDistant(e,width/f,(width/f-1600)/2);ctx.restore();}
function drawExterior(e,beforeNearTrees){
 if(!e.deferDistant)drawDistant(e);
 box(ctx,0,187,1600,120,e.day?'#6a7d5b':'#3d5343');
 // The far road and its traffic stay in the same depth layer as the houses.
 box(ctx,0,201,1600,9,'#52605a');box(ctx,0,210,1600,3,'#36443c');
  const road=woodlandAmbient.ROAD;ctx.fillStyle=e.day?'#6b7c65':'#4a5e4f';ctx.fillRect(0,road.sidewalkTop,1600,road.sidewalkBottom-road.sidewalkTop);ctx.fillStyle=e.day?'#859177':'#60735d';ctx.fillRect(0,road.sidewalkTop,1600,1);
  const traffic=woodlandAmbient.roadActors({seed:e.ambientSeed??0,visualSeconds:time});
 ctx.save();ctx.translate(pointer.x*4,0);
 [[228,198,'house-a'],[318,197,'house-b'],[1092,198,'house-c'],[1192,199,'house-a'],[1281,197,'house-b']].forEach(([x,y,id])=>sprite(ctx,'props',id,x,y,.15,e.season));
 for(const car of traffic.cars){const i=car.id,x=car.x,y=car.y;box(ctx,x,y-6,19,6,['#9eac9c','#b0a28c','#768d92','#bbbdad'][i]);box(ctx,x+4,y-10,10,5,'#758a83');box(ctx,x+2,y,4,3,'#253933');box(ctx,x+13,y,4,3,'#253933');box(ctx,x+18,y-4,3,2,'#e6d69a');}
 for(const person of traffic.people)drawPerson(ctx,person.x,person.y,person.pose,person.direction,person.palette,e.season);ctx.restore();
 if(typeof beforeNearTrees==='function')beforeNearTrees();
 // Pond, reeds and grounded rocks occupy the middle distance.
 paintPineWaterMaterial(ctx,[[0,230],[100,217],[222,224],[320,240],[454,247],[475,269],[396,291],[229,305],[89,291],[0,278]],{kind:'lake',environment:e,time,seasonalWaterTreatment:seasonalWorld.seasonalWaterTreatment});
 if(!e.deferNearTrees)drawNearTrees(e);
 if(!e.hideTree)drawGrowthTree(e);
}
// Paint all opaque landscape panels before near trees, so a neighboring tile
// cannot overwrite the other tile's transparent canopy, trunk or root overhang.
function drawPerson(g,x,y,pose='stand',direction=1,palette='moss',season='summer'){g.save();g.translate(x,y);g.scale(direction,1);sprite(g,'props','person-'+palette+'-'+pose,0,0,.06,season);g.restore();}
function landscapeLayout(width){if(landscapeCache?.width!==width)landscapeCache=woodlandShore.buildPineShoreLayout({width});return landscapeCache;}
function paintLandscape(g,e,t,width){time=t;seasonState=appearanceFor(e,t);const layout=landscapeLayout(width),f=layout.artScale,root=layout.progressRoot,bank={x:root.x-66*f,y:root.y-12*f,w:132*f,h:28*f};
 g.save();if(layout.lakes.some(l=>woodlandShore.rectMeetsPolygon(bank,l.points))){const x=root.x,y=root.y;poly(g,[[-66,13],[-65,1],[-45,-8],[-17,-12],[19,-10],[48,-4],[66,6],[68,18],[-66,18]].map(([dx,dy])=>[x+dx*f,y+dy*f]),e.day?'#6a7d5b':'#3d5343');line(g,[[-65,1],[-45,-8],[-17,-12],[19,-10],[48,-4],[66,6]].map(([dx,dy])=>[x+dx*f,y+dy*f]),e.day?'#81916c':'#576f54',2*f);}
 // Ground shadows paint before the corresponding trees/rocks, with lake holes clipped out.
 g.save();g.beginPath();g.rect(0,188*f,width,124*f);for(const lake of layout.lakes){g.moveTo(...lake.points[0]);for(const point of lake.points.slice(1))g.lineTo(...point);g.closePath();}g.clip('evenodd');
 for(const p of layout.placements){const r=p.rootOrRockBounds;paintWoodlandContactShadow(g,{x:p.anchor.x,y:p.anchor.y-2*f,width:Math.max(12*f,r.w*.9),height:Math.min(9*f,Math.max(4*f,r.h*.16))},e);}g.restore();
 if(reference.state==='ready'){woodlandShore.paintDraftLayer(g,layout,reference.images,'house-pines',{season:e.season,state:seasonState,wind:0});woodlandShore.paintDraftLayer(g,layout,reference.images,'shore',{season:e.season,state:seasonState,wind:0});}
 // Reeds grow on the dry bank; crowns may overhang the water, roots may not.
 for(const panel of layout.panels)for(let i=0;i<40;i++){const x=panel.x+(i*47%480)*f,y=(277+i*11%27)*f,r={x:x-5*f,y:y-2*f,w:10*f,h:4*f};if(layout.lakes.some(l=>woodlandShore.rectMeetsPolygon(r,l.points)))continue;line(g,[[x,y],[x-2*f,y-(10+i%6)*f],[x-4*f,y-(14+i%7)*f]],i%2?'#6e7f51':'#435f40',2*f);}g.restore();return layout;}
function drawNearTrees(e){paintLandscape(ctx,e,time,1600);}

function drawGrowthTree(e){const x=1410,y=286;if(growth===null){oval(ctx,x,y,12,3,'#4e4836');return;}const p=growth/100,frameId=treeState(growth).id;paintWoodlandContactShadow(ctx,{x,y:y-1,width:18+p*38,height:4+p*4},e);if(sprite(ctx,'trees',frameId,x,y,.29,e.season,Math.sin(time*1.1)*.65))return;oval(ctx,x,y,31,8,'#364532');box(ctx,x-17,y-2,34,4,'#a2925d');if(p===0){box(ctx,x-4,y-6,8,5,'#c9ac73');return;}
 if(p<.16){const h=8+p*130;box(ctx,x-2,y-h,4,h,'#9dad65');box(ctx,x-13,y-h-1,12,5,'#b5bd76');box(ctx,x+2,y-h-7,12,5,'#7fa78b');return;}
 const stage=p<.32?1:p<.48?2:p<.66?3:p<.88?4:5,h=34+stage*27,trunk=4+stage*2,leaf=e.season==='winter'?'#9fb4a2':e.season==='autumn'?'#b19a62':'#7ca58a',shade=e.season==='winter'?'#6c8e86':'#426e60';box(ctx,x-trunk/2,y-h,trunk,h,'#806f50');box(ctx,x-1,y-h,2,h,'#b19c6a');for(let i=0;i<stage+2;i++){const yy=y-h+14+i*18,w=18+Math.min(i,stage)*8;box(ctx,x-w,yy,w*2,13,shade);box(ctx,x-w+4,yy-5,w*2-8,11,leaf);box(ctx,x-w+5,yy-6,6,3,'#d0c689');}box(ctx,x-5,y-h-10,10,8,'#d4be78');if(p>=.88)for(let i=0;i<8;i++){const a=i*2.4;box(ctx,x+Math.sin(a)*(22+stage*5),y-h*.65+Math.cos(a)*32,p>=1?6:4,p>=1?7:4,p>=1?'#d4a358':'#dcc3b1');}
}
function drawSurfaceGrass(e){const r=seeded(327);for(let i=0;i<280;i++){const x=r()*1600;if(x>475&&x<1155)continue;const y=295+r()*9;const c=e.season==='autumn'?'#83815b':e.season==='winter'?'#94a997':'#698052';line(ctx,[[x,y+2],[x+Math.sin(time*1.4+x)*2,y-4-r()*8]],c,2);}}

function nest(r){const x=r.x-r.rx*.45,y=r.y+5;oval(ctx,x,y+2,29,21,'#34362a');oval(ctx,x,y,26,18,'#998663');oval(ctx,x,y,21,14,'#514b3a');const q=seeded(r.id+22);for(let i=0;i<24;i++){const a=q()*Math.PI*2,xx=x+Math.cos(a)*24,yy=y+Math.sin(a)*16;line(ctx,[[xx-3,yy],[xx+4,yy+(q()-.5)*6]],i%2?'#b5a07b':'#72684c',2);}oval(ctx,x-8,y,7,10,'#b0b09a');oval(ctx,x+3,y,11,9,'#777e62');line(ctx,[[x-2,y-7],[x-2,y+7]],'#a8b191',2);}

function props(r){
 const role=String(r.role||'agent').toLowerCase(),focus=r.focused===true;
 const c={edge:'#303c30',shadow:'#23342b',wood:focus?'#8c805b':'#756b4e',grain:'#574f3a',lip:'#a39970',paper:focus?'#e3dfbb':'#c8caaa',ink:'#536758',metal:focus?'#a9c4bd':'#7e9e97',blue:'#47798a',green:'#73865a',red:'#a66f59',gold:'#b9a16a'};
 const x=r.x+Math.min(30,Math.max(4,r.rx*.32)),y=r.y,scale=Math.max(.1,Math.min(1,(r.rx-(x-r.x)-3)/39));
 ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);
 const b=(x,y,w,h,color)=>box(ctx,x,y,w,h,color);
 const l=(points,color,width=2)=>line(ctx,points,color,width);
 const disc=(x,y,rx,ry,color)=>oval(ctx,x,y,rx,ry,color);
 function desk(){
  b(-28,16,64,5,c.shadow);b(-23,9,5,11,c.edge);b(24,9,5,11,c.edge);
  b(-29,-12,64,28,c.edge);b(-27,-12,60,23,c.wood);b(-27,10,60,5,c.grain);b(-25,-11,56,2,c.lip);
  b(-22,-4,18,1,c.grain);b(8,5,17,1,c.grain);b(-11,7,9,1,c.lip);
  if(focus){b(-29,-12,64,2,c.paper);b(-29,-10,2,22,c.lip);b(31,-8,2,18,c.lip);}
 }
 function book(x,y,w=17,h=17,color=c.green){b(x+1,y+2,w,h,c.edge);b(x,y,w,h,color);b(x+3,y+2,w-5,h-4,c.paper);b(x+3,y+h-4,w-5,2,c.gold);b(x+1,y+1,2,h-2,c.grain);}
 function screen(x,y,w=23,h=16){b(x-1,y-1,w+2,h+2,c.edge);b(x,y,w,h,c.metal);b(x+2,y+2,w-4,h-5,'#314e4a');b(x+4,y+4,w-8,2,'#80998b');b(x+Math.floor(w/2)-2,y+h,4,4,c.grain);b(x+Math.floor(w/2)-6,y+h+3,12,2,c.edge);}
 function cabinet(x,y,w,h){b(x+2,y+h,w,h*.13,c.shadow);b(x,y,w,h,c.edge);b(x+2,y+2,w-4,h-6,c.wood);b(x+3,y+3,w-6,2,c.lip);b(x+3,y+h-5,w-6,3,c.grain);b(x+w/2,y+5,1,h-11,c.grain);b(x+w/2-4,y+h/2,2,3,c.gold);b(x+w/2+3,y+h/2,2,3,c.gold);}
 function mug(x,y){disc(x+4,y+6,5,2,c.shadow);b(x,y,8,7,c.metal);b(x+8,y+1,3,4,c.paper);b(x+1,y,6,2,'#314c45');}
 function tool(x,y,kind=0){if(kind%2){l([[x,y],[x+10,y+11]],c.metal,3);b(x+7,y+7,5,8,c.wood);l([[x-3,y-2],[x-3,y+3],[x+3,y+6],[x+6,y+2]],c.metal,2);}else{b(x,y,4,15,c.wood);b(x-4,y-3,12,6,c.metal);b(x+1,y+11,2,3,c.gold);}}
 function paper(x,y,w=22,h=17){b(x+1,y+2,w,h,c.grain);b(x,y,w,h,c.paper);b(x+3,y+4,w-7,1,c.ink);b(x+3,y+8,w-10,1,c.ink);b(x+3,y+12,w-8,1,c.ink);}
 function pot(x,y){b(x-4,y+1,11,8,c.grain);b(x-5,y,13,3,c.wood);b(x,y-7,3,9,c.green);b(x-6,y-7,7,4,c.green);b(x+3,y-10,7,4,c.lip);}
 function focusDetail(){if(focus){b(26,14,5,2,c.paper);b(-24,13,4,2,c.gold);}}
 const variant=Math.floor(Math.abs(Number(r.id)||0))%3;
 if(r.state==='retirement'&&!['director','support','cleanup','special-forces'].includes(role)){b(-8,-6,25,18,c.edge);b(-4,-9,17,14,c.metal);b(3,-6,3,8,c.ink);b(0,-3,9,3,c.ink);ctx.restore();return;}
 if(role==='director'){
  desk();for(let i=0;i<3;i++)screen(-25+i*19,-20,17,12);
  b(-6,3,26,5,c.edge);for(let i=0;i<6;i++)b(-4+i*4,4,2,2,c.metal);mug(24,1);disc(3,18,10,4,c.edge);
 }else if(role==='support'){
  cabinet(-23,-19,30,38);b(-19,-15,22,23,c.paper);b(-11,-11,5,15,c.red);b(-16,-6,15,5,c.red);
  b(14,1,19,15,c.edge);b(16,3,15,10,c.metal);b(21,0,6,3,c.grain);b(20,7,7,2,c.paper);b(23,4,2,7,c.paper);tool(22,-16,1);
 }else if(role==='world-requests'||/design|shaping|artist/.test(role)){
  desk();b(-20,-22,32,26,c.edge);b(-17,-20,26,20,c.paper);if(role==='world-requests'){b(-15,-6,22,4,c.green);b(-12,-15,12,7,c.blue);b(-2,-13,8,8,c.lip);}else{b(-14,-16,19,3,c.ink);b(-14,-10,8,6,c.blue);b(-3,-10,8,6,c.green);}
  b(-20,5,26,7,c.grain);for(let i=0;i<4;i++)disc(-16+i*6,8,2,2,[c.red,c.blue,c.green,c.gold][i]);b(20,-12,9,15,c.metal);l([[22,-10],[25,-22]],c.grain,2);l([[25,-10],[30,-19]],c.gold,2);pot(24,13);
 }else if(role==='cleanup'||/memory|clean/.test(role)){
  b(-24,13,28,5,c.shadow);b(-24,-10,23,23,c.edge);b(-21,-8,17,18,c.blue);disc(-12,-8,10,4,c.metal);disc(-12,-8,6,2,c.edge);
  l([[18,-23],[25,13]],c.lip,3);b(17,9,18,10,c.wood);b(18,10,2,9,c.gold);b(24,11,2,8,c.gold);cabinet(6,-7,15,19);
 }else if(role==='special-forces'||/defen|soldier/.test(role)){
  cabinet(-25,-11,58,29);b(-21,-8,50,3,c.green);b(-17,-20,23,20,c.edge);b(-14,-17,17,12,c.green);b(-17,-5,23,4,c.metal);
  poly(ctx,[[14,-18],[29,-15],[28,-1],[21,7],[14,0]],c.edge);poly(ctx,[[17,-15],[26,-13],[25,-2],[21,3],[17,-2]],c.green);b(20,-11,3,10,c.gold);
 }else if(/technical|repair|engineer/.test(role)&&!/test|qa/.test(role)){
  desk();screen(-22,-21,24,15);cabinet(10,-4,21,16);tool(16,-19,1);tool(-9,3,0);b(3,0,9,9,c.edge);b(5,2,5,5,c.metal);mug(-25,7);
 }else if(/develop|coding/.test(role)){
  desk();screen(-24,-21,29,18);screen(10,-16,21,14);b(-17,4,30,5,c.edge);for(let i=0;i<7;i++)b(-15+i*4,5,2,2,c.metal);mug(23,9);
 }else if(role==='optimizer'){
  desk();screen(-20,-21,29,17);b(16,-9,14,18,c.edge);disc(23,-1,5,5,c.metal);l([[20,-5],[26,3]],c.grain,2);l([[26,-5],[20,3]],c.grain,2);tool(-16,6,1);b(1,6,10,4,c.paper);
 }else if(role==='piper'||/analytic/.test(role)){
  desk();book(-24,-17,25,21,c.green);b(10,-18,21,19,c.edge);b(12,-16,17,13,c.wood);for(let i=0;i<3;i++){b(15+i*5,-14,1,10,c.grain);b(13+i*5,-11+(i%2)*4,5,3,c.gold);}mug(19,7);l([[-12,8],[5,6]],c.metal,2);
 }else if(role==='intake'||/request|triage/.test(role)){
  desk();b(-23,-7,29,20,c.grain);for(let i=0;i<3;i++){b(-22+i*2,-13+i*4,23,9,c.paper);l([[-20+i*2,-12+i*4],[-10+i*2,-8+i*4],[-1+i*2,-12+i*4]],c.ink,1);}b(17,4,14,6,c.edge);b(21,-6,6,13,c.wood);disc(24,-6,6,3,c.gold);
 }else if(/release|clos/.test(role)){
  desk();paper(-24,-19,26,19);b(13,-11,16,6,c.paper);b(16,-9,10,12,c.wood);b(12,1,18,5,c.red);disc(-12,12,7,4,c.gold);disc(-12,12,3,2,c.wood);l([[4,13],[24,10]],c.metal,2);
 }else if(/git|merg/.test(role)){
  desk();for(let i=0;i<3;i++)book(-23+i*12,-14+i*3,14,20,[c.green,c.blue,c.wood][i]);l([[18,-18],[18,0],[26,7]],c.metal,2);l([[18,-8],[29,-14]],c.metal,2);for(const[x,y]of [[18,-18],[29,-14],[26,7]]){disc(x,y,4,3,c.edge);disc(x,y,2,1,c.gold);}mug(-23,9);
 }else if(/research/.test(role)){
  desk();book(-24,-15,24,22,c.blue);b(-12,-13,1,17,c.grain);l([[15,-2],[24,-20]],c.wood,4);l([[12,-19],[30,-12]],c.metal,7);b(11,-21,5,7,c.edge);b(29,-14,4,7,c.paper);mug(19,8);
 }else if(/docs|document/.test(role)){
  desk();for(let i=0;i<4;i++){b(-24+i*8,-22,7,25,[c.green,c.wood,c.blue,c.red][i]);b(-22+i*8,-18,3,1,c.paper);}paper(7,-8,24,20);l([[18,5],[28,-13]],c.grain,2);b(23,-15,7,4,c.gold);
 }else if(/architect|plan|follow|delivery|dispatch|coordinator/.test(role)){
  desk();b(-24,-20,52,29,c.edge);b(-21,-18,46,23,c.blue);l([[-17,-12],[3,-12],[3,0],[18,0]],c.paper,2);l([[-17,-6],[-8,-6],[-8,3]],c.metal,2);b(-18,-14,4,4,c.gold);b(16,-2,4,4,c.gold);b(-23,12,47,3,c.lip);b(23,7,5,9,c.metal);if(/dispatch|delivery/.test(role)){paper(-20,3,17,10);b(12,5,12,6,c.grain);}else if(/follow/.test(role)){b(12,-14,10,3,c.gold);b(14,-10,6,12,c.paper);b(12,2,10,3,c.gold);}else if(/coordinator/.test(role))screen(2,-18,24,14);else if(/architect/.test(role))l([[-13,6],[8,-11],[15,5]],c.gold,2);
 }else if(/qa|test|review|native-operator/.test(role)){
  desk();b(-22,-20,25,30,c.grain);paper(-20,-17,21,23);b(-15,-21,11,5,c.metal);disc(17,-6,8,8,c.edge);disc(17,-6,5,5,c.metal);l([[22,0],[31,11]],c.wood,4);mug(-24,10);
 }else{
  desk();cabinet(-24,-8,28,20);tool(11-(Math.floor(Math.abs(Number(r.id)||0)/3)%3)*3,-18,variant);book(12,2,17,15,[c.green,c.blue,c.wood][variant]);if(variant===1)pot(-19,12);else mug(-23+(Math.floor(Math.abs(Number(r.id)||0)/3)%3)*3,11);
 }
 focusDetail();ctx.restore();
}

function drawRain(e){if(!e.raining&&!e.snowing&&e.weather!=='rain'&&e.weather!=='snow')return;ctx.save();ctx.beginPath();ctx.rect(0,0,1600,307);ctx.clip();for(const r of rain){const snow=e.snowing||e.weather==='snow'||e.season==='winter'&&e.raining,x=(r.x-time*(snow?8:28)+32000)%1700-50,y=(r.y+time*r.speed*(snow?.2:1))%330;if(snow)box(ctx,x+Math.sin(time+r.x)*4,y,3,3,'#b9d0c39a');else line(ctx,[[x,y],[x-3,y+r.len]],'#adc5ca44',2);}if(!e.snowing&&e.weather!=='snow'&&e.season!=='winter')for(let i=0;i<35;i++){const a=(time*1.3+i*.137)%1,x=(i*113)%1590,y=245+(i*17)%53;ctx.globalAlpha=(1-a)*.35;line(ctx,[[x-3-a*5,y],[x+3+a*5,y]],'#a8c0b1',2);}ctx.restore();ctx.globalAlpha=1;}


function paintPool(g,p,t,environment={},seasonalWaterTreatment=seasonalWorld.seasonalWaterTreatment){ctx=g;time=t;paintWoodlandContactShadow(ctx,{x:p.x,y:p.y+p.ry*.62,width:p.rx*2.1,height:Math.max(3,p.ry*.34)},environment);oval(ctx,p.x,p.y,p.rx+5,p.ry+4,'#34372d');paintPineWaterMaterial(g,pinePoolContour(p),{kind:'pool',environment,time:t,pixel:Math.max(.5,p.ry/8),scale:p.ry/10,seasonalWaterTreatment});}
function paintGem(g,x,y,r,color,hits){ctx=g;oval(ctx,x,y,r+4,(r+4)*.75,'#32362b');poly(ctx,[[x-r-2,y-4],[x-r*.7,y-r*.7-2],[x+r*.65,y-r*.8],[x+r+4,y+2],[x+r*.4,y+r*.7],[x-r*.7,y+r*.7]],'#736d50');poly(ctx,[[x-r,y-3],[x-r*.5,y-r*.67],[x+r*.55,y-r*.64],[x+r,y+1],[x+r*.4,y+r*.58],[x-r*.7,y+r*.56]],color);poly(ctx,[[x-r,y-3],[x-2,y-3],[x+r*.55,y-r*.64],[x-r*.5,y-r*.67]],'#ccd0b38c');for(let i=0;i<Math.min(18,hits*3);i++){const a=i*2.399;line(ctx,[[x+Math.cos(a+.8)*r*.1,y+Math.sin(a+.8)*r*.1],[x+Math.cos(a+.25)*r*.48,y+Math.sin(a+.25)*r*.38],[x+Math.cos(a)*r*.86,y+Math.sin(a)*r*.56]],'#303d30',2.3);}}
function paintAmbulance(g,p,t,fire=false){ctx=g;time=t;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(Math.atan2(p.dy||0,p.dx||1)+Math.PI/2);oval(ctx,0,3,16,24,'#292f28');for(const y of[-18,11]){box(ctx,-15,y,5,10,'#263632');box(ctx,10,y,5,10,'#263632');}box(ctx,-11,-25,22,48,fire?'#a9654a':'#d4d8bd');box(ctx,-9,-19,18,11,'#678f91');box(ctx,-3,-1,6,15,'#b55e52');box(ctx,-7,3,14,6,'#b55e52');box(ctx,-10,-7,8,4,Math.sin(time*5)>0?'#cf8770':'#896d58');box(ctx,2,-7,8,4,Math.sin(time*5)<0?'#94b8bc':'#6b8686');ctx.restore();}
return{paintDistant,ready:reference.ready,loaded:()=>reference.state==='ready',artStatus:()=>({state:reference.state,source:reference.source,fontReady:reference.fontReady,error:reference.error||null}),paintBackdrop(g,e,t,p,percent,beforeNearTrees){ctx=g;time=t;seasonState=appearanceFor(e,t);pointer=p;growth=typeof percent==='number'&&Number.isFinite(percent)&&percent>=0&&percent<=100?percent:null;drawExterior(e,beforeNearTrees);},paintTree(g,e,t,percent,x,y,scale){ctx=g;time=t;seasonState=appearanceFor(e,t);growth=typeof percent==='number'&&Number.isFinite(percent)&&percent>=0&&percent<=100?percent:null;ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.translate(-1410,-286);drawGrowthTree(e);ctx.restore();},paintNearTrees(g,e,t){ctx=g;time=t;drawNearTrees(e);},paintLandscape,paintPerson:drawPerson,paintForeground(g,e,t,{surfaceGrass=true}={}){ctx=g;time=t;if(surfaceGrass)drawSurfaceGrass(e);drawRain(e);},paintPatch(g,r){ctx=g;const random=seeded(r.seed);for(const [scale,alpha,color]of[[1.1,.24,'#77705a'],[1.03,.32,'#79715a'],[.93,.30,'#756a52']]){ctx.globalAlpha=alpha;poly(ctx,patchPoints(r,scale),color);}ctx.globalAlpha=1;for(let i=0;i<120;i++){const a=random()*Math.PI*2,d=Math.sqrt(random()),x=r.x+Math.cos(a)*r.rx*d*.9,y=r.y+Math.sin(a)*r.ry*d*.9;box(ctx,x,y,random()<.2?4:2,2,random()<.5?'#625942':'#4b4636');}},paintRoom(g,r,t){ctx=g;time=t;const f=r.artScale||r.h/72;ctx.save();ctx.translate(r.x+r.w/2,r.y+r.h/2);ctx.scale(f,f);props({...r,x:0,y:0,rx:r.w/(2*f),ry:36});ctx.restore();},paintNest(g,bed,id,f=1){ctx=g;ctx.save();ctx.translate(bed.x,bed.y);ctx.scale(f,f);nest({x:0,y:-5,rx:0,id});ctx.restore();},paintPool,paintGem,paintAmbulance};}
return{create,treeState,provideReferenceAssets,geometry,surface,layout,fitLayout,landscapeLayout:woodlandShore.buildPineShoreLayout,ambient:woodlandAmbient};});
