// Compiled with the real context validator, operator viewport and qualified
// WorldAudio by the owner-site builder. No frame asset may select another URL.
const frameClosed=(v,keys)=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const frameCommon=['type','worldId','epoch','nonce','controlRevision'];
const frameShape={
 'alife-project-world-request':frameCommon,
 'alife-world-controls':[...frameCommon,'mode','paused','volume'],
 'alife-world-capture-request':frameCommon,
 'alife-world-restore-request':[...frameCommon,'capsule'],
 'alife-world-frame-commit':frameCommon,
 'alife-world-frame-dispose':frameCommon
};
const frameSameRenderer=(a,b)=>a&&b&&['schemaVersion','bundleId','worldVersion','artifactSha256'].every(k=>a[k]===b[k]);
const frameScopeKey=v=>v===null?null:[v.worldKey,v.artKey,v.audienceKey].join('|');
function frameFault(message,revoked=false){const error=new Error(message);error.revoked=revoked;return error;}

export function createOwnerFrameClient({
 windowRef=window,documentRef=document,fetcher=(...args)=>fetch(...args),importModule=url=>import(url),
 validateContext=assertOwnerCandidateFrameContext,createViewport=createOwnerOperatorViewport,
 loadStyle=null,now=Date.now,fetchTimeoutMs=8000,resourceTimeoutMs=15000,pollMs=5000,maxBackoffMs=30000
}={}){
 if(windowRef.parent===windowRef||typeof validateContext!=='function'||typeof createViewport!=='function')throw Error('Owned frame collaborators required');
 const origin=windowRef.location.origin,meta=documentRef.querySelector('meta[name="alife-owner-context"]');
 const contextURL=new URL(meta?.getAttribute('content')||'',origin);
 const path=/^\/world-frame\/([a-f0-9]{64})\/context$/.exec(contextURL.pathname);
 if(!meta||!path||contextURL.origin!==origin||contextURL.search||contextURL.hash||contextURL.username||contextURL.password||windowRef.location.pathname!==contextURL.pathname.slice(0,-7)||windowRef.location.search||windowRef.location.hash)throw Error('Exact pinned context meta required');
 const versionMeta=documentRef.querySelector('meta[name="alife-world-version"]'),versionText=versionMeta?.getAttribute('content');
 if(typeof versionText!=='string'||versionText.length>64||versionText!==''&&!/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(versionText))throw Error('Server-authored actual world version required');
 const actualWorldVersion=versionText===''?null:versionText;
 if(![fetchTimeoutMs,resourceTimeoutMs,pollMs,maxBackoffMs].every(v=>Number.isFinite(v)&&v>=10&&v<=60000))throw Error('Bounded frame timing required');
 let context=null,farm=null,viewport=null,main=null,status=null,booted=false,started=false,disposed=false,revoked=false,active=false,activationHint=false;
 let binding=null,queuedBinding=null,desiredControls=null,generation=0,controlsApplied=-1,renderedGeneration=-1,sourceAvailable=false;
 let knownWorldKey=null,queue=[],commands=Promise.resolve(),bootstrapPromise=null,bootstrapFailed=false,refreshPromise=null,refreshWanted=false;
 let pollTimer=null,retryTimer=null,resourceTimer=null,fetchController=null,failures=0,bootstrapFailures=0,restoreAttempt=null;
 let savedAudio=null,audioWrapped=false,ownedStyle=null,cancelWait=null;
 const correlation=d=>[d.worldId,d.epoch,d.nonce,d.controlRevision].join('|');
 const current=d=>!disposed&&!revoked&&binding&&correlation(d)===correlation(binding)&&(!context||d.worldId===context.worldId);
 function text(value){if(status){status.textContent=value;status.hidden=!value;}}
 function resources(){try{const r=farm?.getResourceStatus?.();return frameClosed(r,['ready','art','font','disposed'])&&typeof r.ready==='boolean'&&typeof r.art==='string'&&typeof r.font==='string'&&typeof r.disposed==='boolean'?r:null;}catch{return null;}}
 const resourcesReady=()=>{const r=resources();return!!r&&r.ready===true&&r.art==='ready'&&r.font==='ready'&&r.disposed===false;};
 function actualControls(){try{const v=viewport?.controlsState?.();return v&&['public','private','view'].includes(v.mode)&&typeof v.paused==='boolean'&&typeof v.volume==='number'&&Number.isFinite(v.volume)&&v.volume>=0&&v.volume<=1&&typeof v.soundEnabled==='boolean'?v:null;}catch{return null;}}
 function controlsMatch(){const v=actualControls(),d=desiredControls;return!!d&&!!v&&v.mode===d.mode&&v.paused===d.paused&&v.volume===d.volume&&(active||v.soundEnabled===false);}
 function receipt(){
  if(!booted||!sourceAvailable||!binding||controlsApplied!==generation||renderedGeneration!==generation||!controlsMatch()||!resourcesReady())return null;
  const r=viewport?.renderReceipt?.(),p=r?.preview,j=r?.joined,age=now()-Date.parse(p?.snapshot?.observedUtc);
  return p&&j&&j.snapshot===p.snapshot&&p.worldId===context.worldId&&p.snapshot?.world?.id===context.worldId&&frameSameRenderer(p.renderer,context.renderer)&&p.snapshot.feed?.error===null&&j.feed?.error===null&&Number.isFinite(age)&&age>=-5000&&age<=45000?r:null;
 }
 function rawPost(value){if(disposed||revoked||!context||!binding)return false;windowRef.parent.postMessage(value,context.ownerOrigin);return true;}
 function resourceReply(){const r=resources();if(!r)return false;return rawPost({type:'alife-world-resource-state',...binding,renderer:context.renderer,resources:r,receiverReady:receipt()!==null});}
 function reply(type,extra={}){if(!resourceReply())return false;return rawPost({type,...binding,...extra});}
 function publish(){if(!binding||!context||!resourceReply())return false;const r=receipt();return rawPost({type:'alife-project-world-preview',...binding,receivedUtc:new Date(now()).toISOString(),preview:r?.preview??null,joined:r?.joined??null});}
 function clearTimers(){for(const id of [pollTimer,retryTimer,resourceTimer])if(id!==null)windowRef.clearTimeout(id);pollTimer=retryTimer=resourceTimer=null;cancelWait?.();cancelWait=null;}
 function clearRuntime(){try{viewport?.dispose();}catch{}try{farm?.destroy();}catch{}if(farm?.host){farm.host.hidden=true;farm.host.replaceChildren();}viewport=null;farm=null;ownedStyle?.remove();ownedStyle=null;if(audioWrapped&&savedAudio)windowRef.WorldAudio=savedAudio;audioWrapped=false;savedAudio=null;}
 function clearPrivate(){sourceAvailable=false;renderedGeneration=-1;controlsApplied=-1;desiredControls=null;queue=[];restoreAttempt=null;refreshWanted=false;clearRuntime();}
 function invalidate(message){if(disposed||revoked)return;revoked=true;active=false;activationHint=false;generation++;fetchController?.abort();clearTimers();clearPrivate();text(message||'World access could not be verified.');}
 function unavailable(message='World updates unavailable. Retaining the last scene.'){
  if(disposed||revoked)return;sourceAvailable=false;renderedGeneration=-1;
  try{const held=viewport?.cachedInput?.();viewport?.unavailable();if(held)farm.render(held.model,{...held.feed,error:'World updates unavailable.'},{sprint:held.snapshot.summary?.current,epic:held.snapshot.summary?.epic});}catch{}
  text(message);publish();
 }
 async function jsonAt(url,limit){
  const u=new URL(url,origin);if(u.origin!==origin||u.search||u.hash||u.username||u.password)throw frameFault('Pinned source changed',true);
  const controller=new AbortController();fetchController=controller;const timer=windowRef.setTimeout(()=>controller.abort(),fetchTimeoutMs);
  try{
   const response=await fetcher(u.href,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',headers:{Accept:'application/json'},signal:controller.signal});
   if(response.status===401||response.status===403)throw frameFault('World access unavailable',true);
   if(!response.ok)throw frameFault('World source unavailable');
   if(response.url&&new URL(response.url).origin!==origin)throw frameFault('Source origin changed',true);
   if(!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')||''))throw frameFault('World context could not be verified',true);
   const reader=response.body?.getReader();if(!reader)throw frameFault('World body unavailable');const chunks=[];let size=0;
   try{while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>limit){await reader.cancel();throw frameFault('World body exceeds its limit');}chunks.push(part.value);}}finally{reader.releaseLock();}
   const bytes=new Uint8Array(size);let offset=0;for(const part of chunks){bytes.set(part,offset);offset+=part.byteLength;}return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
  }finally{windowRef.clearTimeout(timer);if(fetchController===controller)fetchController=null;}
 }
 function checkContext(value,initial=false){
  let next;try{next=validateContext(value,{worldId:context?.worldId??value?.worldId,access:context?.access??value?.access,ownerOrigin:origin,renderer:context?.renderer??{...value?.renderer,artifactSha256:path[1]}});}catch{throw frameFault('Exact world context changed',true);}
  if(next.renderer.artifactSha256!==path[1])throw frameFault('Pinned renderer changed',true);
  if(!initial&&context.visualStateScope!==null){if(next.visualStateScope===null)throw frameFault('World identity temporarily unavailable');if(frameScopeKey(next.visualStateScope)!==frameScopeKey(context.visualStateScope))throw frameFault('World or audience identity changed',true);}
  if(knownWorldKey&&next.visualStateScope?.worldKey&&knownWorldKey!==next.visualStateScope.worldKey)throw frameFault('World identity changed',true);
  return next;
 }
 function ensureDOM(){
  main=documentRef.querySelector('main');if(!main){main=documentRef.createElement('main');documentRef.body.append(main);}
  let host=documentRef.getElementById('world-anchor');if(!host){host=documentRef.createElement('div');host.id='world-anchor';main.append(host);}
  status=documentRef.getElementById('world-profile-status');if(!status){status=documentRef.createElement('p');status.id='world-profile-status';status.setAttribute('role','status');main.append(status);}return host;
 }
 async function stylesheet(href){
  if(loadStyle)return loadStyle(href);
  await new Promise((resolve,reject)=>{const link=documentRef.createElement('link');ownedStyle=link;link.rel='stylesheet';link.href=href;const finish=error=>{windowRef.clearTimeout(timer);cancelWait=null;link.onload=link.onerror=null;if(error){link.remove();reject(error);}else resolve();};const timer=windowRef.setTimeout(()=>finish(frameFault('Selected style unavailable')),resourceTimeoutMs);cancelWait=()=>finish(frameFault('Frame disposed'));link.onload=()=>finish();link.onerror=()=>finish(frameFault('Selected style unavailable'));documentRef.head.append(link);});
 }
 async function selectedImport(url){
  await new Promise((resolve,reject)=>{
   let settled=false;
   const finish=error=>{if(settled)return;settled=true;windowRef.clearTimeout(timer);if(cancelWait===cancel)cancelWait=null;if(error)reject(error);else resolve();};
   const cancel=()=>finish(frameFault('Frame disposed'));
   const timer=windowRef.setTimeout(()=>finish(frameFault('Selected module unavailable')),resourceTimeoutMs);cancelWait=cancel;
   Promise.resolve().then(()=>importModule(url)).then(()=>finish(),finish);
  });
 }
 function wrapAudio(){
  const audio=windowRef.WorldAudio;if(!audio||typeof audio.createSamplePlayer!=='function'||!audio.SAMPLE_FILES)throw frameFault('Qualified bundled audio unavailable');
  const names=new Set(Object.values(audio.SAMPLE_FILES));if([...names].some(n=>typeof n!=='string'||!/^[a-z0-9-]+\.mp3$/.test(n)))throw frameFault('Qualified audio sample list required');
  savedAudio=audio;windowRef.WorldAudio={...audio,createSamplePlayer(options={}){return audio.createSamplePlayer({...options,fetcher:(input,init={})=>{const requested=new URL(String(input),origin),name=requested.pathname.split('/').at(-1);if(requested.origin!==origin||requested.search||requested.hash||!names.has(name)||!requested.pathname.endsWith('/assets/audio/'+name))return Promise.reject(frameFault('Unqualified audio sample'));const selected=new URL(context.resourceBase+'assets/audio/'+name,origin);return fetcher(selected.href,{...init,credentials:'same-origin',redirect:'error'});}});}};audioWrapped=true;
 }
 async function waitResources(){
  const start=now();while(!disposed&&!revoked){const r=resources();if(resourcesReady())return;if(!r||r.disposed||r.art==='fallback'||r.font==='fallback'||now()-start>resourceTimeoutMs)throw frameFault('Selected art or font unavailable');await new Promise(resolve=>{cancelWait=()=>{cancelWait=null;resolve();};resourceTimer=windowRef.setTimeout(()=>{resourceTimer=null;cancelWait=null;resolve();},50);});}throw frameFault('Frame disposed');
 }
 function nextPollDelay(){
  if(failures)return Math.min(maxBackoffMs,pollMs*2**failures);
  const health=viewport?.renderReceipt?.()?.joined?.feed?.agentHealth;
  return health?.some(agent=>agent.activityState==='waiting'&&agent.needsHumanInput===true)?Math.min(1500,pollMs):pollMs;
 }
 function schedulePoll(delay=nextPollDelay()){if(pollTimer!==null)windowRef.clearTimeout(pollTimer);pollTimer=null;if(!active||disposed||revoked||documentRef.hidden)return;pollTimer=windowRef.setTimeout(()=>{pollTimer=null;void refresh();},delay);}
 async function refreshRead(token){
  checkContext(await jsonAt(contextURL.href,32768));
  const preview=await jsonAt(context.snapshotPath,1024*1024);
  if(disposed||revoked||token!==generation)return false;
  if(preview?.worldId!==context.worldId||preview?.snapshot?.world?.id!==context.worldId||!frameSameRenderer(preview?.renderer,context.renderer))throw frameFault('Snapshot identity changed',true);
  const key=preview.snapshot?.model?.visualWorldKey;
  if(knownWorldKey&&key&&key!==knownWorldKey||context.visualStateScope?.worldKey&&key!==context.visualStateScope.worldKey)throw frameFault('Snapshot world identity changed',true);
  if(key)knownWorldKey=key;
  const input=await viewport.resolve(preview);if(disposed||revoked||token!==generation)return false;if(!input)throw frameFault('World input unavailable');
  if(!resourcesReady())throw frameFault('Selected resources not ready');
  farm.render(input.model,input.feed,{sprint:input.snapshot.summary?.current,epic:input.snapshot.summary?.epic});
  if(viewport.rendered(input)!==true)throw frameFault('Actual world render was not acknowledged');
  const actual=viewport.renderReceipt?.();if(!actual||actual.preview!==preview||actual.joined!==input)throw frameFault('Actual rendered receipt required');
  sourceAvailable=true;renderedGeneration=token;failures=0;text('');publish();return true;
 }
 function refresh(){
  if(!booted||disposed||revoked)return Promise.resolve(false);refreshWanted=true;if(refreshPromise)return refreshPromise;if(pollTimer!==null)windowRef.clearTimeout(pollTimer);pollTimer=null;
  refreshPromise=(async()=>{let result=false;while(refreshWanted&&!disposed&&!revoked){refreshWanted=false;const token=generation;try{result=await refreshRead(token);}catch(error){if(disposed||revoked)break;if(error.revoked){invalidate(error.message);break;}if(token===generation){failures=Math.min(6,failures+1);unavailable();}}}return result;})().finally(()=>{refreshPromise=null;schedulePoll();});return refreshPromise;
 }
 function validMessage(data){
  if(!data||!frameShape[data.type]||!frameClosed(data,frameShape[data.type])||typeof data.worldId!=='string'||!/^[a-z][a-z0-9-]{0,63}$/.test(data.worldId)||!Number.isSafeInteger(data.epoch)||data.epoch<1||typeof data.nonce!=='string'||!/^[A-Za-z0-9_-]{16,128}$/.test(data.nonce)||!Number.isSafeInteger(data.controlRevision)||data.controlRevision<0)return false;
  if(data.type==='alife-world-controls'&&(!['public','private','view'].includes(data.mode)||typeof data.paused!=='boolean'||typeof data.volume!=='number'||!Number.isFinite(data.volume)||data.volume<0||data.volume>1))return false;
  if(data.type==='alife-world-restore-request'){try{if(data.capsule!==null&&(typeof data.capsule!=='object'||Array.isArray(data.capsule))||new TextEncoder().encode(JSON.stringify(data.capsule)).byteLength>131072)return false;}catch{return false;}}
  return true;
 }
 function adopt(data){
  if(context&&data.worldId!==context.worldId)return false;
  if(binding){if(data.epoch<binding.epoch||data.epoch===binding.epoch&&(data.nonce!==binding.nonce||data.controlRevision<binding.controlRevision))return false;if(correlation(data)===correlation(binding))return true;}
  if(!['alife-world-controls','alife-project-world-request','alife-world-frame-commit'].includes(data.type))return false;
  binding={worldId:data.worldId,epoch:data.epoch,nonce:data.nonce,controlRevision:data.controlRevision};generation++;controlsApplied=-1;renderedGeneration=-1;desiredControls=null;return true;
 }
 async function command(data,token){
  if(!current(data)||token!==generation)return;
  if(data.type==='alife-world-controls'){
   if(typeof viewport.applyControls!=='function')throw frameFault('Direct controls application unavailable');
   const applied=await viewport.applyControls({mode:data.mode,paused:data.paused,volume:data.volume});if(!current(data)||token!==generation)return;
   if(!frameClosed(applied,['mode','paused','volume','soundEnabled'])||applied.mode!==data.mode||applied.paused!==data.paused||applied.volume!==data.volume||typeof applied.soundEnabled!=='boolean'||!active&&applied.soundEnabled!==false||!controlsMatch())throw frameFault('Actual controls did not match');controlsApplied=token;renderedGeneration=-1;reply('alife-world-controls-applied');await refresh();return;
  }
  if(data.type==='alife-project-world-request'){if(!receipt())await refresh();if(current(data)&&token===generation)publish();return;}
  if(data.type==='alife-world-capture-request'){
   const result=context.visualStateScope===null?{captured:false,reason:'context-unavailable',capsule:null}:!receipt()?{captured:false,reason:'not-ready',capsule:null}:typeof farm.captureVisualState==='function'?farm.captureVisualState():{captured:false,reason:'unsupported',capsule:null};
   if(!frameClosed(result,['captured','reason','capsule'])||typeof result.captured!=='boolean'||typeof result.reason!=='string'||result.captured===false&&result.capsule!==null)throw frameFault('Actual capture result unavailable');
   if(current(data)&&token===generation)reply('alife-world-capture-result',{result});return;
  }
  if(data.type==='alife-world-restore-request'){
   if(refreshPromise)await refreshPromise;if(!current(data)||token!==generation)return;
   if(controlsApplied!==token||!resourcesReady()||!viewport.renderReceipt?.())throw frameFault('Restore receiver not ready');
   const identity=JSON.stringify(data.capsule),key=correlation(data);
   if(restoreAttempt){if(restoreAttempt.key!==key||restoreAttempt.identity!==identity||!restoreAttempt.result)throw frameFault('A different restore was already attempted');reply('alife-world-restore-result',{result:restoreAttempt.result});renderedGeneration=token;publish();return;}
   restoreAttempt={key,identity,result:null};renderedGeneration=-1;
   const result=typeof farm.restoreVisualState==='function'?await farm.restoreVisualState(data.capsule):{applied:false,reason:'unsupported'};
   const keys=result&&Object.hasOwn(result,'actors')?['applied','reason','actors']:['applied','reason'];
   if(!frameClosed(result,keys)||typeof result.applied!=='boolean'||typeof result.reason!=='string'||Object.hasOwn(result,'actors')&&(!Number.isSafeInteger(result.actors)||result.actors<0||result.actors>100))throw frameFault('Actual restore result unavailable');
   restoreAttempt.result=result;if(!current(data)||token!==generation)return;
   reply('alife-world-restore-result',{result});
   // World restore draws synchronously; the getter identifies the actual input
   // currently rendered after that draw, including a legitimately newer input.
   renderedGeneration=token;publish();return;
  }
 }
 function receiveData(data){
  if(disposed||revoked||!validMessage(data)||data.worldId!==context?.worldId||!adopt(data))return;
  const token=generation;
  if(data.type==='alife-world-frame-dispose'){dispose();return;}
  if(data.type==='alife-world-frame-commit'){active=true;activationHint=true;schedulePoll(viewport?.renderReceipt?.()?pollMs:0);return;}
  if(data.type==='alife-world-controls'){
   if(desiredControls){if(['mode','paused','volume'].some(k=>desiredControls[k]!==data[k]))return;if(controlsApplied===token&&controlsMatch()){reply('alife-world-controls-applied');publish();return;}}
   desiredControls={mode:data.mode,paused:data.paused,volume:data.volume};farm.setPresentationMode(data.mode);
  }
  commands=commands.then(()=>command(data,token)).catch(error=>{if(error.revoked)invalidate(error.message);else if(current(data)&&token===generation)unavailable('World controls or transfer could not be confirmed.');});
 }
 function message(event){
  if(disposed||revoked||event.source!==windowRef.parent||event.origin!==origin||!validMessage(event.data))return;
  if(!booted){
   const data=event.data;if(context&&data.worldId!==context.worldId)return;
   // Parent cancellation must end an unfinished import/resource wait promptly.
   // When a challenge is known, only that latest exact lifetime may dispose it.
   if(data.type==='alife-world-frame-dispose'){if(queuedBinding&&correlation(data)!==correlation(queuedBinding))return;dispose();return;}
   if(['alife-world-controls','alife-project-world-request','alife-world-frame-commit'].includes(data.type)){
    if(queuedBinding&&(data.worldId!==queuedBinding.worldId||data.epoch<queuedBinding.epoch||data.epoch===queuedBinding.epoch&&(data.nonce!==queuedBinding.nonce||data.controlRevision<queuedBinding.controlRevision)))return;
    queuedBinding={worldId:data.worldId,epoch:data.epoch,nonce:data.nonce,controlRevision:data.controlRevision};
   }
   if(data.type==='alife-world-frame-commit')activationHint=true;if(queue.length>=16)queue.shift();queue.push(data);if(bootstrapFailed&&activationHint)scheduleBootstrapRetry();return;
  }receiveData(event.data);
 }
 async function bootstrap(){
  context=checkContext(await jsonAt(contextURL.href,32768),true);if(disposed||revoked)return false;
  const css=new URL(context.resourceBase+'agent-outpost/agent-outpost.css',origin).href;await stylesheet(css);if(disposed||revoked)return false;
  await selectedImport(new URL(context.resourceBase+'agent-outpost/colony-art.js',origin).href);if(disposed||revoked)return false;
  await selectedImport(new URL(context.resourceBase+'agent-outpost/agent-outpost.js',origin).href);if(disposed||revoked)return false;
  wrapAudio();const host=ensureDOM();
  farm=windowRef.AgentOutpost?.mount(host,{roomLabelPlacement:'below-room',cameraControls:true,defaultWorld:true,publicTitle:documentRef.title,cosmeticOnly:true,operatorPresentation:true,presentationMode:'view',fillViewport:true,transparentBackground:true,visualStateScope:context.visualStateScope});
  if(!farm?.host||typeof farm.getResourceStatus!=='function')throw frameFault('Actual world resource surface unavailable');
  farm.setAudioPreferenceKey?.(context.worldId);farm.setPresentationMode('view');
  viewport=createViewport({farm,context:{...context,worldVersion:actualWorldVersion},pinnedFrame:true,windowRef,documentRef,now,onRendered(){}});
  if(typeof viewport?.renderReceipt!=='function'||typeof viewport?.controlsState!=='function')throw frameFault('Actual viewport receipt/control surfaces unavailable');
  await waitResources();if(disposed||revoked)return false;booted=true;bootstrapFailed=false;bootstrapFailures=0;
  const pending=queue;queue=[];for(const data of pending)receiveData(data);await commands;if(!viewport.renderReceipt?.())await refresh();return true;
 }
 function scheduleBootstrapRetry(){if(retryTimer!==null||disposed||revoked||!activationHint)return;bootstrapFailures=Math.min(6,bootstrapFailures+1);retryTimer=windowRef.setTimeout(()=>{retryTimer=null;bootstrapPromise=null;void start();},Math.min(maxBackoffMs,1000*2**bootstrapFailures));}
 function start(){
  if(disposed||revoked)return Promise.resolve(false);if(bootstrapPromise)return bootstrapPromise;
  if(!started){started=true;windowRef.addEventListener('message',message);windowRef.addEventListener('pagehide',dispose,{once:true});documentRef.addEventListener?.('visibilitychange',visibility);}
  bootstrapPromise=bootstrap().catch(error=>{if(disposed||revoked)return false;if(error.revoked){invalidate(error.message);return false;}bootstrapFailed=true;clearRuntime();text('World loading unavailable.');scheduleBootstrapRetry();return false;});return bootstrapPromise;
 }
 function visibility(){if(documentRef.hidden){if(pollTimer!==null)windowRef.clearTimeout(pollTimer);pollTimer=null;fetchController?.abort();}else if(active)schedulePoll(0);}
 function dispose(){if(disposed)return;disposed=true;active=false;activationHint=false;generation++;fetchController?.abort();clearTimers();windowRef.removeEventListener('message',message);windowRef.removeEventListener('pagehide',dispose);documentRef.removeEventListener?.('visibilitychange',visibility);clearPrivate();binding=queuedBinding=null;context=null;}
 return Object.freeze({start,refresh,dispose,context:()=>context,state:()=>({booted,active,disposed,revoked,pendingMessages:queue.length,pollScheduled:pollTimer!==null,requestInFlight:fetchController!==null,refreshInFlight:refreshPromise!==null,receiverReady:receipt()!==null})});
}

if(typeof window!=='undefined'&&typeof document!=='undefined'&&document.querySelector('meta[name="alife-owner-context"]')){
 const ownedFrameClient=createOwnerFrameClient();void ownedFrameClient.start();
}
