export function planetLayout(projects){
 const n=projects.length;if(n===1)return[{...projects[0],x:50,y:50}];
 const cols=Math.ceil(Math.sqrt(n)),rows=Math.ceil(n/cols),hash=s=>[...s].reduce((a,c)=>(a*31+c.charCodeAt(0))>>>0,2166136261);
 return projects.map((p,i)=>{const h=hash(p.id);return{...p,x:((i%cols+.5)+((h%100)/100-.5)*.22)*100/cols,y:((Math.floor(i/cols)+.5)+(((h>>>8)%100)/100-.5)*.22)*100/rows};});
}
export function matchingProject(registry,id){return registry?.projects.find(p=>p.id===id)||null;}

// One parent-owned mixer; previews can only emit bounded cues for their exact registered world.
export function createWorldAudioBridge({parentOrigin,getEnabled,canPlay,cue,now=()=>performance.now()}){const frames=new Map();let lastCue=-Infinity;const enabled=()=>getEnabled()===true&&canPlay()===true;function send(source,binding){source.postMessage({type:'alife-sound-state',worldId:binding.worldId,enabled:enabled()},binding.origin);}return{register(source,{origin,worldId}){const u=new URL(origin);if(u.origin!==origin||!['http:','https:'].includes(u.protocol)||!(origin===parentOrigin||['127.0.0.1','localhost','[::1]'].includes(u.hostname))||!/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/.test(worldId))throw Error('Invalid preview audio binding');frames.set(source,{origin,worldId});send(source,frames.get(source));},unregister(source){const binding=frames.get(source);if(binding){source.postMessage({type:'alife-sound-state',worldId:binding.worldId,enabled:false},binding.origin);frames.delete(source);}},clear(){for(const[source,binding]of frames)source.postMessage({type:'alife-sound-state',worldId:binding.worldId,enabled:false},binding.origin);frames.clear();},broadcast(){for(const[source,binding]of frames)send(source,binding);},handle(event){const b=frames.get(event.source),d=event.data;if(!b||event.origin!==b.origin||!d||d.worldId!==b.worldId)return false;if(d.type==='alife-world-ready'){send(event.source,b);return true;}if(d.type!=='alife-world-cue'||!enabled()||!['hit','break','step','stone','water','grass','ui'].includes(d.key)||Object.keys(d).some(k=>!['type','worldId','key','pan','volume','rate'].includes(k))||!Number.isFinite(d.pan)||!Number.isFinite(d.volume)||!Number.isFinite(d.rate)||d.pan< -1||d.pan>1||d.volume<0||d.volume>.35||d.rate<.5||d.rate>2)return false;const time=now();if(time-lastCue<70)return false;lastCue=time;return cue(d.key,{pan:d.pan,volume:d.volume,rate:d.rate})===true;}};}

const ownerClosed=(v,fields)=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===fields.length&&fields.every(k=>Object.hasOwn(v,k));
const ownerAlias=v=>typeof v==='string'&&/^[a-z][a-z0-9-]{0,63}$/.test(v);
const ownerProject=v=>typeof v==='string'&&v===v.trim()&&v.length>0&&v.length<=256&&!/[\x00-\x1f\x7f]/.test(v);
const ownerWorld=v=>typeof v==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/.test(v);
const ownerName=v=>typeof v==='string'&&v===v.trim()&&v.length>0&&v.length<=160&&!/[\\/<>:\x00-\x1f\x7f]/.test(v);
const ownerPreview=v=>['supported','unsupported','unconfirmed'].includes(v);
export function assertOwnerWorldInventory(value,{projectId}={}){
 if(!ownerClosed(value,['schemaVersion','kind','source','status','currentId','projectId','worldId','projects'])||value.schemaVersion!==1||value.kind!=='owner-world-projects'||!ownerProject(value.projectId)||!ownerWorld(value.worldId)||projectId&&value.projectId!==projectId||!Array.isArray(value.projects)||value.projects.length>32||new TextEncoder().encode(JSON.stringify(value)).length>65536)throw Error('Invalid private world inventory');
 const states={'launcher-profile':'configured','legacy-config':'legacy',unavailable:'unavailable'};
 if(!Object.hasOwn(states,value.source)||states[value.source]!==value.status)throw Error('Invalid private world inventory');
 const seen={id:new Set(),projectId:new Set(),worldId:new Set()};
 for(const row of value.projects){
  if(!ownerClosed(row,['id','name','projectId','worldId','availability','preview'])||!ownerAlias(row.id)||!ownerName(row.name)||!ownerProject(row.projectId)||!ownerWorld(row.worldId)||!['unconfirmed','unavailable'].includes(row.availability)||!ownerPreview(row.preview))throw Error('Invalid private world row');
  for(const key of Object.keys(seen)){if(seen[key].has(row[key]))throw Error('Ambiguous private worlds');seen[key].add(row[key]);}
 }
 if(value.status==='unavailable'){if(value.currentId!==null||value.projects.length)throw Error('Invalid unavailable inventory');}
 else{const current=value.projects.find(row=>row.id===value.currentId);if(!current||current.projectId!==value.projectId||current.worldId!==value.worldId)throw Error('Foreign current world');}
 return value;
}
export function assertOwnerWorldSelection(value,inventory,id){
 assertOwnerWorldInventory(inventory);
 if(!ownerClosed(value,['schemaVersion','kind','status','currentId','requestedId','selected'])||value.schemaVersion!==1||value.kind!=='owner-world-selection'||value.requestedId!==id||!ownerAlias(id)||!['ready','unavailable'].includes(value.status))throw Error('Invalid private world selection');
 if(value.status==='unavailable'){if(value.selected!==null||value.currentId!==null&&value.currentId!==inventory.currentId)throw Error('Invalid unavailable selection');return value;}
 const row=inventory.projects.find(row=>row.id===id),s=value.selected;
 if(inventory.source!=='launcher-profile'||value.currentId!==inventory.currentId||!row||!ownerClosed(s,['id','name','projectId','worldId','availability','preview','origin','operatorUrl','viewerUrl'])||['id','name','projectId','worldId','preview'].some(key=>s[key]!==row[key])||s.availability!=='verified'||typeof s.origin!=='string'||!/^http:\/\/127\.0\.0\.1:[1-9]\d{0,4}$/.test(s.origin))throw Error('Foreign private world selection');
 const origin=new URL(s.origin);if(origin.origin!==s.origin||Number(origin.port)>65535||s.operatorUrl!==s.origin+'/?project='+encodeURIComponent(row.projectId)||s.viewerUrl!==s.origin+'/world/view?project='+encodeURIComponent(row.worldId))throw Error('Foreign private world link');
 return value;
}
export async function readOwnerWorldJSON(response){
 if(!response.ok||!/^application\/json(?:;|$)/i.test(response.headers.get('content-type')||''))throw Error('World inventory unavailable');
 const reader=response.body.getReader(),chunks=[];let length=0;
 try{while(true){const next=await reader.read();if(next.done)break;length+=next.value.byteLength;if(length>65536){await reader.cancel();throw Error('World inventory limit');}chunks.push(next.value);}}
 finally{reader.releaseLock();}
 const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
export function createOwnerWorldSelection({inventory,request,navigate,onState=()=>{}}){
 assertOwnerWorldInventory(inventory);let generation=0,controller=null,disposed=false;
 function cancel(){generation++;controller?.abort();controller=null;}
 return{cancel,dispose(){cancel();disposed=true;},async select(id){
  cancel();const row=inventory.projects.find(row=>row.id===id);if(disposed||!row)return false;
  if(id===inventory.currentId){onState(id,'current');return true;}
  const turn=generation,active=new AbortController();controller=active;const current=()=>!disposed&&turn===generation&&!active.signal.aborted;
  onState(id,'checking');
  try{
   const data=await request({id,projectId:inventory.projectId,signal:active.signal});
   if(!current())return false;const selected=assertOwnerWorldSelection(data,inventory,id);
   if(selected.status!=='ready'){onState(id,'unavailable');return false;}
   onState(id,'verified');if(!current())return false;navigate(selected.selected.operatorUrl);return true;
  }catch{if(current())onState(id,'unavailable');return false;}
  finally{if(controller===active)controller=null;}
 }};
}

export function createOwnerPlanetViews({inventory,request,mount,onState=()=>{},limit=4}){
 assertOwnerWorldInventory(inventory);
 if(!Number.isInteger(limit)||limit<1||limit>4)throw Error('Invalid preview concurrency');
 const entries=new Map(inventory.projects.map(row=>[row.id,{row,visible:false,attempted:false,revision:0,controller:null,cleanup:null}]));
 let active=0,disposed=false;
 function pump(){
  if(disposed)return;
  for(const e of entries.values()){
   if(active>=limit)break;
   if(!e.visible||e.attempted||e.controller||e.cleanup)continue;
   e.attempted=true;const controller=new AbortController(),revision=e.revision;e.controller=controller;active++;
   const current=()=>!disposed&&e.visible&&e.revision===revision&&!controller.signal.aborted;
   onState(e.row.id,'checking');
   void(async()=>{try{
    const answer=await request({id:e.row.id,projectId:inventory.projectId,signal:controller.signal});
    if(!current())return;
    const result=assertOwnerWorldSelection(answer,inventory,e.row.id);
    if(result.status!=='ready'){onState(e.row.id,'unavailable');return;}
    const cleanup=mount(e.row,result.selected);
    if(typeof cleanup!=='function')throw Error('Preview cleanup required');
    if(!current()){cleanup();return;}e.cleanup=cleanup;onState(e.row.id,'ready');
   }catch{if(current())onState(e.row.id,'unavailable');}
   finally{if(e.controller===controller)e.controller=null;active--;pump();}})();
  }
 }
 function setVisible(id,value){const e=entries.get(id);if(disposed||!e||e.visible===(value===true))return;e.visible=value===true;e.revision++;
  if(!e.visible){e.controller?.abort();e.cleanup?.();e.cleanup=null;onState(id,'paused');}
  else e.attempted=false;
  pump();
 }
 return{setVisible,dispose(){if(disposed)return;disposed=true;for(const e of entries.values()){e.revision++;e.controller?.abort();e.cleanup?.();e.cleanup=null;}},};
}
