import {assertProjectWorldAppearance} from './project-world-presentation.mjs';

const descriptorKeys=['schemaVersion','bundleId','worldVersion','artifactSha256'];
const descriptor=value=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===descriptorKeys.length&&descriptorKeys.every(k=>Object.hasOwn(value,k))&&value.schemaVersion===1&&typeof value.bundleId==='string'&&/^[a-z][a-z0-9-]{0,79}$/.test(value.bundleId)&&typeof value.worldVersion==='string'&&/^\d+\.\d+\.\d+$/.test(value.worldVersion)&&typeof value.artifactSha256==='string'&&/^[a-f0-9]{64}$/.test(value.artifactSha256);
const same=(a,b)=>descriptor(a)&&descriptor(b)&&descriptorKeys.every(k=>a[k]===b[k]);
const woodland=assertProjectWorldAppearance({schemaVersion:1,kind:'project-world-style',source:'qualified-scene',material:'soil',motif:'pines',palette:{sky:'#172d3c',ground:'#524a35',foliage:'#52684a',trim:'#b8ab7d',accent:'#78a5a0'}});

// Caller supplies its existing qualified helper's compiled descriptor and its
// successful ownerWorldInput result. No catalog extension or additional read.
export function qualifiedProjectWorldAppearance({project,catalog,catalogState='unavailable',preview,joined,approvedRenderer}={}){
 if(catalogState!=='current'||!catalog||catalog.kind!=='owner-world-catalog'||catalog.schemaVersion!==1||catalog.sourceState!=='current'||!project||project.id!==catalog.currentId||!Array.isArray(catalog.worlds))return null;
 const registered=catalog.worlds.find(row=>row.id===project.id);
 if(!registered||registered.name!==project.name||preview?.schemaVersion!==3||preview.kind!=='owner-world-preview'||preview.worldId!==catalog.worldId||preview.snapshot?.world?.id!==catalog.worldId||!same(preview.renderer,approvedRenderer))return null;
 if(!joined||joined.snapshot!==preview.snapshot||joined.metadataMarker?.worldId!==catalog.worldId||joined.metadataMarker.artifactSha256!==approvedRenderer.artifactSha256)return null;
 return woodland;
}
