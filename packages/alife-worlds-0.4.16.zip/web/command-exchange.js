(function(root){
 "use strict";
 function create(context,env={}){
  const fetcher=env.fetch||root.fetch?.bind(root),origin=env.origin||root.location?.origin,now=env.now||Date.now;let sequence=0;
  const valid=c=>c?.version===1&&c.origin===origin&&c.endpoint==='/api/ant-farm-command'&&/^[a-f0-9]{32}$/.test(c.session||'')&&/^[a-f0-9]{64}$/.test(c.csrf||'')&&Date.parse(c.expiresUtc)>now()&&typeof fetcher==='function';
  async function reconnect(){if(typeof fetcher!=='function')return false;try{const r=await fetcher('/operator',{method:'GET',mode:'same-origin',credentials:'omit',redirect:'error',cache:'no-store',signal:root.AbortSignal?.timeout(15000)});if(r.ok===false)return false;const html=await r.text();if(html.length>4194304)return false;const match=html.match(/JSON\.parse\('([^'\r\n]*"endpoint":"\/api\/ant-farm-command"[^'\r\n]*)'\)/);if(!match)return false;const fresh=JSON.parse(match[1]);if(!valid(fresh))return false;context=fresh;sequence=0;return true;}catch{return false;}}
  async function post(request){return fetcher('/api/ant-farm-command',{method:'POST',mode:'same-origin',credentials:'omit',redirect:'error',cache:'no-store',headers:{'Content-Type':'application/json','X-Farm-Session':context.session,'X-Farm-CSRF':context.csrf,'X-Farm-Sequence':String(++sequence)},body:JSON.stringify(request),signal:root.AbortSignal?.timeout(15000)});}
  return{async sendAction(request){if(!['unblock','wake','retire'].includes(request?.action))throw Error('Unknown Farm action');if(!valid(context)&&!await reconnect())return{state:'unavailable',message:'Refresh the Farm page to reconnect. No request was sent.'};let response=await post(request);
   // An authentication refusal occurs before effect reservation. Refresh only this known no-effect case,once,using the same request ID. Never replay an unknown POST.
   if(response.status===403){if(!await reconnect())return{state:'unavailable',message:'The Farm page connection expired. Refresh the page;no request was sent.'};response=await post(request);}
   const v=await response.json();if(!['sent','failed','busy','unavailable','unknown','pending','queued'].includes(v?.state))throw Error('Command delivery status unknown');return{state:v.state,message:v.state==='unavailable'?'The project command connector is disconnected. No request was sent.':String(v.message||'').slice(0,180),requestId:v.requestId||request.requestId,staleAction:v.staleAction===true,knownNoDispatch:v.knownNoDispatch===true};}};
 }
 if(typeof module==='object'&&module.exports)module.exports={create};else root.FarmCommandBrowserExchange=Object.freeze({create});
})(typeof globalThis!=='undefined'?globalThis:this);
