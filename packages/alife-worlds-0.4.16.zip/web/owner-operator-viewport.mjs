// This module is compiled with the generic join/recovery/bridge helpers by the
// owner-site resource builder. Server-authored context supplies identity.
export function ownerOperatorContext(value,{windowRef=window}={}){
 const q=new URLSearchParams(windowRef.location.search);
 if(!value||value.access!=='local-owner'||windowRef.parent===windowRef||q.get('worldViewport')!=='1'||q.has('project')||q.get('worldId')!==value.worldId||q.get('hostOrigin')!==value.ownerOrigin||value.ownerOrigin!==windowRef.location.origin)return null;
 return value;
}
export function createOwnerOperatorViewport({farm,context,windowRef=window,documentRef=document,now=Date.now,onRendered=()=>{},pinnedFrame=false}={}){
 if(!farm?.host||!context||context.ownerOrigin!==windowRef.location.origin)throw Error('Configured owned renderer required');
 if(typeof onRendered!=='function')throw Error('Rendered observer must be a function');
 if(typeof pinnedFrame!=='boolean')throw Error('Explicit pinned-frame option required');
 const main=documentRef.querySelector('main'),controls=farm.host.querySelector('.ag-controls'),range=controls?.querySelector('input[type=range]'),pause=controls?.querySelector('.ag-pause-toggle');
 if(!main||!controls||!pause)throw Error('Existing world controls required');
 documentRef.documentElement.classList.add('alife-owned-viewport');farm.host.classList.add('alife-owned-world');
 const css=documentRef.createElement('link');css.rel='stylesheet';css.href='/owner-world-viewport.css';documentRef.head.append(css);
 const kept=new Set([farm.host,documentRef.getElementById('world-anchor'),documentRef.getElementById('world-profile-status')]);
 const operations=[...main.children].filter(n=>!kept.has(n)).map(node=>{const marker=documentRef.createComment('owned viewport operation');node.before(marker);node.remove();return{node,marker};});
 const status=documentRef.createElement('p');status.className='owner-frame-status';status.setAttribute('role','status');farm.host.append(status);
 // Release identity comes from this page's validated selected-world context, never its renderer/build descriptor.
 farm.setWorldVersion?.(context.worldVersion);
 const mode=documentRef.createElement('select');mode.className='ag-website-mode';mode.setAttribute('aria-label','World presentation');
 for(const value of ['public','private','view']){const option=documentRef.createElement('option');option.value=value;option.textContent=value[0].toUpperCase()+value.slice(1);mode.append(option);}mode.value='view';controls.prepend(mode);
 let disposed=false,last=null,lastPreview=null,pending=null,pendingPreview=null,metadata=null,available=false;
 const send=(type,extra={})=>{if(!disposed)windowRef.parent.postMessage({type,worldId:context.worldId,...extra},context.ownerOrigin);};
 const bridge=context.renderer?createOwnerProjectPreviewBridge({worldId:context.worldId,renderer:context.renderer,parentOrigin:context.ownerOrigin,windowRef,now}):null;
 const join=context.renderer?createOwnerPreviewJoin(context.renderer):null;
 const state=()=>{const audio=farm.audio.state();return{mode:farm.host.dataset.mode,paused:pause.getAttribute('aria-pressed')==='true',volume:Number.isFinite(audio?.volume)?audio.volume:range?Number(range.value)/100:1,soundEnabled:audio?.enabled===true};};
 const sendState=()=>send('alife-world-state',{...state(),fullscreen:farm.host.dataset.fullscreen==='true'});
 function applyControls(value){
  if(disposed||!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==3||!['mode','paused','volume'].every(key=>Object.hasOwn(value,key))||!['public','private','view'].includes(value.mode)||typeof value.paused!=='boolean'||typeof value.volume!=='number'||!Number.isFinite(value.volume)||value.volume<0||value.volume>1||!['setPresentationMode','setPaused','setVolume'].every(key=>typeof farm[key]==='function'))return null;
  try{farm.setPresentationMode(value.mode);const paused=farm.setPaused(value.paused),volume=farm.setVolume(value.volume);const applied=state();mode.value=applied.mode;if(paused!==value.paused||volume!==value.volume||applied.mode!==value.mode||applied.paused!==value.paused||applied.volume!==value.volume)return null;if(last)annotateOwnerModelContext(farm.host,last.model,{available,operator:true});sendState();return applied;}catch{return null;}
 }
 // The pinned client owns recovery and correlated preferences for its lifetime.
 // It must not consume legacy session recovery state or expose manual reload UI.
 const recovery=context.renderer&&!pinnedFrame?createOwnerFeedRecovery({worldId:context.worldId,current:context.renderer,status,documentRef,capture:state,restore:v=>{farm.setAudioPreferenceKey?.(context.worldId);return applyControls({mode:v.mode,paused:v.paused,volume:v.volume});},canAutoReload:()=>!documentRef.fullscreenElement&&!farm.audio.state()?.enabled&&!documentRef.querySelector(':active')&&!documentRef.activeElement?.matches('input,select,textarea,[contenteditable=true]')}):null;
 function unavailable(){if(disposed)return;available=false;lastPreview=null;pending=null;pendingPreview=null;bridge?.unavailable();recovery?.unavailable({hasSnapshot:!!last});if(last)annotateOwnerModelContext(farm.host,last.model,{available:false,operator:true});}
 function modeChanged(){send('alife-operator-mode-request',{mode:mode.value});}
 function fullscreen(event){send('alife-world-fullscreen',{active:event.detail?.active===true});sendState();}
 function message(event){
  const data=event.data;if(disposed||event.source!==windowRef.parent||event.origin!==context.ownerOrigin||data?.worldId!==context.worldId)return;
  if((data.type==='alife-website-context'||data.type==='alife-world-mode')&&['public','private','view'].includes(data.mode)){
   farm.setPresentationMode(data.mode);mode.value=data.mode;if(last)annotateOwnerModelContext(farm.host,last.model,{available,operator:true});
   if(data.type==='alife-website-context'&&data.websiteVersion===context.websiteVersion)send('alife-website-toolbar-ready',{websiteVersion:context.websiteVersion});sendState();
  }
 }
 mode.addEventListener('change',modeChanged);controls.addEventListener('input',sendState);controls.addEventListener('click',sendState);farm.host.addEventListener('alife-sound',sendState);farm.host.addEventListener('alife-fullscreen',fullscreen);windowRef.addEventListener('message',message);
 function dispose(){if(disposed)return;disposed=true;available=false;last=null;lastPreview=null;pending=null;pendingPreview=null;metadata=null;bridge?.dispose();windowRef.removeEventListener('message',message);windowRef.removeEventListener('pagehide',dispose);mode.removeEventListener('change',modeChanged);controls.removeEventListener('input',sendState);controls.removeEventListener('click',sendState);farm.host.removeEventListener('alife-sound',sendState);farm.host.removeEventListener('alife-fullscreen',fullscreen);for(const {node,marker}of operations){if(marker.isConnected)marker.after(node);marker.remove();}mode.remove();farm.setWorldVersion?.(null);css.remove();status.remove();documentRef.documentElement.classList.remove('alife-owned-viewport');farm.host.classList.remove('alife-owned-world');}
 windowRef.addEventListener('pagehide',dispose,{once:true});
 return Object.freeze({
  projectId:()=>null,acceptProject(){},dispose,cachedInput:()=>last,applyControls,controlsState:()=>disposed?null:state(),renderReceipt:()=>!disposed&&available&&lastPreview&&last?{preview:lastPreview,joined:last}:null,
  async resolve(preview){if(disposed)return null;send('alife-world-controls-ready');pending=null;pendingPreview=null;if(!join||!preview){unavailable();return null;}if(recovery?.consider(preview)){unavailable();return null;}try{const input=await join.ownerWorldInput(preview,{expectedWorldId:context.worldId,previousMetadata:metadata,now:now()});if(disposed)return null;pending=input;pendingPreview=preview;return input;}catch{unavailable();return null;}},
  rendered(input){if(disposed)return false;if(!input||input!==pending){unavailable();return false;}const preview=pendingPreview;last=input;metadata=input.metadataMarker;pending=null;pendingPreview=null;available=!input.feed.error;annotateOwnerModelContext(farm.host,input.model,{available,operator:true});if(!available){unavailable();return false;}recovery?.current();if(!bridge?.publish(preview,input)){unavailable();return false;}lastPreview=preview;send('alife-world-ready',{renderBuild:farm.host.dataset.renderBuild});sendState();onRendered(preview,input);return true;},
  unavailable
 });
}
