const familyNames=Object.freeze(['Astra','Sol 6.1','Sol 6','Terra','Luna','Unrecognized family']);
export function ownerModelContext(agent){
 const last=agent.modelMetadataState==='stale'?' (last verified)':'',applied=agent.appliedModelToken===null?'Unknown':familyNames[agent.appliedModelToken];
 const selected=agent.selectedModelSource==='native-index-selection'?'Selected: '+(agent.selectedModelState==='unknown'?'Unknown':familyNames[agent.localAppearance.token])+(agent.selectedModelState==='stale'?' (last verified)':''):'Selection: not observed';
 return selected+' · Last applied: '+applied+last+(agent.modelPresentationSource==='applied-model'?' · Showing applied-family fallback.':agent.modelPresentationSource==='unknown'?' · Showing Unknown.':'');
}
const ownerTitleBases=new WeakMap(),ownerKeyBases=new WeakMap();
export function annotateOwnerModelContext(host,model,{available=true,operator=true}={}){
 const allowed=operator&&host.dataset.mode!=='view',byId=new Map((model?.agents||[]).map(a=>[a.threadId,a]));
 for(const node of host.querySelectorAll('.ag-agent[data-agent-id]')){if(!ownerTitleBases.has(node))ownerTitleBases.set(node,{title:node.title,aria:node.getAttribute('aria-label')});const original=ownerTitleBases.get(node),agent=byId.get(node.dataset.agentId);if(!allowed||!agent){node.title=original.title;if(original.aria!==null)node.setAttribute('aria-label',original.aria);continue;}const context=(available?'':'Last snapshot · ')+ownerModelContext(agent);node.title=original.title+' · '+context;node.setAttribute('aria-label',(original.aria||original.title)+' · '+context);}
 const note=host.querySelector('.ag-ant-key-panel > p');if(note){if(!ownerKeyBases.has(note))ownerKeyBases.set(note,note.textContent);note.textContent=allowed?'Color and size follow a verified Codex model selection. Before a selection is observed, applied-family fallback is explicit. Last applied describes the previous turn evidence. Unknown selections appear gray.':ownerKeyBases.get(note);}
}
