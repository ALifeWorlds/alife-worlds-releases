import './audio.mjs';
await import('./agent-outpost/colony-art.js').catch(()=>{});
import './agent-outpost/agent-outpost.js';
const main=document.getElementById('world-showcase'),query=new URLSearchParams(location.search),embedded=query.get('embedded')==='planet',expected=main.dataset.world||query.get('project'),source=new URL(main.dataset.source,document.baseURI);
if(main.dataset.world&&query.get('project')&&main.dataset.world!==query.get('project'))throw Error('World identity mismatch');
if(source.origin!==location.origin)throw Error('A same-origin public display source is required.');
if(expected&&source.pathname.startsWith('/api/'))source.searchParams.set('project',expected);
function httpOrigin(value){try{const u=new URL(value);return ['http:','https:'].includes(u.protocol)?u.origin:null;}catch{return null;}}
const soundHost=httpOrigin(query.get('soundHost')),parentOrigin=httpOrigin(query.get('hostOrigin'))||httpOrigin(document.referrer),operatorPresentation=main.dataset.operatorPresentation==='true'&&!embedded;
const farm=globalThis.AgentOutpost.mount(document.getElementById('world-anchor'),{roomLabelPlacement:'below-room',modelKey:false,cosmeticOnly:true,operatorPresentation,presentationMode:'view',defaultWorld:true,transparentBackground:true,fillViewport:true,publicTitle:'ALife Worlds',...(embedded&&soundHost?{audioBridge:{worldId:expected||'world-current',origin:soundHost}}:{})});
// View remains cosmetic-only. Explicit owner operator presentation may inspect sanitized
// room data and show disabled contextual controls, but never receives a native command host.
for(const node of main.querySelectorAll('.viewer-progress,#viewer-current,#viewer-epic,#viewer-updated'))node.remove();
main.dataset.embedded=String(embedded);main.dataset.interactions='true';
const controls=farm.host.querySelector('.ag-controls'),range=controls.querySelector('input[type=range]'),pause=controls.querySelector('.ag-pause-toggle');
let last=null,busy=false,disposed=false;
function send(type,extra={}){if(parent===window||!parentOrigin||!last)return;parent.postMessage({type,worldId:last.world.id,...extra},parentOrigin);}
function sendState(){send('alife-world-state',{mode:farm.host.dataset.mode,paused:pause.getAttribute('aria-pressed')==='true',soundEnabled:farm.audio.state()?.enabled===true,volume:range?Number(range.value)/100:1,fullscreen:farm.host.dataset.fullscreen==='true'});}
farm.host.addEventListener('alife-sound',sendState);farm.host.addEventListener('alife-fullscreen',event=>{send('alife-world-fullscreen',{active:event.detail?.active===true});sendState();});controls.addEventListener('input',sendState);controls.addEventListener('click',()=>queueMicrotask(sendState));
async function refresh(){if(busy||document.hidden||disposed)return;busy=true;try{let r=await fetch(source,{cache:'no-store',credentials:'omit'}),fallback=false;if(!r.ok&&!last&&main.dataset.fallback){const u=new URL(main.dataset.fallback,document.baseURI);if(u.origin!==location.origin)throw Error('Invalid display fallback');r=await fetch(u,{cache:'no-store',credentials:'omit'});fallback=true;}if(!r.ok)throw Error('World display unavailable');const next=await r.json();if(fallback)next.feed={...next.feed,error:'World activity unavailable'};if(next.kind!=='read-only-world'||expected&&next.world?.id!==expected||last&&last.world.id!==next.world?.id)throw Error('World identity mismatch');last=next;farm.setAudioPreferenceKey?.(next.world.id);farm.render(next.model,next.feed,{sprint:next.summary?.current,epic:next.summary?.epic});main.dataset.sourceState=next.feed.error?'unavailable':'ready';send('alife-world-ready',{renderBuild:farm.host.dataset.renderBuild});sendState();}catch{main.dataset.sourceState='unavailable';if(last)farm.receiveFeed({...last.feed,error:'World display unavailable'});}finally{busy=false;}}
window.addEventListener('message',event=>{
 if(event.source!==parent)return;
 if(embedded){if(soundHost&&event.origin===soundHost&&event.data?.worldId===expected&&event.data?.type==='alife-sound-state'&&typeof event.data.enabled==='boolean')farm.audio.setExternalEnabled(event.data.enabled);return;}
 if(!parentOrigin||event.origin!==parentOrigin||!last||event.data?.worldId!==last.world.id)return;
 const data=event.data;
 if(data.type==='alife-world-mode'&&['public','private','view'].includes(data.mode)){farm.setPresentationMode(operatorPresentation?data.mode:'view');sendState();}
 if(data.type==='alife-world-control'){
  // Closed cosmetic commands only. The iframe never receives a native command host.
  if(data.action==='pause'&&typeof data.paused==='boolean'&&(pause.getAttribute('aria-pressed')==='true')!==data.paused)pause.click();
  if(data.action==='volume'&&Number.isFinite(data.volume)&&data.volume>=0&&data.volume<=1&&range&&!range.disabled){range.value=String(Math.round(data.volume*100));range.dispatchEvent(new Event('input',{bubbles:true}));}
  if(data.action==='fullscreen')void farm.toggleFullscreen?.();
  sendState();
 }
});
void refresh();const timer=setInterval(()=>void refresh(),5000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)void refresh();});
window.addEventListener('pagehide',()=>{disposed=true;clearInterval(timer);farm.destroy?.();},{once:true});
// The marketing parent owns page scrolling. Browser zoom and direct world drag stay intact.
if(parent!==window&&!embedded&&parentOrigin){
 const relay=deltaY=>{if(Number.isFinite(deltaY))parent.postMessage({type:'alife-farm-scroll',deltaY:Math.max(-800,Math.min(800,deltaY))},parentOrigin);};
 window.addEventListener('wheel',event=>{if(event.ctrlKey||event.metaKey)return;relay(event.deltaY*(event.deltaMode===1?16:event.deltaMode===2?innerHeight:1));if(event.cancelable)event.preventDefault();},{passive:false});
}
