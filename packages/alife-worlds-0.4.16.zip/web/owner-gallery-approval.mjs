import {assertOwnerCandidateFrameContext} from './owner-candidate-readiness.mjs';
import {createOwnerPreviewJoin} from '../lib/owner-preview-join.mjs';

const sameScope=(a,b)=>a!==null&&b!==null&&a.worldKey===b.worldKey&&a.artKey===b.artKey&&a.audienceKey===b.audienceKey;

// The caller independently fetches protected Root contexts and owns release-pair
// membership/current commit. This factory accepts no messages and performs no I/O.
export function createOwnerGalleryApproval({initialRenderer,worldId,access,ownerOrigin}={}){
 const initial=initialRenderer===null?null:createOwnerPreviewJoin(initialRenderer).descriptor;
 let baseline=null;
 function qualify(frameContext,renderer){
  try{return assertOwnerCandidateFrameContext(frameContext,{worldId,access,ownerOrigin,renderer});}
  catch{return null;}
 }
 return Object.freeze({
  establish(frameContext){
   if(initial===null)return false;
   const qualified=qualify(frameContext,initial),scope=qualified?.visualStateScope;
   if(!qualified||scope===null)return false;
   if(baseline!==null)return sameScope(baseline,scope);
   baseline=scope;return true;
  },
  rendererFor(frameContext){
   if(initial===null||baseline===null)return null;
   const qualified=qualify(frameContext,frameContext?.renderer);
   return qualified&&sameScope(baseline,qualified.visualStateScope)?qualified.renderer:null;
  }
 });
}
